const API = '/api/features';
const defaults = () => ({version:1,enabled:false,heading:'',interval:5,accent:'#087f8c',background:'#ffffff',textColor:'#080b0d',mutedColor:'#666666',paddingTop:28,paddingBottom:70,features:[],updatedAt:''});
let config, product, digest='', dirty=false, busy=false, advanced=false, opened=new Set(), notice='', failure=false, root;
function el(tag, props={}, children=[]) {
  const node=document.createElement(tag);
  for(const [key,value] of Object.entries(props)){if(key.startsWith('on'))node.addEventListener(key.slice(2).toLowerCase(),value);else node[key]=value;}
  for(const child of children)node.append(typeof child==='string'?document.createTextNode(child):child);
  return node;
}
const button=(label,click,props={})=>el('s-button',{onClick:click,disabled:busy,...props},[label]);
const stack=(children,props={})=>el('s-stack',{gap:'base',...props},children);
const message=(text,tone='info')=>el('s-banner',{tone},[text]);
function changed(){dirty=true;const b=document.getElementById('wc-features-save');if(b)b.disabled=busy;const t=document.getElementById('wc-features-status');if(t)t.textContent='Unsaved changes';}
function field(tag,label,value,change,props={}) {return el(tag,{label,value,onChange:e=>{change(e.currentTarget.value);changed();},disabled:busy,...props});}
async function api(values) {
  const body=new FormData();for(const [k,v] of Object.entries(values))body.set(k,v);
  const response=await fetch(API,{method:'POST',body});const data=await response.json();if(!data.ok)throw new Error(data.message || 'Request failed.');return data;
}
async function work(fn){busy=true;notice='';render();try{await fn();failure=false;}catch(e){notice=e.message;failure=true;}finally{busy=false;render();}}
async function uploadIcon(item,files){if(!files?.[0])return;await work(async()=>{if(files[0].size>16000)throw new Error('SVG must be smaller than 16 KB.');item.iconSvg=(await api({intent:'icon',svg:await files[0].text()})).icon;changed();});}
async function uploadPhoto(item,files){if(!files?.[0])return;await work(async()=>{let data=await api({intent:'upload',photo:files[0]});for(let i=0;!data.upload.photo && i<30;i++){await new Promise(r=>setTimeout(r,1000));data=await api({intent:'photo-status',id:data.upload.id});}if(!data.upload.photo)throw new Error('Photo is still processing. Select it from Shopify Files shortly.');item.photo=data.upload.photo;changed();});}
async function choosePhoto(item,useFiles){busy=true;render();try{
  let photos=useFiles?(await api({intent:'files'})).files: {nodes:product.images.nodes.map(image=>({image})),pageInfo:{hasNextPage:false}};
  const picker=el('s-section',{heading:'Choose photo'});
  function draw(){picker.replaceChildren(stack([button('Close photo picker',()=>{picker.remove();}),...photos.nodes.filter(n=>n.image).map(n=>button('',()=>{item.photo={...n.image,alt:n.image.alt || ''};changed();render();},{accessibilityLabel:n.image.alt || 'Select photo'}))]));
    const buttons=picker.querySelectorAll('s-button');photos.nodes.filter(n=>n.image).forEach((n,i)=>buttons[i+1].append(el('s-image',{src:n.image.url+(n.image.url.includes('?')?'&':'?')+'width=160',alt:n.image.alt || 'Select photo',inlineSize:'100px',aspectRatio:'1',objectFit:'contain'})));
    if(photos.pageInfo.hasNextPage)picker.append(button('Next page',async()=>{try{photos=(await api({intent:'files',after:photos.pageInfo.endCursor})).files;draw();}catch(e){picker.append(message(e.message,'critical'));}},{disabled:false}));
  }
  busy=false;render();draw();root.append(picker);
}catch(e){notice=e.message;failure=true;busy=false;render();}}
function featurePanel(item,index){
  const expanded=opened.has(item.id), children=[button(`${index+1}. ${item.title || 'New feature'} ${expanded?'▴':'▾'}`,()=>{expanded?opened.delete(item.id):opened.add(item.id);render();},{variant:'tertiary'})];
  if(expanded){children.push(stack([
    field('s-text-field','Title',item.title,v=>item.title=v,{maxLength:100}),
    field('s-text-area','Description',item.description,v=>item.description=v,{maxLength:500,rows:3}),
    el('s-drop-zone',{label:'Upload SVG icon',accept:'.svg,image/svg+xml',disabled:busy,onChange:e=>void uploadIcon(item,e.currentTarget.files)}),
    ...(item.iconSvg?[el('s-text',{},['SVG icon loaded'])]:[]),
    button('Advanced: SVG code',()=>{item.showCode=!item.showCode;render();},{variant:'tertiary'}),
    ...(item.showCode?[field('s-text-area','SVG code',item.iconSvg,v=>item.iconSvg=v,{rows:4,maxLength:16000})]:[]),
    ...(item.photo?[el('s-image',{src:item.photo.url+(item.photo.url.includes('?')?'&':'?')+'width=240',alt:item.photo.alt || item.title || 'Feature photo',inlineSize:'120px',aspectRatio:'3/4',objectFit:'contain'})]:[]),
    el('s-drop-zone',{label:'Upload photo',accept:'image/jpeg,image/png,image/webp',disabled:busy,onChange:e=>void uploadPhoto(item,e.currentTarget.files)}),
    stack([button('Product photos',()=>void choosePhoto(item,false)),button('Shopify Files',()=>void choosePhoto(item,true))],{direction:'inline'}),
    ...(item.photo?[field('s-text-field','Photo alt text',item.photo.alt || '',v=>item.photo.alt=v,{maxLength:200})]:[]),
    stack([button('Move up',()=>move(index,-1),{disabled:busy || index===0}),button('Move down',()=>move(index,1),{disabled:busy || index===config.features.length-1}),button('Remove',()=>{config.features.splice(index,1);changed();render();},{tone:'critical'})],{direction:'inline'}),
  ]));}
  return el('s-section',{},children);
}
function move(i,by){[config.features[i],config.features[i+by]]=[config.features[i+by],config.features[i]];changed();render();}
function render(){
  root=el('s-admin-block',{heading:'Features with Image Slider',collapsedSummary:config?`${config.enabled?'Enabled':'Disabled'} · ${config.features.length} features`:'Loading…'});
  document.body.replaceChildren(root);
  if(!config){root.append(message(notice || 'Loading product settings…',failure?'critical':'info'));return;}
  root.append(stack([
    ...(notice?[message(notice,failure?'critical':'success')]:[]),
    el('s-checkbox',{label:'Enable this block for this product',checked:config.enabled,disabled:busy,onChange:e=>{config.enabled=e.currentTarget.checked;changed();}}),
    field('s-text-area','Main heading',config.heading,v=>config.heading=v,{rows:2,maxLength:200}),
    field('s-number-field','Switch every (seconds)',String(config.interval),v=>config.interval=Number(v),{min:2,max:20,step:1}),
    el('s-paragraph',{color:'subdued'},['Hover pauses autoplay. Clicking a feature selects its photo and stops autoplay.']),
    button('Colors and spacing',()=>{advanced=!advanced;render();},{variant:'tertiary'}),
    ...(advanced?[el('s-section',{heading:'Colors and spacing'},[
      ...[['accent','Accent'],['background','Background'],['textColor','Titles'],['mutedColor','Descriptions']].map(([key,label])=>field('s-color-field',label,config[key],v=>config[key]=v)),
      ...[['paddingTop','Top spacing'],['paddingBottom','Bottom spacing']].map(([key,label])=>field('s-number-field',label,String(config[key]),v=>config[key]=Number(v),{min:0,max:120,step:1})),
    ])]:[]),
    ...config.features.map(featurePanel),
    button(`Add feature (${config.features.length}/10)`,()=>{const item={id:`draft-${Date.now()}`,title:'',description:'',iconSvg:'',photo:null};config.features.push(item);opened.add(item.id);changed();render();},{disabled:busy || config.features.length>=10}),
    stack([button(busy?'Processing…':'Save slider',()=>void work(async()=>{const data=await api({intent:'save',product:product.id,digest,config:JSON.stringify(config)});config=data.selection.config;product=data.selection.product;digest=product.config?.compareDigest || '';dirty=false;notice='Slider saved for this product.';opened.clear();}),{id:'wc-features-save',variant:'primary',disabled:busy || !dirty}),el('s-text',{id:'wc-features-status',color:'subdued'},[dirty?'Unsaved changes':'Saved'])],{direction:'inline'}),
  ]));
}
export default async () => {
  render();try{const id=shopify.data.selected?.[0]?.id;if(!id)throw new Error('Open a saved product to configure its slider.');const response=await fetch(API+'?product='+encodeURIComponent(id));const data=await response.json();if(!data.ok)throw new Error(data.message);product=data.selection.product;digest=product.config?.compareDigest || '';config=data.selection.config || defaults();}catch(e){notice=e.message;failure=true;}render();
};
