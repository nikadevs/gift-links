/*
 * WoodenCrew Apps — Cart Summary (storefront, /cart page only).
 *
 * The theme (Umino) shows one "Subtotal" row that is really cart.total_price
 * (after discount codes), so the discount is invisible. This script puts a
 * clear summary in front of the theme's .totals and hides the theme row:
 *   Subtotal (items_subtotal_price) · Discount (CODE) −x per cart-level discount ·
 *   Shipping FREE (only when the theme's free-shipping bar is reached) ·
 *   Total (total_price) · You save (total_discount) · note.
 * Numbers: first render from Liquid (no request), later from /cart.js whenever the
 * theme or our modules re-render the cart (MutationObserver on .totals and the
 * wc:cart-page-rendered event). Money is formatted like the theme's own `money`
 * filter (sample printed by Liquid). Cart and checkout are never changed.
 */
(function () {
  "use strict";
  var el = document.getElementById("wc-cs");
  if (!el || window.WCCartSummary) return;
  var data;
  try {
    data = JSON.parse(el.textContent || "{}");
  } catch (e) {
    return;
  }
  var L = data.labels || {};
  var ROOT = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
  if (ROOT.charAt(ROOT.length - 1) !== "/") ROOT += "/";
  var rawFetch = window.fetch.bind(window);

  // ---------- money, same format as the theme's `money` filter ----------
  // sample = 123456 cents rendered by Liquid, e.g. "$1,234.56", "€1.234,56", "¥1,235"
  var fmt = (function (s) {
    s = String(s || "$1,234.56");
    var first = s.search(/\d/);
    var last = s.length - 1;
    while (last >= 0 && !/\d/.test(s.charAt(last))) last--;
    if (first < 0) return { pre: "$", suf: "", th: ",", dec: ".", digits: 2 };
    var mid = s.slice(first, last + 1);
    var digitsOnly = mid.replace(/\D/g, "");
    var decimals = digitsOnly === "123456" ? 2 : 0;
    var dec = ".";
    var th = "";
    if (decimals) {
      dec = mid.charAt(mid.length - 3);
      var head = mid.slice(0, mid.length - 3);
      th = head.replace(/\d/g, "").charAt(0) || "";
    } else {
      th = mid.replace(/\d/g, "").charAt(0) || "";
    }
    return { pre: s.slice(0, first), suf: s.slice(last + 1), th: th, dec: dec, digits: decimals };
  })(data.sample);

  function money(cents) {
    var v = Math.round(Number(cents) || 0);
    var neg = v < 0;
    v = Math.abs(v);
    var whole, frac;
    if (fmt.digits) {
      whole = String(Math.floor(v / 100));
      frac = String(v % 100);
      if (frac.length < 2) frac = "0" + frac;
    } else {
      whole = String(Math.round(v / 100));
    }
    if (fmt.th) whole = whole.replace(/\B(?=(\d{3})+(?!\d))/g, fmt.th);
    return (neg ? "-" : "") + fmt.pre + whole + (fmt.digits ? fmt.dec + frac : "") + fmt.suf;
  }

  function esc(s) {
    return String(s == null ? "" : s)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/"/g, "&quot;");
  }

  function freeShipping() {
    var bar = document.querySelector("free-ship-progress-bar");
    return !!(bar && bar.classList.contains("cart_shipping_free"));
  }

  function rowsHtml(cart) {
    var h = "";
    var row = function (cls, label, value) {
      return '<div class="wc-cs-row ' + cls + '"><span>' + label + "</span><span>" + value + "</span></div>";
    };
    h += row("wc-cs-sub", esc(L.subtotal || "Subtotal"), esc(money(cart.items_subtotal_price)));
    var ds = cart.cart_level_discount_applications || [];
    for (var i = 0; i < ds.length; i++) {
      var amt = Number(ds[i].total_allocated_amount) || 0;
      if (!amt) continue;
      var t = ds[i].title ? " (" + ds[i].title + ")" : "";
      h += row("wc-cs-disc", esc((L.discount || "Discount") + t), "&minus;" + esc(money(amt)));
    }
    if (freeShipping()) h += row("wc-cs-ship", esc(L.shipping || "Shipping"), '<b>' + esc(L.free || "FREE") + "</b>");
    h += row("wc-cs-total", esc(L.total || "Total"), esc(money(cart.total_price)));
    var save = Number(cart.total_discount) || 0;
    if (L.savings && save > 0) h += row("wc-cs-save", esc(L.savings), esc(money(save)));
    if (L.note) h += '<p class="wc-cs-note">' + esc(L.note) + "</p>";
    return h;
  }

  var box = null;
  var last = "";
  function render(cart) {
    var totals = document.querySelector(".cart__blocks .totals") || document.querySelector(".cart__footer .totals");
    if (!totals || !cart || !(cart.item_count > 0)) {
      if (box && box.parentNode) box.parentNode.removeChild(box);
      document.documentElement.classList.remove("wc-cs-ready");
      return;
    }
    if (!box || !box.isConnected) {
      box = document.createElement("div");
      box.className = "wc-cs";
      box.setAttribute("aria-live", "polite");
      last = "";
    }
    if (box.nextSibling !== totals) totals.parentNode.insertBefore(box, totals);
    var html = rowsHtml(cart);
    if (html !== last) {
      box.innerHTML = html;
      last = html;
    }
    document.documentElement.classList.add("wc-cs-ready");
  }

  var timer = null;
  var seq = 0;
  function refetch() {
    clearTimeout(timer);
    timer = setTimeout(function () {
      var my = ++seq;
      rawFetch(ROOT + "cart.js", { credentials: "same-origin", headers: { Accept: "application/json" } })
        .then(function (r) {
          return r.json();
        })
        .then(function (cart) {
          if (my === seq) render(cart);
        })
        .catch(function () {});
    }, 150);
  }

  // first paint: numbers from Liquid, no request
  render(data.cart || {});

  // the theme rewrites .totals after every quantity change / remove / our re-render
  var watched = null;
  var mo = window.MutationObserver
    ? new MutationObserver(function () {
        refetch();
        watch();
      })
    : null;
  function watch() {
    var t = document.querySelector(".cart__blocks .totals") || document.querySelector(".cart__footer .totals");
    if (!mo || !t || t === watched) return;
    if (watched) mo.disconnect();
    watched = t;
    mo.observe(t, { childList: true, subtree: true, characterData: true });
    var wrap = document.getElementById("main-cart-items");
    if (wrap) mo.observe(wrap, { childList: true }); // empty ↔ not empty swaps the wrapper
  }
  watch();
  document.addEventListener("wc:cart-page-rendered", function (e) {
    watch();
    if (e && e.detail && e.detail.cart) render(e.detail.cart);
    else refetch();
  });
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) refetch();
  });

  window.WCCartSummary = { render: render, refetch: refetch, money: money };
})();
