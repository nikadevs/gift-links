(() => {
  if (customElements.get('wc-features-image-slider')) return;
  class FeaturesImageSlider extends HTMLElement {
    connectedCallback() {
      this.buttons = [...this.querySelectorAll('.wc-fi-item')];
      this.photos = [...this.querySelectorAll('.wc-fi-photo')];
      if (!this.buttons.length || this.buttons.length !== this.photos.length) return;
      this.index = 0; this.locked = false; this.hovered = false; this.focused = false; this.visible = false;
      this.abort = new AbortController(); const options = { signal: this.abort.signal };
      this.motion = window.matchMedia('(prefers-reduced-motion: reduce)');
      this.interval = Math.max(2, Math.min(20, Number(this.dataset.interval) || 5)) * 1000;
      this.select(0);
      this.addEventListener('pointerenter', e => { if(e.pointerType !== 'touch') { this.hovered = true; this.schedule(); } }, options);
      this.addEventListener('pointerleave', () => {this.hovered = false; this.schedule();}, options);
      this.addEventListener('focusin', () => {this.focused = true; this.schedule();}, options);
      this.addEventListener('focusout', e => {if(!this.contains(e.relatedTarget)) {this.focused = false; this.schedule();}}, options);
      this.addEventListener('click', e => {const button = e.target.closest('.wc-fi-item');const i = this.buttons.indexOf(button);if(i >= 0){this.locked = true;this.select(i);this.schedule();}}, options);
      document.addEventListener('visibilitychange', () => this.schedule(), options);
      this.motion.addEventListener('change', () => this.schedule(), options);
      if ('IntersectionObserver' in window) {this.observer = new IntersectionObserver(entries => {this.visible = entries[0].isIntersecting;this.schedule();},{rootMargin:'80px'});this.observer.observe(this);} else {this.visible = true;this.schedule();}
    }
    pause() {clearTimeout(this.timer);if(this.running)this.remaining=Math.max(0,this.remaining-(Date.now()-this.startedAt));this.running=false;this.animation?.pause();}
    select(index) {this.pause();this.animation?.cancel();this.remaining=this.interval;this.index=index;this.buttons.forEach((b,i)=>b.setAttribute('aria-pressed',String(i===index)));this.photos.forEach((p,i)=>{p.hidden=i!==index;});const fill=this.buttons[index].querySelector?.('.wc-fi-progress-fill');this.animation=fill?.animate?.([{transform:'scaleX(0)'},{transform:'scaleX(1)'}],{duration:this.interval,easing:'linear',fill:'forwards'});this.animation?.pause();if(this.locked || this.motion?.matches || this.buttons.length<2)this.animation?.finish();}
    schedule() {this.pause();if(this.buttons.length<2 || this.locked || this.hovered || this.focused || !this.visible || document.hidden || this.motion.matches || window.Shopify?.designMode) return;this.remaining??=this.interval;this.startedAt=Date.now();this.running=true;this.animation?.play();this.timer=setTimeout(()=>{this.running=false;this.select((this.index+1)%this.buttons.length);this.schedule();},this.remaining);}
    disconnectedCallback() {this.pause();this.animation?.cancel();this.abort?.abort();this.observer?.disconnect();}
  }
  customElements.define('wc-features-image-slider', FeaturesImageSlider);
})();
