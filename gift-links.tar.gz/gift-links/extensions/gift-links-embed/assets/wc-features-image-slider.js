(() => {
  if (customElements.get('wc-features-image-slider')) return;
  class FeaturesImageSlider extends HTMLElement {
    connectedCallback() {
      this.buttons = [...this.querySelectorAll('.wc-fi-item')];
      this.photos = [...this.querySelectorAll('.wc-fi-photo')];
      if (!this.buttons.length || this.buttons.length !== this.photos.length) return;
      this.index = 0; this.locked = false; this.hovered = false; this.focused = false; this.visible = false;
      this.abort = new AbortController(); const options = { signal: this.abort.signal };
      this.motion = window.matchMedia('(prefers-reduced-motion: reduce)');
      this.interval = Math.max(2, Math.min(20, Number(this.dataset.interval) || 5)) * 1000;
      this.addEventListener('pointerenter', e => { if(e.pointerType !== 'touch') { this.hovered = true; this.schedule(); } }, options);
      this.addEventListener('pointerleave', () => {this.hovered = false; this.schedule();}, options);
      this.addEventListener('focusin', () => {this.focused = true; this.schedule();}, options);
      this.addEventListener('focusout', e => {if(!this.contains(e.relatedTarget)) {this.focused = false; this.schedule();}}, options);
      this.addEventListener('click', e => {const button = e.target.closest('.wc-fi-item');const i = this.buttons.indexOf(button);if(i >= 0){this.locked = true;this.select(i);this.schedule();}}, options);
      document.addEventListener('visibilitychange', () => this.schedule(), options);
      this.motion.addEventListener('change', () => this.schedule(), options);
      if ('IntersectionObserver' in window) {this.observer = new IntersectionObserver(entries => {this.visible = entries[0].isIntersecting;this.schedule();},{rootMargin:'80px'});this.observer.observe(this);} else {this.visible = true;this.schedule();}
    }
    select(index) {this.index = index;this.buttons.forEach((b,i)=>b.setAttribute('aria-pressed',String(i===index)));this.photos.forEach((p,i)=>{p.hidden=i!==index;});}
    schedule() {clearTimeout(this.timer);if(this.buttons.length<2 || this.locked || this.hovered || this.focused || !this.visible || document.hidden || this.motion.matches || window.Shopify?.designMode) return;this.timer=setTimeout(()=>{this.select((this.index+1)%this.buttons.length);this.schedule();},this.interval);}
    disconnectedCallback() {clearTimeout(this.timer);this.abort?.abort();this.observer?.disconnect();}
  }
  customElements.define('wc-features-image-slider', FeaturesImageSlider);
})();
