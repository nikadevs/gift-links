/*!
 * WoodenCrew Apps — Checkbox Upsell (theme app embed)
 *
 * 1. Moves the server-rendered list (#wcu-root) next to the Add to cart button
 *    of this product's form.
 * 2. When the theme adds THIS product to the cart (fetch to /cart/add[.js]),
 *    the ticked upsells are added in the SAME request (items[]), so the cart
 *    drawer the theme renders already contains them.
 * 3. Upsell lines carry hidden properties _wc_upsell / _wc_upsell_for.
 *    Nothing else in the cart is ever touched (bundle $0 lines, PDF Travel Book,
 *    Gift Links gifts stay as they are).
 */
(function () {
  "use strict";

  var root = document.getElementById("wcu-root");
  if (!root || window.__wcUpsellLoaded) return;
  window.__wcUpsellLoaded = true;

  var DEBUG = root.getAttribute("data-debug") === "true";
  var ROOT = (root.getAttribute("data-root") || "/").replace(/\/?$/, "/");
  var HANDLE = root.getAttribute("data-product-handle") || "";
  var SELECTOR =
    root.getAttribute("data-selector") ||
    "form[action*='/cart/add'] button[type='submit'][name='add']";
  var POSITION = root.getAttribute("data-position") === "after" ? "after" : "before";
  var VARIANTS = {};
  (root.getAttribute("data-variants") || "").split(",").forEach(function (v) {
    if (v) VARIANTS[String(Number(v))] = true;
  });
  var ADD_RE = /\/cart\/add(\.js)?\/?$/;

  function log() {
    if (DEBUG && window.console)
      console.log.apply(
        console,
        ["[WC Upsell]"].concat([].slice.call(arguments)),
      );
  }

  // ---------- placement ----------
  function formVariant(form) {
    var el = form && form.querySelector('[name="id"]');
    return el ? String(Number(el.value)) : "";
  }
  function findAnchor() {
    var list;
    try {
      list = document.querySelectorAll(SELECTOR);
    } catch (e) {
      log("bad selector", SELECTOR);
      return null;
    }
    var fallback = null;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === root || root.contains(el)) continue;
      var form = el.closest ? el.closest("form") : null;
      if (form && VARIANTS[formVariant(form)]) return el;
      if (!fallback) fallback = el;
    }
    return fallback;
  }
  var mounted = false;
  function mount() {
    if (mounted) return true;
    var anchor = findAnchor();
    if (!anchor || !anchor.parentNode) return false;
    if (POSITION === "after") anchor.parentNode.insertBefore(root, anchor.nextSibling);
    else anchor.parentNode.insertBefore(root, anchor);
    root.hidden = false;
    mounted = true;
    log("mounted", POSITION, anchor);
    return true;
  }
  if (!mount()) {
    var obs = new MutationObserver(function () {
      if (mount()) obs.disconnect();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function () {
      obs.disconnect();
    }, 15000);
  }

  // ---------- ⓘ info popup ----------
  var modal = null;
  function closeInfo() {
    if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
    modal = null;
    document.removeEventListener("keydown", onKey);
  }
  function onKey(e) {
    if (e.key === "Escape") closeInfo();
  }
  function openInfo(text) {
    closeInfo();
    modal = document.createElement("div");
    modal.className = "wcu-modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    var box = document.createElement("div");
    box.className = "wcu-modal-box";
    var p = document.createElement("p");
    p.className = "wcu-modal-text";
    p.textContent = text; // plain text only — never HTML
    var x = document.createElement("button");
    x.type = "button";
    x.className = "wcu-modal-close";
    x.setAttribute("aria-label", "Close");
    x.textContent = "\u2715";
    box.appendChild(x);
    box.appendChild(p);
    modal.appendChild(box);
    modal.addEventListener("click", function (e) {
      if (e.target === modal || e.target === x) closeInfo();
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(modal);
    x.focus();
  }
  root.addEventListener("click", function (e) {
    var btn = e.target && e.target.closest ? e.target.closest(".wcu-info") : null;
    if (!btn) return;
    e.preventDefault(); // don't toggle the checkbox / submit the form
    e.stopPropagation();
    openInfo(btn.getAttribute("data-info") || "");
  });

  // ---------- what is ticked ----------
  function selected(mainQty) {
    var out = [];
    var items = root.querySelectorAll(".wcu-item");
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var input = it.querySelector(".wcu-input");
      if (!input || !input.checked) continue;
      out.push({
        offer: it.getAttribute("data-offer") || "",
        id: Number(it.getAttribute("data-variant")),
        quantity: it.getAttribute("data-qty") === "match" ? mainQty : 1,
        once: it.getAttribute("data-once") === "true",
      });
    }
    return out;
  }
  function upsellLine(u) {
    return {
      id: u.id,
      quantity: u.quantity,
      properties: { _wc_upsell: u.offer, _wc_upsell_for: HANDLE },
    };
  }

  // ---------- read the theme's add-to-cart request ----------
  function pathOf(url) {
    try {
      return new URL(url, window.location.href).pathname;
    } catch (e) {
      return String(url || "").split("?")[0];
    }
  }
  /** Returns {main, extra, hasFile} or null when the request isn't a single add of THIS product. */
  function parseAdd(body) {
    var main = { properties: {} };
    var extra = {};
    var hasFile = false;
    var pairs = null;

    if (typeof FormData !== "undefined" && body instanceof FormData) {
      pairs = [];
      body.forEach(function (v, k) {
        if (typeof v !== "string") hasFile = true;
        pairs.push([k, v]);
      });
    } else if (
      typeof URLSearchParams !== "undefined" &&
      body instanceof URLSearchParams
    ) {
      pairs = [];
      body.forEach(function (v, k) {
        pairs.push([k, v]);
      });
    } else if (typeof body === "string") {
      var obj = null;
      try {
        obj = JSON.parse(body);
      } catch (e) {
        pairs = [];
        new URLSearchParams(body).forEach(function (v, k) {
          pairs.push([k, v]);
        });
      }
      if (obj && typeof obj === "object") {
        if (Array.isArray(obj.items)) {
          if (obj.items.length !== 1) return null;
          var it = obj.items[0] || {};
          main.id = it.id;
          main.quantity = it.quantity;
          if (it.properties) main.properties = it.properties;
          if (it.selling_plan) main.selling_plan = it.selling_plan;
        } else {
          main.id = obj.id;
          main.quantity = obj.quantity;
          if (obj.properties) main.properties = obj.properties;
          if (obj.selling_plan) main.selling_plan = obj.selling_plan;
        }
        for (var key in obj) {
          if (
            Object.prototype.hasOwnProperty.call(obj, key) &&
            ["items", "id", "quantity", "properties", "selling_plan"].indexOf(key) < 0
          )
            extra[key] = obj[key];
        }
      }
    } else {
      return null;
    }

    if (pairs) {
      for (var i = 0; i < pairs.length; i++) {
        var k = pairs[i][0];
        var v = pairs[i][1];
        var m = /^properties\[(.+)\]$/.exec(k);
        if (k === "id") main.id = v;
        else if (k === "quantity") main.quantity = v;
        else if (k === "selling_plan") {
          if (v) main.selling_plan = v;
        } else if (m) {
          if (typeof v === "string") main.properties[m[1]] = v;
        } else if (/^items\[/.test(k)) return null; // already a multi-add
        else if (k === "sections" || k === "sections_url") extra[k] = v;
      }
    }

    var vid = String(Number(main.id));
    if (!VARIANTS[vid]) return null; // not this product (quick view, gift, etc.)
    main.id = Number(vid);
    main.quantity = Math.max(1, parseInt(main.quantity, 10) || 1);
    if (main.selling_plan) main.selling_plan = Number(main.selling_plan);
    var hasProps = false;
    for (var p in main.properties) hasProps = true;
    if (!hasProps) delete main.properties;
    return { main: main, extra: extra, hasFile: hasFile };
  }

  // ---------- network ----------
  var prevFetch = window.fetch;
  function call(url, init) {
    return prevFetch.call(window, url, init);
  }
  function json(path, body) {
    return call(ROOT + path, {
      method: body ? "POST" : "GET",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      credentials: "same-origin",
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) throw d;
        return d;
      });
    });
  }
  function getCart() {
    return json("cart.js").catch(function () {
      return { items: [] };
    });
  }
  function inCart(cart, variantId) {
    var items = (cart && cart.items) || [];
    for (var i = 0; i < items.length; i++)
      if (Number(items[i].variant_id) === variantId) return true;
    return false;
  }
  /** Adds upsells on their own; if one fails (sold out) the others still go in. */
  function addSeparately(ups) {
    if (!ups.length) return Promise.resolve();
    return json("cart/add.js", { items: ups.map(upsellLine) }).catch(function () {
      return ups.reduce(function (p, u) {
        return p.then(function () {
          return json("cart/add.js", { items: [upsellLine(u)] }).catch(function (e) {
            log("upsell not added", u, e);
          });
        });
      }, Promise.resolve());
    });
  }

  // re-render the mini cart after a late (fallback) add
  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-upsell:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      window.location.reload();
      return;
    }
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    getCart().then(function (cart) {
      var counts = document.querySelectorAll(".cart-count");
      for (var i = 0; i < counts.length; i++) {
        counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer")
          ? "(" + cart.item_count + ")"
          : cart.item_count;
      }
    });
    if (!ids.length) return;
    call(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          return new DOMParser().parseFromString(html || "", "text/html").querySelector(sel);
        };
        var swap = function (id, html, sel) {
          var el = document.getElementById(id);
          var next = html && parse(html, sel);
          if (el && next) el.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", sections["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", sections["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", sections["cart-drawer"], "#CartDrawer");
        var notif = document.querySelector("cart-notification");
        if (notif && typeof notif.cartAction === "function") notif.cartAction();
      })
      .catch(function () {});
  }

  /** The heart: one request with the main product + ticked upsells. */
  function addWithUpsells(url, init, plan, ups) {
    if (plan.hasFile) {
      // file upload properties can't go into JSON — let the theme add, then add upsells
      return call(url, init).then(function (res) {
        if (res.ok) addSeparately(ups).then(refreshUI);
        return res;
      });
    }
    var body = { items: [plan.main].concat(ups.map(upsellLine)) };
    for (var k in plan.extra) body[k] = plan.extra[k];
    var headers = new Headers((init && init.headers) || {});
    headers.set("Content-Type", "application/json");
    headers.set("Accept", "application/json");
    var next = {};
    for (var key in init) next[key] = init[key];
    next.method = "POST";
    next.headers = headers;
    next.body = JSON.stringify(body);
    log("combined add", body);

    return call(url, next).then(function (res) {
      if (!res.ok) {
        log("combined add refused, falling back", res.status);
        return call(url, init).then(function (r2) {
          if (r2.ok) addSeparately(ups).then(refreshUI);
          return r2;
        });
      }
      return res.json().then(function (data) {
        // themes read a single-item response (id, quantity…) as well as sections:
        // give them both shapes so nothing in the theme breaks
        var first = (data && data.items && data.items[0]) || {};
        var merged = {};
        for (var a in first) merged[a] = first[a];
        for (var b in data) merged[b] = data[b];
        try {
          document.dispatchEvent(
            new CustomEvent("wc-upsell:added", { bubbles: true, detail: { upsells: ups } }),
          );
        } catch (e) {
          // ignore
        }
        return new Response(JSON.stringify(merged), {
          status: res.status,
          statusText: res.statusText,
          headers: { "Content-Type": "application/json" },
        });
      });
    });
  }

  function planFor(url, init) {
    if (!init || !init.body) return null;
    var method = String(init.method || "GET").toUpperCase();
    if (method !== "POST" || !ADD_RE.test(pathOf(url))) return null;
    var plan = parseAdd(init.body);
    if (!plan) return null;
    var ups = selected(plan.main.quantity);
    if (!ups.length) return null;
    plan.ups = ups;
    return plan;
  }

  window.fetch = function (input, init) {
    var plan = null;
    var url = typeof input === "string" ? input : (input && input.url) || "";
    try {
      if (typeof input === "string" || input instanceof URL) plan = planFor(String(input), init);
    } catch (e) {
      log("parse error", e);
      plan = null;
    }
    if (!plan) return prevFetch.apply(window, arguments);

    var needCart = plan.ups.some(function (u) {
      return u.once;
    });
    var ready = needCart ? getCart() : Promise.resolve(null);
    return ready.then(function (cart) {
      var ups = plan.ups.filter(function (u) {
        return !(u.once && cart && inCart(cart, u.id));
      });
      if (!ups.length) return call(url, init);
      return addWithUpsells(url, init, plan, ups);
    });
  };

  // ---------- themes that submit the form natively (no AJAX) ----------
  document.addEventListener("submit", function (e) {
    var form = e.target;
    if (e.defaultPrevented || !form || !form.getAttribute) return;
    if (!ADD_RE.test(pathOf(form.getAttribute("action") || ""))) return;
    if (!VARIANTS[formVariant(form)]) return;
    var plan = parseAdd(new FormData(form));
    if (!plan || plan.hasFile) return;
    var ups = selected(plan.main.quantity);
    if (!ups.length) return;
    e.preventDefault();
    getCart()
      .then(function (cart) {
        var list = ups.filter(function (u) {
          return !(u.once && inCart(cart, u.id));
        });
        return json("cart/add.js", { items: [plan.main].concat(list.map(upsellLine)) });
      })
      .catch(function () {
        return json("cart/add.js", { items: [plan.main] });
      })
      .then(function () {
        window.location.href = ROOT + "cart";
      }, function () {
        form.submit();
      });
  });

  // public hook for debugging: window.WCUpsell.selected()
  window.WCUpsell = {
    selected: function () {
      return selected(1);
    },
  };
})();
