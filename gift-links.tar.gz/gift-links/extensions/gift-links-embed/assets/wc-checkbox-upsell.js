/*!
 * WoodenCrew Apps — Checkbox Upsell (theme app embed)  v2 "watch the cart"
 *
 * Works no matter WHO adds the product to the cart (theme form, Vitals bundle
 * tiers, Simple Bundles, quick buy, native form post + redirect to /cart):
 *
 *  1. Product page: the list (#wcu-root) is moved next to Add to cart.
 *  2. When the shopper presses Add to cart (click / submit), the ticked
 *     upsells are saved as a "pending" order in localStorage together with the
 *     quantity of THIS product already in the cart.
 *  3. On this page AND on the next page (e.g. /cart after a redirect) the
 *     script watches the cart. As soon as the product quantity grew, it adds
 *     the pending upsells with /cart/add.js and refreshes the cart UI.
 *     No pending + no product added within 2 minutes → nothing happens.
 *
 * The theme's / other apps' requests are never modified.
 * Upsell lines carry hidden properties _wc_upsell / _wc_upsell_for.
 * Nothing else in the cart is ever touched.
 */
(function () {
  "use strict";
  if (window.__wcUpsellLoaded) return;
  window.__wcUpsellLoaded = true;

  var root = document.getElementById("wcu-root"); // only on product pages with offers
  var boot = document.getElementById("wcu-boot") || root;
  if (!boot) return;

  var DEBUG = boot.getAttribute("data-debug") === "true";
  var ROOT = (boot.getAttribute("data-root") || "/").replace(/\/?$/, "/");
  var PENDING_KEY = "wcUpsell.pending.v2";
  var PENDING_TTL = 2 * 60 * 1000;
  var CART_RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|\/|$)/;

  function log() {
    if (DEBUG && window.console)
      console.log.apply(console, ["[WC Upsell]"].concat([].slice.call(arguments)));
  }

  // ---------- storage (never throws) ----------
  function readPending() {
    try {
      var p = JSON.parse(window.localStorage.getItem(PENDING_KEY) || "null");
      if (p && Date.now() - p.ts < PENDING_TTL) return p;
    } catch (e) {
      // ignore
    }
    return null;
  }
  function writePending(p) {
    try {
      if (p) window.localStorage.setItem(PENDING_KEY, JSON.stringify(p));
      else window.localStorage.removeItem(PENDING_KEY);
    } catch (e) {
      // ignore
    }
  }

  // ---------- network (original fetch, so we never observe ourselves) ----------
  var rawFetch = window.fetch.bind(window);
  function api(path, body) {
    return rawFetch(ROOT + path, {
      method: body ? "POST" : "GET",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      credentials: "same-origin",
      keepalive: !!body,
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) throw d;
        return d;
      });
    });
  }
  function getCart() {
    return api("cart.js");
  }
  function qtyOf(cart, variants) {
    var n = 0;
    var items = (cart && cart.items) || [];
    for (var i = 0; i < items.length; i++) {
      // skip lines added by other upsell/gift logic of ours
      var p = items[i].properties || {};
      if (p._wc_upsell || p._gift_link) continue;
      if (variants[String(items[i].variant_id)]) n += Number(items[i].quantity) || 0;
    }
    return n;
  }
  function inCart(cart, variantId) {
    var items = (cart && cart.items) || [];
    for (var i = 0; i < items.length; i++)
      if (Number(items[i].variant_id) === Number(variantId)) return true;
    return false;
  }

  // ---------- stale /cart page after a redirect race ----------
  // If we added lines in the last 20 s (e.g. on the product page while Vitals was
  // already redirecting), the server-rendered /cart may not show them: reload once.
  var ADDED_KEY = "wcUpsell.added.v2";
  function markAdded() {
    try {
      window.localStorage.setItem(ADDED_KEY, JSON.stringify({ ts: Date.now(), reloaded: false }));
    } catch (e) {
      // ignore
    }
  }
  function reloadCartIfStale() {
    if (!/\/cart\/?$/.test(window.location.pathname)) return;
    try {
      var a = JSON.parse(window.localStorage.getItem(ADDED_KEY) || "null");
      if (!a || a.reloaded || Date.now() - a.ts > 20000) return;
      a.reloaded = true;
      window.localStorage.setItem(ADDED_KEY, JSON.stringify(a));
      setTimeout(function () {
        window.location.reload();
      }, 1200); // let a keepalive add finish first
    } catch (e) {
      // ignore
    }
  }

  // ---------- refresh the theme's cart UI after we added something ----------
  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-upsell:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      // full cart page: reload so the lines show up (pending is already cleared → no loop)
      try {
        window.localStorage.setItem(ADDED_KEY, JSON.stringify({ ts: Date.now(), reloaded: true }));
      } catch (e) {
        // ignore
      }
      window.location.reload();
      return;
    }
    getCart().then(function (cart) {
      var counts = document.querySelectorAll(".cart-count");
      for (var i = 0; i < counts.length; i++) {
        counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer")
          ? "(" + cart.item_count + ")"
          : cart.item_count;
      }
    });
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    if (!ids.length) return;
    rawFetch(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          return new DOMParser().parseFromString(html || "", "text/html").querySelector(sel);
        };
        var swap = function (id, html, sel) {
          var el = document.getElementById(id);
          var next = html && parse(html, sel);
          if (el && next) el.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", sections["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", sections["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", sections["cart-drawer"], "#CartDrawer");
        var notif = document.querySelector("cart-notification");
        if (notif && typeof notif.cartAction === "function") notif.cartAction();
      })
      .catch(function () {});
  }

  // ---------- reconcile: add pending upsells once the product is in the cart ----------
  var reconciling = false;
  function reconcile(reason) {
    var p = readPending();
    if (!p) return Promise.resolve();
    if (reconciling) return Promise.resolve();
    reconciling = true;
    var variants = {};
    p.variants.forEach(function (v) {
      variants[v] = true;
    });
    return getCart()
      .then(function (cart) {
        var now = qtyOf(cart, variants);
        if (now <= p.baseQty) {
          log("waiting for product (", reason, ") qty", now, "base", p.baseQty);
          return null;
        }
        // claim it first so a second tab/handler can't add twice
        var claim = readPending();
        if (!claim || claim.id !== p.id) return null;
        writePending(null);
        var added = now - p.baseQty;
        var lines = [];
        p.upsells.forEach(function (u) {
          if (u.once && inCart(cart, u.id)) return;
          lines.push({
            id: u.id,
            quantity: u.match ? added : 1,
            properties: { _wc_upsell: u.offer, _wc_upsell_for: p.handle },
          });
        });
        if (!lines.length) return null;
        log("adding upsells", lines);
        markAdded();
        return api("cart/add.js", { items: lines })
          .catch(function () {
            // one is sold out → add the others one by one
            return lines.reduce(function (chain, l) {
              return chain.then(function () {
                return api("cart/add.js", { items: [l] }).catch(function (e) {
                  log("upsell not added", l, e);
                });
              });
            }, Promise.resolve());
          })
          .then(refreshUI);
      })
      .catch(function (e) {
        log("reconcile error", e);
      })
      .then(function () {
        reconciling = false;
        if (!readPending() && onCartChanged) onCartChanged(); // keep baseQty in sync
      });
  }

  var onCartChanged = null; // set on product pages (keeps baseQty fresh)
  function afterCartChange() {
    if (readPending()) reconcile("cart change");
    else if (onCartChanged) onCartChanged();
  }

  // watch cart requests made by anyone (pass-through, never modified)
  var prevFetch = window.fetch;
  window.fetch = function (input, init) {
    var p = prevFetch.apply(window, arguments);
    try {
      var u = typeof input === "string" ? input : (input && input.url) || "";
      if (CART_RE.test(String(u)))
        p.then(function () {
          setTimeout(afterCartChange, 300);
        }, function () {});
    } catch (e) {
      // ignore
    }
    return p;
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, u) {
    try {
      if (CART_RE.test(String(u)))
        this.addEventListener("load", function () {
          setTimeout(afterCartChange, 300);
        });
    } catch (e) {
      // ignore
    }
    return xhrOpen.apply(this, arguments);
  };

  // safety net: poll while something is pending (covers apps using a cached fetch)
  var pollTimer = null;
  function startPolling() {
    if (pollTimer) return;
    var started = Date.now();
    pollTimer = setInterval(function () {
      if (!readPending() || Date.now() - started > PENDING_TTL) {
        clearInterval(pollTimer);
        pollTimer = null;
        return;
      }
      reconcile("poll");
    }, 1500);
  }

  // every page: something may be pending from the previous page (redirect to /cart)
  reloadCartIfStale();
  if (readPending()) {
    reconcile("page load");
    startPolling();
  }

  if (!root) return; // not a product page with checkboxes

  // =====================  product page  =====================
  var HANDLE = root.getAttribute("data-product-handle") || "";
  var SELECTOR =
    root.getAttribute("data-selector") ||
    "form[action*='/cart/add'] button[type='submit'][name='add']";
  var POSITION = root.getAttribute("data-position") === "after" ? "after" : "before";
  var VARIANTS = {};
  var VARIANT_LIST = [];
  (root.getAttribute("data-variants") || "").split(",").forEach(function (v) {
    if (v) {
      VARIANTS[String(Number(v))] = true;
      VARIANT_LIST.push(String(Number(v)));
    }
  });

  // ---------- placement ----------
  function formVariant(form) {
    var el = form && form.querySelector('[name="id"]');
    return el ? String(Number(el.value)) : "";
  }
  function findAnchor() {
    var list;
    try {
      list = document.querySelectorAll(SELECTOR);
    } catch (e) {
      log("bad selector", SELECTOR);
      return null;
    }
    var fallback = null;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === root || root.contains(el)) continue;
      var form = el.closest ? el.closest("form") : null;
      if (form && VARIANTS[formVariant(form)]) return el;
      if (!fallback) fallback = el;
    }
    return fallback;
  }
  var mounted = false;
  function mount() {
    if (mounted) return true;
    var anchor = findAnchor();
    if (!anchor || !anchor.parentNode) return false;
    if (POSITION === "after") anchor.parentNode.insertBefore(root, anchor.nextSibling);
    else anchor.parentNode.insertBefore(root, anchor);
    root.hidden = false;
    mounted = true;
    log("mounted", POSITION, anchor);
    return true;
  }
  if (!mount()) {
    var obs = new MutationObserver(function () {
      if (mount()) obs.disconnect();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function () {
      obs.disconnect();
    }, 15000);
  }

  // ---------- ⓘ info popup ----------
  var modal = null;
  function closeInfo() {
    if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
    modal = null;
    document.removeEventListener("keydown", onKey);
  }
  function onKey(e) {
    if (e.key === "Escape") closeInfo();
  }
  function openInfo(text) {
    closeInfo();
    modal = document.createElement("div");
    modal.className = "wcu-modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    var box = document.createElement("div");
    box.className = "wcu-modal-box";
    var p = document.createElement("p");
    p.className = "wcu-modal-text";
    p.textContent = text; // plain text only — never HTML
    var x = document.createElement("button");
    x.type = "button";
    x.className = "wcu-modal-close";
    x.setAttribute("aria-label", "Close");
    x.textContent = "✕";
    box.appendChild(x);
    box.appendChild(p);
    modal.appendChild(box);
    modal.addEventListener("click", function (e) {
      if (e.target === modal || e.target === x) closeInfo();
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(modal);
    x.focus();
  }
  root.addEventListener("click", function (e) {
    var btn = e.target && e.target.closest ? e.target.closest(".wcu-info") : null;
    if (!btn) return;
    e.preventDefault(); // don't toggle the checkbox / submit the form
    e.stopPropagation();
    openInfo(btn.getAttribute("data-info") || "");
  });

  // ---------- what is ticked ----------
  function selected() {
    var out = [];
    var items = root.querySelectorAll(".wcu-item");
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var input = it.querySelector(".wcu-input");
      if (!input || !input.checked) continue;
      out.push({
        offer: it.getAttribute("data-offer") || "",
        id: Number(it.getAttribute("data-variant")),
        match: it.getAttribute("data-qty") === "match",
        once: it.getAttribute("data-once") === "true",
      });
    }
    return out;
  }

  // current quantity of this product in the cart, kept fresh
  var baseQty = 0;
  function refreshBase() {
    return getCart()
      .then(function (cart) {
        baseQty = qtyOf(cart, VARIANTS);
      })
      .catch(function () {});
  }
  refreshBase();
  onCartChanged = refreshBase;
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && !readPending()) refreshBase();
  });

  // ---------- capture "Add to cart" however the page does it ----------
  var lastArm = 0;
  function arm(why) {
    var ups = selected();
    if (!ups.length) {
      writePending(null); // nothing ticked on this press → forget older presses
      return;
    }
    var now = Date.now();
    if (now - lastArm < 800) return; // click + submit of the same press
    lastArm = now;
    var p = {
      id: now.toString(36) + Math.random().toString(36).slice(2, 6),
      ts: now,
      handle: HANDLE,
      variants: VARIANT_LIST,
      baseQty: baseQty,
      upsells: ups,
    };
    writePending(p);
    log("armed (", why, ")", p);
    startPolling();
  }
  function isAddButton(el) {
    if (!el || !el.closest) return false;
    var b = el.closest('button, input[type="submit"], [role="button"]');
    if (!b || root.contains(b)) return false;
    if (b.name === "add" || b.getAttribute("name") === "add") return true;
    var form = b.closest("form");
    if (form && /\/cart\/add/.test(form.getAttribute("action") || "") && (b.type === "submit" || !b.type))
      return true;
    var txt = (b.textContent || b.value || "").trim().toLowerCase();
    return /^(add to (cart|bag)|buy now)$/.test(txt);
  }
  // capture phase: runs before the theme / Vitals handlers can stop the event
  document.addEventListener(
    "click",
    function (e) {
      if (isAddButton(e.target)) arm("click");
    },
    true,
  );
  document.addEventListener(
    "submit",
    function (e) {
      var f = e.target;
      if (f && f.getAttribute && /\/cart\/add/.test(f.getAttribute("action") || "") && VARIANTS[formVariant(f)])
        arm("submit");
    },
    true,
  );

  // public hook for debugging: window.WCUpsell
  window.WCUpsell = {
    selected: selected,
    pending: readPending,
    reconcile: function () {
      return reconcile("manual");
    },
  };
})();
