/*!
 * WoodenCrew Apps — Checkbox Upsell (theme app embed)  v2 "watch the cart"
 *
 * Works no matter WHO adds the product to the cart (theme form, Vitals bundle
 * tiers, Simple Bundles, quick buy, native form post + redirect to /cart):
 *
 *  1. Product page: the list (#wcu-root) is moved next to Add to cart.
 *  2. When the shopper presses Add to cart (click / submit), the ticked
 *     upsells are saved as a "pending" order in localStorage together with the
 *     quantity of THIS product already in the cart.
 *  3. On this page AND on the next page (e.g. /cart after a redirect) the
 *     script watches the cart. As soon as the product quantity grew, it adds
 *     the pending upsells with /cart/add.js and refreshes the cart UI.
 *     No pending + no product added within 2 minutes → nothing happens.
 *
 * v3 (2026-10-18) "add first": when the theme (fetch / XHR) or our Volume
 * Discounts block sends the Add to cart request for THIS product, the ticked
 * upsells are added FIRST and the request is sent right after (body untouched).
 * So the drawer / mini cart / /cart page the theme shows already contain the
 * upsells: no page reload. If the product add fails, the upsells are removed
 * again. The "watch the cart" path above stays as a fallback (native form post).
 * "Once per cart" upsells already in the cart are shown ON and locked.
 *
 * The theme's / other apps' requests are never modified.
 * Upsell lines carry hidden properties _wc_upsell / _wc_upsell_for.
 * Nothing else in the cart is ever touched.
 */
(function () {
  "use strict";
  if (window.__wcUpsellLoaded) return;
  window.__wcUpsellLoaded = true;

  var root = document.getElementById("wcu-root"); // only on product pages with offers
  var boot = document.getElementById("wcu-boot") || root;
  if (!boot) return;

  var DEBUG = boot.getAttribute("data-debug") === "true";
  var ROOT = (boot.getAttribute("data-root") || "/").replace(/\/?$/, "/");
  var PENDING_KEY = "wcUpsell.pending.v2";
  var PENDING_TTL = 2 * 60 * 1000;
  var CART_RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|\/|$)/;
  var ADD_RE = /\/cart\/add(\.js)?(\?|\/|$)/;
  var preAdd = null; // set on product pages: (body) => Promise | null

  function log() {
    if (DEBUG && window.console)
      console.log.apply(console, ["[WC Upsell]"].concat([].slice.call(arguments)));
  }

  // ---------- storage (never throws) ----------
  function readPending() {
    try {
      var p = JSON.parse(window.localStorage.getItem(PENDING_KEY) || "null");
      if (p && Date.now() - p.ts < PENDING_TTL) return p;
    } catch (e) {
      // ignore
    }
    return null;
  }
  function writePending(p) {
    try {
      if (p) window.localStorage.setItem(PENDING_KEY, JSON.stringify(p));
      else window.localStorage.removeItem(PENDING_KEY);
    } catch (e) {
      // ignore
    }
  }

  // ---------- network (original fetch, so we never observe ourselves) ----------
  var rawFetch = window.fetch.bind(window);
  function api(path, body) {
    return rawFetch(ROOT + path, {
      method: body ? "POST" : "GET",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      credentials: "same-origin",
      keepalive: !!body,
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) throw d;
        return d;
      });
    });
  }
  function getCart() {
    return api("cart.js");
  }
  function qtyOf(cart, variants) {
    var n = 0;
    var items = (cart && cart.items) || [];
    for (var i = 0; i < items.length; i++) {
      // skip lines added by other upsell/gift logic of ours
      var p = items[i].properties || {};
      if (p._wc_upsell || p._gift_link) continue;
      if (variants[String(items[i].variant_id)]) n += Number(items[i].quantity) || 0;
    }
    return n;
  }
  function inCart(cart, variantId) {
    var items = (cart && cart.items) || [];
    for (var i = 0; i < items.length; i++)
      if (Number(items[i].variant_id) === Number(variantId)) return true;
    return false;
  }

  // ---------- /cart page: re-render in place, never reload (shared by all WoodenCrew Apps scripts) ----------
  // The first of our scripts defines window.WCCartPage; the others reuse it, so several
  // modules changing the cart at once give ONE re-render. Same steps as the theme's own
  // CartItems.updateQuantity (Umino): section HTML → .js-contents, totals, gift wrap, counts.
  if (!window.WCCartPage) {
    window.WCCartPage = (function () {
      var timer = null;
      var running = null;
      var again = false;
      var waiters = [];
      var RELOAD_KEY = "wcCartPage.reload";
      function root() {
        var r = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
        return r.charAt(r.length - 1) === "/" ? r : r + "/";
      }
      function isCartPage() {
        return /\/cart\/?$/.test(window.location.pathname);
      }
      function pick(doc, sel) {
        return doc.querySelector(sel);
      }
      function render() {
        var main = document.getElementById("main-cart-items");
        var sec = main && main.closest('[id^="shopify-section-"]');
        var id = (main && main.getAttribute("data-id")) || (sec && sec.id.replace("shopify-section-", ""));
        if (!id || !sec) return Promise.reject(new Error("cart section not found"));
        // no Accept: application/json here — with it Shopify answers /cart?sections= with cart JSON
        var get = function (path) {
          return window.fetch(root() + path, { credentials: "same-origin" }).then(function (r) {
            if (!r.ok) throw new Error(path + " " + r.status);
            return r.json();
          });
        };
        return Promise.all([get("cart?sections=" + encodeURIComponent(id)), get("cart.js")]).then(function (res) {
          var html = res[0] && res[0][id];
          var cart = res[1];
          if (!html) throw new Error("empty section");
          var doc = new DOMParser().parseFromString(html, "text/html");
          var curC = main.querySelector(".js-contents");
          var newC = pick(doc, "#main-cart-items .js-contents") || pick(doc, ".js-contents");
          if (cart.item_count > 0 && curC && newC) {
            curC.innerHTML = newC.innerHTML;
            var t1 = document.querySelector(".cart__footer .totals");
            var t2 = pick(doc, ".cart__footer .totals");
            if (t1 && t2) t1.innerHTML = t2.innerHTML;
            var g1 = document.getElementById("bls__gift");
            var g2 = doc.getElementById("bls__gift");
            if (g1 && g2) g1.innerHTML = g2.innerHTML;
          } else {
            // empty ↔ not empty: the layout changes, swap the whole cart wrapper
            var w1 = document.querySelector(".cart-wrapper") || main;
            var w2 = pick(doc, ".cart-wrapper") || pick(doc, "#main-cart-items");
            if (!w1 || !w2) throw new Error("cart wrapper not found");
            w1.innerHTML = w2.innerHTML;
          }
          var counts = document.querySelectorAll(".cart-count");
          for (var i = 0; i < counts.length; i++)
            counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer") ? "(" + cart.item_count + ")" : cart.item_count;
          try {
            var tp = document.querySelector("header-total-price");
            if (tp && tp.updateTotal) tp.updateTotal(cart);
            var fs = document.querySelector("free-ship-progress-bar");
            if (fs && fs.init) fs.init(cart.items_subtotal_price);
            var ci = document.querySelector("cart-items");
            if (ci && "currentItemCount" in ci) ci.currentItemCount = cart.item_count;
            if (window.BlsLazyloadImg && window.BlsLazyloadImg.init) window.BlsLazyloadImg.init();
            document.dispatchEvent(new CustomEvent("wc:cart-page-rendered", { detail: { cart: cart } }));
          } catch (e) {
            // theme extras are optional
          }
          return cart;
        });
      }
      function fallbackReload() {
        // last resort, at most once per 10 s for ALL our scripts together
        try {
          var last = Number(window.sessionStorage.getItem(RELOAD_KEY) || 0);
          if (Date.now() - last < 10000) return;
          window.sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
        } catch (e) {
          return; // can't guard → don't reload
        }
        window.location.reload();
      }
      function run() {
        running = render()
          .catch(function () {
            fallbackReload();
          })
          .then(function () {
            running = null;
            if (again) {
              again = false;
              return run();
            }
            var w = waiters;
            waiters = [];
            w.forEach(function (f) {
              f();
            });
          });
        return running;
      }
      function refresh(delay) {
        if (!isCartPage()) return Promise.resolve();
        return new Promise(function (resolve) {
          waiters.push(resolve);
          clearTimeout(timer);
          timer = setTimeout(function () {
            if (running) again = true;
            else run();
          }, delay == null ? 250 : delay);
        });
      }
      return { refresh: refresh, isCartPage: isCartPage };
    })();
  }

  // ---------- stale /cart page after a redirect race ----------
  // If we added lines in the last 20 s (e.g. on the product page while Vitals was
  // already redirecting), the server-rendered /cart may not show them: reload once.
  var ADDED_KEY = "wcUpsell.added.v2";
  function markAdded() {
    try {
      window.localStorage.setItem(ADDED_KEY, JSON.stringify({ ts: Date.now(), reloaded: false }));
    } catch (e) {
      // ignore
    }
  }
  function reloadCartIfStale() {
    if (!/\/cart\/?$/.test(window.location.pathname)) return;
    try {
      var a = JSON.parse(window.localStorage.getItem(ADDED_KEY) || "null");
      if (!a || a.reloaded || Date.now() - a.ts > 20000) return;
      a.reloaded = true;
      window.localStorage.setItem(ADDED_KEY, JSON.stringify(a));
      window.WCCartPage.refresh(1200); // let a keepalive add finish first; re-render in place, no reload
    } catch (e) {
      // ignore
    }
  }

  // ---------- refresh the theme's cart UI after we added something ----------
  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-upsell:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      // full cart page: re-render it in place so the lines show up (no reload)
      try {
        window.localStorage.setItem(ADDED_KEY, JSON.stringify({ ts: Date.now(), reloaded: true }));
      } catch (e) {
        // ignore
      }
      window.WCCartPage.refresh();
      return;
    }
    getCart().then(function (cart) {
      var counts = document.querySelectorAll(".cart-count");
      for (var i = 0; i < counts.length; i++) {
        counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer")
          ? "(" + cart.item_count + ")"
          : cart.item_count;
      }
    }).catch(function (error) {
      log("cart count refresh failed", error);
    });
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    if (!ids.length) return;
    rawFetch(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          return new DOMParser().parseFromString(html || "", "text/html").querySelector(sel);
        };
        var swap = function (id, html, sel) {
          var el = document.getElementById(id);
          var next = html && parse(html, sel);
          if (el && next) el.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", sections["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", sections["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", sections["cart-drawer"], "#CartDrawer");
        var notif = document.querySelector("cart-notification");
        if (notif && typeof notif.cartAction === "function") notif.cartAction();
      })
      .catch(function () {});
  }

  // ---------- reconcile: add pending upsells once the product is in the cart ----------
  var reconciling = false;
  function reconcile(reason) {
    var p = readPending();
    if (!p) return Promise.resolve();
    if (reconciling) return Promise.resolve();
    reconciling = true;
    var variants = {};
    p.variants.forEach(function (v) {
      variants[v] = true;
    });
    return getCart()
      .then(function (cart) {
        var now = qtyOf(cart, variants);
        if (now <= p.baseQty) {
          log("waiting for product (", reason, ") qty", now, "base", p.baseQty);
          return null;
        }
        // claim it first so a second tab/handler can't add twice
        var claim = readPending();
        if (!claim || claim.id !== p.id) return null;
        writePending(null);
        var added = now - p.baseQty;
        var lines = [];
        p.upsells.forEach(function (u) {
          if (u.once && inCart(cart, u.id)) return;
          lines.push({
            id: u.id,
            quantity: u.match ? added : 1,
            properties: { _wc_upsell: u.offer, _wc_upsell_for: p.handle },
          });
        });
        if (!lines.length) return null;
        log("adding upsells", lines);
        markAdded();
        return api("cart/add.js", { items: lines })
          .catch(function () {
            // one is sold out → add the others one by one
            return lines.reduce(function (chain, l) {
              return chain.then(function () {
                return api("cart/add.js", { items: [l] }).catch(function (e) {
                  log("upsell not added", l, e);
                });
              });
            }, Promise.resolve());
          })
          .then(refreshUI);
      })
      .catch(function (e) {
        log("reconcile error", e);
      })
      .then(function () {
        reconciling = false;
        if (!readPending() && onCartChanged) onCartChanged(); // keep baseQty in sync
      });
  }

  var onCartChanged = null; // set on product pages (keeps baseQty fresh)
  function afterCartChange() {
    if (readPending()) reconcile("cart change");
    else if (onCartChanged) onCartChanged();
  }

  // watch cart requests made by anyone (pass-through, never modified)
  var prevFetch = window.fetch;
  window.fetch = function (input, init) {
    var args = arguments;
    try {
      var au = typeof input === "string" ? input : (input && input.url) || "";
      var pre = preAdd && ADD_RE.test(String(au)) ? preAdd(init && init.body) : null;
      if (pre) {
        var handle = null;
        var sent = pre.then(function (h) {
          handle = h;
          return prevFetch.apply(window, args);
        });
        sent.then(
          function (r) {
            if (r && !r.ok && handle) handle.rollback();
            setTimeout(afterCartChange, 300);
          },
          function () {
            if (handle) handle.rollback();
          },
        );
        return sent;
      }
    } catch (e) {
      // ignore → normal path
    }
    var p = prevFetch.apply(window, args);
    try {
      var u = typeof input === "string" ? input : (input && input.url) || "";
      if (CART_RE.test(String(u)))
        p.then(function () {
          setTimeout(afterCartChange, 300);
        }, function () {});
    } catch (e) {
      // ignore
    }
    return p;
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  var xhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (body) {
    var xhr = this;
    try {
      var pre = preAdd && ADD_RE.test(String(xhr.__wcuUrl || "")) ? preAdd(body) : null;
      if (pre) {
        pre.then(function (h) {
          if (h)
            xhr.addEventListener("loadend", function () {
              if (!(xhr.status >= 200 && xhr.status < 300)) h.rollback();
            });
          xhrSend.call(xhr, body);
        });
        return;
      }
    } catch (e) {
      // ignore → normal path
    }
    return xhrSend.apply(xhr, arguments);
  };
  XMLHttpRequest.prototype.open = function (method, u) {
    try {
      this.__wcuUrl = String(u || "");
      if (CART_RE.test(String(u)))
        this.addEventListener("load", function () {
          setTimeout(afterCartChange, 300);
        });
    } catch (e) {
      // ignore
    }
    return xhrOpen.apply(this, arguments);
  };

  // safety net: poll while something is pending (covers apps using a cached fetch)
  var pollTimer = null;
  function startPolling() {
    if (pollTimer) return;
    var started = Date.now();
    pollTimer = setInterval(function () {
      if (!readPending() || Date.now() - started > PENDING_TTL) {
        clearInterval(pollTimer);
        pollTimer = null;
        return;
      }
      reconcile("poll");
    }, 1500);
  }

  // every page: something may be pending from the previous page (redirect to /cart)
  reloadCartIfStale();
  if (readPending()) {
    reconcile("page load");
    startPolling();
  }

  if (!root) return; // not a product page with checkboxes

  // =====================  product page  =====================
  var HANDLE = root.getAttribute("data-product-handle") || "";
  var SELECTOR =
    root.getAttribute("data-selector") ||
    "form[action*='/cart/add'] button[type='submit'][name='add']";
  var POSITION = root.getAttribute("data-position") === "after" ? "after" : "before";
  var VARIANTS = {};
  var VARIANT_LIST = [];
  (root.getAttribute("data-variants") || "").split(",").forEach(function (v) {
    if (v) {
      VARIANTS[String(Number(v))] = true;
      VARIANT_LIST.push(String(Number(v)));
    }
  });

  // ---------- placement ----------
  function formVariant(form) {
    var el = form && form.querySelector('[name="id"]');
    return el ? String(Number(el.value)) : "";
  }
  function findAnchor() {
    var list;
    try {
      list = document.querySelectorAll(SELECTOR);
    } catch (e) {
      log("bad selector", SELECTOR);
      return null;
    }
    var fallback = null;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === root || root.contains(el)) continue;
      var form = el.closest ? el.closest("form") : null;
      if (form && VARIANTS[formVariant(form)]) return el;
      if (!fallback) fallback = el;
    }
    return fallback;
  }
  var mounted = false;
  function mount() {
    if (mounted) return true;
    var anchor = findAnchor();
    if (!anchor || !anchor.parentNode) return false;
    if (POSITION === "after") anchor.parentNode.insertBefore(root, anchor.nextSibling);
    else anchor.parentNode.insertBefore(root, anchor);
    root.hidden = false;
    mounted = true;
    log("mounted", POSITION, anchor);
    return true;
  }
  if (!mount()) {
    var obs = new MutationObserver(function () {
      if (mount()) obs.disconnect();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function () {
      obs.disconnect();
    }, 15000);
  }

  // ---------- ⓘ info popup ----------
  var modal = null;
  function closeInfo() {
    if (modal && modal.parentNode) modal.parentNode.removeChild(modal);
    modal = null;
    document.removeEventListener("keydown", onKey);
  }
  function onKey(e) {
    if (e.key === "Escape") closeInfo();
  }
  function openInfo(text) {
    closeInfo();
    modal = document.createElement("div");
    modal.className = "wcu-modal";
    modal.setAttribute("role", "dialog");
    modal.setAttribute("aria-modal", "true");
    var box = document.createElement("div");
    box.className = "wcu-modal-box";
    var p = document.createElement("p");
    p.className = "wcu-modal-text";
    p.textContent = text; // plain text only — never HTML
    var x = document.createElement("button");
    x.type = "button";
    x.className = "wcu-modal-close";
    x.setAttribute("aria-label", "Close");
    x.textContent = "✕";
    box.appendChild(x);
    box.appendChild(p);
    modal.appendChild(box);
    modal.addEventListener("click", function (e) {
      if (e.target === modal || e.target === x) closeInfo();
    });
    document.addEventListener("keydown", onKey);
    document.body.appendChild(modal);
    x.focus();
  }
  root.addEventListener("click", function (e) {
    var btn = e.target && e.target.closest ? e.target.closest(".wcu-info") : null;
    if (!btn) return;
    e.preventDefault(); // don't toggle the checkbox / submit the form
    e.stopPropagation();
    openInfo(btn.getAttribute("data-info") || "");
  });

  // ---------- what is ticked ----------
  function selected() {
    var out = [];
    var items = root.querySelectorAll(".wcu-item");
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var input = it.querySelector(".wcu-input");
      if (!input || !input.checked || input.disabled) continue;
      out.push({
        offer: it.getAttribute("data-offer") || "",
        id: Number(it.getAttribute("data-variant")),
        match: it.getAttribute("data-qty") === "match",
        once: it.getAttribute("data-once") === "true",
      });
    }
    return out;
  }

  // current quantity of this product in the cart, kept fresh
  var baseQty = 0;
  var lastCart = null;
  function refreshBase() {
    return getCart()
      .then(function (cart) {
        lastCart = cart;
        baseQty = qtyOf(cart, VARIANTS);
        syncOnce(cart);
      })
      .catch(function () {});
  }

  // "once per cart" upsell already in the cart → shown ON and locked
  function syncOnce(cart) {
    var items = root.querySelectorAll('.wcu-item[data-once="true"]');
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var input = it.querySelector(".wcu-input");
      if (!input) continue;
      var has = inCart(cart, it.getAttribute("data-variant"));
      var locked = it.classList.contains("wcu-in-cart");
      if (has && !locked) {
        input.setAttribute("data-wcu-prev", input.checked ? "1" : "0");
        input.checked = true;
        input.disabled = true;
        it.classList.add("wcu-in-cart");
        it.setAttribute("title", "Already in your cart");
      } else if (!has && locked) {
        input.disabled = false;
        input.checked = input.getAttribute("data-wcu-prev") === "1";
        it.classList.remove("wcu-in-cart");
        it.removeAttribute("title");
      }
    }
  }

  // ---------- v3: add the upsells right BEFORE the product's add request ----------
  var lastDirect = 0;
  var pressSeq = 0; // +1 per Add to cart press (click + submit of one press = 1)
  var lastPressTs = 0;
  var handledSeq = -1; // press whose upsells were already added
  function num(v) {
    var n = parseInt(v, 10);
    return isNaN(n) ? 0 : n;
  }
  // how many units of THIS product the add request carries (0 = not ours / unknown)
  function qtyInBody(body) {
    if (body == null) return 0;
    var pairs = [];
    try {
      if (typeof FormData !== "undefined" && body instanceof FormData) {
        body.forEach(function (v, k) {
          pairs.push([k, v]);
        });
      } else if (typeof URLSearchParams !== "undefined" && body instanceof URLSearchParams) {
        body.forEach(function (v, k) {
          pairs.push([k, v]);
        });
      } else if (typeof body === "string" || typeof body === "object") {
        var obj = null;
        if (typeof body === "string") {
          try {
            obj = JSON.parse(body);
          } catch (e) {
            new URLSearchParams(body).forEach(function (v, k) {
              pairs.push([k, v]);
            });
          }
        } else obj = body;
        if (obj && typeof obj === "object") {
          var list = Array.isArray(obj.items) ? obj.items : [obj];
          var n = 0;
          list.forEach(function (it) {
            if (it && VARIANTS[String(Number(it.id))]) n += it.quantity == null ? 1 : num(it.quantity);
          });
          return n;
        }
      }
    } catch (e) {
      return 0;
    }
    // form fields: id + quantity, or items[0][id] + items[0][quantity]
    var single = { id: null, q: null };
    var multi = {};
    pairs.forEach(function (kv) {
      var k = String(kv[0]);
      var m = /^items\[(\d*)\]\[(id|quantity)\]$/.exec(k);
      if (m) {
        var idx = m[1] || "0";
        multi[idx] = multi[idx] || {};
        multi[idx][m[2]] = kv[1];
      } else if (k === "id") single.id = kv[1];
      else if (k === "quantity") single.q = kv[1];
    });
    var total = 0;
    if (single.id != null && VARIANTS[String(Number(single.id))])
      total += single.q == null || single.q === "" ? 1 : num(single.q);
    Object.keys(multi).forEach(function (idx) {
      var it = multi[idx];
      if (VARIANTS[String(Number(it.id))]) total += it.quantity == null ? 1 : num(it.quantity);
    });
    return total;
  }

  function withTimeout(p, ms) {
    return new Promise(function (resolve) {
      var done = false;
      var t = setTimeout(function () {
        if (!done) {
          done = true;
          log("upsell add slow → product request goes on");
          resolve(null);
        }
      }, ms);
      p.then(
        function (v) {
          if (!done) {
            done = true;
            clearTimeout(t);
            resolve(v);
          }
        },
        function () {
          if (!done) {
            done = true;
            clearTimeout(t);
            resolve(null);
          }
        },
      );
    });
  }

  function addLines(lines) {
    return api("cart/add.js", { items: lines })
      .then(function (r) {
        return (r && r.items) || [];
      })
      .catch(function () {
        // one is sold out → add the others one by one
        var out = [];
        return lines
          .reduce(function (chain, l) {
            return chain.then(function () {
              return api("cart/add.js", { items: [l] }).then(
                function (r) {
                  out = out.concat((r && r.items) || []);
                },
                function (e) {
                  log("upsell not added", l, e);
                },
              );
            });
          }, Promise.resolve())
          .then(function () {
            return out;
          });
      });
  }

  // returns Promise<{rollback}|null>; never rejects
  function addBefore(qty, why) {
    if (!(qty > 0)) return null;
    // same press already handled (e.g. VD hook + its request through our fetch hook)
    if (handledSeq === pressSeq && Date.now() - lastDirect < 2500) return null;
    var ups = selected();
    if (!ups.length) return null;
    handledSeq = pressSeq;
    lastDirect = Date.now();
    writePending(null); // the watcher must not add them a second time
    var job = (lastCart ? Promise.resolve(lastCart) : getCart()).then(function (cart) {
      var lines = [];
      ups.forEach(function (u) {
        if (u.once && inCart(cart, u.id)) return;
        lines.push({
          id: u.id,
          quantity: u.match ? qty : 1,
          properties: { _wc_upsell: u.offer, _wc_upsell_for: HANDLE },
        });
      });
      if (!lines.length) return null;
      var before = {};
      ((cart && cart.items) || []).forEach(function (l) {
        before[l.key] = Number(l.quantity) || 0;
      });
      log("adding upsells before product (", why, ")", lines);
      return addLines(lines).then(function (added) {
        if (!added.length) return null;
        var rolled = false;
        return {
          rollback: function () {
            if (rolled) return;
            rolled = true;
            log("product add failed → removing upsells");
            added
              .reduce(function (chain, l) {
                return chain.then(function () {
                  return api("cart/change.js", { id: l.key, quantity: before[l.key] || 0 }).catch(function () {});
                });
              }, Promise.resolve())
              .then(refreshBase);
          },
        };
      });
    });
    return withTimeout(job, 6000);
  }
  preAdd = function (body) {
    return addBefore(qtyInBody(body), "request");
  };
  refreshBase();
  onCartChanged = refreshBase;
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "visible" && !readPending()) refreshBase();
  });

  // ---------- capture "Add to cart" however the page does it ----------
  var lastArm = 0;
  function arm(why) {
    var ups = selected();
    if (!ups.length) {
      writePending(null); // nothing ticked on this press → forget older presses
      return;
    }
    var now = Date.now();
    if (now - lastArm < 800) return; // click + submit of the same press
    if (handledSeq === pressSeq) return; // already added before the product request
    lastArm = now;
    var p = {
      id: now.toString(36) + Math.random().toString(36).slice(2, 6),
      ts: now,
      handle: HANDLE,
      variants: VARIANT_LIST,
      baseQty: baseQty,
      upsells: ups,
    };
    writePending(p);
    log("armed (", why, ")", p);
    startPolling();
  }
  function isAddButton(el) {
    if (!el || !el.closest) return false;
    var b = el.closest('button, input[type="submit"], [role="button"]');
    if (!b || root.contains(b)) return false;
    if (b.name === "add" || b.getAttribute("name") === "add") return true;
    var form = b.closest("form");
    if (form && /\/cart\/add/.test(form.getAttribute("action") || "") && (b.type === "submit" || !b.type))
      return true;
    var txt = (b.textContent || b.value || "").trim().toLowerCase();
    return /^(add to (cart|bag)|buy now)$/.test(txt);
  }
  function press() {
    var now = Date.now();
    if (now - lastPressTs > 800) pressSeq++;
    lastPressTs = now;
  }
  // capture phase on WINDOW: runs before the theme / our Volume Discounts block
  // (document capture) can stop the event or start their own add request
  window.addEventListener(
    "click",
    function (e) {
      if (isAddButton(e.target)) {
        press();
        arm("click");
      }
    },
    true,
  );
  window.addEventListener(
    "submit",
    function (e) {
      var f = e.target;
      if (f && f.getAttribute && /\/cart\/add/.test(f.getAttribute("action") || "") && VARIANTS[formVariant(f)]) {
        press();
        arm("submit");
      }
    },
    true,
  );

  // public hook for debugging: window.WCUpsell
  window.WCUpsell = {
    selected: selected,
    // used by our Volume Discounts block before its own /cart/add.js
    beforeAdd: function (qty) {
      return addBefore(Number(qty) || 0, "volume discounts") || Promise.resolve(null);
    },
    pending: readPending,
    reconcile: function () {
      return reconcile("manual");
    },
  };
})();
