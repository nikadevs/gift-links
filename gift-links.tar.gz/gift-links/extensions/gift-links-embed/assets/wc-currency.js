/* WoodenCrew Apps — Currency Converter (replacement for Vitals «Currency Converter»).
 * Data comes from <script id="wc-cc-data"> printed by blocks/gift-links.liquid.
 * Switching = Shopify's own Markets conversion: POST /localization with a country
 * whose currency is the picked one, so cart and checkout use that currency too.
 * Does not touch the cart or any request of the theme / other apps. */
(function () {
  "use strict";
  if (window.__wcCc) return;
  var el = document.getElementById("wc-cc-data");
  if (!el) return;
  var D;
  try { D = JSON.parse(el.textContent || "{}"); } catch (e) { return; }
  window.__wcCc = D;
  var C = D.cfg || {};
  var countries = D.countries || {};
  var names = D.names || {};
  var available = {};
  Object.keys(countries).forEach(function (k) { available[countries[k]] = 1; });
  var list = (D.list || []).filter(function (c) { return available[c]; });
  if (!list.length) return;
  var active = D.active || D.base;
  var bot = /bot|crawl|spider|lighthouse|pagespeed|headless|gtmetrix|pingdom|ptst|inspectiontool/i.test(navigator.userAgent);
  var LS_MANUAL = "wcCc.manual", SS_AUTO = "wcCc.auto", SS_GEO = "wcCc.geo";
  var PREFERRED = { USD: "US", EUR: "DE", GBP: "GB", CAD: "CA", AUD: "AU", NZD: "NZ", CHF: "CH", JPY: "JP", SEK: "SE", DKK: "DK", PLN: "PL", SGD: "SG" };
  var FLAG = { EUR: "eu", XCD: "ag", XOF: "sn", XAF: "cm", XPF: "pf", ANG: "cw" };

  function store(s, k, v) { try { v === undefined ? s.removeItem(k) : s.setItem(k, v); } catch (e) {} }
  function read(s, k) { try { return s.getItem(k); } catch (e) { return null; } }
  function flagUrl(code) { return "https://flagcdn.com/w40/" + (FLAG[code] || code.slice(0, 2).toLowerCase()) + ".png"; }

  /* ---------- country for a currency ---------- */
  function detected() {
    var cached = read(sessionStorage, SS_GEO);
    if (cached !== null) return Promise.resolve(cached);
    var ctl = window.AbortController ? new AbortController() : null;
    var t = setTimeout(function () { ctl && ctl.abort(); }, 2500);
    return fetch("/browsing_context_suggestions.json?country[enabled]=true", { credentials: "same-origin", signal: ctl && ctl.signal })
      .then(function (r) { return r.json(); })
      .then(function (j) {
        var c = (j && j.detected_values && j.detected_values.country && j.detected_values.country.handle) || "";
        store(sessionStorage, SS_GEO, c);
        return c;
      })
      .catch(function () { return ""; })
      .then(function (c) { clearTimeout(t); return c; });
  }
  function countryFor(code, geo) {
    if (countries[D.country] === code) return D.country;
    if (geo && countries[geo] === code) return geo;
    var p = PREFERRED[code];
    if (p && countries[p] === code) return p;
    for (var k in countries) if (countries[k] === code) return k;
    return "";
  }
  function submitCountry(country) {
    var f = document.createElement("form");
    f.method = "post";
    f.action = (D.root || "/") + "localization";
    f.style.display = "none";
    var fields = { form_type: "localization", utf8: "✓", _method: "put", return_to: location.pathname + location.search + location.hash, country_code: country };
    for (var k in fields) {
      var i = document.createElement("input");
      i.type = "hidden"; i.name = k; i.value = fields[k];
      f.appendChild(i);
    }
    document.body.appendChild(f);
    HTMLFormElement.prototype.submit.call(f);
  }
  function switchTo(code, manual) {
    if (code === active) return;
    if (manual) store(localStorage, LS_MANUAL, code);
    detected().then(function (geo) {
      var c = countryFor(code, geo);
      if (c) submitCountry(c);
    });
  }

  /* ---------- dropdown ---------- */
  var ARROW = '<svg viewBox="0 0 20 20" width="20" height="20" aria-hidden="true" focusable="false"><path d="M6.5 8.5 10 11.6l3.5-3.1" fill="none" stroke="currentColor" stroke-width="1.1" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function label(code) {
    return (C.flags ? '<img class="wc-cc-flag" src="' + flagUrl(code) + '" alt="" width="20" height="15" loading="lazy">' : "") + '<span class="wc-cc-code">' + code + "</span>";
  }
  var openDlg = null;
  function close() {
    if (!openDlg) return;
    openDlg.root.classList.remove("wc-cc--open");
    openDlg.btn.setAttribute("aria-expanded", "false");
    openDlg.layer.remove();
    openDlg = null;
  }
  function open(root, btn) {
    close();
    var layer = document.createElement("div");
    layer.className = "wc-cc-layer";
    var back = document.createElement("div");
    back.className = "wc-cc-back";
    var dlg = document.createElement("ul");
    dlg.className = "wc-cc-list";
    dlg.setAttribute("role", "listbox");
    list.forEach(function (code) {
      var li = document.createElement("li");
      li.className = "wc-cc-opt" + (code === active ? " wc-cc-opt--sel" : "");
      li.setAttribute("role", "option");
      li.setAttribute("aria-selected", code === active ? "true" : "false");
      li.tabIndex = 0;
      li.title = names[code] || code;
      li.innerHTML = label(code);
      li.addEventListener("click", function () { close(); switchTo(code, true); });
      li.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); li.click(); }
        if (e.key === "ArrowDown" && li.nextSibling) { e.preventDefault(); li.nextSibling.focus(); }
        if (e.key === "ArrowUp" && li.previousSibling) { e.preventDefault(); li.previousSibling.focus(); }
        if (e.key === "Escape") { close(); btn.focus(); }
      });
      dlg.appendChild(li);
    });
    back.addEventListener("click", close);
    layer.appendChild(back);
    layer.appendChild(dlg);
    document.body.appendChild(layer);
    var r = btn.getBoundingClientRect();
    var up = root.classList.contains("wc-cc--bottom_left") || root.classList.contains("wc-cc--bottom_right");
    var fixed = getComputedStyle(root).position === "fixed";
    var sx = fixed ? 0 : window.pageXOffset, sy = fixed ? 0 : window.pageYOffset;
    layer.style.position = fixed ? "fixed" : "absolute";
    dlg.style.left = Math.max(4, r.left + sx) + "px";
    if (up) dlg.style.top = Math.max(4, r.top + sy - 4 - Math.min(250, dlg.scrollHeight + 2)) + "px";
    else dlg.style.top = r.bottom + sy + 4 + "px";
    var w = dlg.getBoundingClientRect();
    if (w.right > document.documentElement.clientWidth - 4) dlg.style.left = Math.max(4, document.documentElement.clientWidth - 4 - w.width + sx) + "px";
    root.classList.add("wc-cc--open");
    btn.setAttribute("aria-expanded", "true");
    openDlg = { root: root, btn: btn, layer: layer };
    var sel = dlg.querySelector(".wc-cc-opt--sel");
    if (sel && sel.offsetTop + sel.offsetHeight > dlg.clientHeight) dlg.scrollTop = sel.offsetTop + sel.offsetHeight - dlg.clientHeight;
  }
  function build(where) {
    var root = document.createElement("div");
    root.className = "wc-cc wc-cc--" + where;
    var btn = document.createElement("button");
    btn.type = "button";
    btn.className = "wc-cc-btn";
    btn.setAttribute("aria-haspopup", "listbox");
    btn.setAttribute("aria-expanded", "false");
    btn.setAttribute("aria-label", "Currency: " + active);
    btn.innerHTML = '<span class="wc-cc-sel">' + label(active) + '</span><span class="wc-cc-arrow">' + ARROW + "</span>";
    btn.addEventListener("click", function () { openDlg && openDlg.root === root ? close() : open(root, btn); });
    root.appendChild(btn);
    return root;
  }
  function menuTarget() {
    var sel = D.menuSelector || "";
    var t = sel ? document.querySelector(sel) : null;
    if (t) return { parent: t, before: null };
    var logo = document.querySelector("header .header__logo, .header__logo, header [class*='logo']");
    if (logo && logo.parentElement) return { parent: logo.parentElement, before: logo.nextSibling };
    return null;
  }
  function mount() {
    var made = [];
    var mq = window.matchMedia("(max-width: 768px)");
    var spots = [];
    if (C.showDesktop) spots.push({ pos: C.desktopPos || "menu", dev: "d" });
    if (C.showMobile) spots.push({ pos: C.mobilePos || "menu", dev: "m" });
    // same position on both → one element
    if (spots.length === 2 && spots[0].pos === spots[1].pos) spots = [{ pos: spots[0].pos, dev: "dm" }];
    spots.forEach(function (s) {
      var root = build(s.pos);
      root.classList.add("wc-cc--" + s.dev);
      if (s.pos === "menu") {
        var t = menuTarget();
        if (t) t.parent.insertBefore(root, t.before);
        else { root.className = root.className.replace("wc-cc--menu", "wc-cc--top_left wc-cc--fallback"); document.body.appendChild(root); }
      } else document.body.appendChild(root);
      made.push(root);
    });
    var onMq = function () { close(); };
    mq.addEventListener ? mq.addEventListener("change", onMq) : mq.addListener(onMq);
    window.addEventListener("resize", close);
    document.addEventListener("keydown", function (e) { if (e.key === "Escape") close(); });
    return made;
  }

  /* ---------- prices: currency code / original price on hover ---------- */
  var MONEY = ".money, .price-item, .price__regular .price-item, [data-wc-money]";
  function parseAmount(t) {
    var s = String(t).replace(/[^\d.,]/g, "");
    if (!s) return NaN;
    var lc = s.lastIndexOf(","), ld = s.lastIndexOf(".");
    var dec = lc > ld ? "," : ".";
    var parts = s.split(dec);
    if (parts.length > 1 && parts[parts.length - 1].length === 3 && parts.length === 2 && (dec === "," ? ld < 0 : lc < 0)) {
      // "1,234" or "1.234" – a thousands separator, no decimals
      return parseFloat(s.replace(/[.,]/g, ""));
    }
    var whole = parts.slice(0, -1).join("").replace(/[.,]/g, "");
    return parts.length > 1 ? parseFloat(whole + "." + parts[parts.length - 1]) : parseFloat(s.replace(/[.,]/g, ""));
  }
  function addCodes(scope) {
    var nodes = (scope || document).querySelectorAll(MONEY);
    for (var i = 0; i < nodes.length; i++) {
      var n = nodes[i];
      if (n.querySelector(MONEY) || n.closest(".wc-cc")) continue;
      var txt = n.textContent || "";
      if (!/\d/.test(txt) || /\b[A-Z]{3}\b/.test(txt) || n.getAttribute("data-wc-cc") === txt) continue;
      n.appendChild(document.createTextNode(" " + active));
      n.setAttribute("data-wc-cc", n.textContent);
    }
  }
  var tip = null;
  function showTip(n) {
    var amount = parseAmount((n.textContent || "").replace(/\b[A-Z]{3}\b/g, ""));
    var rate = parseFloat((window.Shopify && Shopify.currency && Shopify.currency.rate) || "1");
    if (!isFinite(amount) || !rate) return;
    var base = amount / rate, s;
    try { s = new Intl.NumberFormat(document.documentElement.lang || "en", { style: "currency", currency: D.base }).format(base) + " " + D.base; }
    catch (e) { s = base.toFixed(2) + " " + D.base; }
    if (!tip) { tip = document.createElement("div"); tip.className = "wc-cc-tip"; document.body.appendChild(tip); }
    tip.textContent = s;
    tip.style.display = "block";
    var r = n.getBoundingClientRect(), w = tip.getBoundingClientRect();
    tip.style.left = Math.max(4, Math.min(r.left + r.width / 2 - w.width / 2, document.documentElement.clientWidth - w.width - 4)) + "px";
    tip.style.top = (r.top - w.height - 6 < 0 ? r.bottom + 6 : r.top - w.height - 6) + "px";
  }
  function hideTip() { if (tip) tip.style.display = "none"; }

  /* ---------- cart notice ---------- */
  function cartNotice() {
    if (!C.cartNotice || !D.isCart || active === D.base) return;
    if (document.querySelector(".wc-cc-notice")) return;
    var anchor = document.querySelector("form[action*='/cart'] [name='checkout'], #checkout, .cart__checkout-button, form[action*='/cart'] button[type='submit']");
    if (!anchor) return;
    var p = document.createElement("p");
    p.className = "wc-cc-notice";
    p.textContent = String(C.cartNoticeText || "")
      .replace(/\{\{\s*visible_currency\s*\}\}/g, active)
      .replace(/\{\{\s*default_currency\s*\}\}/g, D.base);
    var host = anchor.parentElement;
    host.parentElement ? host.parentElement.insertBefore(p, host) : host.insertBefore(p, anchor);
  }

  function auto() {
    if (!C.autoConvert || bot || read(localStorage, LS_MANUAL) || read(sessionStorage, SS_AUTO)) return;
    store(sessionStorage, SS_AUTO, "1");
    detected().then(function (geo) {
      var code = geo && countries[geo];
      if (!code || code === active) return;
      if (C.onlyListed && list.indexOf(code) < 0) return;
      submitCountry(geo);
    });
  }

  function start() {
    mount();
    if (C.showCode) {
      addCodes();
      var pend = false;
      new MutationObserver(function () {
        if (pend) return;
        pend = true;
        requestAnimationFrame(function () { pend = false; addCodes(); });
      }).observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    if (C.hoverOriginal && active !== D.base) {
      document.addEventListener("mouseover", function (e) {
        var n = e.target && e.target.closest && e.target.closest(MONEY);
        n && !n.closest(".wc-cc") ? showTip(n) : hideTip();
      });
      window.addEventListener("scroll", hideTip, { passive: true });
    }
    cartNotice();
    auto();
  }
  document.readyState === "loading" ? document.addEventListener("DOMContentLoaded", start) : start();
  window.WcCurrency = { switchTo: function (c) { switchTo(String(c).toUpperCase(), true); }, close: close };
})();
