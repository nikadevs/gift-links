/*
 * WoodenCrew Apps — Bundles: "Included" block under bundle lines on /cart.
 * Data: app.metafields.wc_gb.cart (written by the app from the Bundles page):
 *   { v: { "<variantId>": [["Short title", "imageUrl", qty], …] } } — active bundles only,
 *   every component incl. the main item. Collapsed: icons + "Included" + caret;
 *   a click anywhere on the block opens the list of short names. Cart is never changed.
 */
(function () {
  "use strict";
  var el = document.getElementById("wc-bi");
  if (!el || window.WCBundleItems) return;
  window.WCBundleItems = true;
  var map = {};
  try {
    map = (JSON.parse(el.textContent || "{}") || {}).v || {};
  } catch (e) {
    return;
  }
  var LABEL = el.getAttribute("data-label") || "Included";
  var open = {};

  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function img(u, w) {
    if (!u) return "";
    var base = String(u).split("?")[0];
    return base + "?width=" + w;
  }
  function variantOf(row) {
    var links = row.querySelectorAll("a[href*='variant=']");
    for (var i = 0; i < links.length; i++) {
      var m = /[?&]variant=(\d+)/.exec(links[i].getAttribute("href") || "");
      if (m) return m[1];
    }
    return "";
  }
  function block(vid, items) {
    var thumbs = "";
    var list = "";
    for (var i = 0; i < items.length; i++) {
      var t = items[i][0], u = items[i][1], q = items[i][2] || 1;
      var name = (q > 1 ? q + " × " : "") + t;
      thumbs += '<span class="wc-bi-th">' + (u ? '<img src="' + esc(img(u, 80)) + '" alt="' + esc(t) + '" width="40" height="40" loading="lazy">' : "") + "</span>";
      list += '<li class="wc-bi-li"><span class="wc-bi-im">' + (u ? '<img src="' + esc(img(u, 96)) + '" alt="" width="48" height="48" loading="lazy">' : "") + '</span><span class="wc-bi-nm">' + esc(name) + "</span></li>";
    }
    var isOpen = !!open[vid];
    return (
      '<div class="wc-bi' + (isOpen ? " wc-bi-open" : "") + '" data-vid="' + esc(vid) + '">' +
      '<button type="button" class="wc-bi-head" aria-expanded="' + isOpen + '">' +
      '<span class="wc-bi-ths">' + thumbs + "</span>" +
      '<span class="wc-bi-lb">' + esc(LABEL) + '</span><span class="wc-bi-car" aria-hidden="true"></span></button>' +
      '<ul class="wc-bi-list"' + (isOpen ? "" : " hidden") + ">" + list + "</ul></div>"
    );
  }
  function apply() {
    var rows = document.querySelectorAll("tr.cart-item");
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var vid = variantOf(row);
      var items = vid && map[vid];
      var next = row.nextElementSibling;
      var has = next && next.classList.contains("wc-bi-row");
      if (!items || !items.length) {
        if (has) next.parentNode.removeChild(next);
        continue;
      }
      if (has && next.getAttribute("data-vid") === vid) continue;
      if (has) next.parentNode.removeChild(next);
      var tr = document.createElement("tr");
      tr.className = "wc-bi-row";
      tr.setAttribute("data-vid", vid);
      tr.innerHTML = '<td colspan="6">' + block(vid, items) + "</td>";
      row.parentNode.insertBefore(tr, row.nextSibling);
      row.classList.add("wc-bi-has");
    }
  }
  document.addEventListener("click", function (e) {
    var head = e.target && e.target.closest ? e.target.closest(".wc-bi-head") : null;
    if (!head) return;
    e.preventDefault();
    var box = head.parentNode;
    var vid = box.getAttribute("data-vid");
    var on = !box.classList.contains("wc-bi-open");
    open[vid] = on;
    box.classList.toggle("wc-bi-open", on);
    head.setAttribute("aria-expanded", on);
    var ul = box.querySelector(".wc-bi-list");
    if (ul) ul.hidden = !on;
  });
  var t = 0;
  function later() {
    clearTimeout(t);
    t = setTimeout(apply, 30);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", apply);
  else apply();
  new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var n = muts[i].target;
      if (n && n.closest && n.closest(".wc-bi-row")) continue;
      later();
      return;
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener("wc:cart-page-rendered", later);
})();
