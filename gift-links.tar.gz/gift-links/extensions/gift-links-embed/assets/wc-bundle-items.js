/*
 * WoodenCrew Apps — Bundles: "Included" block under bundle lines on /cart.
 * Data: app.metafields.wc_gb.cart (written by the app from the Bundles page):
 *   { v: { "<variantId>": [["Short title", "imageUrl", qty], …] } } — active bundles only,
 *   every component incl. the main item. Collapsed: icons + "Included" + caret;
 *   a click anywhere on the block opens the list of short names. Cart is never changed.
 */
(function () {
  "use strict";
  var el = document.getElementById("wc-bi");
  if (!el || window.WCBundleItems) return;
  window.WCBundleItems = true;
  var map = {};
  try {
    map = (JSON.parse(el.textContent || "{}") || {}).v || {};
  } catch (e) {
    return;
  }
  var LABEL = el.getAttribute("data-label") || "Included";
  var open = {};

  function esc(s) {
    return String(s == null ? "" : s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;");
  }
  function img(u, w) {
    if (!u) return "";
    var base = String(u).split("?")[0];
    return base + "?width=" + w;
  }
  function variantOf(row) {
    var links = row.querySelectorAll("a[href*='variant=']");
    for (var i = 0; i < links.length; i++) {
      var m = /[?&]variant=(\d+)/.exec(links[i].getAttribute("href") || "");
      if (m) return m[1];
    }
    return "";
  }
  function block(vid, items) {
    var thumbs = "";
    var list = "";
    for (var i = 0; i < items.length; i++) {
      var t = items[i][0], u = items[i][1], q = items[i][2] || 1;
      var name = (q > 1 ? q + " × " : "") + t;
      thumbs += '<span class="wc-bi-th">' + (u ? '<img src="' + esc(img(u, 80)) + '" alt="' + esc(t) + '" width="40" height="40" loading="lazy">' : "") + "</span>";
      list += '<li class="wc-bi-li"><span class="wc-bi-im">' + (u ? '<img src="' + esc(img(u, 96)) + '" alt="" width="48" height="48" loading="lazy">' : "") + '</span><span class="wc-bi-nm">' + esc(name) + "</span></li>";
    }
    var isOpen = !!open[vid];
    return (
      '<div class="wc-bi' + (isOpen ? " wc-bi-open" : "") + '" data-vid="' + esc(vid) + '">' +
      '<div class="wc-bi-head" role="button" tabindex="0" aria-expanded="' + isOpen + '">' +
      '<span class="wc-bi-ths">' + thumbs + "</span>" +
      '<span class="wc-bi-lb">' + esc(LABEL) + '</span><span class="wc-bi-car" aria-hidden="true"></span></div>' +
      '<ul class="wc-bi-list"' + (isOpen ? "" : " hidden") + ">" + list + "</ul></div>"
    );
  }
  // $0 lines (gift copies of the same product) get no block — from /cart.js, by line position
  var free = {};
  var ROOT = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
  function loadCart() {
    return fetch(ROOT.replace(/\/?$/, "/") + "cart.js", { credentials: "same-origin" })
      .then(function (r) { return r.json(); })
      .then(function (c) {
        free = {};
        (c.items || []).forEach(function (it, i) {
          if (Number(it.final_line_price) === 0 && Number(it.original_line_price) > 0) free[i + 1] = true;
        });
      })
      .catch(function () {});
  }
  function lineNo(row) {
    var m = /CartItem-(\d+)/.exec(row.id || "");
    return m ? Number(m[1]) : 0;
  }
  function apply() {
    var rows = document.querySelectorAll("tr.cart-item");
    for (var i = 0; i < rows.length; i++) {
      var row = rows[i];
      var vid = variantOf(row);
      var items = vid && !free[lineNo(row)] && map[vid];
      var next = row.nextElementSibling;
      var has = next && next.classList.contains("wc-bi-row");
      if (!items || !items.length) {
        if (has) next.parentNode.removeChild(next);
        continue;
      }
      if (has && next.getAttribute("data-vid") === vid) continue;
      if (has) next.parentNode.removeChild(next);
      var tr = document.createElement("tr");
      tr.className = "wc-bi-row";
      tr.setAttribute("data-vid", vid);
      tr.innerHTML = '<td colspan="6">' + block(vid, items) + "</td>";
      row.parentNode.insertBefore(tr, row.nextSibling);
      row.classList.add("wc-bi-has");
    }
  }
  function toggleFrom(e) {
    var head = e.target && e.target.closest ? e.target.closest(".wc-bi-head") : null;
    if (!head) return;
    if (e.type === "keydown" && e.key !== "Enter" && e.key !== " ") return;
    e.preventDefault();
    var box = head.parentNode;
    var vid = box.getAttribute("data-vid");
    var on = !box.classList.contains("wc-bi-open");
    open[vid] = on;
    box.classList.toggle("wc-bi-open", on);
    head.setAttribute("aria-expanded", on);
    var ul = box.querySelector(".wc-bi-list");
    if (ul) ul.hidden = !on;
  }
  document.addEventListener("click", toggleFrom);
  document.addEventListener("keydown", toggleFrom);
  var t = 0;
  var lastSig = "";
  function later() {
    clearTimeout(t);
    t = setTimeout(function () {
      // refetch the cart only when the theme re-rendered the lines
      var sig = Array.prototype.map.call(document.querySelectorAll("tr.cart-item"), function (r) { return r.id + ":" + variantOf(r) + ":" + (r.textContent || "").length; }).join("|");
      if (sig === lastSig) return apply();
      lastSig = sig;
      loadCart().then(apply);
    }, 60);
  }
  function start() {
    lastSig = Array.prototype.map.call(document.querySelectorAll("tr.cart-item"), function (r) { return r.id + ":" + variantOf(r) + ":" + (r.textContent || "").length; }).join("|");
    loadCart().then(apply);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
  new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var n = muts[i].target;
      if (n && n.closest && n.closest(".wc-bi-row")) continue;
      later();
      return;
    }
  }).observe(document.documentElement, { childList: true, subtree: true });
  document.addEventListener("wc:cart-page-rendered", later);
})();
