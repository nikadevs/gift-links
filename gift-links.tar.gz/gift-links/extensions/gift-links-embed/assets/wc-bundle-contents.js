(function () {
  "use strict";
  if (customElements.get("wc-bundle-contents")) return;
  customElements.define("wc-bundle-contents", class extends HTMLElement {
    connectedCallback() {
      this.variants = JSON.parse(this.dataset.variants || "{}");
      this.closeBanner = () => { const banner = this.querySelector('.wcb-banner'); if (banner) banner.hidden = true; };
      this.querySelector('.wcb-banner-close')?.addEventListener('click', this.closeBanner);
      this.update = () => {
        cancelAnimationFrame(this.frame);
        clearTimeout(this.timer);
        this.frame = requestAnimationFrame(() => this.select());
        this.timer = setTimeout(() => this.select(), 150);
      };
      this.events = ["change", "variant:change", "variant-change", "product:variant-change", "shopify:section:load"];
      this.events.forEach(name => document.addEventListener(name, this.update));
      window.addEventListener("popstate", this.update);
      this.select();
    }
    select() {
      const section = this.closest(".shopify-section");
      const forms = (section || document).querySelectorAll("form[action*='/cart/add']");
      let id;
      for (const form of forms) {
        const input = form.querySelector("[name='id']");
        if (input && Object.prototype.hasOwnProperty.call(this.variants, input.value)) { id = input.value; break; }
      }
      if (!id) id = new URLSearchParams(location.search).get("variant");
      if (!Object.prototype.hasOwnProperty.call(this.variants, id)) return;
      this.querySelectorAll("[data-panel]").forEach(panel => { panel.hidden = panel.dataset.panel !== this.variants[id]; });
      const panel = this.querySelector("[data-panel]:not([hidden])");
      this.hidden = !panel || !panel.querySelector(".wcb-card");
    }
    disconnectedCallback() {
      this.querySelector('.wcb-banner-close')?.removeEventListener('click', this.closeBanner);
      this.events.forEach(name => document.removeEventListener(name, this.update));
      window.removeEventListener("popstate", this.update);
      cancelAnimationFrame(this.frame);
      clearTimeout(this.timer);
    }
  });
}());
