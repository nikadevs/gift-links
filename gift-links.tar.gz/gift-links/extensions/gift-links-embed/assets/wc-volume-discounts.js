/*
 * WoodenCrew Apps — Volume Discounts (storefront).
 *
 * 1. Product page: renders "Buy N with X% off" tiers (data from Liquid,
 *    #wcvd-product), 1:1 with the Vitals block. The selected tier shows, per
 *    item (#1, #2 …), the photo of the chosen variant + a select with all
 *    variants; free gifts show their photo + a variant select. Add to cart with a 2+
 *    tier adds the chosen variants with ONE /cart/add.js request.
 * 2. Every page: cart sync. For each active offer it counts the offer's
 *    products in the cart, finds the reached tier and keeps exactly one line
 *    of each of that tier's gifts ($0 copies) with the hidden property
 *    _wc_vd_gift. Other lines are never touched, except a $0 gift variant of a
 *    product tagged gift-links-gift / wc-vd-gift that sits in the cart WITHOUT
 *    our property (added by hand) — that one is removed, so it can't be bought
 *    on its own. Untagged $0 products (bundle parts…) are never removed.
 *
 * The % discount is a native Shopify automatic discount (created by the app),
 * so checkout prices are right even if this script doesn't run.
 */
(function () {
  "use strict";
  var cfgEl = document.getElementById("wcvd-config");
  var bootEl = document.getElementById("wcvd-boot");
  if (!cfgEl || !bootEl || window.WCVolume) return;

  var ROOT = cfgEl.getAttribute("data-root") || "/";
  if (ROOT.charAt(ROOT.length - 1) !== "/") ROOT += "/";
  var SHOP = cfgEl.getAttribute("data-shop") || "";
  var BEACON = cfgEl.getAttribute("data-beacon") || "";
  var CURRENCY = cfgEl.getAttribute("data-currency") || "USD";
  var LOCALE = cfgEl.getAttribute("data-locale") || "en";
  var AFTER_ADD = cfgEl.getAttribute("data-after-add") === "stay" ? "stay" : "cart";
  var DEBUG = cfgEl.getAttribute("data-debug") === "true";
  var GIFT_PROP = "_wc_vd_gift";
  var CHOICE_KEY = "wcvd.choice.v1";
  var CART_RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|\/|$)/;

  function log() {
    if (!DEBUG || !window.console) return;
    var a = Array.prototype.slice.call(arguments);
    a.unshift("[Volume Discounts]");
    console.log.apply(console, a);
  }

  var boot = { offers: [], giftVariants: [] };
  try {
    boot = JSON.parse(bootEl.textContent || "{}");
  } catch (e) {
    log("bad boot json", e);
  }
  var OFFERS = (boot.offers || []).map(function (o) {
    o.tiers = (o.tiers || []).slice().sort(function (a, b) {
      return a.qty - b.qty;
    });
    o.products = (o.products || []).map(String);
    return o;
  });
  var GIFT_SET = {};
  (boot.giftVariants || []).forEach(function (v) {
    GIFT_SET[String(v)] = true;
  });

  var rawFetch = window.fetch.bind(window);
  function api(path, body) {
    return rawFetch(ROOT + path, {
      method: body ? "POST" : "GET",
      credentials: "same-origin",
      headers: body
        ? { "Content-Type": "application/json", Accept: "application/json" }
        : { Accept: "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) {
          var err = new Error((d && (d.description || d.message)) || "HTTP " + r.status);
          err.status = r.status;
          throw err;
        }
        return d;
      });
    });
  }

  function readChoice() {
    try {
      return JSON.parse(window.localStorage.getItem(CHOICE_KEY) || "{}") || {};
    } catch (e) {
      return {};
    }
  }
  function saveChoice(productId, variantId) {
    var c = readChoice();
    c[String(productId)] = String(variantId);
    try {
      window.localStorage.setItem(CHOICE_KEY, JSON.stringify(c));
    } catch (e) {
      // private mode — the first variant is used then
    }
  }

  // =====================  cart sync (every page)  =====================

  /** What has to change in this cart. Exported for tests via WCVolume.plan */
  function plan(cart) {
    var lines = (cart && cart.items) || [];
    var choice = readChoice();
    var required = {}; // slot → gift
    OFFERS.forEach(function (o) {
      var counts = {};
      if (o.combineProducts !== false) counts.all = 0;
      lines.forEach(function (l) {
        if (l.properties && l.properties[GIFT_PROP]) return;
        var pid = String(l.product_id);
        if (o.products.indexOf(pid) < 0) return;
        var group = o.combineProducts === false ? pid : "all";
        counts[group] = (counts[group] || 0) + l.quantity;
      });
      Object.keys(counts).forEach(function (group) {
        var count = counts[group];
        var tier = null;
        o.tiers.forEach(function (t) {
          if (count >= t.qty) tier = t;
        });
        if (!tier) return;
        (tier.gifts || []).forEach(function (g) {
          required[o.id + (o.combineProducts === false ? ":" + group : "") + ":" + g.p] = g;
        });
      });
    });

    var remove = []; // { key, quantity }
    var seen = {};
    lines.forEach(function (l) {
      var vid = String(l.variant_id);
      var slot = l.properties && l.properties[GIFT_PROP];
      if (!slot) {
        // a gift variant without our property: added by hand / by a link → not allowed.
        // A Gift Links campaign line (_gift_link) is legit: a campaign may use the same $0 gift copy.
        if (GIFT_SET[vid] && Number(l.original_price) === 0 && !(l.properties && l.properties._gift_link))
          remove.push({ key: l.key, quantity: 0 });
        return;
      }
      var g = required[slot];
      var ok = g && (g.v || []).map(String).indexOf(vid) >= 0;
      if (!ok || seen[slot]) {
        remove.push({ key: l.key, quantity: 0 });
        return;
      }
      seen[slot] = true;
      if (l.quantity !== 1) remove.push({ key: l.key, quantity: 1 });
    });

    var add = [];
    Object.keys(required).forEach(function (slot) {
      if (seen[slot]) return;
      var g = required[slot];
      var vs = (g.v || []).map(String);
      var pick = choice[String(g.p)];
      var order = pick && vs.indexOf(pick) >= 0 ? [pick].concat(vs.filter(function (v) { return v !== pick; })) : vs;
      if (order.length) add.push({ slot: slot, variants: order });
    });
    return { remove: remove, add: add };
  }

  var syncing = null;
  var syncAgain = false;
  var syncTimes = [];

  function sync(reason) {
    if (!OFFERS.length && !Object.keys(GIFT_SET).length) return Promise.resolve(false);
    if (syncing) {
      syncAgain = true;
      return syncing;
    }
    var now = Date.now();
    syncTimes = syncTimes.filter(function (t) {
      return now - t < 15000;
    });
    if (syncTimes.length >= 8) {
      log("sync rate limit");
      return Promise.resolve(false);
    }
    syncTimes.push(now);
    var changed = false;
    syncing = api("cart.js")
      .then(function (cart) {
        var p = plan(cart);
        log("sync", reason, p);
        var chain = Promise.resolve();
        p.remove.forEach(function (r) {
          chain = chain.then(function () {
            changed = true;
            return api("cart/change.js", { id: r.key, quantity: r.quantity }).catch(function (e) {
              log("change failed", e);
            });
          });
        });
        p.add.forEach(function (a) {
          chain = chain.then(function () {
            // first variant that is in stock
            return a.variants.reduce(function (c, vid) {
              return c.then(function (done) {
                if (done) return true;
                return api("cart/add.js", {
                  items: [{ id: Number(vid), quantity: 1, properties: { _wc_vd_gift: a.slot } }],
                }).then(
                  function () {
                    changed = true;
                    return true;
                  },
                  function (e) {
                    log("gift add failed", vid, e && e.message);
                    return false;
                  },
                );
              });
            }, Promise.resolve(false));
          });
        });
        return chain;
      })
      .catch(function (e) {
        log("sync error", e);
      })
      .then(function () {
        syncing = null;
        if (changed) refreshUI();
        if (syncAgain) {
          syncAgain = false;
          return sync("again").then(function (c2) {
            return changed || c2;
          });
        }
        return changed;
      });
    return syncing;
  }

  var timer = null;
  function scheduleSync(reason) {
    clearTimeout(timer);
    timer = setTimeout(function () {
      sync(reason);
    }, 350);
  }

  // ---------- /cart page: re-render in place, never reload (shared by all WoodenCrew Apps scripts) ----------
  // The first of our scripts defines window.WCCartPage; the others reuse it, so several
  // modules changing the cart at once give ONE re-render. Same steps as the theme's own
  // CartItems.updateQuantity (Umino): section HTML → .js-contents, totals, gift wrap, counts.
  if (!window.WCCartPage) {
    window.WCCartPage = (function () {
      var timer = null;
      var running = null;
      var again = false;
      var waiters = [];
      var RELOAD_KEY = "wcCartPage.reload";
      function root() {
        var r = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
        return r.charAt(r.length - 1) === "/" ? r : r + "/";
      }
      function isCartPage() {
        return /\/cart\/?$/.test(window.location.pathname);
      }
      function pick(doc, sel) {
        return doc.querySelector(sel);
      }
      function render() {
        var main = document.getElementById("main-cart-items");
        var sec = main && main.closest('[id^="shopify-section-"]');
        var id = (main && main.getAttribute("data-id")) || (sec && sec.id.replace("shopify-section-", ""));
        if (!id || !sec) return Promise.reject(new Error("cart section not found"));
        // no Accept: application/json here — with it Shopify answers /cart?sections= with cart JSON
        var get = function (path) {
          return window.fetch(root() + path, { credentials: "same-origin" }).then(function (r) {
            if (!r.ok) throw new Error(path + " " + r.status);
            return r.json();
          });
        };
        return Promise.all([get("cart?sections=" + encodeURIComponent(id)), get("cart.js")]).then(function (res) {
          var html = res[0] && res[0][id];
          var cart = res[1];
          if (!html) throw new Error("empty section");
          var doc = new DOMParser().parseFromString(html, "text/html");
          var curC = main.querySelector(".js-contents");
          var newC = pick(doc, "#main-cart-items .js-contents") || pick(doc, ".js-contents");
          if (cart.item_count > 0 && curC && newC) {
            curC.innerHTML = newC.innerHTML;
            var t1 = document.querySelector(".cart__footer .totals");
            var t2 = pick(doc, ".cart__footer .totals");
            if (t1 && t2) t1.innerHTML = t2.innerHTML;
            var g1 = document.getElementById("bls__gift");
            var g2 = doc.getElementById("bls__gift");
            if (g1 && g2) g1.innerHTML = g2.innerHTML;
          } else {
            // empty ↔ not empty: the layout changes, swap the whole cart wrapper
            var w1 = document.querySelector(".cart-wrapper") || main;
            var w2 = pick(doc, ".cart-wrapper") || pick(doc, "#main-cart-items");
            if (!w1 || !w2) throw new Error("cart wrapper not found");
            w1.innerHTML = w2.innerHTML;
          }
          var counts = document.querySelectorAll(".cart-count");
          for (var i = 0; i < counts.length; i++)
            counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer") ? "(" + cart.item_count + ")" : cart.item_count;
          try {
            var tp = document.querySelector("header-total-price");
            if (tp && tp.updateTotal) tp.updateTotal(cart);
            var fs = document.querySelector("free-ship-progress-bar");
            if (fs && fs.init) fs.init(cart.items_subtotal_price);
            var ci = document.querySelector("cart-items");
            if (ci && "currentItemCount" in ci) ci.currentItemCount = cart.item_count;
            if (window.BlsLazyloadImg && window.BlsLazyloadImg.init) window.BlsLazyloadImg.init();
            document.dispatchEvent(new CustomEvent("wc:cart-page-rendered", { detail: { cart: cart } }));
          } catch (e) {
            // theme extras are optional
          }
          return cart;
        });
      }
      function fallbackReload() {
        // last resort, at most once per 10 s for ALL our scripts together
        try {
          var last = Number(window.sessionStorage.getItem(RELOAD_KEY) || 0);
          if (Date.now() - last < 10000) return;
          window.sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
        } catch (e) {
          return; // can't guard → don't reload
        }
        window.location.reload();
      }
      function run() {
        running = render()
          .catch(function () {
            fallbackReload();
          })
          .then(function () {
            running = null;
            if (again) {
              again = false;
              return run();
            }
            var w = waiters;
            waiters = [];
            w.forEach(function (f) {
              f();
            });
          });
        return running;
      }
      function refresh(delay) {
        if (!isCartPage()) return Promise.resolve();
        return new Promise(function (resolve) {
          waiters.push(resolve);
          clearTimeout(timer);
          timer = setTimeout(function () {
            if (running) again = true;
            else run();
          }, delay == null ? 250 : delay);
        });
      }
      return { refresh: refresh, isCartPage: isCartPage };
    })();
  }

  // ---------- refresh the theme's cart UI ----------
  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-volume:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      window.WCCartPage.refresh(); // re-render in place, no reload
      return;
    }
    api("cart.js")
      .then(function (cart) {
        var counts = document.querySelectorAll(".cart-count");
        for (var i = 0; i < counts.length; i++) {
          counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer")
            ? "(" + cart.item_count + ")"
            : cart.item_count;
        }
      })
      .catch(function () {});
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    if (!ids.length) return;
    rawFetch(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          return new DOMParser().parseFromString(html || "", "text/html").querySelector(sel);
        };
        var swap = function (id, html, sel) {
          var el = document.getElementById(id);
          var next = html && parse(html, sel);
          if (el && next) el.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", sections["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", sections["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", sections["cart-drawer"], "#CartDrawer");
      })
      .catch(function () {});
  }

  // ---------- watch the theme / other apps changing the cart ----------
  window.fetch = function (input, init) {
    var p = rawFetch(input, init);
    try {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      if (CART_RE.test(url))
        p.then(
          function () {
            scheduleSync("fetch");
          },
          function () {},
        );
    } catch (e) {
      // ignore
    }
    return p;
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, u) {
    try {
      if (CART_RE.test(String(u)))
        this.addEventListener("load", function () {
          scheduleSync("xhr");
        });
    } catch (e) {
      // ignore
    }
    return xhrOpen.apply(this, arguments);
  };

  if (Number(cfgEl.getAttribute("data-cart-count") || 0) > 0) scheduleSync("load");
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) scheduleSync("bfcache");
  });

  window.WCVolume = { sync: sync, plan: plan, offers: OFFERS };

  // =====================  product page block  =====================
  var root = document.getElementById("wcvd-root");
  var dataEl = document.getElementById("wcvd-product");
  if (!root || !dataEl) return;
  var D;
  try {
    D = JSON.parse(dataEl.textContent || "{}");
  } catch (e) {
    log("bad product json", e);
    return;
  }
  var TIERS = D.tiers || [];
  if (!TIERS.length) return;
  var VARIANTS = D.variants || [];
  var VMAP = {};
  VARIANTS.forEach(function (v) {
    VMAP[String(v.id)] = v;
  });
  var MULTI = VARIANTS.length > 1;
  var SELECTOR = root.getAttribute("data-selector") || "form[action*='/cart/add']";
  var POSITION = root.getAttribute("data-position") === "after" ? "after" : "before";

  var sel = Math.min(Math.max(Number(D.defaultTier) || 0, 0), TIERS.length - 1);
  var visible = Math.max(1, Number(D.visible) || 3);
  var expanded = sel >= visible;
  var slots = []; // variant id per item of the selected tier
  var touched = []; // slot changed by the shopper
  var clicked = false;
  var busy = false;
  var errorText = "";

  var fmt;
  try {
    fmt = new Intl.NumberFormat(LOCALE, { style: "currency", currency: CURRENCY, currencyDisplay: "narrowSymbol" });
  } catch (e) {
    fmt = null;
  }
  function money(cents) {
    var n = Math.round(cents) / 100;
    return fmt ? fmt.format(n) : "$" + n.toFixed(2);
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function ourForm() {
    var forms = document.querySelectorAll("form[action*='/cart/add']");
    for (var i = 0; i < forms.length; i++) {
      var f = forms[i];
      if (root.contains(f)) continue;
      var idEl = f.querySelector('[name="id"]');
      if (idEl && VMAP[String(Number(idEl.value))]) return f;
    }
    return null;
  }
  function currentVariant() {
    var f = ourForm();
    var idEl = f && f.querySelector('[name="id"]');
    var id = idEl ? String(Number(idEl.value)) : "";
    if (VMAP[id]) return id;
    for (var i = 0; i < VARIANTS.length; i++) if (VARIANTS[i].available) return String(VARIANTS[i].id);
    return String(VARIANTS[0].id);
  }

  function resetSlots() {
    var t = TIERS[sel];
    var cur = currentVariant();
    var next = [];
    var nextTouched = [];
    for (var i = 0; i < t.qty; i++) {
      // #1 is always the variant picked in the theme's own picker (linked both ways)
      if (i > 0 && touched[i] && slots[i]) {
        next.push(slots[i]);
        nextTouched.push(true);
      } else {
        next.push(cur);
        nextTouched.push(false);
      }
    }
    slots = next;
    touched = nextTouched;
  }
  function followTheme() {
    var cur = currentVariant();
    for (var i = 0; i < slots.length; i++) if (i === 0 || !touched[i]) slots[i] = cur;
  }

  // ---------- link #1 with the theme's own variant picker ----------
  /** pick the variant in the theme picker above (its slider, price and URL follow) */
  function setThemeVariant(vid) {
    var v = VMAP[String(vid)];
    if (!v || currentVariant() === String(vid)) return;
    var seq = themeSeq;
    var opts = v.opts || [];
    var pickers = document.querySelectorAll("variant-selects, variant-radios, variant-picker, .product-form__input");
    var done = 0;
    opts.forEach(function (val) {
      for (var p = 0; p < pickers.length; p++) {
        var pk = pickers[p];
        if (root.contains(pk)) continue;
        // Umino-style swatches: <div class="bls__product-color-swatches" data-value="…">
        var sws = pk.querySelectorAll("[data-value]");
        for (var j = 0; j < sws.length; j++) {
          if (sws[j].getAttribute("data-value") !== val) continue;
          if (!sws[j].classList.contains("active")) sws[j].click();
          done++;
          return;
        }
        // Dawn-style: radios / selects named for the option
        var r = pk.querySelector('input[type="radio"][value="' + String(val).replace(/"/g, '\\"') + '"]');
        if (r) {
          if (!r.checked) r.click();
          done++;
          return;
        }
        var sels = pk.querySelectorAll("select");
        for (var k = 0; k < sels.length; k++) {
          var o = sels[k].querySelector('option[value="' + String(val).replace(/"/g, '\\"') + '"]');
          if (!o) continue;
          if (sels[k].value !== val) {
            sels[k].value = val;
            sels[k].dispatchEvent(new Event("change", { bubbles: true }));
          }
          done++;
          return;
        }
      }
    });
    // no picker found (or it didn't react): at least the theme form adds the right variant
    clearTimeout(fallbackTimer);
    fallbackTimer = setTimeout(function () {
      // the theme reacted (or the customer already picked something else up there) → leave it
      if (currentVariant() === String(vid) || themeSeq !== seq) return;
      var f = ourForm();
      var idEl = f && f.querySelector('[name="id"]');
      if (idEl) {
        idEl.value = String(vid);
        idEl.dispatchEvent(new Event("change", { bubbles: true }));
      }
      log("theme picker not found/changed, set form id", done);
    }, 400);
  }

  var lastTheme = "";
  var themeSeq = 0; // +1 on every variant change seen in the theme picker
  var fallbackTimer = 0;
  function syncFromTheme() {
    var cur = currentVariant();
    if (cur === lastTheme) return;
    lastTheme = cur;
    themeSeq++;
    followTheme();
    render();
  }

  function freeCount(t) {
    return Math.max(0, Number(t.free) || 0);
  }
  function tierPrices(i) {
    var t = TIERS[i];
    var prices = [];
    if (i === sel && slots.length === t.qty) {
      slots.forEach(function (vid) {
        prices.push((VMAP[vid] || VARIANTS[0]).price);
      });
    } else {
      var p = (VMAP[currentVariant()] || VARIANTS[0]).price;
      for (var k = 0; k < t.qty; k++) prices.push(p);
    }
    var full = 0;
    prices.forEach(function (p) {
      full += p;
    });
    var n = freeCount(t);
    if (n) {
      // Shopify Buy X Get Y makes the cheapest items free
      var sorted = prices.slice().sort(function (a, b) {
        return a - b;
      });
      var off = 0;
      for (var j = 0; j < n && j < sorted.length; j++) off += sorted[j];
      return { full: full, total: full - off };
    }
    var total = full - Math.round((full * (Number(t.percent) || 0)) / 100);
    return { full: full, total: total };
  }

  function giftChoice(g) {
    var c = readChoice()[String(g.p)];
    var ok = (g.variants || []).filter(function (v) {
      return v.available !== false;
    });
    for (var i = 0; i < ok.length; i++) if (String(ok[i].id) === c) return c;
    return ok.length ? String(ok[0].id) : "";
  }

  var CHEVRON =
    '<svg class="wcvd-chev" width="20" height="20" viewBox="0 0 20 20" aria-hidden="true"><path d="M6 8l4 4 4-4" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  var CHECK =
    '<svg class="wcvd-check" width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><path d="M4.5 11.5l4.2 4.2 8.8-9.4" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>';

  function variantImage(list, id, fallback) {
    for (var i = 0; i < list.length; i++) if (String(list[i].id) === String(id) && list[i].image) return list[i].image;
    return fallback || "";
  }
  function variantById(list, id) {
    for (var i = 0; i < list.length; i++) if (String(list[i].id) === String(id)) return list[i];
    return null;
  }

  // ---------- reuse the photos the theme already loaded (no extra downloads) ----------
  // "files/Pillow-Gray_small.png?v=1" and "files/Pillow-Gray.png?v=1&width=820" → "pillow-gray.png"
  function fileKey(u) {
    if (!u) return "";
    var p = String(u).split("?")[0].split("#")[0];
    var f = p.substring(p.lastIndexOf("/") + 1);
    f = f.replace(/_(pico|icon|thumb|small|compact|medium|large|grande|original|master|\d+x\d*|x\d+)(_crop_[a-z]+)?(@\dx)?(?=\.[a-z0-9]+$)/i, "");
    try {
      f = decodeURIComponent(f);
    } catch (e) {
      // keep as is
    }
    return f.toLowerCase();
  }
  var themeThumbs = null; // fileKey → URL of the theme's own variant swatch photo
  var themeBig = null; // fileKey → <img> of the product media slider
  function scanTheme() {
    themeThumbs = {};
    themeBig = {};
    var sw = document.querySelectorAll(".bls__product-color-swatches, .bls__option-swatch, [data-image]");
    for (var i = 0; i < sw.length; i++) {
      if (root.contains(sw[i])) continue;
      var bg = "";
      try {
        bg = getComputedStyle(sw[i]).backgroundImage || "";
      } catch (e) {
        bg = "";
      }
      var m = /url\(["']?([^"')]+)["']?\)/.exec(bg);
      if (m) {
        var k = fileKey(m[1]);
        if (k && !themeThumbs[k]) themeThumbs[k] = m[1];
      }
    }
    var imgs = document.querySelectorAll(
      ".bls__prod-media img, .product__media img, .product-media img, media-gallery img, [class*='product-gallery'] img, [class*='product__media'] img",
    );
    for (var j = 0; j < imgs.length; j++) {
      if (root.contains(imgs[j])) continue;
      var key = fileKey(imgs[j].currentSrc || imgs[j].src || "");
      if (key && !themeBig[key]) themeBig[key] = imgs[j];
    }
  }
  function sliderSrc(url) {
    if (!url) return "";
    if (!themeBig) scanTheme();
    var el = themeBig[fileKey(url)];
    return el ? el.currentSrc || el.src || "" : "";
  }
  /** thumbnail: the theme swatch photo, else the slider photo, else our own small URL */
  function thumbSrc(url) {
    if (!url) return "";
    if (!themeThumbs) scanTheme();
    return themeThumbs[fileKey(url)] || sliderSrc(url) || url;
  }

  // ---------- variant dropdown: photo + name + chevron, opens a list of photos (inline, pushes content down) ----------
  var openPk = ""; // "<kind>:<idx>" of the open dropdown
  function pkImg(v) {
    return v && v.image ? '<img class="wcvd-pk-img" src="' + esc(thumbSrc(v.image)) + '" alt="" width="52" height="52" decoding="async">' : "";
  }
  function picker(kind, idx, list, value, label) {
    var key = kind + ":" + idx;
    var open = openPk === key;
    var cur = variantById(list, value) || list[0] || {};
    var a = ' data-kind="' + kind + '" data-idx="' + esc(idx) + '"';
    var h = '<div class="wcvd-pk' + (open ? " is-open" : "") + '"' + a + ">";
    h += '<button type="button" class="wcvd-pk-btn" aria-haspopup="listbox" aria-expanded="' + open + '" aria-label="' + esc(label + ": " + (cur.title || "")) + '"' + a + ' data-v="' + esc(cur.id) + '">' +
      pkImg(cur) + '<span class="wcvd-pk-t">' + esc(cur.title || "Default") + "</span>" + CHEVRON + "</button>";
    if (open) {
      h += '<div class="wcvd-pk-list" role="listbox" aria-label="' + esc(label) + '">';
      list.forEach(function (v) {
        var na = v.available === false;
        var on = String(v.id) === String(value);
        h += '<button type="button" class="wcvd-opt' + (on ? " is-on" : "") + (na ? " is-na" : "") + '" role="option" aria-selected="' + on + '"' +
          (na ? ' aria-disabled="true"' : "") + a + ' data-v="' + esc(v.id) + '">' + pkImg(v) +
          '<span class="wcvd-pk-t">' + esc(v.title || "Default") + (na ? ' <small>Sold out</small>' : "") + "</span>" + (on ? CHECK : "") + "</button>";
      });
      h += "</div>";
    }
    return h + "</div>";
  }

  var SHOW_HEADER = root.getAttribute("data-show-header") === "true";
  var SHOW_BADGE = root.getAttribute("data-show-badge") === "true";

  function render() {
    var h = "";
    if (SHOW_HEADER && D.header) h += '<div class="wcvd-h"><span>' + esc(D.header) + "</span></div>";
    h += '<ul class="wcvd-list">';
    TIERS.forEach(function (t, i) {
      if (i >= visible && !expanded && i !== sel) return;
      var on = i === sel;
      var pr = tierPrices(i);
      var free = freeCount(t);
      var pct = free ? 0 : Number(t.percent) || 0;
      var badge = SHOW_BADGE && t.label;
      h += '<li class="wcvd-tier' + (on ? " is-on" : "") + (badge ? " has-badge" : "") + '" role="radio" tabindex="0" aria-checked="' + on + '" data-tier="' + i + '">';
      if (badge) h += '<span class="wcvd-badge">' + esc(t.label) + "</span>";
      h += '<div class="wcvd-row"><span class="wcvd-head"><span class="wcvd-radio" aria-hidden="true"></span><span class="wcvd-title">';
      h += free
        ? "Buy <b>" + free + "</b> Get " + free + ' <b class="wcvd-free-t">FREE</b>'
        : pct > 0
          ? "Buy <b>" + t.qty + "</b> with <b>" + pct + "%</b> off"
          : "Buy <b>" + t.qty + "</b> for<b class=\"wcvd-unit\">" + money(pr.total) + "</b>";
      h += '</span></span><span class="wcvd-price">' + money(pr.total) + "</span></div>";
      if (on && MULTI) {
        // "#1 [photo  Light Gray  ⌄]" — one dropdown per item
        h += '<div class="wcvd-items">';
        slots.forEach(function (vid, k) {
          h += '<div class="wcvd-vrow"><span class="wcvd-n">#' + (k + 1) + "</span>" + picker("item", k, VARIANTS, vid, "Item " + (k + 1)) + "</div>";
        });
        h += "</div>";
      }
      var gifts = t.gifts || [];
      if (gifts.length) h += '<div class="wcvd-gifts">';
      gifts.forEach(function (g) {
        var gv = g.variants || [];
        var pick = giftChoice(g);
        var val = Number(g.value) > 0 ? money(g.value) : g.valueText ? money(Number(g.valueText) * 100) : "";
        var gimg = variantImage(gv, pick, g.image);
        var price = '<span class="wcvd-gift-price">' + (val ? '<s class="wcvd-gift-val">' + val + "</s>" : "") + "</span>";
        if (on && gv.length > 1) {
          // "Free wallet" + dropdown with the gift's variants, struck value on the right
          h += '<div class="wcvd-gift wcvd-gift--pk"><div class="wcvd-gh">Free ' + esc(g.title) + "</div>";
          h += '<div class="wcvd-gift-line">' + picker("gift", g.p, gv, pick, "Free " + g.title) + price + "</div></div>";
          return;
        }
        h += '<div class="wcvd-gift">';
        h += gimg ? '<img class="wcvd-gift-img" src="' + esc(gimg) + '" alt="" loading="lazy" width="70" height="70">' : '<span class="wcvd-gift-img"></span>';
        h += '<div class="wcvd-gift-body"><span class="wcvd-gift-t">Free ' + esc(g.title) + "</span>";
        h += "</div>";
        h += price;
        h += "</div>";
      });
      if (gifts.length) h += "</div>";
      if ((pct > 0 || free) && pr.full > pr.total)
        h += '<span class="wcvd-save"><span>Save:</span><b>' + money(pr.full - pr.total) + "</b></span>";
      h += "</li>";
    });
    h += "</ul>";
    if (!expanded && TIERS.length > visible) h += '<button type="button" class="wcvd-more">Show more options</button>';
    if (errorText) h += '<div class="wcvd-err" role="alert">' + esc(errorText) + "</div>";
    root.innerHTML = h;
    root.setAttribute("role", "radiogroup");
  }

  function setThemeQty(q) {
    var f = ourForm();
    var inp = f && f.querySelector('[name="quantity"]');
    if (!inp) inp = document.querySelector('quantity-input input[name="quantity"], input.quantity__input');
    if (!inp || String(inp.value) === String(q)) return;
    inp.value = q;
    try {
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {
      // ignore
    }
  }

  function beacon(t) {
    if (!BEACON || !SHOP || !navigator.sendBeacon) return;
    try {
      navigator.sendBeacon(BEACON, JSON.stringify({ shop: SHOP, offer: D.offer, t: t }));
    } catch (e) {
      // ignore
    }
  }

  function select(i) {
    if (i === sel) return;
    sel = i;
    errorText = "";
    resetSlots();
    setThemeQty(TIERS[sel].qty);
    if (!clicked) {
      clicked = true;
      beacon("c");
    }
    render();
  }

  function closePk(focus) {
    if (!openPk) return;
    var key = openPk;
    openPk = "";
    render();
    if (focus) {
      var b = root.querySelector('.wcvd-pk-btn[data-kind="' + key.split(":")[0] + '"][data-idx="' + key.split(":").slice(1).join(":") + '"]');
      if (b) b.focus();
    }
  }
  function pickVariant(kind, idx, vid) {
    if (kind === "item") {
      slots[Number(idx)] = vid;
      touched[Number(idx)] = true;
      if (Number(idx) === 0) setThemeVariant(vid);
    } else {
      saveChoice(idx, vid);
    }
  }

  root.addEventListener("click", function (e) {
    var t = e.target;
    e.wcvdInside = true; // the target may be detached by render() before the document handler runs
    var btn = t.closest && t.closest(".wcvd-pk-btn");
    if (btn) {
      e.preventDefault();
      var key = btn.getAttribute("data-kind") + ":" + btn.getAttribute("data-idx");
      openPk = openPk === key ? "" : key;
        render();
      // keep the focus inside the (re-rendered) dropdown so Escape / arrows work
      var cur = openPk && e.detail === 0 ? root.querySelector(".wcvd-pk.is-open .wcvd-opt.is-on") || root.querySelector(".wcvd-pk.is-open .wcvd-opt") : null;
      if (!cur) cur = root.querySelector('.wcvd-pk-btn[data-kind="' + btn.getAttribute("data-kind") + '"][data-idx="' + btn.getAttribute("data-idx") + '"]');
      if (cur) cur.focus({ preventScroll: true });
      return;
    }
    var opt = t.closest && t.closest(".wcvd-opt");
    if (opt) {
      e.preventDefault();
      if (opt.classList.contains("is-na")) return;
      var kind = opt.getAttribute("data-kind");
      var idx = opt.getAttribute("data-idx");
      pickVariant(kind, idx, opt.getAttribute("data-v"));
      openPk = "";
        render();
      var again = root.querySelector('.wcvd-pk-btn[data-kind="' + kind + '"][data-idx="' + idx + '"]');
      if (again && e.detail === 0) again.focus();
      return;
    }
    if (openPk && !(t.closest && t.closest(".wcvd-pk"))) closePk(false);
    if (t.closest && t.closest(".wcvd-more")) {
      expanded = true;
      render();
      return;
    }
    var tier = t.closest && t.closest(".wcvd-tier");
    if (tier) select(Number(tier.getAttribute("data-tier")));
  });
  root.addEventListener("keydown", function (e) {
    if (openPk && e.target.closest && e.target.closest(".wcvd-pk")) {
      if (e.key === "Escape") {
        e.preventDefault();
        closePk(true);
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        var opts = Array.prototype.slice.call(root.querySelectorAll(".wcvd-pk.is-open .wcvd-opt"));
        var i = opts.indexOf(document.activeElement);
        var n = opts[Math.max(0, Math.min(opts.length - 1, i + (e.key === "ArrowDown" ? 1 : -1)))];
        if (n) {
          e.preventDefault();
          n.focus();
        }
        return;
      }
    }
    var tier = e.target.classList && e.target.classList.contains("wcvd-tier") ? e.target : null;
    if (!tier || (e.key !== "Enter" && e.key !== " ")) return;
    e.preventDefault();
    select(Number(tier.getAttribute("data-tier")));
  });

  // the theme's own variant picker changed → items not picked by hand follow it
  document.addEventListener("change", function (e) {
    if (root.contains(e.target)) return;
    setTimeout(syncFromTheme, 50);
  });
  // Umino picks a variant on a click of a swatch (no change event) and updates ?variant= in the URL
  document.addEventListener("click", function (e) {
    if (e.wcvdInside || root.contains(e.target)) return;
    if (openPk) closePk(false);
    setTimeout(syncFromTheme, 150);
    setTimeout(syncFromTheme, 600);
  });
  ["pushState", "replaceState"].forEach(function (m) {
    var orig = history[m];
    if (typeof orig !== "function") return;
    history[m] = function () {
      var res = orig.apply(this, arguments);
      setTimeout(syncFromTheme, 0);
      return res;
    };
  });
  window.addEventListener("popstate", function () {
    setTimeout(syncFromTheme, 0);
  });

  // ---------- placement ----------
  function findAnchor() {
    var list;
    try {
      list = document.querySelectorAll(SELECTOR);
    } catch (e) {
      log("bad selector", SELECTOR);
      return null;
    }
    var fallback = null;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === root || root.contains(el)) continue;
      var form = el.tagName === "FORM" ? el : el.closest ? el.closest("form") : null;
      var idEl = form && form.querySelector('[name="id"]');
      if (idEl && VMAP[String(Number(idEl.value))]) return el;
      if (!fallback) fallback = el;
    }
    return fallback;
  }
  var mounted = false;
  function mount() {
    if (mounted) return true;
    var a = findAnchor();
    if (!a || !a.parentNode) return false;
    if (POSITION === "after") a.parentNode.insertBefore(root, a.nextSibling);
    else a.parentNode.insertBefore(root, a);
    mounted = true;
    resetSlots();
    lastTheme = currentVariant();
    setThemeQty(TIERS[sel].qty);
    render();
    root.hidden = false;
    beacon("v");
    log("mounted", a);
    return true;
  }
  if (!mount()) {
    var obs = new MutationObserver(function () {
      if (mount()) obs.disconnect();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function () {
      obs.disconnect();
    }, 15000);
  }

  // ---------- Add to cart ----------
  function isAddButton(el) {
    if (!el || !el.closest) return null;
    var b = el.closest('button, input[type="submit"]');
    if (!b || root.contains(b)) return null;
    var form = b.closest("form") || (b.form || null);
    if (!form || form !== ourForm()) return null;
    if (b.name === "add" || b.type === "submit") return b;
    return null;
  }

  function formProperties(form) {
    var props = {};
    var els = form.querySelectorAll('[name^="properties["]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) continue;
      var m = /^properties\[(.+)\]$/.exec(el.name);
      if (m && el.value !== "") props[m[1]] = el.value;
    }
    return props;
  }

  function addTier(btn) {
    var t = TIERS[sel];
    var form = ourForm();
    var props = form ? formProperties(form) : {};
    followTheme();
    var byVariant = {};
    var order = [];
    slots.forEach(function (vid) {
      if (!byVariant[vid]) {
        byVariant[vid] = 0;
        order.push(vid);
      }
      byVariant[vid] += 1;
    });
    var items = order.map(function (vid) {
      var it = { id: Number(vid), quantity: byVariant[vid] };
      if (Object.keys(props).length) it.properties = props;
      return it;
    });
    busy = true;
    errorText = "";
    if (btn) {
      btn.setAttribute("aria-busy", "true");
      btn.classList.add("wcvd-loading");
    }
    log("add tier", t.qty, items);
    // Checkbox Upsell: ticked upsells go into the cart first (same press, no reload)
    var upsell = null;
    var hook = window.WCUpsell && window.WCUpsell.beforeAdd;
    var pre = Promise.resolve(null);
    try {
      if (hook) pre = Promise.resolve(hook(slots.length)).catch(function () {
        return null;
      });
    } catch (e) {
      pre = Promise.resolve(null);
    }
    return pre
      .then(function (h) {
        upsell = h;
        return api("cart/add.js", { items: items }).catch(function (e) {
          if (upsell && upsell.rollback) upsell.rollback();
          throw e;
        });
      })
      .then(function () {
        return sync("tier-add");
      })
      .then(function () {
        if (AFTER_ADD === "cart") {
          window.location.href = ROOT + "cart";
          return;
        }
        refreshUI();
      })
      .catch(function (e) {
        errorText = (e && e.message) || "Could not add to cart";
        render();
      })
      .then(function () {
        busy = false;
        if (btn) {
          btn.removeAttribute("aria-busy");
          btn.classList.remove("wcvd-loading");
        }
      });
  }

  function intercept(e, btn) {
    var t = TIERS[sel];
    if (!mounted || !t || t.qty <= 1) return; // 1 item: the theme adds it as usual
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    addTier(btn);
  }

  // capture phase on document: runs before the theme's own handlers
  document.addEventListener(
    "click",
    function (e) {
      var b = isAddButton(e.target);
      if (b) intercept(e, b);
    },
    true,
  );
  document.addEventListener(
    "submit",
    function (e) {
      var f = e.target;
      if (f && f === ourForm()) intercept(e, f.querySelector('[type="submit"]'));
    },
    true,
  );

  window.WCVolume.state = function () {
    return { tier: sel, slots: slots.slice(), touched: touched.slice() };
  };
})();
