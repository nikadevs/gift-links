/*
 * WoodenCrew Apps — Volume Discounts (storefront).
 *
 * 1. Product page: renders "Buy N with X% off" tiers (data from Liquid,
 *    #wcvd-product). The selected tier shows one row of image swatches per
 *    item (#1, #2 …) and swatches for the free gifts. Add to cart with a 2+
 *    tier adds the chosen variants with ONE /cart/add.js request.
 * 2. Every page: cart sync. For each active offer it counts the offer's
 *    products in the cart, finds the reached tier and keeps exactly one line
 *    of each of that tier's gifts ($0 copies) with the hidden property
 *    _wc_vd_gift. Other lines are never touched, except a gift variant that
 *    sits in the cart WITHOUT our property (added by hand) — that one is
 *    removed, so a $0 gift can't be bought on its own.
 *
 * The % discount is a native Shopify automatic discount (created by the app),
 * so checkout prices are right even if this script doesn't run.
 */
(function () {
  "use strict";
  var cfgEl = document.getElementById("wcvd-config");
  var bootEl = document.getElementById("wcvd-boot");
  if (!cfgEl || !bootEl || window.WCVolume) return;

  var ROOT = cfgEl.getAttribute("data-root") || "/";
  if (ROOT.charAt(ROOT.length - 1) !== "/") ROOT += "/";
  var SHOP = cfgEl.getAttribute("data-shop") || "";
  var BEACON = cfgEl.getAttribute("data-beacon") || "";
  var CURRENCY = cfgEl.getAttribute("data-currency") || "USD";
  var LOCALE = cfgEl.getAttribute("data-locale") || "en";
  var AFTER_ADD = cfgEl.getAttribute("data-after-add") === "stay" ? "stay" : "cart";
  var DEBUG = cfgEl.getAttribute("data-debug") === "true";
  var GIFT_PROP = "_wc_vd_gift";
  var CHOICE_KEY = "wcvd.choice.v1";
  var CART_RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|\/|$)/;

  function log() {
    if (!DEBUG || !window.console) return;
    var a = Array.prototype.slice.call(arguments);
    a.unshift("[Volume Discounts]");
    console.log.apply(console, a);
  }

  var boot = { offers: [], giftVariants: [] };
  try {
    boot = JSON.parse(bootEl.textContent || "{}");
  } catch (e) {
    log("bad boot json", e);
  }
  var OFFERS = (boot.offers || []).map(function (o) {
    o.tiers = (o.tiers || []).slice().sort(function (a, b) {
      return a.qty - b.qty;
    });
    o.products = (o.products || []).map(String);
    return o;
  });
  var GIFT_SET = {};
  (boot.giftVariants || []).forEach(function (v) {
    GIFT_SET[String(v)] = true;
  });

  var rawFetch = window.fetch.bind(window);
  function api(path, body) {
    return rawFetch(ROOT + path, {
      method: body ? "POST" : "GET",
      credentials: "same-origin",
      headers: body
        ? { "Content-Type": "application/json", Accept: "application/json" }
        : { Accept: "application/json" },
      body: body ? JSON.stringify(body) : undefined,
    }).then(function (r) {
      return r.json().then(function (d) {
        if (!r.ok) {
          var err = new Error((d && (d.description || d.message)) || "HTTP " + r.status);
          err.status = r.status;
          throw err;
        }
        return d;
      });
    });
  }

  function readChoice() {
    try {
      return JSON.parse(window.localStorage.getItem(CHOICE_KEY) || "{}") || {};
    } catch (e) {
      return {};
    }
  }
  function saveChoice(productId, variantId) {
    var c = readChoice();
    c[String(productId)] = String(variantId);
    try {
      window.localStorage.setItem(CHOICE_KEY, JSON.stringify(c));
    } catch (e) {
      // private mode — the first variant is used then
    }
  }

  // =====================  cart sync (every page)  =====================

  /** What has to change in this cart. Exported for tests via WCVolume.plan */
  function plan(cart) {
    var lines = (cart && cart.items) || [];
    var choice = readChoice();
    var required = {}; // slot → gift
    OFFERS.forEach(function (o) {
      var count = 0;
      lines.forEach(function (l) {
        if (l.properties && l.properties[GIFT_PROP]) return;
        if (o.products.indexOf(String(l.product_id)) >= 0) count += l.quantity;
      });
      var tier = null;
      o.tiers.forEach(function (t) {
        if (count >= t.qty) tier = t;
      });
      if (!tier) return;
      (tier.gifts || []).forEach(function (g) {
        required[o.id + ":" + g.p] = g;
      });
    });

    var remove = []; // { key, quantity }
    var seen = {};
    lines.forEach(function (l) {
      var vid = String(l.variant_id);
      var slot = l.properties && l.properties[GIFT_PROP];
      if (!slot) {
        // a gift variant without our property: added by hand / by a link → not allowed
        if (GIFT_SET[vid] && Number(l.original_price) === 0) remove.push({ key: l.key, quantity: 0 });
        return;
      }
      var g = required[slot];
      var ok = g && (g.v || []).map(String).indexOf(vid) >= 0;
      if (!ok || seen[slot]) {
        remove.push({ key: l.key, quantity: 0 });
        return;
      }
      seen[slot] = true;
      if (l.quantity !== 1) remove.push({ key: l.key, quantity: 1 });
    });

    var add = [];
    Object.keys(required).forEach(function (slot) {
      if (seen[slot]) return;
      var g = required[slot];
      var vs = (g.v || []).map(String);
      var pick = choice[String(g.p)];
      var order = pick && vs.indexOf(pick) >= 0 ? [pick].concat(vs.filter(function (v) { return v !== pick; })) : vs;
      if (order.length) add.push({ slot: slot, variants: order });
    });
    return { remove: remove, add: add };
  }

  var syncing = null;
  var syncAgain = false;
  var syncTimes = [];

  function sync(reason) {
    if (!OFFERS.length && !Object.keys(GIFT_SET).length) return Promise.resolve(false);
    if (syncing) {
      syncAgain = true;
      return syncing;
    }
    var now = Date.now();
    syncTimes = syncTimes.filter(function (t) {
      return now - t < 15000;
    });
    if (syncTimes.length >= 8) {
      log("sync rate limit");
      return Promise.resolve(false);
    }
    syncTimes.push(now);
    var changed = false;
    syncing = api("cart.js")
      .then(function (cart) {
        var p = plan(cart);
        log("sync", reason, p);
        var chain = Promise.resolve();
        p.remove.forEach(function (r) {
          chain = chain.then(function () {
            changed = true;
            return api("cart/change.js", { id: r.key, quantity: r.quantity }).catch(function (e) {
              log("change failed", e);
            });
          });
        });
        p.add.forEach(function (a) {
          chain = chain.then(function () {
            // first variant that is in stock
            return a.variants.reduce(function (c, vid) {
              return c.then(function (done) {
                if (done) return true;
                return api("cart/add.js", {
                  items: [{ id: Number(vid), quantity: 1, properties: { _wc_vd_gift: a.slot } }],
                }).then(
                  function () {
                    changed = true;
                    return true;
                  },
                  function (e) {
                    log("gift add failed", vid, e && e.message);
                    return false;
                  },
                );
              });
            }, Promise.resolve(false));
          });
        });
        return chain;
      })
      .catch(function (e) {
        log("sync error", e);
      })
      .then(function () {
        syncing = null;
        if (changed) refreshUI();
        if (syncAgain) {
          syncAgain = false;
          return sync("again").then(function (c2) {
            return changed || c2;
          });
        }
        return changed;
      });
    return syncing;
  }

  var timer = null;
  function scheduleSync(reason) {
    clearTimeout(timer);
    timer = setTimeout(function () {
      sync(reason);
    }, 350);
  }

  // ---------- refresh the theme's cart UI ----------
  var RELOAD_KEY = "wcvd.reloaded";
  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-volume:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      var last = 0;
      try {
        last = Number(window.sessionStorage.getItem(RELOAD_KEY) || 0);
        window.sessionStorage.setItem(RELOAD_KEY, String(Date.now()));
      } catch (e) {
        last = Date.now(); // can't guard → don't reload
      }
      if (Date.now() - last > 5000) window.location.reload();
      return;
    }
    api("cart.js")
      .then(function (cart) {
        var counts = document.querySelectorAll(".cart-count");
        for (var i = 0; i < counts.length; i++) {
          counts[i].innerHTML = counts[i].classList.contains("cart-count-drawer")
            ? "(" + cart.item_count + ")"
            : cart.item_count;
        }
      })
      .catch(function () {});
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    if (!ids.length) return;
    rawFetch(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (sections) {
        var parse = function (html, sel) {
          return new DOMParser().parseFromString(html || "", "text/html").querySelector(sel);
        };
        var swap = function (id, html, sel) {
          var el = document.getElementById(id);
          var next = html && parse(html, sel);
          if (el && next) el.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", sections["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", sections["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", sections["cart-drawer"], "#CartDrawer");
      })
      .catch(function () {});
  }

  // ---------- watch the theme / other apps changing the cart ----------
  window.fetch = function (input, init) {
    var p = rawFetch(input, init);
    try {
      var url = typeof input === "string" ? input : (input && input.url) || "";
      if (CART_RE.test(url))
        p.then(
          function () {
            scheduleSync("fetch");
          },
          function () {},
        );
    } catch (e) {
      // ignore
    }
    return p;
  };
  var xhrOpen = XMLHttpRequest.prototype.open;
  XMLHttpRequest.prototype.open = function (method, u) {
    try {
      if (CART_RE.test(String(u)))
        this.addEventListener("load", function () {
          scheduleSync("xhr");
        });
    } catch (e) {
      // ignore
    }
    return xhrOpen.apply(this, arguments);
  };

  if (Number(cfgEl.getAttribute("data-cart-count") || 0) > 0) scheduleSync("load");
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) scheduleSync("bfcache");
  });

  window.WCVolume = { sync: sync, plan: plan, offers: OFFERS };

  // =====================  product page block  =====================
  var root = document.getElementById("wcvd-root");
  var dataEl = document.getElementById("wcvd-product");
  if (!root || !dataEl) return;
  var D;
  try {
    D = JSON.parse(dataEl.textContent || "{}");
  } catch (e) {
    log("bad product json", e);
    return;
  }
  var TIERS = D.tiers || [];
  if (!TIERS.length) return;
  var VARIANTS = D.variants || [];
  var VMAP = {};
  VARIANTS.forEach(function (v) {
    VMAP[String(v.id)] = v;
  });
  var MULTI = VARIANTS.length > 1;
  var SELECTOR = root.getAttribute("data-selector") || "form[action*='/cart/add']";
  var POSITION = root.getAttribute("data-position") === "after" ? "after" : "before";

  var sel = Math.min(Math.max(Number(D.defaultTier) || 0, 0), TIERS.length - 1);
  var visible = Math.max(1, Number(D.visible) || 3);
  var expanded = sel >= visible;
  var slots = []; // variant id per item of the selected tier
  var touched = []; // slot changed by the shopper
  var clicked = false;
  var busy = false;
  var errorText = "";

  var fmt;
  try {
    fmt = new Intl.NumberFormat(LOCALE, { style: "currency", currency: CURRENCY, currencyDisplay: "narrowSymbol" });
  } catch (e) {
    fmt = null;
  }
  function money(cents) {
    var n = Math.round(cents) / 100;
    return fmt ? fmt.format(n) : "$" + n.toFixed(2);
  }
  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }

  function ourForm() {
    var forms = document.querySelectorAll("form[action*='/cart/add']");
    for (var i = 0; i < forms.length; i++) {
      var f = forms[i];
      if (root.contains(f)) continue;
      var idEl = f.querySelector('[name="id"]');
      if (idEl && VMAP[String(Number(idEl.value))]) return f;
    }
    return null;
  }
  function currentVariant() {
    var f = ourForm();
    var idEl = f && f.querySelector('[name="id"]');
    var id = idEl ? String(Number(idEl.value)) : "";
    if (VMAP[id]) return id;
    for (var i = 0; i < VARIANTS.length; i++) if (VARIANTS[i].available) return String(VARIANTS[i].id);
    return String(VARIANTS[0].id);
  }

  function resetSlots() {
    var t = TIERS[sel];
    var cur = currentVariant();
    var next = [];
    var nextTouched = [];
    for (var i = 0; i < t.qty; i++) {
      if (touched[i] && slots[i]) {
        next.push(slots[i]);
        nextTouched.push(true);
      } else {
        next.push(cur);
        nextTouched.push(false);
      }
    }
    slots = next;
    touched = nextTouched;
  }
  function followTheme() {
    var cur = currentVariant();
    for (var i = 0; i < slots.length; i++) if (!touched[i]) slots[i] = cur;
  }

  function tierPrices(i) {
    var t = TIERS[i];
    var full = 0;
    if (i === sel && slots.length === t.qty) {
      slots.forEach(function (vid) {
        full += (VMAP[vid] || VARIANTS[0]).price;
      });
    } else {
      full = (VMAP[currentVariant()] || VARIANTS[0]).price * t.qty;
    }
    var total = full - Math.round((full * (Number(t.percent) || 0)) / 100);
    return { full: full, total: total };
  }

  function giftChoice(g) {
    var c = readChoice()[String(g.p)];
    var ok = (g.variants || []).filter(function (v) {
      return v.available !== false;
    });
    for (var i = 0; i < ok.length; i++) if (String(ok[i].id) === c) return c;
    return ok.length ? String(ok[0].id) : "";
  }

  function swatch(kind, idx, v, on, label) {
    var na = v.available === false;
    return (
      '<button type="button" class="wcvd-sw' + (on ? " is-on" : "") + (na ? " is-na" : "") + '"' +
      ' data-kind="' + kind + '" data-idx="' + esc(idx) + '" data-v="' + esc(v.id) + '"' +
      ' title="' + esc(label || v.title) + (na ? " — sold out" : "") + '"' +
      ' aria-label="' + esc(label || v.title) + '" aria-pressed="' + (on ? "true" : "false") + '"' +
      (na ? " disabled" : "") + ">" +
      (v.image ? '<img src="' + esc(v.image) + '" alt="" loading="lazy" width="60" height="60">' : '<span>' + esc(v.title) + "</span>") +
      "</button>"
    );
  }

  function render() {
    var h = "";
    if (D.header) h += '<div class="wcvd-h"><span>' + esc(D.header) + "</span></div>";
    TIERS.forEach(function (t, i) {
      if (i >= visible && !expanded && i !== sel) return;
      var on = i === sel;
      var pr = tierPrices(i);
      var pct = Number(t.percent) || 0;
      h += '<div class="wcvd-tier' + (on ? " is-on" : "") + (t.label ? " has-badge" : "") + '" role="radio" tabindex="0" aria-checked="' + on + '" data-tier="' + i + '">';
      if (t.label) h += '<span class="wcvd-badge">' + esc(t.label) + "</span>";
      h += '<div class="wcvd-row"><span class="wcvd-radio" aria-hidden="true"></span><span class="wcvd-title">';
      h += pct > 0
        ? "Buy <b>" + t.qty + "</b> with <b>" + pct + "%</b> off"
        : "Buy <b>" + t.qty + "</b> for <b>" + money(t.qty > 1 ? pr.total : pr.total) + "</b>";
      h += '</span><span class="wcvd-price">' + money(pr.total) + "</span></div>";
      if (on && MULTI && t.qty > 1) {
        h += '<div class="wcvd-items">';
        slots.forEach(function (vid, k) {
          h += '<div class="wcvd-item"><span class="wcvd-n">#' + (k + 1) + '</span><div class="wcvd-sws">';
          VARIANTS.forEach(function (v) {
            h += swatch("item", k, v, String(v.id) === vid);
          });
          h += "</div></div>";
        });
        h += "</div>";
      }
      (t.gifts || []).forEach(function (g) {
        var gv = g.variants || [];
        var pick = giftChoice(g);
        var val = Number(g.value) > 0 ? money(g.value) : g.valueText ? money(Number(g.valueText) * 100) : "";
        h += '<div class="wcvd-gift">';
        if (g.image) h += '<img class="wcvd-gift-img" src="' + esc(g.image) + '" alt="" loading="lazy" width="64" height="64">';
        h += '<div class="wcvd-gift-body"><div class="wcvd-gift-t">Free ' + esc(g.title) + "</div>";
        if (on && gv.length > 1) {
          h += '<div class="wcvd-sws">';
          gv.forEach(function (v) {
            h += swatch("gift", g.p, v, String(v.id) === pick);
          });
          h += "</div>";
        }
        h += "</div>";
        if (val) h += '<s class="wcvd-gift-val">' + val + "</s>";
        h += "</div>";
      });
      if (pct > 0 && pr.full > pr.total) h += '<span class="wcvd-save">Save: <b>' + money(pr.full - pr.total) + "</b></span>";
      h += "</div>";
    });
    if (!expanded && TIERS.length > visible) h += '<button type="button" class="wcvd-more">Show more options</button>';
    if (errorText) h += '<div class="wcvd-err" role="alert">' + esc(errorText) + "</div>";
    root.innerHTML = h;
    root.setAttribute("role", "radiogroup");
  }

  function setThemeQty(q) {
    var f = ourForm();
    var inp = f && f.querySelector('[name="quantity"]');
    if (!inp) inp = document.querySelector('quantity-input input[name="quantity"], input.quantity__input');
    if (!inp || String(inp.value) === String(q)) return;
    inp.value = q;
    try {
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      inp.dispatchEvent(new Event("change", { bubbles: true }));
    } catch (e) {
      // ignore
    }
  }

  function beacon(t) {
    if (!BEACON || !SHOP || !navigator.sendBeacon) return;
    try {
      navigator.sendBeacon(BEACON, JSON.stringify({ shop: SHOP, offer: D.offer, t: t }));
    } catch (e) {
      // ignore
    }
  }

  function select(i) {
    if (i === sel) return;
    sel = i;
    errorText = "";
    resetSlots();
    setThemeQty(TIERS[sel].qty);
    if (!clicked) {
      clicked = true;
      beacon("c");
    }
    render();
  }

  root.addEventListener("click", function (e) {
    var t = e.target;
    var sw = t.closest && t.closest(".wcvd-sw");
    if (sw && root.contains(sw)) {
      e.preventDefault();
      var kind = sw.getAttribute("data-kind");
      var v = sw.getAttribute("data-v");
      if (kind === "item") {
        var k = Number(sw.getAttribute("data-idx"));
        slots[k] = v;
        touched[k] = true;
      } else {
        saveChoice(sw.getAttribute("data-idx"), v);
      }
      render();
      return;
    }
    if (t.closest && t.closest(".wcvd-more")) {
      expanded = true;
      render();
      return;
    }
    var tier = t.closest && t.closest(".wcvd-tier");
    if (tier) select(Number(tier.getAttribute("data-tier")));
  });
  root.addEventListener("keydown", function (e) {
    var tier = e.target.classList && e.target.classList.contains("wcvd-tier") ? e.target : null;
    if (!tier || (e.key !== "Enter" && e.key !== " ")) return;
    e.preventDefault();
    select(Number(tier.getAttribute("data-tier")));
  });

  // the theme's own variant picker changed → items not picked by hand follow it
  document.addEventListener("change", function (e) {
    if (root.contains(e.target)) return;
    setTimeout(function () {
      followTheme();
      render();
    }, 50);
  });

  // ---------- placement ----------
  function findAnchor() {
    var list;
    try {
      list = document.querySelectorAll(SELECTOR);
    } catch (e) {
      log("bad selector", SELECTOR);
      return null;
    }
    var fallback = null;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === root || root.contains(el)) continue;
      var form = el.tagName === "FORM" ? el : el.closest ? el.closest("form") : null;
      var idEl = form && form.querySelector('[name="id"]');
      if (idEl && VMAP[String(Number(idEl.value))]) return el;
      if (!fallback) fallback = el;
    }
    return fallback;
  }
  var mounted = false;
  function mount() {
    if (mounted) return true;
    var a = findAnchor();
    if (!a || !a.parentNode) return false;
    if (POSITION === "after") a.parentNode.insertBefore(root, a.nextSibling);
    else a.parentNode.insertBefore(root, a);
    mounted = true;
    resetSlots();
    setThemeQty(TIERS[sel].qty);
    render();
    root.hidden = false;
    beacon("v");
    log("mounted", a);
    return true;
  }
  if (!mount()) {
    var obs = new MutationObserver(function () {
      if (mount()) obs.disconnect();
    });
    obs.observe(document.documentElement, { childList: true, subtree: true });
    setTimeout(function () {
      obs.disconnect();
    }, 15000);
  }

  // ---------- Add to cart ----------
  function isAddButton(el) {
    if (!el || !el.closest) return null;
    var b = el.closest('button, input[type="submit"]');
    if (!b || root.contains(b)) return null;
    var form = b.closest("form") || (b.form || null);
    if (!form || form !== ourForm()) return null;
    if (b.name === "add" || b.type === "submit") return b;
    return null;
  }

  function formProperties(form) {
    var props = {};
    var els = form.querySelectorAll('[name^="properties["]');
    for (var i = 0; i < els.length; i++) {
      var el = els[i];
      if ((el.type === "checkbox" || el.type === "radio") && !el.checked) continue;
      var m = /^properties\[(.+)\]$/.exec(el.name);
      if (m && el.value !== "") props[m[1]] = el.value;
    }
    return props;
  }

  function addTier(btn) {
    var t = TIERS[sel];
    var form = ourForm();
    var props = form ? formProperties(form) : {};
    followTheme();
    var byVariant = {};
    var order = [];
    slots.forEach(function (vid) {
      if (!byVariant[vid]) {
        byVariant[vid] = 0;
        order.push(vid);
      }
      byVariant[vid] += 1;
    });
    var items = order.map(function (vid) {
      var it = { id: Number(vid), quantity: byVariant[vid] };
      if (Object.keys(props).length) it.properties = props;
      return it;
    });
    busy = true;
    errorText = "";
    if (btn) {
      btn.setAttribute("aria-busy", "true");
      btn.classList.add("wcvd-loading");
    }
    log("add tier", t.qty, items);
    return api("cart/add.js", { items: items })
      .then(function () {
        return sync("tier-add");
      })
      .then(function () {
        if (AFTER_ADD === "cart") {
          window.location.href = ROOT + "cart";
          return;
        }
        refreshUI();
      })
      .catch(function (e) {
        errorText = (e && e.message) || "Could not add to cart";
        render();
      })
      .then(function () {
        busy = false;
        if (btn) {
          btn.removeAttribute("aria-busy");
          btn.classList.remove("wcvd-loading");
        }
      });
  }

  function intercept(e, btn) {
    var t = TIERS[sel];
    if (!mounted || !t || t.qty <= 1) return; // 1 item: the theme adds it as usual
    e.preventDefault();
    e.stopPropagation();
    if (busy) return;
    addTier(btn);
  }

  // capture phase on document: runs before the theme's own handlers
  document.addEventListener(
    "click",
    function (e) {
      var b = isAddButton(e.target);
      if (b) intercept(e, b);
    },
    true,
  );
  document.addEventListener(
    "submit",
    function (e) {
      var f = e.target;
      if (f && f === ourForm()) intercept(e, f.querySelector('[type="submit"]'));
    },
    true,
  );

  window.WCVolume.state = function () {
    return { tier: sel, slots: slots.slice(), touched: touched.slice() };
  };
})();
