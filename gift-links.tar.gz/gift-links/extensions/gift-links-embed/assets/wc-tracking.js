/* WoodenCrew Apps - Order tracking page (replacement for Track123).
 * Mounts into the "Order tracking" app block ([data-wct-block]) or, without the
 * block, into #wc-trk on /pages/<handle> (embed fallback). Data from
 * <endpoint>/api/trk/lookup. No cookies, no cart access. */
(function () {
  "use strict";
  if (window.__wcTrkInit) return;
  var me = document.currentScript;
  if (!me) return;
  var ENDPOINT = me.getAttribute("data-endpoint") || "";
  var SHOP = me.getAttribute("data-shop") || "";
  if (!ENDPOINT || !SHOP) return;

  function start() {
    if (window.__wcTrkInit) return;
    window.__wcTrkInit = true;

    var R = document.querySelector("[data-wct-block]") || document.getElementById("wc-trk");
    if (!R) {
      R = document.createElement("div");
      R.id = "wc-trk";
      (document.querySelector("main .rte, main .page__content, .main-page .rte, main") || document.body).appendChild(R);
    }
    R.classList.add("wct");

    var T = {
      title: "Track your order", tabOrder: "Order number", tabNumber: "Tracking number",
      phOrder: "Order number, e.g. 39086", phEmail: "Email used for the order", phNumber: "Tracking number",
      button: "Track", order: "Order:", carrier: "Carrier", number: "Tracking number",
      details: "Shipping details", more: "Show full history", loading: "Loading…",
      carrierSite: "Track on {carrier} website",
      notFound: "We could not find this shipment yet. Tracking appears within 24 hours after your order ships.",
      noScans: "Your parcel has been handed over to the carrier. The first scans usually appear within 1–3 days.",
      steps: {}, status: {}
    };
    try {
      var cfg = JSON.parse(R.getAttribute("data-texts") || "{}");
      for (var k in cfg) if (cfg[k] !== "" && cfg[k] != null) T[k] = cfg[k];
    } catch (e) {}

    function el(tag, cls, text) {
      var e = document.createElement(tag);
      if (cls) e.className = cls;
      if (text != null) e.textContent = text;
      return e;
    }
    function fmtDate(iso, withTime) {
      if (!iso) return "";
      var d = new Date(iso);
      if (isNaN(d)) return "";
      var o = { month: "short", day: "numeric" };
      if (withTime) { o.hour = "2-digit"; o.minute = "2-digit"; }
      if (d.getFullYear() !== new Date().getFullYear()) o.year = "numeric";
      try { return d.toLocaleString(undefined, o); } catch (e) { return d.toISOString().slice(0, 10); }
    }
    function row(parent, k, v) {
      var line = el("div", "wct-pkg");
      line.appendChild(el("span", "wct-k", k));
      line.appendChild(el("span", "wct-v", v));
      parent.appendChild(line);
    }

    var form = el("form", "wct-form");
    var tabs = el("div", "wct-tabs");
    var tOrder = el("button", "wct-tab is-on", T.tabOrder);
    var tNum = el("button", "wct-tab", T.tabNumber);
    tOrder.type = tNum.type = "button";
    tabs.appendChild(tOrder);
    tabs.appendChild(tNum);
    var fOrder = el("div", "wct-fields");
    var iOrder = el("input", "wct-input");
    iOrder.name = "order"; iOrder.placeholder = T.phOrder; iOrder.autocomplete = "off";
    var iEmail = el("input", "wct-input");
    iEmail.name = "email"; iEmail.type = "email"; iEmail.placeholder = T.phEmail; iEmail.autocomplete = "email";
    fOrder.appendChild(iOrder); fOrder.appendChild(iEmail);
    var fNum = el("div", "wct-fields");
    fNum.hidden = true;
    var iNum = el("input", "wct-input");
    iNum.name = "nums"; iNum.placeholder = T.phNumber; iNum.autocomplete = "off";
    fNum.appendChild(iNum);
    var btn = el("button", "wct-btn", T.button);
    btn.type = "submit";
    if (T.title) form.appendChild(el("h2", "wct-title", T.title));
    form.appendChild(tabs); form.appendChild(fOrder); form.appendChild(fNum); form.appendChild(btn);
    var out = el("div", "wct-out");
    R.textContent = "";
    R.appendChild(form);
    R.appendChild(out);

    var mode = "order";
    function setMode(m) {
      mode = m;
      tOrder.classList.toggle("is-on", m === "order");
      tNum.classList.toggle("is-on", m === "nums");
      fOrder.hidden = m !== "order";
      fNum.hidden = m !== "nums";
    }
    tOrder.addEventListener("click", function () { setMode("order"); });
    tNum.addEventListener("click", function () { setMode("nums"); });

    function render(data) {
      out.textContent = "";
      if (!data || data.error) { out.appendChild(el("p", "wct-msg", (data && data.error) || "Something went wrong, please try again.")); return; }
      if (!data.results || !data.results.length) { out.appendChild(el("p", "wct-msg", T.notFound)); return; }
      data.results.forEach(function (r) {
        var card = el("div", "wct-card");
        var head = el("div", "wct-head");
        head.appendChild(el("div", "wct-order", r.order ? T.order + " " + String(r.order).replace("#", "") : ""));
        head.appendChild(el("div", "wct-status wct-s-" + r.status, T.status[r.status] || r.statusLabel));
        card.appendChild(head);

        var steps = el("ol", "wct-steps");
        r.steps.forEach(function (s) {
          var li = el("li", "wct-step" + (s.done ? " is-done" : ""));
          li.appendChild(el("span", "wct-dot"));
          li.appendChild(el("span", "wct-step-l", T.steps[s.key] || s.label));
          li.appendChild(el("span", "wct-step-d", s.done ? fmtDate(s.at) : ""));
          steps.appendChild(li);
        });
        card.appendChild(steps);

        var info = el("div", "wct-info");
        if (r.lastMileNumber && r.lastMileOnly) {
          row(info, T.carrier, r.lastMileCarrier || r.carrier);
          row(info, T.number, r.lastMileNumber);
        } else {
          row(info, T.carrier, r.carrier);
          row(info, T.number, r.number);
          if (r.lastMileNumber) {
            row(info, T.carrier, r.lastMileCarrier || "");
            row(info, T.number, r.lastMileNumber);
          }
        }
        if (r.lastMileSite) {
          var a = el("a", "wct-link", String(T.carrierSite).replace("{carrier}", r.lastMileCarrier || r.carrier) + " ↗");
          a.href = r.lastMileSite; a.target = "_blank"; a.rel = "noopener nofollow";
          info.appendChild(a);
        }
        card.appendChild(info);

        if (r.events.length) {
          var list = el("ul", "wct-events");
          r.events.forEach(function (e, i) {
            var li = el("li", "wct-ev" + (i === 0 ? " is-last" : ""));
            if (i >= 4) li.hidden = true;
            li.appendChild(el("div", "wct-ev-t", e.text));
            li.appendChild(el("div", "wct-ev-m", [fmtDate(e.at, true), e.place].filter(Boolean).join(" · ")));
            list.appendChild(li);
          });
          card.appendChild(el("h3", "wct-sub", T.details));
          card.appendChild(list);
          if (r.events.length > 4) {
            var more = el("button", "wct-more", T.more);
            more.type = "button";
            more.addEventListener("click", function () {
              [].forEach.call(list.children, function (c) { c.hidden = false; });
              more.remove();
            });
            card.appendChild(more);
          }
        } else {
          card.appendChild(el("p", "wct-msg", T.noScans));
        }
        out.appendChild(card);
      });
    }

    function lookup(body) {
      out.textContent = "";
      out.appendChild(el("p", "wct-msg", T.loading));
      btn.disabled = true;
      body.shop = SHOP;
      // POST + text/plain: no CORS preflight, and the email never appears in a URL
      fetch(ENDPOINT.replace(/\/$/, "") + "/api/trk/lookup", {
        method: "POST",
        credentials: "omit",
        headers: { "Content-Type": "text/plain" },
        body: JSON.stringify(body)
      })
        .then(function (r) { return r.json(); })
        .then(render)
        .catch(function () { render({ error: "Tracking is temporarily unavailable, please try again later." }); })
        .then(function () { btn.disabled = false; });
    }

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      if (mode === "nums") {
        var n = iNum.value.trim();
        if (!n) return;
        try { history.replaceState(null, "", location.pathname + "?nums=" + encodeURIComponent(n)); } catch (x) {}
        lookup({ nums: n });
      } else {
        var o = iOrder.value.replace(/[^0-9a-z-]/gi, ""), m = iEmail.value.trim();
        if (!o || !m) return;
        lookup({ order: o, email: m });
      }
    });

    var p = new URLSearchParams(location.search);
    var nums = p.get("nums") || p.get("tracking");
    if (nums) {
      setMode("nums");
      iNum.value = nums;
      lookup({ nums: nums });
    }
  }

  // wait for the DOM so the app block (if any) is found before the embed fallback mounts
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", start);
  else start();
})();
