/* WoodenCrew Apps \u2014 Tracking page (replacement for Track123).
 * Loaded only on /pages/<handle> when the module is on. Data from
 * <endpoint>/api/trk/lookup. No cookies, no cart access. */
(function () {
  "use strict";
  var me = document.currentScript;
  if (!me) return;
  var ENDPOINT = me.getAttribute("data-endpoint") || "";
  var SHOP = me.getAttribute("data-shop") || "";
  if (!ENDPOINT || !SHOP) return;

  function el(tag, cls, text) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (text != null) e.textContent = text;
    return e;
  }
  function fmtDate(iso, withTime) {
    if (!iso) return "";
    var d = new Date(iso);
    if (isNaN(d)) return "";
    var o = { month: "short", day: "numeric" };
    if (withTime) { o.hour = "2-digit"; o.minute = "2-digit"; }
    if (d.getFullYear() !== new Date().getFullYear()) o.year = "numeric";
    try { return d.toLocaleString(undefined, o); } catch (e) { return d.toISOString().slice(0, 10); }
  }

  function root() {
    var r = document.getElementById("wc-trk");
    if (r) return r;
    r = el("div");
    r.id = "wc-trk";
    var host = document.querySelector("main .rte, main .page__content, .main-page .rte, main") || document.body;
    host.appendChild(r);
    return r;
  }

  var R = root();
  R.classList.add("wct");
  var form = el("form", "wct-form");
  var tabs = el("div", "wct-tabs");
  var tOrder = el("button", "wct-tab is-on", "Order number");
  var tNum = el("button", "wct-tab", "Tracking number");
  tOrder.type = tNum.type = "button";
  tabs.appendChild(tOrder);
  tabs.appendChild(tNum);
  var fOrder = el("div", "wct-fields");
  var iOrder = el("input", "wct-input");
  iOrder.name = "order"; iOrder.placeholder = "Order number, e.g. 39086"; iOrder.autocomplete = "off";
  var iEmail = el("input", "wct-input");
  iEmail.name = "email"; iEmail.type = "email"; iEmail.placeholder = "Email used for the order"; iEmail.autocomplete = "email";
  fOrder.appendChild(iOrder); fOrder.appendChild(iEmail);
  var fNum = el("div", "wct-fields");
  fNum.hidden = true;
  var iNum = el("input", "wct-input");
  iNum.name = "nums"; iNum.placeholder = "Tracking number"; iNum.autocomplete = "off";
  fNum.appendChild(iNum);
  var btn = el("button", "wct-btn", "Track");
  btn.type = "submit";
  form.appendChild(el("h2", "wct-title", "Track your order"));
  form.appendChild(tabs); form.appendChild(fOrder); form.appendChild(fNum); form.appendChild(btn);
  var out = el("div", "wct-out");
  R.appendChild(form);
  R.appendChild(out);

  var mode = "order";
  function setMode(m) {
    mode = m;
    tOrder.classList.toggle("is-on", m === "order");
    tNum.classList.toggle("is-on", m === "nums");
    fOrder.hidden = m !== "order";
    fNum.hidden = m !== "nums";
  }
  tOrder.addEventListener("click", function () { setMode("order"); });
  tNum.addEventListener("click", function () { setMode("nums"); });

  function render(data) {
    out.textContent = "";
    if (!data || data.error) { out.appendChild(el("p", "wct-msg", (data && data.error) || "Something went wrong, please try again.")); return; }
    if (!data.results || !data.results.length) { out.appendChild(el("p", "wct-msg", data.message || "Shipment not found.")); return; }
    data.results.forEach(function (r) {
      var card = el("div", "wct-card");
      var head = el("div", "wct-head");
      head.appendChild(el("div", "wct-order", r.order ? "Order: " + r.order : ""));
      var st = el("div", "wct-status wct-s-" + r.status, r.statusLabel);
      head.appendChild(st);
      card.appendChild(head);

      var steps = el("ol", "wct-steps");
      r.steps.forEach(function (s) {
        var li = el("li", "wct-step" + (s.done ? " is-done" : ""));
        li.appendChild(el("span", "wct-dot"));
        li.appendChild(el("span", "wct-step-l", s.label));
        li.appendChild(el("span", "wct-step-d", s.done ? fmtDate(s.at) : ""));
        steps.appendChild(li);
      });
      card.appendChild(steps);

      var info = el("div", "wct-info");
      var carrier = r.lastMileCarrier || r.carrier;
      var number = r.lastMileNumber || r.number;
      var line = el("div", "wct-pkg");
      line.appendChild(el("span", "wct-k", "Carrier"));
      line.appendChild(el("span", "wct-v", carrier));
      info.appendChild(line);
      var line2 = el("div", "wct-pkg");
      line2.appendChild(el("span", "wct-k", "Tracking number"));
      var v = el("span", "wct-v", number);
      line2.appendChild(v);
      info.appendChild(line2);
      if (r.lastMileSite) {
        var a = el("a", "wct-link", "Track on " + carrier + " website \u2197");
        a.href = r.lastMileSite; a.target = "_blank"; a.rel = "noopener nofollow";
        info.appendChild(a);
      }
      card.appendChild(info);

      if (r.events.length) {
        var list = el("ul", "wct-events");
        r.events.forEach(function (e, i) {
          var li = el("li", "wct-ev" + (i === 0 ? " is-last" : ""));
          if (i >= 4) li.hidden = true;
          li.appendChild(el("div", "wct-ev-t", e.text));
          li.appendChild(el("div", "wct-ev-m", [fmtDate(e.at, true), e.place].filter(Boolean).join(" \u00b7 ")));
          list.appendChild(li);
        });
        card.appendChild(el("h3", "wct-sub", "Shipping details"));
        card.appendChild(list);
        if (r.events.length > 4) {
          var more = el("button", "wct-more", "Show full history");
          more.type = "button";
          more.addEventListener("click", function () {
            [].forEach.call(list.children, function (c) { c.hidden = false; });
            more.remove();
          });
          card.appendChild(more);
        }
      } else {
        card.appendChild(el("p", "wct-msg", "Your parcel has been handed over to the carrier. The first scans usually appear within 1\u20133 days."));
      }
      out.appendChild(card);
    });
  }

  function lookup(body) {
    out.textContent = "";
    out.appendChild(el("p", "wct-msg", "Loading\u2026"));
    btn.disabled = true;
    body.shop = SHOP;
    // POST + text/plain: no CORS preflight, and the email never appears in a URL
    fetch(ENDPOINT.replace(/\/$/, "") + "/api/trk/lookup", {
      method: "POST",
      credentials: "omit",
      headers: { "Content-Type": "text/plain" },
      body: JSON.stringify(body)
    })
      .then(function (r) { return r.json(); })
      .then(render)
      .catch(function () { render({ error: "Tracking is temporarily unavailable, please try again later." }); })
      .then(function () { btn.disabled = false; });
  }

  form.addEventListener("submit", function (e) {
    e.preventDefault();
    if (mode === "nums") {
      var n = iNum.value.trim();
      if (!n) return;
      try { history.replaceState(null, "", location.pathname + "?nums=" + encodeURIComponent(n)); } catch (x) {}
      lookup({ nums: n });
    } else {
      var o = iOrder.value.replace(/[^0-9a-z-]/gi, ""), m = iEmail.value.trim();
      if (!o || !m) return;
      lookup({ order: o, email: m });
    }
  });

  var p = new URLSearchParams(location.search);
  var nums = p.get("nums") || p.get("tracking");
  if (nums) {
    setMode("nums");
    iNum.value = nums;
    lookup({ nums: nums });
  }
})();
