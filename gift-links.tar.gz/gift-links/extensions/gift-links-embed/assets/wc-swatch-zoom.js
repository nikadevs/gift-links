/*
 * WoodenCrew Apps — big photo popup for the theme's own variant swatches
 * (product page, works without the Volume Discounts block).
 * Mouse: shows on hover. Touch: shows on tap (the theme still selects the
 * variant). Hidden on scroll, on mouse out and on a tap on the popup.
 * No extra downloads: the photo is the one the product slider already loaded.
 */
(function () {
  "use strict";
  if (window.WCSwatchZoom) return;
  window.WCSwatchZoom = true;

  var SWATCH =
    "variant-selects .bls__product-color-swatches, variant-radios .bls__product-color-swatches, " +
    ".product-form__input .bls__product-color-swatches, variant-selects [data-image], variant-radios [data-image]";

  function fileKey(u) {
    if (!u) return "";
    var p = String(u).split("?")[0].split("#")[0];
    var f = p.substring(p.lastIndexOf("/") + 1);
    f = f.replace(/_(pico|icon|thumb|small|compact|medium|large|grande|original|master|\d+x\d*|x\d+)(_crop_[a-z]+)?(@\dx)?(?=\.[a-z0-9]+$)/i, "");
    try {
      f = decodeURIComponent(f);
    } catch (e) {
      // keep as is
    }
    return f.toLowerCase();
  }
  function bgUrl(el) {
    var m = /url\(["']?([^"')]+)["']?\)/.exec(getComputedStyle(el).backgroundImage || "");
    return m ? m[1] : "";
  }
  /** the slider photo with the same file (already loaded), else a 600px photo */
  function bigSrc(sw) {
    var raw = sw.getAttribute("data-image") || bgUrl(sw);
    var key = fileKey(raw);
    if (!key) return "";
    var imgs = document.querySelectorAll(
      ".bls__prod-media img, .product__media img, .product-media img, media-gallery img, [class*='product-gallery'] img",
    );
    for (var i = 0; i < imgs.length; i++) {
      var s = imgs[i].currentSrc || imgs[i].src || "";
      if (s && fileKey(s) === key) return s;
    }
    var u = raw.replace(/_(small|compact|medium|thumb|icon|pico)(?=\.[a-z0-9]+(\?|$))/i, "");
    return u + (u.indexOf("?") >= 0 ? "&" : "?") + "width=600";
  }
  function title(sw) {
    return sw.getAttribute("data-value") || sw.getAttribute("title") || "";
  }

  var CSS =
    ".wcz-pop{position:fixed;top:0;left:0;z-index:2147483000;display:none;width:min(300px,calc(100vw - 16px));padding:8px;" +
    "border-radius:8px;background:#fff;box-shadow:0 10px 30px rgba(0,0,0,.18),0 0 0 1px rgba(0,0,0,.06);cursor:pointer;box-sizing:border-box}" +
    ".wcz-pop.is-on{display:block}.wcz-pop img{display:block;width:100%;height:auto;aspect-ratio:1/1;border-radius:4px;object-fit:contain;background:#fff}" +
    ".wcz-pop span{display:block;padding:6px 2px 0;color:#222;font-size:13px;font-weight:600;line-height:1.3;text-align:center}";

  var pop = null;
  var popFor = null;
  var popY = 0;
  var lastPointer = "";
  function popEl() {
    if (pop) return pop;
    var st = document.createElement("style");
    st.textContent = CSS;
    document.head.appendChild(st);
    pop = document.createElement("div");
    pop.className = "wcz-pop";
    pop.setAttribute("aria-hidden", "true");
    pop.innerHTML = '<img alt=""><span></span>';
    pop.addEventListener("click", hide);
    document.body.appendChild(pop);
    return pop;
  }
  /**
   * Put the popup above or below the whole group of swatches so it never covers
   * any of them: full size where it fits, otherwise shrunk to the bigger free
   * side (min 120px photo). Only when there is no room at all it sits by the photo.
   */
  function fitPop(el, group, btn) {
    var r = group.getBoundingClientRect();
    var b = btn.getBoundingClientRect();
    var vw = document.documentElement.clientWidth || window.innerWidth;
    var vh = window.innerHeight;
    var gap = 8;
    var full = Math.min(300, vw - 2 * gap);
    el.style.width = full + "px";
    var h = el.offsetHeight;
    var chrome = h - (full - 16); // padding + caption around the square photo
    var above = r.top - 2 * gap;
    var below = vh - r.bottom - 2 * gap;
    var top;
    if (above >= h) top = r.top - h - gap;
    else if (below >= h) top = r.bottom + gap;
    else {
      var room = Math.max(above, below);
      var img = Math.floor(room - chrome);
      if (img >= 120) {
        el.style.width = img + 16 + "px";
        h = el.offsetHeight;
        top = above >= below ? r.top - h - gap : r.bottom + gap;
      } else {
        top = b.top > vh - b.bottom ? b.top - h - gap : b.bottom + gap;
      }
    }
    top = Math.max(gap, Math.min(top, vh - h - gap));
    var w = el.offsetWidth;
    var left = Math.max(gap, Math.min(b.left + b.width / 2 - w / 2, vw - w - gap));
    el.style.top = Math.round(top) + "px";
    el.style.left = Math.round(left) + "px";
  }
  function place() {
    if (!pop || !popFor || !document.body.contains(popFor)) return hide();
    var group = popFor.closest("fieldset, .product-form__input, variant-selects, variant-radios") || popFor;
    fitPop(pop, group, popFor);
  }
  function show(sw, byMouse) {
    var src = bigSrc(sw);
    if (!src) return;
    var el = popEl();
    var img = el.firstChild;
    if (img.getAttribute("src") !== src) img.setAttribute("src", src);
    el.lastChild.textContent = title(sw);
    popFor = sw;
    popY = window.pageYOffset || 0;
    // with a mouse it never blocks the swatches under it; on touch a tap on it closes it
    el.style.pointerEvents = byMouse ? "none" : "auto";
    el.classList.add("is-on");
    el.setAttribute("aria-hidden", "false");
    place();
    // the popup image may load a moment later on the first show
    if (!img.complete) img.onload = place;
  }
  function hide() {
    popFor = null;
    if (!pop) return;
    pop.classList.remove("is-on");
    pop.setAttribute("aria-hidden", "true");
  }
  function swatchOf(t) {
    try {
      return t && t.closest ? t.closest(SWATCH) : null;
    } catch (e) {
      return null;
    }
  }

  document.addEventListener("pointerdown", function (e) {
    lastPointer = e.pointerType || "";
  }, true);
  document.addEventListener("pointerover", function (e) {
    if (e.pointerType !== "mouse") return;
    var sw = swatchOf(e.target);
    if (sw && sw !== popFor) show(sw, true);
  });
  document.addEventListener("pointerout", function (e) {
    if (e.pointerType !== "mouse") return;
    var sw = swatchOf(e.target);
    var to = e.relatedTarget;
    if (sw && !(to && sw.contains(to))) hide();
  });
  // tap on phones (after the theme picked the variant)
  document.addEventListener("click", function (e) {
    if (lastPointer === "mouse") return;
    var sw = swatchOf(e.target);
    if (!sw) return;
    var val = sw.getAttribute("data-value");
    setTimeout(function () {
      // the theme may re-render its swatches after the pick
      if (!document.body.contains(sw) && val) {
        var all = document.querySelectorAll(SWATCH);
        for (var i = 0; i < all.length; i++) if (all[i].getAttribute("data-value") === val) sw = all[i];
      }
      show(sw, false);
    }, 0);
  });
  window.addEventListener(
    "scroll",
    function () {
      if (popFor && Math.abs((window.pageYOffset || 0) - popY) > 4) hide();
    },
    { passive: true },
  );
  window.addEventListener("resize", hide);
})();
