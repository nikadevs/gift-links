(() => {
  if (customElements.get('wc-trustpilot')) return;
  let cacheRequest;
  const element = (tag, cls, value) => { const el = document.createElement(tag); el.className = cls; if (value !== undefined) el.textContent = value; return el; };
  const stars = (score) => {
    const el = element('span', 'wctp-stars');
    el.setAttribute('role', 'img'); el.setAttribute('aria-label', `${score} out of 5 stars`);
    for (let i = 0; i < 5; i++) { const star = element('span', 'wctp-star', '★'); star.setAttribute('aria-hidden', 'true'); star.style.setProperty('--fill', `${Math.max(0, Math.min(1, score - i)) * 100}%`); el.append(star); }
    return el;
  };
  class Trustpilot extends HTMLElement {
    connectedCallback() {
      if (this.initialized) return;
      this.initialized = true; this.index = 0; this.paused = matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.addEventListener('mouseenter', () => { this.hovered = true; });
      this.addEventListener('mouseleave', () => { this.hovered = false; });
      this.addEventListener('focusin', () => { this.focused = true; });
      this.addEventListener('focusout', e => { this.focused = this.contains(e.relatedTarget); });
      if (!cacheRequest) cacheRequest = fetch(this.dataset.endpoint, { credentials: 'omit' }).then(r => { if (!r.ok) throw new Error('Cache unavailable'); return r.json(); }).catch(() => { cacheRequest = null; return null; });
      cacheRequest.then(data => { if (data && this.isConnected) this.render(data); });
      this.observer = new MutationObserver(() => this.queuePhotos());
      this.observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset', 'data-src'] });
      this.loadListener = e => { if (e.target.matches?.('.jdgm-rev__pics img, .jdgm-rev__pic-img')) this.queuePhotos(); };
      document.addEventListener('load', this.loadListener, true);
      this.queuePhotos();
    }
    disconnectedCallback() { clearInterval(this.timer); cancelAnimationFrame(this.frame); this.observer?.disconnect(); document.removeEventListener('load', this.loadListener, true); this.initialized = false; }
    render(data) {
      if (!Number.isFinite(data.score) || !Array.isArray(data.reviews) || data.reviews.length < 5 || data.reviews.some(r => r.rating !== 5)) return;
      this.querySelector('.wctp-score').textContent = data.score.toFixed(1);
      this.querySelector('.wctp-label').textContent = data.label;
      this.querySelector('.wctp-count').textContent = `${data.count.toLocaleString('en-US')} reviews`;
      const rating = this.querySelector('.wctp-rating'); rating.replaceChildren(...stars(data.score >= 4.8 ? 5 : data.score).childNodes); rating.setAttribute('aria-label', `${data.score} out of 5 stars`);
      const slides = this.querySelector('.wctp-slides'); const dots = this.querySelector('.wctp-dots'); slides.replaceChildren(); dots.replaceChildren();
      data.reviews.slice(0, 5).forEach((r, i) => {
        const slide = element('article', 'wctp-slide'); slide.setAttribute('aria-label', `${i + 1} of 5`);
        const header = element('div', 'wctp-author'); const avatar = element('span', 'wctp-avatar', r.author.slice(0, 1).toUpperCase()); avatar.setAttribute('aria-hidden', 'true');
        const meta = element('div', 'wctp-meta'); const nameLine = element('div', 'wctp-name-line'); const reviewStars = stars(5); reviewStars.classList.add('wctp-review-stars');
        for (const star of reviewStars.children) {
          const icon = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
          icon.setAttribute('viewBox', '0 0 100 100'); icon.setAttribute('class', 'wctp-review-star-icon');
          icon.setAttribute('aria-hidden', 'true'); icon.setAttribute('focusable', 'false');
          const shape = document.createElementNS('http://www.w3.org/2000/svg', 'path');
          shape.setAttribute('d', 'M50 6 61 39 96 39 68 59 79 93 50 72 21 93 32 59 4 39 39 39Z');
          icon.append(shape); star.replaceChildren(icon);
        }
        nameLine.append(element('span', 'wctp-name', r.author));
        const date = element('time', 'wctp-date', new Date(r.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' })); date.dateTime = r.date;
        const ratingLine = element('div', 'wctp-rating-line'); ratingLine.append(reviewStars, date);
        meta.append(nameLine, ratingLine); header.append(avatar, meta);
        const text = element('div', 'wctp-text', r.text);
        slide.append(header, text); slides.append(slide);
        const dot = element('button', 'wctp-dot'); dot.type = 'button'; dot.setAttribute('aria-label', `Show review ${i + 1}`); dot.addEventListener('click', () => { this.show(i); this.startTimer(); }); dots.append(dot);
      });
      const card = this.querySelector('.wctp-card');
      if (!card.wctpNext) { card.wctpNext = true; card.addEventListener('click', e => { if (e.target.closest('a, .wctp-dots')) return; const n = this.querySelectorAll('.wctp-slide').length; if (n) { this.show((this.index + 1) % n); this.startTimer(); } }); }
      this.hidden = false; this.show(0); this.startTimer();
    }
    show(index) { this.index = index; this.querySelectorAll('.wctp-slide').forEach((s, i) => { s.hidden = i !== index; }); this.querySelectorAll('.wctp-dot').forEach((d, i) => d.setAttribute('aria-pressed', String(i === index))); }
    startTimer() { clearInterval(this.timer); this.timer = setInterval(() => { if (!this.paused && !this.hovered && !this.focused && !document.hidden) this.show((this.index + 1) % 5); }, 7000); }
    queuePhotos() { if (this.frame) return; this.frame = requestAnimationFrame(() => { this.frame = null; this.photos(); }); }
    photos() {
      const widget = Array.from(document.querySelectorAll('.jdgm-review-widget')).find(w => !this.dataset.product || w.dataset.id === this.dataset.product);
      if (!widget) return;
      // Start the same Judge.me image requests before its lazy loader reaches the widget.
      const urls = [...new Set(Array.from(widget.querySelectorAll('.jdgm-rev__pics img, .jdgm-rev__pic-img')).map(img => img.complete && img.naturalWidth > 0 ? img.currentSrc || img.src : img.getAttribute('data-src') || img.currentSrc || img.src).filter(src => /^https?:\/\//.test(src)))].slice(0, 8);
      if (!urls.length) return;
      const signature = urls.join('|'); if (signature === this.photoSignature) return; this.photoSignature = signature;
      const collage = this.querySelector('.wctp-collage'); const columns = Array.from({ length: 4 }, () => element('div', 'wctp-column'));
      urls.forEach((url, i) => { const photo = element('img', 'wctp-photo'); photo.loading = 'eager'; photo.fetchPriority = 'low'; photo.decoding = 'async'; photo.src = url; photo.alt = 'Customer product photo'; columns[i < 3 ? 0 : 1 + Math.floor((i - 3) / 2)].append(photo); });
      collage.replaceChildren(...columns); collage.hidden = false;
    }
  }
  customElements.define('wc-trustpilot', Trustpilot);
})();
