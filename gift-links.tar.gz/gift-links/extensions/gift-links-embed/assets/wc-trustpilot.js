(() => {
  if (customElements.get('wc-trustpilot')) return;
  let cacheRequest;
  const element = (tag, cls, value) => { const el = document.createElement(tag); el.className = cls; if (value !== undefined) el.textContent = value; return el; };
  const stars = (score) => {
    const el = element('span', 'wctp-stars');
    el.setAttribute('role', 'img'); el.setAttribute('aria-label', `${score} out of 5 stars`);
    for (let i = 0; i < 5; i++) { const star = element('span', 'wctp-star', '★'); star.setAttribute('aria-hidden', 'true'); star.style.setProperty('--fill', `${Math.max(0, Math.min(1, score - i)) * 100}%`); el.append(star); }
    return el;
  };
  class Trustpilot extends HTMLElement {
    connectedCallback() {
      if (this.initialized) return;
      this.initialized = true; this.index = 0; this.paused = matchMedia('(prefers-reduced-motion: reduce)').matches;
      this.addEventListener('mouseenter', () => { this.hovered = true; });
      this.addEventListener('mouseleave', () => { this.hovered = false; });
      this.addEventListener('focusin', () => { this.focused = true; });
      this.addEventListener('focusout', e => { this.focused = this.contains(e.relatedTarget); });
      this.querySelector('.wctp-pause').addEventListener('click', () => { this.paused = !this.paused; this.updatePause(); });
      this.updatePause();
      if (!cacheRequest) cacheRequest = fetch(this.dataset.endpoint, { credentials: 'omit' }).then(r => { if (!r.ok) throw new Error('Cache unavailable'); return r.json(); }).catch(() => { cacheRequest = null; return null; });
      cacheRequest.then(data => { if (data && this.isConnected) this.render(data); });
      this.observer = new MutationObserver(() => this.queuePhotos());
      this.observer.observe(document.body, { subtree: true, childList: true, attributes: true, attributeFilter: ['src', 'srcset'] });
      this.loadListener = e => { if (e.target.matches?.('.jdgm-rev__pics img, .jdgm-rev__pic-img')) this.queuePhotos(); };
      document.addEventListener('load', this.loadListener, true);
      this.queuePhotos();
    }
    disconnectedCallback() { clearInterval(this.timer); cancelAnimationFrame(this.frame); this.observer?.disconnect(); document.removeEventListener('load', this.loadListener, true); this.initialized = false; }
    updatePause() { const b = this.querySelector('.wctp-pause'); b.textContent = this.paused ? '▶' : 'Ⅱ'; b.setAttribute('aria-label', this.paused ? 'Resume review rotation' : 'Pause review rotation'); }
    render(data) {
      if (!Number.isFinite(data.score) || !Array.isArray(data.reviews) || data.reviews.length !== 7 || data.reviews.some(r => r.rating !== 5)) return;
      this.querySelector('.wctp-score').textContent = data.score.toFixed(1);
      this.querySelector('.wctp-label').textContent = data.label;
      this.querySelector('.wctp-count').textContent = `${data.count.toLocaleString('en-US')} reviews`;
      const rating = this.querySelector('.wctp-rating'); rating.replaceChildren(...stars(data.score).childNodes); rating.setAttribute('aria-label', `${data.score} out of 5 stars`);
      const slides = this.querySelector('.wctp-slides'); const dots = this.querySelector('.wctp-dots'); slides.replaceChildren(); dots.replaceChildren();
      data.reviews.forEach((r, i) => {
        const slide = element('article', 'wctp-slide'); slide.setAttribute('aria-label', `${i + 1} of 7`);
        const header = element('div', 'wctp-author'); const avatar = element('span', 'wctp-avatar', r.author.slice(0, 1).toUpperCase()); avatar.setAttribute('aria-hidden', 'true');
        const meta = element('div', 'wctp-meta'); const nameLine = element('div', 'wctp-name-line'); const reviewStars = stars(5); reviewStars.classList.add('wctp-review-stars');
        nameLine.append(element('span', 'wctp-name', r.author), reviewStars);
        const date = element('time', 'wctp-date', new Date(r.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric', timeZone: 'UTC' })); date.dateTime = r.date;
        meta.append(nameLine, date); header.append(avatar, meta);
        const text = element('a', 'wctp-text', r.text); if (/^https:\/\/www\.trustpilot\.com\/reviews\/[a-z\d]+$/i.test(r.url)) text.href = r.url; text.target = '_blank'; text.rel = 'noopener';
        slide.append(header, text); slides.append(slide);
        const dot = element('button', 'wctp-dot'); dot.type = 'button'; dot.setAttribute('aria-label', `Show review ${i + 1}`); dot.addEventListener('click', () => { this.show(i); this.startTimer(); }); dots.append(dot);
      });
      this.hidden = false; this.show(0); this.startTimer();
    }
    show(index) { this.index = index; this.querySelectorAll('.wctp-slide').forEach((s, i) => { s.hidden = i !== index; }); this.querySelectorAll('.wctp-dot').forEach((d, i) => d.setAttribute('aria-pressed', String(i === index))); }
    startTimer() { clearInterval(this.timer); this.timer = setInterval(() => { if (!this.paused && !this.hovered && !this.focused && !document.hidden) this.show((this.index + 1) % 7); }, 7000); }
    queuePhotos() { if (this.frame) return; this.frame = requestAnimationFrame(() => { this.frame = null; this.photos(); }); }
    photos() {
      const widget = Array.from(document.querySelectorAll('.jdgm-review-widget')).find(w => !this.dataset.product || w.dataset.id === this.dataset.product);
      if (!widget) return;
      const urls = [...new Set(Array.from(widget.querySelectorAll('.jdgm-rev__pics img, .jdgm-rev__pic-img')).filter(img => img.complete && img.naturalWidth > 0).map(img => img.currentSrc || img.src).filter(src => /^https?:\/\//.test(src)))].slice(0, 9);
      if (!urls.length) return;
      const signature = urls.join('|'); if (signature === this.photoSignature) return; this.photoSignature = signature;
      const collage = this.querySelector('.wctp-collage'); const columns = Array.from({ length: 4 }, () => element('div', 'wctp-column'));
      urls.forEach((url, i) => { const photo = element('img', 'wctp-photo'); photo.src = url; photo.alt = 'Customer product photo'; photo.decoding = 'async'; columns[i < 3 ? 0 : 1 + Math.floor((i - 3) / 2)].append(photo); });
      collage.replaceChildren(...columns); collage.hidden = false;
    }
  }
  customElements.define('wc-trustpilot', Trustpilot);
})();
