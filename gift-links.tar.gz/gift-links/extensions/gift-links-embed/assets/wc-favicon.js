/*
 * WoodenCrew Apps — Favicon Cart Count (replacement for Vitals «Favicon Cart Count").
 * Draws the number of items in the cart over the store favicon (browser tab).
 * Settings come from data-* attributes of <script id="wc-fav"> (blocks/gift-links.liquid).
 * - Initial count from Liquid (cart.item_count) — no request on page load.
 * - Cart changes made by the theme/apps are noticed passively (PerformanceObserver on
 *   /cart/add|change|update|clear) and re-read from /cart.js. fetch/XHR are not wrapped.
 * - The favicon image is the theme's own icon URL; it is loaded (CORS) only when count > 0.
 * - Animation frames are computed from elapsed time, so throttled timers in background
 *   tabs still end on the right frame.
 */
(function () {
  "use strict";
  var d = document;
  var el = d.getElementById("wc-fav");
  if (!el || window.__wcFav) return;
  window.__wcFav = 1;
  var ds = el.dataset;
  var O = {
    shape: ds.shape === "rectangle" ? "rectangle" : "circle",
    pos: ds.pos || "bottom-left",
    anim: ds.anim || "pop",
    bg: ds.bg || "#ff0101",
    fg: ds.fg || "#ffffff",
    every: Math.max(0, parseInt(ds.every, 10) || 0) * 1000,
  };
  var DUR = 400; // ms, one in-animation (≈10 frames × 40 ms, like favico.js)
  var STEP = 40;
  var count = parseInt(ds.count, 10) || 0;
  var originals = null; // original <link rel=icon> elements
  var ours = null;
  var img = null;
  var imgState = 0; // 0 none, 1 loading, 2 ready, 3 failed
  var canvas = null;
  var ctx = null;
  var S = 32;
  var animStart = 0;
  var tick = null;
  var repeat = null;

  function iconLinks() {
    var l = d.querySelectorAll('link[rel~="icon"]');
    var out = [];
    for (var i = 0; l.length > i; i++) if (l[i] !== ours) out.push(l[i]);
    return out;
  }

  function loadImg(cb) {
    if (imgState === 2) return cb();
    if (imgState === 1 || imgState === 3) return;
    var links = iconLinks();
    if (!links.length) {
      imgState = 3;
      return;
    }
    imgState = 1;
    var src = links[links.length - 1].href;
    img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = function () {
      imgState = 2;
      S = Math.min(Math.max(img.naturalWidth || 32, 32), 64);
      canvas = d.createElement("canvas");
      canvas.width = canvas.height = S;
      ctx = canvas.getContext("2d");
      cb();
    };
    img.onerror = function () {
      imgState = 3;
    };
    img.src = src;
  }

  function label(n) {
    return n > 99 ? "99+" : String(n);
  }

  function ease(p) {
    return 1 - Math.pow(1 - p, 3);
  }

  // Badge box at progress p (0..1) — same idea as favico.js frames.
  function frame(n, p) {
    var t = label(n);
    var h = S * 0.6;
    var w = t.length === 1 ? h : t.length === 2 ? h * 1.4 : S;
    var left = O.pos.indexOf("left") >= 0;
    var top = O.pos.indexOf("top") === 0;
    var x = left ? 0 : S - w;
    var y = top ? 0 : S - h;
    var a = 1;
    var k = ease(p);
    if (O.anim === "fade") a = k;
    else if (O.anim === "pop" || O.anim === "popFade") {
      // grows from the outer corner
      var nw = w * k;
      var nh = h * k;
      x = left ? x : x + (w - nw);
      y = top ? y : y + (h - nh);
      w = nw;
      h = nh;
      if (O.anim === "popFade") a = k;
    } else if (O.anim === "slide") {
      y = top ? -h + (y + h) * k : y + (S - y) * (1 - k);
    }
    return { x: x, y: y, w: w, h: h, a: a, t: t };
  }

  function round(c, x, y, w, h, r) {
    c.beginPath();
    c.moveTo(x + r, y);
    c.lineTo(x + w - r, y);
    c.arc(x + w - r, y + r, r, -Math.PI / 2, Math.PI / 2);
    c.lineTo(x + r, y + h);
    c.arc(x + r, y + r, r, Math.PI / 2, (3 * Math.PI) / 2);
    c.closePath();
  }

  function render(p) {
    if (imgState !== 2) return;
    var f = frame(count, p);
    ctx.clearRect(0, 0, S, S);
    ctx.globalAlpha = 1;
    ctx.drawImage(img, 0, 0, S, S);
    if (f.w > 0.5 && f.h > 0.5) {
      ctx.globalAlpha = f.a;
      ctx.fillStyle = O.bg;
      if (O.shape === "circle") {
        if (f.w - f.h < 0.5) {
          ctx.beginPath();
          ctx.arc(f.x + f.w / 2, f.y + f.h / 2, f.h / 2, 0, 2 * Math.PI);
        } else round(ctx, f.x, f.y, f.w, f.h, f.h / 2);
        ctx.fill();
      } else ctx.fillRect(f.x, f.y, f.w, f.h);
      var fs = f.h * (f.t.length === 1 ? 0.85 : f.t.length === 2 ? 0.75 : 0.6);
      if (fs >= 3) {
        ctx.fillStyle = O.fg;
        ctx.font = "bold " + Math.round(fs) + "px Arial, Helvetica, sans-serif";
        ctx.textAlign = "center";
        ctx.textBaseline = "middle";
        ctx.fillText(f.t, f.x + f.w / 2, f.y + f.h / 2 + f.h * 0.06);
      }
    }
    ctx.globalAlpha = 1;
    var url;
    try {
      url = canvas.toDataURL("image/png");
    } catch (e) {
      imgState = 3; // tainted canvas (no CORS) — leave the theme favicon alone
      restore();
      return;
    }
    setIcon(url);
  }

  function setIcon(url) {
    if (!ours) {
      originals = iconLinks();
      for (var i = 0; originals.length > i; i++) originals[i].parentNode && originals[i].parentNode.removeChild(originals[i]);
      ours = d.createElement("link");
      ours.rel = "icon";
      ours.type = "image/png";
      ours.id = "wc-fav-link";
      d.head.appendChild(ours);
    }
    ours.href = url;
  }

  function restore() {
    stop();
    if (!ours) return;
    if (ours.parentNode) ours.parentNode.removeChild(ours);
    ours = null;
    if (originals) for (var i = 0; originals.length > i; i++) d.head.appendChild(originals[i]);
    originals = null;
  }

  function stop() {
    if (tick) clearTimeout(tick);
    if (repeat) clearTimeout(repeat);
    tick = repeat = null;
  }

  function step() {
    var p = O.anim === "none" ? 1 : Math.min(1, (Date.now() - animStart) / DUR);
    render(p);
    if (p < 1) tick = setTimeout(step, STEP);
    else {
      tick = null;
      if (O.every && O.anim !== "none" && count > 0) repeat = setTimeout(play, O.every);
    }
  }

  function play() {
    stop();
    if (count <= 0) return restore();
    loadImg(function () {
      if (count <= 0) return restore();
      stop();
      animStart = Date.now();
      step();
    });
  }

  function setCount(n) {
    n = Math.max(0, parseInt(n, 10) || 0);
    if (n === count && (n === 0 || ours)) return;
    count = n;
    play();
  }

  var busy = 0;
  var last = 0;
  function refresh() {
    if (busy) return;
    busy = 1;
    last = Date.now();
    var root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
    fetch(root + "cart.js", { credentials: "same-origin", headers: { Accept: "application/json" } })
      .then(function (r) {
        return r.ok ? r.json() : null;
      })
      .then(function (c) {
        busy = 0;
        if (c && typeof c.item_count === "number") setCount(c.item_count);
      })
      .catch(function () {
        busy = 0;
      });
  }
  var deb = null;
  function later() {
    if (deb) clearTimeout(deb);
    deb = setTimeout(refresh, 250);
  }

  var RE = /\/cart\/(add|change|update|clear)(\.js|\.json)?(\?|$)/;
  if (window.PerformanceObserver) {
    try {
      new PerformanceObserver(function (list) {
        var e = list.getEntries();
        for (var i = 0; e.length > i; i++) {
          if (RE.test(e[i].name.split("#")[0].replace(location.origin, ""))) {
            later();
            return;
          }
        }
      }).observe({ type: "resource" });
    } catch (e) {
      /* old browser — count still updates on navigation */
    }
  }
  // Back/forward cache and changes made in another tab.
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) refresh();
  });
  d.addEventListener("visibilitychange", function () {
    if (d.visibilityState === "visible" && Date.now() - last > 10000) refresh();
  });

  window.WcFaviconCount = { set: setCount, refresh: refresh };
  if (count > 0) play();
})();
