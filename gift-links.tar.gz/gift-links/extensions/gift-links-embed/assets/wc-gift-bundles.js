/*
 * WoodenCrew Apps — Gift Bundles (storefront).
 *
 * Catalog bundle products are normal products; their free extras (gifts,
 * warranty, PDF book…) are $0 products kept in the cart by this script:
 *  - one line per gift variant with the hidden property _wc_gb,
 *    quantity = Σ (parent quantity × qty in bundle);
 *  - our lines that are no longer needed are removed;
 *  - a $0 gift COPY (map.g) sitting in the cart without _wc_gb is removed
 *    (it can't be bought on its own).
 * Lines without _wc_gb are never touched otherwise (PDF book added by other
 * scripts, Volume Discounts / Gift Links gifts, Simple-Bundle leftovers…).
 * Missing gifts are also added to the ORDER by the app server (Buy now,
 * Shop Pay…), so this script is for the cart view.
 *
 * Cart changes made by the theme / other apps are noticed passively
 * (PerformanceObserver on /cart/add|change|update|clear); fetch/XHR are not
 * wrapped. Same logic as cartPlan() in app/gb.shared.ts.
 */
(function () {
  "use strict";
  var el = document.getElementById("wc-gb-map");
  if (!el || window.WCGiftBundles) return;
  var MAP;
  try {
    MAP = JSON.parse(el.textContent || "{}");
  } catch (e) {
    return;
  }
  var M = (MAP && MAP.m) || {};
  var G = {};
  ((MAP && MAP.g) || []).forEach(function (v) {
    G[v] = 1;
  });
  var PROP = "_wc_gb";
  var ROOT = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
  var RE = /\/cart\/(add|change|update|clear)(\.js)?(\?|\/|$)/;
  var busy = false;
  var again = false;
  var timer = 0;
  var stamps = [];

  function json(url, body) {
    var opt = { credentials: "same-origin", headers: { Accept: "application/json" } };
    if (body) {
      opt.method = "POST";
      opt.headers["Content-Type"] = "application/json";
      opt.body = JSON.stringify(body);
    }
    return fetch(ROOT + url, opt).then(function (r) {
      if (!r.ok) throw new Error("HTTP " + r.status);
      return r.json();
    });
  }

  function ours(line) {
    return !!(line.properties && line.properties[PROP]);
  }

  function plan(items) {
    var want = {};
    var i, j, l;
    for (i = 0; i < items.length; i++) {
      l = items[i];
      if (ours(l)) continue;
      var gifts = M[String(l.variant_id)] || [];
      for (j = 0; j < gifts.length; j++) want[gifts[j][0]] = (want[gifts[j][0]] || 0) + l.quantity * gifts[j][1];
    }
    var have = {};
    for (i = 0; i < items.length; i++) {
      l = items[i];
      if (!ours(l)) continue;
      (have[l.variant_id] = have[l.variant_id] || []).push(l);
    }
    var updates = {};
    var adds = [];
    var n = 0;
    var keys = {};
    for (var a in want) keys[a] = 1;
    for (var b in have) keys[b] = 1;
    for (var g in keys) {
      var w = want[g] || 0;
      var list = have[g] || [];
      var sum = 0;
      for (j = 0; j < list.length; j++) sum += list[j].quantity;
      if (sum === w && list.length <= 1) continue;
      if (!list.length) {
        if (w > 0) adds.push({ id: Number(g), quantity: w, properties: { _wc_gb: "1" } });
        continue;
      }
      for (j = 0; j < list.length; j++) {
        var q = j === 0 ? w : 0;
        if (list[j].quantity !== q) {
          updates[list[j].key] = q;
          n++;
        }
      }
    }
    for (i = 0; i < items.length; i++) {
      l = items[i];
      if (G[l.variant_id] && !ours(l)) {
        updates[l.key] = 0;
        n++;
      }
    }
    return { updates: updates, n: n, adds: adds };
  }

  function refreshUI() {
    try {
      document.dispatchEvent(new CustomEvent("wc-gift-bundles:cart-updated", { bubbles: true }));
    } catch (e) {
      // ignore
    }
    if (/\/cart\/?$/.test(window.location.pathname)) {
      if (window.WCCartPage && window.WCCartPage.refresh) window.WCCartPage.refresh();
      else {
        try {
          var last = Number(window.sessionStorage.getItem("wc.reload.at") || 0);
          if (Date.now() - last < 10000) return;
          window.sessionStorage.setItem("wc.reload.at", String(Date.now()));
        } catch (e) {
          return;
        }
        window.location.reload();
      }
      return;
    }
    var ids = [];
    if (document.getElementById("form-mini-cart")) ids.push("form-mini-cart"); // Umino
    if (document.getElementById("cart-icon-bubble")) ids.push("cart-icon-bubble"); // Dawn
    if (document.getElementById("CartDrawer")) ids.push("cart-drawer"); // Dawn
    json("cart.js")
      .then(function (cart) {
        var c = document.querySelectorAll(".cart-count");
        for (var i = 0; i < c.length; i++)
          c[i].innerHTML = c[i].classList.contains("cart-count-drawer") ? "(" + cart.item_count + ")" : cart.item_count;
      })
      .catch(function () {});
    if (!ids.length) return;
    fetch(ROOT + "?sections=" + ids.join(","), { credentials: "same-origin" })
      .then(function (r) {
        return r.json();
      })
      .then(function (s) {
        var swap = function (id, html, sel) {
          var node = document.getElementById(id);
          var next = html && new DOMParser().parseFromString(html, "text/html").querySelector(sel);
          if (node && next) node.innerHTML = next.innerHTML;
        };
        swap("form-mini-cart", s["form-mini-cart"], "#form-mini-cart");
        swap("cart-icon-bubble", s["cart-icon-bubble"], ".shopify-section");
        swap("CartDrawer", s["cart-drawer"], "#CartDrawer");
      })
      .catch(function () {});
  }

  function sync() {
    if (busy) {
      again = true;
      return;
    }
    // at most 6 runs per 10 s (no loops with other scripts)
    var now = Date.now();
    stamps = stamps.filter(function (t) {
      return now - t < 10000;
    });
    if (stamps.length >= 6) return;
    stamps.push(now);
    busy = true;
    json("cart.js")
      .then(function (cart) {
        var p = plan(cart.items || []);
        if (!p.n && !p.adds.length) return false;
        var step = p.n ? json("cart/update.js", { updates: p.updates }) : Promise.resolve();
        return step
          .then(function () {
            if (!p.adds.length) return;
            return json("cart/add.js", { items: p.adds }).catch(function () {
              // one gift unavailable → add the others one by one
              return p.adds.reduce(function (chain, it) {
                return chain.then(function () {
                  return json("cart/add.js", { items: [it] }).catch(function () {});
                });
              }, Promise.resolve());
            });
          })
          .then(function () {
            return true;
          });
      })
      .then(function (changed) {
        if (changed) refreshUI();
      })
      .catch(function () {})
      .then(function () {
        busy = false;
        if (again) {
          again = false;
          later(300);
        }
      });
  }

  function later(ms) {
    clearTimeout(timer);
    timer = setTimeout(sync, ms == null ? 250 : ms);
  }

  if (window.PerformanceObserver) {
    try {
      new PerformanceObserver(function (list) {
        var e = list.getEntries();
        for (var i = 0; i < e.length; i++) {
          if (RE.test(e[i].name.split("#")[0].replace(location.origin, ""))) {
            later();
            return;
          }
        }
      }).observe({ type: "resource" });
    } catch (e) {
      // old browser: sync on page load only
    }
  }
  window.addEventListener("pageshow", function (e) {
    if (e.persisted) later(0);
  });
  window.WCGiftBundles = { sync: sync, plan: plan };
  later(0);
})();
