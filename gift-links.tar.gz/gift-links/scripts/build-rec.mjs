// Builds the storefront recorder: rec/recorder.src.js (+ rrweb record) →
// extensions/gift-links-embed/assets/wc-rec.js. Run: node scripts/build-rec.mjs
import { build } from "esbuild";

await build({
  entryPoints: ["rec/recorder.src.js"],
  outfile: "extensions/gift-links-embed/assets/wc-rec.js",
  bundle: true,
  minify: true,
  format: "iife",
  target: ["es2018"],
  legalComments: "none",
  banner: { js: "/* WoodenCrew Apps · Session Recordings · rrweb (MIT) */" },
  logLevel: "info",
});
