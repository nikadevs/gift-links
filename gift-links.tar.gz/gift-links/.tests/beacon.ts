import fs from "node:fs"; import os from "node:os"; import path from "node:path";
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "wcb-")); process.env.WC_DATA_DIR = dir;
(async () => {
  const { action } = await import("../app/routes/api.seo.404");
  const post = (body: string, ip = "1.1.1.1") => action({ request: new Request("https://x/api/seo/404", { method: "POST", body, headers: { "x-forwarded-for": ip } }), params: {}, context: {} } as any);
  const r1 = await post(JSON.stringify({ shop: "8e4f20.myshopify.com", path: "/products/old-thing?utm=1", ref: "https://www.google.com/search?q=x" }));
  await post(JSON.stringify({ shop: "8e4f20.myshopify.com", path: "/products/old-thing/", ref: "" }));
  await post(JSON.stringify({ shop: "evil.com", path: "/x" }));
  await post(JSON.stringify({ shop: "8e4f20.myshopify.com", path: "/wp-login.php" }));
  await post("not json");
  for (let i = 0; i < 25; i++) await post(JSON.stringify({ shop: "8e4f20.myshopify.com", path: "/flood" }), "9.9.9.9");
  console.log("status", r1.status, r1.headers.get("access-control-allow-origin"));
  console.log(fs.readFileSync(path.join(dir, "seo/8e4f20.myshopify.com/404.json"), "utf8"));
})();
