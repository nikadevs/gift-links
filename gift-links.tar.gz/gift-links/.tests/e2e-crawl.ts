import http from "node:http";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

const F = "/home/claude/fixtures/";
const data = fs.mkdtempSync(path.join(os.tmpdir(), "wcseo-"));
process.env.WC_DATA_DIR = data;

const server = http.createServer((req, res) => {
  const origin = `http://127.0.0.1:${(server.address() as any).port}`;
  const fix = (f: string) =>
    fs.readFileSync(F + f, "utf8").replaceAll("https://woodencrew.store", origin).replaceAll("//woodencrew.store", "//127.0.0.1:" + (server.address() as any).port);
  const u = new URL(req.url!, origin);
  const send = (status: number, body: string, type = "text/html; charset=utf-8", extra: Record<string, string> = {}) => {
    res.writeHead(status, { "content-type": type, ...extra });
    res.end(req.method === "HEAD" ? undefined : body);
  };
  const p = u.pathname;
  if (p === "/robots.txt") return send(200, fix("robots.txt"), "text/plain");
  if (p === "/sitemap.xml") return send(200, `<?xml version="1.0"?><sitemapindex><sitemap><loc>${origin}/sitemap_products_1.xml?from=1</loc></sitemap><sitemap><loc>https://other.example/sitemap.xml</loc></sitemap></sitemapindex>`, "application/xml");
  if (p === "/sitemap_products_1.xml") return send(200, `<urlset>${["/products/pillow-deep-sleep-set", "/collections/all", "/blogs/travel/the-joy-of-slow-travel-embracing-the-journey-not-just-the-destination", "/products/dead-product", "/pages/moved"].map((x) => `<url><loc>${origin}${x}</loc></url>`).join("")}</urlset>`, "application/xml");
  if (p === "/") return send(200, fix("home.html").replace("</main>", `<a href="/pages/broken-test">x</a><a href="/pages/old-link">y</a></main>`));
  if (p === "/products/pillow-deep-sleep-set") return send(200, fix("products_pillow-deep-sleep-set.html"));
  if (p === "/collections/all") return send(200, fix("collections_all.html"));
  if (p.startsWith("/blogs/travel/the-joy")) return send(200, fix("blogs_travel_the-joy-of-slow-travel-embracing-the-journey-not-just-the-destination.html"));
  if (p === "/pages/moved" || p === "/pages/old-link") { res.writeHead(301, { location: "/pages/contact" }); return res.end(); }
  if (p === "/pages/broken-test" || p === "/products/dead-product") return send(404, "<html><head><title>404</title></head><body>nf</body></html>");
  if (p.endsWith(".mp4")) return send(200, "x", "video/mp4", { "content-length": String(5 * 1024 * 1024) });
  if (p.endsWith(".js")) return send(200, "console.log(1)".repeat(100), "application/javascript");
  return send(200, `<html lang="en"><head><title>Generic page ${p} title here</title><meta name="description" content="generic"></head><body><h1>x</h1></body></html>`);
});

server.listen(0, "127.0.0.1", async () => {
  const origin = `http://127.0.0.1:${(server.address() as any).port}`;
  const { runCrawl } = await import("/home/claude/wc/app/seo/seo-crawl.server");
  const { record404 } = await import("/home/claude/wc/app/seo/seo-store.server");
  await record404("test.myshopify.com", "/products/old", "google.com");
  const t = Date.now();
  const r = await runCrawl({ shop: "test.myshopify.com", origin, mode: "full" });
  console.log("took", Date.now() - t, "ms");
  if (!r) { console.log("NO REPORT", fs.readFileSync(path.join(data, "seo/test.myshopify.com/job-crawl.json"), "utf8")); process.exit(1); }
  console.log({ checked: r.checked, discovered: r.discovered, links: r.linksChecked, score: r.score, robots: r.robots, sitemap: r.sitemap, notes: r.notes });
  const by: Record<string, number> = {};
  for (const f of r.findings) by[f.check] = (by[f.check] ?? 0) + 1;
  console.log(by);
  for (const c of ["broken_link", "link_to_redirect", "http_error", "redirected", "video_heavy", "not_found_hits", "title_duplicate", "desc_duplicate"])
    console.log(c, r.findings.filter((f) => f.check === c).slice(0, 3).map((f) => `${f.url.replace(origin, "")} :: ${f.detail?.replaceAll(origin, "")}`));
  console.log("scripts", r.scripts.slice(0, 5).map((s) => [s.src.replace(origin, ""), s.pages, s.bytes, s.thirdParty]));
  console.log("files", fs.readdirSync(path.join(data, "seo/test.myshopify.com")));
  server.close();
  process.exit(0);
});
