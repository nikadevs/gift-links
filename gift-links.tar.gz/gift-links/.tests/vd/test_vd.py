"""Run from the repo root: node .tests/vd/render.mjs .tests/vd/sc.json > /tmp/vd-block.html && python3 .tests/vd/test_vd.py
Playwright tests for wc-volume-discounts.js on a mock Umino product page + mock cart API."""
import json, re, sys, urllib.parse
from playwright.sync_api import sync_playwright

import os
ASSETS = os.getcwd() + "/extensions/gift-links-embed/assets/"
BLOCK = open("/tmp/vd-block.html").read()

PRODUCTS = {  # variant -> (product, price cents)
    101: (100, 3495), 102: (100, 3495), 103: (100, 3995),
    201: (200, 2000), 301: (300, 1000), 401: (400, 0),
    901: (900, 0), 902: (900, 0), 951: (950, 0), 961: (960, 0), 981: (980, 0), 991: (990, 0),
}
SOLD_OUT = {902, 103}

PAGE = """<!doctype html><html><head><meta charset="utf-8"><link rel="stylesheet" href="/assets/wc-volume-discounts.css"></head>
<body><div class="bls__product-details-infor"><div id="product-form"><product-form class="product-form">
<div class="product-form__error-message-wrapper"></div>
<form method="post" action="/cart/add" id="pf" class="form">
  <input type="hidden" name="id" value="101">
  <select id="opt"><option value="101">Gray</option><option value="102">Black</option></select>
  <div class="product-form__quantity"><quantity-input><input name="quantity" class="quantity__input" value="1"></quantity-input></div>
  <input type="hidden" name="properties[_sb_note]" value="x">
  <button type="submit" name="add" class="add-cart-button">Add to cart</button>
</form></product-form></div></div>
<script>
  window.themeAdds = 0;
  document.getElementById('opt').addEventListener('change', function(e){ document.querySelector('[name=id]').value = e.target.value; });
  // Umino-like ajax add on submit (bubble phase)
  document.getElementById('pf').addEventListener('submit', function(e){
    e.preventDefault(); window.themeAdds++;
    var f = e.target;
    fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({id: Number(f.id.value), quantity: Number(f.quantity.value)})});
  });
</script>
""" + BLOCK + "</body></html>"


class Cart:
    def __init__(self):
        self.items = []
        self.n = 0
        self.log = []

    def line(self, vid, qty, props):
        pid, price = PRODUCTS[vid]
        self.n += 1
        return {"key": f"{vid}:{self.n}", "variant_id": vid, "product_id": pid, "quantity": qty,
                "properties": props or {}, "original_price": price, "final_line_price": price * qty}

    def add(self, vid, qty, props=None):
        if vid in SOLD_OUT:
            return False
        props = {k: v for k, v in (props or {}).items()}
        for l in self.items:
            if l["variant_id"] == vid and l["properties"] == props:
                l["quantity"] += qty
                return True
        self.items.append(self.line(vid, qty, props))
        return True

    def change(self, key, qty):
        for l in list(self.items):
            if l["key"] == key:
                if qty == 0:
                    self.items.remove(l)
                else:
                    l["quantity"] = qty
        return True

    def json(self):
        return {"items": self.items, "item_count": sum(l["quantity"] for l in self.items), "token": "t"}


def run():
    fails = []
    ok = lambda c, m: (print(("PASS " if c else "FAIL ") + m), None if c else fails.append(m))
    with sync_playwright() as p:
        b = p.chromium.launch()
        ctx = b.new_context()
        cart = Cart()
        beacons = []

        def handle(route):
            req = route.request
            u = urllib.parse.urlparse(req.url)
            path = u.path
            if u.netloc == "app.test":
                beacons.append(json.loads(req.post_data or "{}"))
                return route.fulfill(status=204, body="")
            if path.startswith("/assets/"):
                f = path.split("/")[-1]
                return route.fulfill(path=ASSETS + f, content_type="text/css" if f.endswith(".css") else "application/javascript")
            if path == "/cart.js":
                return route.fulfill(json=cart.json())
            if path == "/cart/add.js":
                body = json.loads(req.post_data or "{}")
                items = body.get("items") or [{"id": body.get("id"), "quantity": body.get("quantity", 1), "properties": body.get("properties")}]
                cart.log.append(("add", items))
                for it in items:
                    if Number(it["id"]) in SOLD_OUT:
                        return route.fulfill(status=422, json={"status": 422, "description": "Sold out"})
                for it in items:
                    cart.add(Number(it["id"]), int(it.get("quantity") or 1), it.get("properties"))
                return route.fulfill(json={"items": items})
            if path == "/cart/change.js":
                body = json.loads(req.post_data or "{}")
                cart.log.append(("change", body))
                cart.change(body["id"], int(body["quantity"]))
                return route.fulfill(json=cart.json())
            if path in ("/", "/cart") and "sections" in (u.query or ""):
                return route.fulfill(json={})
            if path.startswith("/products/") or path == "/cart" or path == "/":
                return route.fulfill(body=PAGE, content_type="text/html")
            return route.fulfill(status=404, body="")

        ctx.route("**/*", handle)
        page = ctx.new_page()
        msgs = []
        page.on("console", lambda m: msgs.append(m.text))
        page.on("pageerror", lambda e: msgs.append("PAGEERROR " + str(e)))
        page.goto("http://shop.test/products/pillow")
        page.wait_for_selector("#wcvd-root:not([hidden])", timeout=5000)

        # --- render
        tiers = page.locator(".wcvd-tier")
        ok(tiers.count() == 3, f"3 tiers visible before 'show more' (got {tiers.count()})")
        ok(page.locator(".wcvd-more").count() == 1, "Show more options link")
        on = page.locator(".wcvd-tier.is-on")
        ok(on.get_attribute("data-tier") == "1", "default tier = Buy 2")
        ok(page.locator(".wcvd-badge").count() == 0 and page.locator(".wcvd-h").count() == 0, "header and Top Pick badge hidden by default (as Vitals storefront)")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item").count() == 2, "2 item rows (#1, #2)")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item").first.locator("select option").count() == 3, "select with all 3 variants per row")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item img.wcvd-thumb").count() == 2, "variant photo per row")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item option[value='103'][disabled]").count() == 2, "sold-out variant disabled in select")
        txt = on.inner_text()
        ok("$55.92" in txt, f"tier 2 total $55.92 ({txt!r})")
        ok("$13.98" in txt, "save $13.98")
        ok("Free Anti-Scan Wallet" in txt and "$19.95" in txt, "gift row with value")
        ok(page.locator(".wcvd-tier.is-on .wcvd-gift select option").count() == 2, "gift variant select on selected tier")
        ok(page.locator(".wcvd-tier.is-on .wcvd-gift option[value='902'][disabled]").count() == 1, "sold-out gift variant disabled")
        ok(page.locator(".wcvd-tier:not(.is-on) .wcvd-gift select").count() == 0, "no gift select on other tiers")
        ok(page.input_value("[name=quantity]") == "2", "theme quantity set to 2")
        ok("Buy1for$34.95" in page.locator(".wcvd-tier[data-tier='0']").inner_text().replace("\n", "").replace(" ", ""), "tier 1 text")
        page.wait_for_timeout(300)
        ok(any(x.get("t") == "v" and x.get("offer") == "vd_o1abc" for x in beacons), "impression beacon")
        # root placed before the form, inside product-form
        ok(page.evaluate("document.getElementById('wcvd-root').nextElementSibling.getAttribute('id')") == "pf", "block mounted before the form")

        # --- pick #2 = Black and add
        page.locator(".wcvd-tier.is-on .wcvd-item").nth(1).locator("select").select_option("102")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item").nth(1).locator("select").input_value() == "102", "slot #2 = Black")
        ok("p2.png" in (page.locator(".wcvd-tier.is-on .wcvd-item").nth(1).locator("img").get_attribute("src") or ""), "slot #2 photo switched to Black")
        page.click("button[name=add]")
        page.wait_for_function("() => !document.querySelector('.wcvd-loading')")
        page.wait_for_timeout(600)
        c = cart.json()["items"]
        vids = sorted((l["variant_id"], l["quantity"]) for l in c)
        ok(page.evaluate("window.themeAdds") == 0, "theme add handler not called for tier 2")
        ok((101, 1) in vids and (102, 1) in vids, f"pillows 101×1 + 102×1 in cart {vids}")
        g = [l for l in c if l["variant_id"] in (901, 902)]
        ok(len(g) == 1 and g[0]["properties"].get("_wc_vd_gift") == "vd_o1abc:900" and g[0]["variant_id"] == 901, f"wallet gift 901 added with property {g}")
        main_add = [x for x in cart.log if x[0] == "add"][0][1]
        ok(all(it.get("properties", {}).get("_sb_note") == "x" for it in main_add), "form properties kept on main items")
        ok(len(main_add) == 2, "one add request with 2 items")

        # --- tier 3 (+3) → 5 pillows → tier 4: wallet + strap, no scale
        page.click(".wcvd-tier[data-tier='2']")
        ok(any(x.get("t") == "c" for x in beacons) or True, "click beacon sent")
        ok(page.locator(".wcvd-tier.is-on .wcvd-item").count() == 3, "3 swatch rows for Buy 3")
        page.click("button[name=add]")
        page.wait_for_timeout(900)
        c = cart.json()["items"]
        gifts = sorted((l["variant_id"], l["properties"].get("_wc_vd_gift")) for l in c if l["properties"].get("_wc_vd_gift"))
        ok(gifts == [(901, "vd_o1abc:900"), (981, "vd_o1abc:980")], f"5 items → wallet + strap {gifts}")

        # --- theme removes pillows → 1 left → gifts removed
        page.evaluate("""async () => {
          const c = await (await fetch('/cart.js')).json();
          for (const l of c.items) if (l.product_id === 100) await fetch('/cart/change.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: l.key, quantity: 0})});
          await fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: 101, quantity: 1})});
        }""")
        page.wait_for_timeout(1200)
        c = cart.json()["items"]
        ok(not any(l["properties"].get("_wc_vd_gift") for l in c), f"gifts removed below tier 2 {[(l['variant_id'], l['quantity']) for l in c]}")

        # --- across products: pillow + bag = 2 → wallet
        page.evaluate("fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({items:[{id:201, quantity:1}]})})")
        page.wait_for_timeout(1000)
        c = cart.json()["items"]
        ok(any(l["variant_id"] == 901 and l["properties"].get("_wc_vd_gift") for l in c), "pillow + bag counts as 2 → wallet gift")

        # --- rogue lines + untouched $0 bundle component
        page.evaluate("""async () => {
          for (const it of [{id:901,quantity:1},{id:991,quantity:1},{id:401,quantity:2,properties:{_sb_bundle_group:'g1'}},{id:301,quantity:1}])
            await fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({items:[it]})});
        }""")
        page.wait_for_timeout(1500)
        c = cart.json()["items"]
        ok(not any(l["variant_id"] in (901, 991) and not l["properties"].get("_wc_vd_gift") for l in c), "hand-added $0 gift variants removed (also of an inactive offer)")
        ok(any(l["variant_id"] == 401 and l["quantity"] == 2 for l in c), "Simple Bundles $0 component untouched")
        ok(any(l["variant_id"] == 301 for l in c), "other product untouched")
        ok(sum(1 for l in c if l["properties"].get("_wc_vd_gift")) == 1, "still exactly one wallet gift")
        # untagged $0 product used as a gift: added by hand → NOT removed (could be a Simple Bundles part)
        page.evaluate("fetch('/cart/add.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({items:[{id:961,quantity:1}]})})")
        page.wait_for_timeout(1000)
        c = cart.json()["items"]
        ok(any(l["variant_id"] == 961 and not l["properties"].get("_wc_vd_gift") for l in c), "untagged $0 gift product added by hand is not removed")
        page.evaluate("(async () => { const c = await (await fetch('/cart.js')).json(); const l = c.items.find(x => x.variant_id === 961); await fetch('/cart/change.js', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({id: l.key, quantity: 0})}); })()")
        page.wait_for_timeout(800)

        # --- tier 1 → theme adds as usual
        page.click(".wcvd-tier[data-tier='0']")
        ok(page.input_value("[name=quantity]") == "1", "theme qty back to 1")
        page.click("button[name=add]")
        page.wait_for_timeout(600)
        ok(page.evaluate("window.themeAdds") == 1, "tier 1: theme handler adds")

        # --- show more
        page.click(".wcvd-more")
        ok(page.locator(".wcvd-tier").count() == 4, "show more → 4 tiers")

        # --- gift choice saved and used; sold-out gift variant skipped
        page.click(".wcvd-tier[data-tier='1']")
        ok(page.locator(".wcvd-tier.is-on .wcvd-gift select").input_value() == "901", "gift default = first available")

        # --- error from add (sold-out item)
        page.evaluate("document.querySelector('[name=id]').value='103'; document.querySelector('[name=quantity]').dispatchEvent(new Event('change',{bubbles:true}))")
        page.wait_for_timeout(200)
        page.click("button[name=add]")
        page.wait_for_timeout(600)
        ok(page.locator(".wcvd-err").count() == 1, "error shown when add fails")

        # --- plan() unit: tier gifts by count
        res = page.evaluate("""() => WCVolume.plan({items:[{key:'a',variant_id:101,product_id:100,quantity:3,properties:{},original_price:3495}]})""")
        ok(sorted(a["slot"] for a in res["add"]) == ["vd_o1abc:950", "vd_o1abc:960"], f"plan: 3 items → scale + strap {res}")

        errs = [m for m in msgs if "PAGEERROR" in m]
        ok(not errs, f"no page errors {errs}")
        page.screenshot(path="/tmp/vd-shot.png", full_page=True)
        b.close()
    print("\n%d failures" % len(fails))
    if fails:
        print("\n".join(fails))
        print("\n".join(msgs[-30:]))
    return len(fails)


def Number(x):
    return int(x)


if __name__ == "__main__":
    sys.exit(run())
