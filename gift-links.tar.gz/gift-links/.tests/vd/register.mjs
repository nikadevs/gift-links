import { register } from "node:module"; register(new URL("./stub-hooks.mjs", import.meta.url));
