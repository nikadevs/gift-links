export async function resolve(spec, ctx, next) {
  if (/(^|\/)(db|shopify)\.server(\.ts)?$/.test(spec)) return { url: new URL("./stub-server.mjs", import.meta.url).href, shortCircuit: true };
  return next(spec, ctx);
}
