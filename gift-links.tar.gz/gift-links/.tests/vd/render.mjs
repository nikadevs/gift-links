// Renders blocks/volume-discounts.liquid with LiquidJS + Shopify-like filters.
// usage: node render.mjs <scenario.json> → prints HTML of the block
import { Liquid } from "liquidjs";
import fs from "node:fs";

const SRC = process.cwd() + "/extensions/gift-links-embed/blocks/volume-discounts.liquid";
const sc = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
let tpl = fs.readFileSync(SRC, "utf8").replace(/\{% schema %\}[\s\S]*\{% endschema %\}/, "");

const engine = new Liquid({ strictFilters: true });
engine.registerFilter("json", (v) => JSON.stringify(v === undefined ? null : v));
engine.registerFilter("image_url", (v, ...args) => {
  const src = typeof v === "string" ? v : v && v.src;
  return src ? `${src}?width=120` : "";
});
engine.registerFilter("asset_url", (v) => `/assets/${v}`);
engine.registerFilter("stylesheet_tag", (v) => `<link rel="stylesheet" href="${v}">`);
engine.registerFilter("escape", (v) => String(v ?? "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;"));
// 'now' | date: '%Y-%m-%d'
engine.registerFilter("date", (v, f) => (v === "now" ? sc.today : String(v)));

const ctx = {
  app: { metafields: { wc_vd: { config: { value: sc.config } } } },
  request: { page_type: sc.pageType || "product", locale: { iso_code: "en" } },
  product: sc.product,
  all_products: sc.allProducts || {},
  routes: { root_url: "/" },
  shop: { permanent_domain: "woodencrew.myshopify.com" },
  cart: { currency: { iso_code: "USD" }, item_count: sc.cartCount ?? 0 },
  block: {
    settings: {
      selector: "form[action*='/cart/add']",
      position: "before",
      accent: "#1E7B85",
      selected_bg: "#EAF3F4",
      border: "#D9D9D9",
      text: "#1A1A1A",
      after_add: sc.afterAdd || "stay",
      debug: true,
    },
  },
};
process.stdout.write(await engine.parseAndRender(tpl, ctx));
