// SSR smoke test for the new home page and the Volume Discounts admin pages.
// run: node --import tsx --import ./.tests/vd/register.mjs .tests/vd-smoke.tsx (stubs db/shopify.server)
const APP = process.cwd() + "/app/";
import React from "react";
import { renderToString } from "react-dom/server";
import { createRoutesStub } from "react-router";
import { blankOffer, cleanTitle, discountSteps, invisibleSuffix } from "../app/vd.shared";
import { aggregate, summarizeOffers } from "../app/vd-stats.server";

let fails = 0;
const check = (c: boolean, m: string) => { console.log((c ? "PASS " : "FAIL ") + m); if (!c) fails++; };

async function render(name: string, mod: string, url: string, data: any, expect: string[]) {
  const m = await import(APP + "routes/" + mod);
  const Stub = createRoutesStub([{ id: "r", path: url.split("?")[0].replace(/vd_[a-z0-9]+$/, ":id"), Component: m.default, loader: () => data, action: () => null }]);
  try {
    const html = renderToString(<Stub initialEntries={[url]} hydrationData={{ loaderData: { r: data } }} />);
    const miss = expect.filter((e) => !html.includes(e));
    check(!miss.length, `${name}: ${html.length} chars${miss.length ? " missing " + miss.join(", ") : ""}`);
  } catch (e) {
    check(false, `${name}: ${(e as Error).stack?.split("\n").slice(0, 3).join(" | ")}`);
  }
}

(async () => {
  await render("home", "app._index.tsx", "/app", { gifts: 1, upsells: 3, volume: 0, seo: true },
    ["Volume Discounts", "Checkbox Upsell", "Gift Links", "SEO &amp; Speed", ">Active<"]);
  const offer = { ...blankOffer(), id: "vd_abc123", name: "High Ticket", productIds: ["1", "2"], productTitles: ["Pillow", "Bag"], productImages: ["https://x/a.png", ""],
    tiers: [...blankOffer().tiers, { qty: 4, percent: 30, label: "", gifts: [{ productId: "9", handle: "w", title: "Anti-Scan Wallet", image: "", value: "19.95", variants: [{ id: "91", title: "Grey", image: "" }] }] }] };
  await render("volume list", "app.volume._index.tsx", "/app/volume", {
    days: 30, embed: { state: "off", activateUrl: "https://x" }, stats: { status: "idle", error: "", computedAt: new Date().toISOString(), currency: "USD" }, total: 1234.5,
    offers: [{ id: offer.id, name: offer.name, status: "Active", upTo: 30, gifts: 1, images: offer.productImages, titles: offer.productTitles, discounts: 2, discountError: "", impressions: 3848, clicks: 535, orders: 263, revenue: 16703.41 }],
  }, ["High Ticket", "Up to 30% off", "13.9%", "$16,703.41", "Create Volume Discount", "Scheduled"]);
  await render("volume list empty", "app.volume._index.tsx", "/app/volume", {
    days: 30, embed: { state: "on", activateUrl: "" }, stats: { status: "running", error: "", computedAt: "", currency: "USD" }, total: 0, offers: [] }, ["No volume discounts yet"]);
  await render("volume form", "app.volume.$id.tsx", "/app/volume/vd_abc123", { offer }, ["Tier #4", "Free Anti-Scan Wallet", "Top Pick", "Buy more, save more!", "20% from 2 items, 30% from 3 items"]);
  await render("volume form new", "app.volume.$id.tsx", "/app/volume/new", { offer: blankOffer() }, ["New volume discount", "Select products"]);

  // chain math
  const s = discountSteps([{ qty: 1, percent: 0, label: "", gifts: [] }, { qty: 2, percent: 20, label: "", gifts: [] }, { qty: 3, percent: 30, label: "", gifts: [] }, { qty: 4, percent: 30, label: "", gifts: [] }]);
  check(s.length === 2 && s[0].pct === 0.2 && s[1].pct === 0.3 && s[1].qty === 3, `steps 20% / 30% (tier 4 = same % → no extra discount) = ${JSON.stringify(s)}`);
  const t1 = "Bundle discount" + invisibleSuffix("vd_a:0"), t2 = "Bundle discount" + invisibleSuffix("vd_a:1");
  check(t1 !== t2 && cleanTitle(t1) === "Bundle discount" && cleanTitle(t2) === "Bundle discount", "unique invisible titles clean back to the same name");

  // stats aggregation
  const jsonl = [
    { id: "gid://shopify/Order/1", createdAt: new Date().toISOString(), test: false },
    { __parentId: "gid://shopify/Order/1", quantity: 3, product: { id: "gid://shopify/Product/1" }, discountedTotalSet: { shopMoney: { amount: "94.40", currencyCode: "USD" } },
      discountAllocations: [{ discountApplication: { __typename: "AutomaticDiscountApplication", title: "Bundle discount\u2060\u200b" } }, { discountApplication: { __typename: "AutomaticDiscountApplication", title: "Bundle discount\u2060\u200c" } }, { discountApplication: { __typename: "DiscountCodeApplication" } }] },
    { __parentId: "gid://shopify/Order/1", quantity: 1, product: { id: "gid://shopify/Product/7" }, discountedTotalSet: { shopMoney: { amount: "10.00", currencyCode: "USD" } }, discountAllocations: [] },
  ].map((x) => JSON.stringify(x)).join("\n");
  const agg = aggregate(jsonl);
  const day = new Date().toISOString().slice(0, 10);
  const rows = summarizeOffers({ version: 1, status: "idle", days: agg.days }, { [day]: { vd_abc123: [10, 3] } }, [{ id: "vd_abc123", discountTitle: "Bundle discount", productIds: ["1", "2"] }], 30);
  check(rows.vd_abc123.orders === 1 && rows.vd_abc123.revenue === 94.4 && rows.vd_abc123.impressions === 10 && rows.vd_abc123.clicks === 3, `stats ${JSON.stringify(rows)}`);
  console.log(`\n${fails} failures`);
  process.exit(fails ? 1 : 0);
})();
