import Module from "node:module";
for (const f of ["/home/claude/wc/app/db.server.ts", "/home/claude/wc/app/shopify.server.ts"]) {
  const m = new (Module as any)(f);
  m.filename = f; m.loaded = true;
  m.exports = { default: {}, authenticate: {}, unauthenticated: {}, addDocumentResponseHeaders: () => {} };
  (Module as any)._cache[f] = m;
}
import fs from "node:fs";
import React from "react";
import { renderToString } from "react-dom/server";
import { createRoutesStub } from "react-router";
import { parsePsi } from "/home/claude/wc/app/seo/seo-psi.server";
import { cwvStatus, latestRuns } from "/home/claude/wc/app/seo/seo.shared";

const dataDir = fs.readdirSync("/tmp").filter((d) => d.startsWith("wcseo-")).map((d) => "/tmp/" + d).sort().pop()!;
const report = JSON.parse(fs.readFileSync(`${dataDir}/seo/test.myshopify.com/latest.json`, "utf8"));
const lhr = JSON.parse(fs.readFileSync("/home/claude/lh/lhr.json", "utf8"));
const run = parsePsi("https://woodencrew.store/", "mobile", new Date().toISOString(), { lighthouseResult: lhr } as any);
const run2 = { ...run, strategy: "desktop" as const };
const origin = report.origin;

async function render(name: string, modPath: string, url: string, data: any) {
  const mod = await import(modPath);
  const Stub = createRoutesStub([{ id: "r", path: url.split("?")[0], Component: mod.default, loader: () => data, action: () => null }]);
  try {
    const html = renderToString(<Stub initialEntries={[url]} hydrationData={{ loaderData: { r: data } }} />);
    console.log(`OK  ${name}: ${html.length} chars`, /Unexpected|Error/.test(html) ? "(contains 'Error' text)" : "");
  } catch (e) {
    console.log(`ERR ${name}:`, (e as Error).stack?.split("\n").slice(0, 4).join(" | "));
  }
}

(async () => {
const R = "/home/claude/wc/app/routes/";
const embed = { state: "off", activateUrl: "https://x/admin" };
const jobs = { crawl: { kind: "crawl", status: "running", progress: "Checking pages… 3/6" }, psi: { kind: "psi", status: "idle" } };
await render("overview", R + "app.seo._index.tsx", "/app/seo", {
  origin, hasKey: false,
  report: { finishedAt: report.finishedAt, mode: report.mode, checked: report.checked, score: report.score, linksChecked: 3, notes: ["note"] },
  counts: { critical: 1, high: 2, other: 3 },
  top: [{ id: "broken_link", title: "Broken", severity: "high", count: 2, why: "w", fixIn: "links" }],
  history: [{ score: 70 }, { score: 74 }],
  psi: [{ url: run.url, strategy: "mobile", at: run.at, performance: 47, seo: 100, lcp: 1500, tbt: 300, cls: 0.01, field: { scope: "url", status: cwvStatus(run.field), lcp: 2500, inp: 90, cls: 0.2 } }],
  psiError: "quota", jobs, embed,
});
await render("issues", R + "app.seo.issues.tsx", "/app/seo/issues?check=broken_link", { findings: report.findings, finishedAt: report.finishedAt, checked: report.checked });
await render("pages", R + "app.seo.pages.tsx", "/app/seo/pages", { finishedAt: report.finishedAt, pages: report.pages.map((p: any) => ({ ...p, findings: report.findings.filter((f: any) => f.url === p.url) })) });
await render("speed", R + "app.seo.speed.tsx", "/app/seo/speed", {
  origin, latest: latestRuns([run, run2]), history: [{ at: run.at, url: run.url, strategy: "mobile", performance: 47, lcp: 1, tbt: 2, cls: 0.1 }],
  lastError: "", speedGroups: [{ id: "html_heavy", title: "t", severity: "low", fix: "f", count: 2, sample: ["/ — 1 KB"] }],
  scripts: report.scripts, pagesChecked: 6, jobs, embedCfg: { instantNav: "off", track404: true, beaconUrl: "" }, embed,
});
const rows = [{ id: "gid://shopify/Page/1", kind: "pages", name: "About Us", handle: "about-us", path: "/pages/about-us", status: "ACTIVE", seoTitle: "", seoDescription: "", fallbackDescription: "We are...", hidden: false },
  { id: "gid://shopify/Page/2", kind: "pages", name: "Contact Us", handle: "contact", path: "/pages/contact", status: "ACTIVE", seoTitle: "Contact Us", seoDescription: "x".repeat(200), fallbackDescription: "", hidden: true }];
await render("meta", R + "app.seo.meta.tsx", "/app/seo/meta?kind=pages", { kind: "pages", rows, origin, shopName: "WoodenCrew", accessError: "" });
await render("images", R + "app.seo.images.tsx", "/app/seo/images", { images: [{ id: "gid://shopify/MediaImage/1", productId: "p", productTitle: "Pillow", productHandle: "pillow", position: 1, alt: "", url: "https://cdn/x.jpg", width: 2000, height: 2000, fileSize: 5666128 }], shopName: "WoodenCrew", error: "" });
await render("links", R + "app.seo.links.tsx", "/app/seo/links", {
  origin, error: "", redirects: [{ id: "gid://shopify/UrlRedirect/1", path: "/products/woodencrew%e2%84%a2-pillow", target: "/products/pillow" }],
  redirectIssues: [{ id: "1", path: "/a", target: "/a", problem: "Points to itself" }],
  broken: [{ target: origin + "/pages/broken-test", status: "404", from: [origin + "/"], path: "/pages/broken-test", redirected: false, suggestion: "/" }],
  notFound: [{ path: "/products/old", hits: 3, first: new Date().toISOString(), last: new Date().toISOString(), referrers: {}, redirected: false, suggestion: "/collections/all", refs: ["google.com (2)"] }],
  finishedAt: report.finishedAt, track404: true, embed,
});
await render("theme", R + "app.seo.theme.tsx", "/app/seo/theme", { scan: { themeId: "t", themeName: "WoodenCrew SEO", files: 500, totalBytes: 9e6, largestAssets: [{ filename: "assets/a.js", size: 300000 }], unusedSnippets: ["old-snippet"], externalScripts: [{ file: "layout/theme.liquid", src: "https://x/y.js" }], blockingScripts: [], appEmbeds: [{ type: "judgeme/blocks/x", disabled: false }], leftovers: [{ file: "layout/theme.liquid", match: "Tapita" }], scannedAt: new Date().toISOString() } });
await render("theme-empty", R + "app.seo.theme.tsx", "/app/seo/theme", { scan: null });
await render("settings", R + "app.seo.settings.tsx", "/app/seo/settings", { origin, keySet: false, keyHint: "", envKey: false, keyPaths: "/", autoDaily: true, autoPsi: true, fullCrawlMax: 300 });

})();
