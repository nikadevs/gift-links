import fs from 'node:fs';
import http from 'node:http';
import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
const require = createRequire(process.env.WC_TEST_DEPS+'/package.json');
const ts=require('typescript');
const {Liquid}=createRequire(process.env.WC_LIQUID_DEPS+'/package.json')('liquidjs');
const {chromium}=createRequire(process.env.WC_BROWSER_MODULES+'/package.json')('playwright');
const url=code=>'data:text/javascript;base64,'+Buffer.from(code).toString('base64');
const opts={compilerOptions:{module:ts.ModuleKind.ESNext,target:ts.ScriptTarget.ES2022}};
const shared=url(ts.transpileModule(fs.readFileSync('app/bundles.shared.ts','utf8'),opts).outputText);
const code=ts.transpileModule(fs.readFileSync('app/bundles.server.ts','utf8'),opts).outputText.replace('"./bundles.shared"',JSON.stringify(shared));
const {buildBundle}=await import(url(code));
const fixture=JSON.parse(fs.readFileSync('../reports/bundle-live-fixture.json','utf8'));
let parent;
const admin={async graphql(q,{variables}){if(q.includes('BundleProduct'))return Response.json({data:{shop:{currencyCode:'USD'},product:parent}});return Response.json({data:{nodes:variables.ids.map(id=>fixture.components.find(c=>c.id===id)||null)}});}};
const configs={};
for(const [name,includePaid] of [['pillow',false],['bag',true]]){parent=fixture[name];configs[name]=(await buildBundle(admin,parent.id,includePaid,false)).preview;}
fs.writeFileSync('../reports/bundle-configs.json',JSON.stringify(configs,null,2));
const engine=new Liquid({strictFilters:true});
engine.registerFilter('asset_url',v=>'/assets/'+v); engine.registerFilter('stylesheet_tag',v=>`<link rel="stylesheet" href="${v}">`);engine.registerFilter('json',JSON.stringify);
engine.registerFilter('money',v=>'$'+(Number(v)/100).toFixed(2));engine.registerFilter('money_without_currency',v=>(Number(v)/100).toFixed(2));engine.registerFilter('font_face',()=> '');
const template=fs.readFileSync('extensions/gift-links-embed/blocks/bundle-contents.liquid','utf8').replace(/\{% schema %\}[\s\S]*?\{% endschema %\}/,'').replace(/\{%-? style -?%\}([\s\S]*?)\{%-? endstyle -?%\}/,'$1');
const render=async(name,model)=>engine.parseAndRender(template,{request:{page_type:'product'},product:{id:fixture[name].id.split('/').pop(),selected_or_first_available_variant:{id:fixture[name].variants.nodes[0].id.split('/').pop()},metafields:{custom:{wc_bundle_contents:{value:{...model,enabled:true}}}}},cart:{currency:{iso_code:'USD'}},block:{settings:{heading:'WHAT’S INCLUDED?',heading_font:{family:'Oswald',fallback_families:'sans-serif',weight:700},heading_size:28,value_label:'Value',total_label:'TOTAL SAVINGS',show_total:true}}});
let html='<!doctype html><meta charset="utf-8"><link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Oswald:wght@700&display=swap"><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{margin:0;background:#f6f6f6;font-family:Arial}main{display:grid;grid-template-columns:1fr 1fr;gap:28px;padding:24px;max-width:1200px;margin:auto}section{background:white;padding:16px;min-width:0}.wcb{margin:0!important}@media(max-width:700px){main{grid-template-columns:1fr;padding:12px}}</style><main>';
for(const name of ['bag','pillow']){const p=fixture[name];html+=`<section class="shopify-section" id="${name}"><form action="/cart/add"><input type="hidden" name="id" value="${p.variants.nodes[0].id.split('/').pop()}"></form>${await render(name,configs[name])}</section>`;}
html+='</main>';
const server=http.createServer((req,res)=>{if(req.url.startsWith('/assets/')){const file='extensions/gift-links-embed/assets/'+req.url.split('/').pop();res.setHeader('Content-Type',req.url.endsWith('.css')?'text/css':'application/javascript');res.end(fs.readFileSync(file));}else{res.setHeader('Content-Type','text/html');res.end(html);}});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
try{
 const page=await browser.newPage({viewport:{width:1280,height:800}});const errors=[];page.on('pageerror',e=>errors.push(e.message));
 await page.goto(`http://127.0.0.1:${server.address().port}`,{waitUntil:'networkidle'});
 assert.equal(await page.locator('#bag .wcb-panel:not([hidden]) .wcb-card').count(),5);
 assert.equal(await page.locator('#pillow .wcb-panel:not([hidden]) .wcb-card').count(),6);
 assert.equal(await page.locator('#bag .wcb-card-hero').first().evaluate(el=>getComputedStyle(el).gridRowStart),'span 2');
 await page.screenshot({path:'../reports/bundle-preview-desktop.png',fullPage:true});
 await page.setViewportSize({width:390,height:844});await page.screenshot({path:'../reports/bundle-preview-mobile.png',fullPage:true});
 assert.ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth));
 const catalog=JSON.parse(fs.readFileSync('../reports/product-short-titles-before-2026-10-10.json','utf8'));
 for(const width of [390,360,320]) {
  await page.setViewportSize({width,height:844});
  const overflow=await page.locator('#pillow .wcb-panel:not([hidden]) .wcb-title').first().evaluate((el,titles)=>{const original=el.textContent;const long=[];for(const title of titles){el.textContent=title;if(el.scrollWidth>el.clientWidth)long.push(title);}el.textContent=original;return long;},catalog.map(r=>r.shortTitle));
  assert.deepEqual(overflow,[], `Every Short Title must fit at ${width}px without truncation`);
 }
 const next=fixture.bag.variants.nodes[1].id.split('/').pop();await page.locator('#bag input[name=id]').evaluate((el,value)=>{el.value=value;el.dispatchEvent(new Event('change',{bubbles:true}));},next);await page.waitForTimeout(200);
 assert.equal(await page.locator('#bag .wcb-panel:not([hidden])').getAttribute('data-panel'),configs.bag.variants[next]);
 assert.deepEqual(errors,[]);
 console.log('Browser passed: 5/6-card layouts, mobile overflow, variant switching, zero page errors. Preview uses Oswald; deployed block loads it from Shopify. Live missing compare-at values are deliberately blank.');
}finally{await browser.close();server.close();}
