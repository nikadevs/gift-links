import fs from "node:fs";
import assert from "node:assert";
(async () => {
  const { rootDisallowForAll } = await import("../app/seo/seo-crawl.server");
  assert.equal(rootDisallowForAll(fs.readFileSync("/home/claude/fixtures/robots.txt", "utf8")), false);
  assert.equal(rootDisallowForAll("User-agent: *\nDisallow: /\n"), true);
  assert.equal(rootDisallowForAll("User-agent: GPTBot\nDisallow: /\n\nUser-agent: *\nDisallow: /cart\n"), false);
  assert.equal(rootDisallowForAll("User-agent: Googlebot\nUser-agent: Bingbot\nDisallow: /\n"), true);
  const { suggestTarget, scanTheme } = await import("../app/seo/seo-admin.server");
  const live = [{ path: "/products/pillow-deep-sleep-set", name: "WoodenCrew Travel Pillow Ultimate Kit" }, { path: "/products/compression-socks", name: "Compression Socks" }, { path: "/blogs/travel", name: "Travel" }];
  assert.equal(suggestTarget("/products/compression-socks", live), "/products/compression-socks");
  assert.equal(suggestTarget("/products/travel-compression-socks-2023", live), "/products/compression-socks");
  assert.equal(suggestTarget("/products/unknown-thing", live), "/collections/all");
  assert.equal(suggestTarget("/blogs/travel/old-post", live), "/blogs/travel");
  assert.equal(suggestTarget("/random", live), "/");
  // theme scan with a fake admin
  const files: Record<string, string> = {
    "layout/theme.liquid": `<head>{%- include 'tapita-seo-schema' -%}{% render 'meta-tags' %}<script src="https://cdn.example.com/a.js"></script><script src="{{ 'x.js' | asset_url }}" defer></script></head>`,
    "snippets/tapita-seo-schema.liquid": "tapita",
    "snippets/meta-tags.liquid": "<meta>",
    "snippets/unused-one.liquid": "x",
    "sections/main.liquid": "{% liquid\n render 'card' \n%}",
    "snippets/card.liquid": "c",
    "config/settings_data.json": `/* comment */ {"current":{"blocks":{"1":{"type":"shopify://apps/judge-me/blocks/x/1","disabled":false},"2":{"type":"shopify://apps/tapita/blocks/y/2","disabled":true}}}}`,
  };
  const admin = { graphql: async (q: string, o?: any) => {
    const v = o?.variables ?? {};
    let data: any;
    if (q.includes("WcSeoMainTheme")) data = { themes: { nodes: [{ id: "gid://t/1", name: "Main" }] } };
    else if (q.includes("WcSeoThemeFiles")) data = { theme: { files: { nodes: [...Object.keys(files).map((f) => ({ filename: f, size: String(files[f].length) })), { filename: "assets/big.js", size: "400000" }], pageInfo: { hasNextPage: false, endCursor: null } } } };
    else if (q.includes("WcSeoThemeBodies")) { const pat = v.names[0].replace("*", ""); data = { theme: { files: { nodes: Object.keys(files).filter((f) => f.startsWith(pat)).map((f) => ({ filename: f, size: "1", body: { content: files[f] } })), pageInfo: { hasNextPage: false, endCursor: null } } } }; }
    return new Response(JSON.stringify({ data }));
  } };
  const scan = await scanTheme(admin as any);
  console.log(JSON.stringify({ unused: scan.unusedSnippets, ext: scan.externalScripts, block: scan.blockingScripts, embeds: scan.appEmbeds, left: scan.leftovers, largest: scan.largestAssets[0] }));
  assert.deepEqual(scan.unusedSnippets, ["unused-one"]);
  assert.equal(scan.blockingScripts.length, 1);
  assert.ok(scan.leftovers.some((l) => l.match === "Tapita" && l.file === "layout/theme.liquid"));
  assert.equal(scan.appEmbeds.length, 2);
  console.log("units OK");
})().catch((e) => { console.error(e); process.exit(1); });
