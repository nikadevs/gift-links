// SSR smoke for the Vitals-style home. run: node --import tsx --import ./.tests/vd/register.mjs .tests/home-smoke.tsx
import React from "react";
import { renderToString } from "react-dom/server";
import { createRoutesStub } from "react-router";
import { writeFileSync } from "node:fs";
const row = (o: any) => ({ kind: "offer", icon: "volume", sub: "", status: "Active", earned: 0, editUrl: "/x", offRoute: "/app/volume?index", offId: "x", isOn: true, updatedAt: "", order: 0, ...o });
(async () => {
  const m = await import(process.cwd() + "/app/routes/app._index.tsx");
  const data = { currency: "USD", pins: ["m:volume"], rows: [
    row({ key: "m:volume", kind: "app", title: "Volume Discounts", sub: "App · 3 offers", earned: 56234, order: 0 }),
    row({ key: "m:upsells", kind: "app", icon: "checkbox", title: "Checkbox Upsell", sub: "App · 3 offers", earned: 1612, order: 1 }),
    row({ key: "m:seo", kind: "app", icon: "seo", title: "SEO & Speed", sub: "App", earned: 0, order: 2 }),
    row({ key: "vd:1", title: "GPS Wallet: 2 and 3 items 20-30% OFF", sub: "Volume Discounts · Up to 30% OFF", status: "Draft", isOn: false, earned: 17000, order: 3 }),
    row({ key: "vd:2", title: "High Ticket: 2 and 3 items 20-30% OFF", sub: "Volume Discounts · Up to 30% OFF", earned: 812.4, order: 4 }),
  ] };
  const Stub = createRoutesStub([{ id: "r", path: "/app", Component: m.default, loader: () => data, action: () => null }]);
  const html = (renderToString(<Stub initialEntries={["/app"]} hydrationData={{ loaderData: { r: data } }} />)).replace(/<!-- -->/g, "");
  const need = ["What you&#x27;ve set up", "Showing 4 active · 1 draft", "+$56K", "+$1.6K", "+$812", "Drafts first", "Top earning", "Recently edited", "wch-row pin", "5 items", "Setup guide"];
  const miss = need.filter((n) => !html.includes(n));
  // order: pinned volume first, then Draft GPS
  const order = ["Volume Discounts", "GPS Wallet", "Checkbox Upsell"].map((t) => html.indexOf(t));
  console.log(miss.length ? "FAIL missing " + miss.join(" | ") : "PASS content", order.every((v, i, a) => !i || v > a[i - 1]) ? "PASS order" : "FAIL order " + order);
  writeFileSync("/tmp/home.html", `<!doctype html><meta charset=utf-8><body style="margin:0;background:#f1f1f1;font-family:Inter,system-ui,sans-serif;padding:40px 126px">${html}</body>`);
})();
