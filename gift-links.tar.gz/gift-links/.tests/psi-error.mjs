import assert from "node:assert/strict";
import { latestPsiError } from "../app/seo/seo.shared.ts";

const run = (strategy, at, error) => ({
  url: "https://woodencrew.store/products/pillow-deep-sleep-set",
  strategy, at, error, scores: {}, lab: {}, opportunities: [],
});
const failed = run("mobile", "2026-10-08T10:00:00Z", "IP restricted");
const passed = run("mobile", "2026-10-08T11:00:00Z");
assert.equal(latestPsiError([failed, passed]), "");
assert.equal(latestPsiError([passed, failed]), "");
assert.equal(latestPsiError([failed]), "IP restricted");
assert.equal(latestPsiError([failed, passed, run("desktop", "2026-10-08T11:01:00Z", "quota")]), "quota");
assert.equal(latestPsiError([]), "");
console.log("5 PageSpeed error regression checks passed");

