import fs from 'node:fs';
import assert from 'node:assert/strict';
import http from 'node:http';
import {createRequire} from 'node:module';
const {Liquid}=createRequire(process.env.WC_LIQUID_DEPS+'/package.json')('liquidjs');
const {chromium}=createRequire(process.env.WC_BROWSER_MODULES+'/package.json')('playwright');
const engine=new Liquid({strictFilters:true});engine.registerFilter('asset_url',v=>'/assets/'+v);engine.registerFilter('json',JSON.stringify);
engine.registerFilter('image_url',v=>v);engine.registerFilter('money',v=>'$'+v);engine.registerFilter('money_with_currency',v=>'$'+v);engine.registerFilter('stylesheet_tag',v=>v);
const tpl=fs.readFileSync('extensions/gift-links-embed/blocks/checkbox-upsell.liquid','utf8').replace(/\{% schema %\}[\s\S]*?\{% endschema %\}/,'');
const html=await engine.parseAndRender(tpl,{app:{metafields:{wc_upsell:{config:{value:{offers:[{active:true}]}}}}},request:{page_type:'index'},routes:{root_url:'/'},block:{settings:{debug:false}}});
const script=fs.readFileSync('extensions/gift-links-embed/assets/wc-checkbox-upsell.js','utf8');
const server=http.createServer((req,res)=>{res.setHeader('Content-Type',req.url.startsWith('/assets/')?'application/javascript':'text/html;charset=utf-8');res.end(req.url.startsWith('/assets/')?script:html);});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const browser=await chromium.launch({executablePath:'C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe',headless:true});
try{
 for(const scenario of ['none','expired','corrupt','valid']){
  const context=await browser.newContext();let downloads=0,adds=0;let cart={items:[{variant_id:501,quantity:1,properties:{}}]};
  await context.addInitScript(s=>{const key='wcUpsell.pending.v2';if(s==='corrupt')localStorage.setItem(key,'{');if(s==='expired'||s==='valid')localStorage.setItem(key,JSON.stringify({id:'test',ts:Date.now()-(s==='expired'?180000:0),handle:'test',variants:['501'],baseQty:0,upsells:[{offer:'u',id:999,match:false,once:true}]}));},scenario);
  await context.route('**/cart.js',route=>route.fulfill({json:cart}));
  await context.route('**/cart/add.js',async route=>{adds++;const body=route.request().postDataJSON();for(const item of body.items)cart.items.push({variant_id:item.id,quantity:item.quantity,properties:item.properties});await route.fulfill({json:{items:cart.items}});});
  const page=await context.newPage();page.on('request',r=>{if(r.url().endsWith('wc-checkbox-upsell.js'))downloads++;});
  await page.goto(`http://127.0.0.1:${server.address().port}/`,{waitUntil:'networkidle'});await page.waitForTimeout(200);
  assert.equal(downloads,scenario==='valid'?1:0,scenario);assert.equal(adds,scenario==='valid'?1:0,scenario);assert.equal(cart.items[0].variant_id,501);
  await context.close();
 }
 console.log('Upsell loader passed: no download for absent/expired/corrupt pending; valid pending loads once and adds the upsell without changing the main line.');
}finally{await browser.close();server.close();}
