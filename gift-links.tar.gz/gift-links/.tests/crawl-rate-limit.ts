import assert from "node:assert/strict";
import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import { runCrawl } from "../app/seo/seo-crawl.server";
import { saveSettings } from "../app/seo/seo-store.server";
import { DEFAULT_SETTINGS } from "../app/seo/seo.shared";

process.env.WC_DATA_DIR = await fs.mkdtemp(path.join(os.tmpdir(), "wc-429-test-"));
const origin = "https://fixture.test";
const originalFetch = globalThis.fetch;
const requests: string[] = [];
let mode: "pages" | "links" = "pages";
globalThis.fetch = async (input) => {
  const url = String(input);
  const p = new URL(url).pathname;
  requests.push(p);
  let status = 200;
  let content = "";
  let type = "text/html";
  if (p === "/robots.txt") { content = `User-agent: *\nSitemap: ${origin}/sitemap.xml`; type = "text/plain"; }
  else if (p === "/sitemap.xml") { content = "<urlset/>"; type = "application/xml"; }
  else if (p === "/limited") status = 429;
  else if (p === "/dead") status = 404;
  else if (p === "/gone") status = 410;
  else if (p === "/forbidden") status = 403;
  else if (p === "/unavailable") status = 503;
  else content = `<html><head><title>Fixture page title</title><meta name="description" content="Fixture description"><link rel="canonical" href="${origin}${mode === "links" ? "/limited" : "/"}"></head><body><h1>Fixture</h1>${mode === "links" ? ["/dead", "/gone", "/forbidden", "/unavailable", "/limited", "/later1", "/later2", "/later3"].map(x => `<a href="${x}">Link</a>`).join("") : ""}</body></html>`;
  const response = new Response(content, {status, headers: {"content-type": type}});
  Object.defineProperty(response, "url", {value: url});
  return response;
};
try {
  await saveSettings("pages.test", {...DEFAULT_SETTINGS, keyPaths: ["/", "/limited", "/later1", "/later2"]});
  const pages = await runCrawl({shop: "pages.test", origin, mode: "quick"});
  assert.ok(pages);
  assert.ok(pages.findings.some(x => x.check === "rate_limited"));
  assert.ok(!pages.findings.some(x => ["http_error", "broken_link", "canonical_broken"].includes(x.check)));
  assert.equal(pages.checked, 2);
  assert.equal(pages.linksChecked, 0);
  assert.ok(!requests.includes("/later1"));
  mode = "links";
  requests.length = 0;
  await saveSettings("links.test", {...DEFAULT_SETTINGS, keyPaths: ["/"]});
  const links = await runCrawl({shop: "links.test", origin, mode: "quick"});
  assert.ok(links);
  assert.equal(links.findings.filter(x => x.check === "broken_link").length, 2);
  assert.ok(!links.findings.some(x => x.check === "canonical_broken"));
  assert.ok(links.findings.some(x => x.check === "rate_limited"));
  assert.equal(links.findings.filter(x => x.check === "fetch_failed").length, 2);
  assert.equal(links.linksChecked, 6);
  assert.ok(!requests.includes("/later2"));
  assert.ok(links.notes.some(x => x.includes("stopped after HTTP 429")));
  console.log("Crawler integration passed: 429 is incomplete, 404/410 are broken, 403/503 unverified; stops further probes.");
} finally {
  globalThis.fetch = originalFetch;
}
