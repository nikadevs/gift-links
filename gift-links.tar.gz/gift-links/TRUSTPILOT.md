# Trustpilot Reviews

New application module: `/app/trustpilot`; theme extension block: **Trustpilot Reviews**.

The app process reads WoodenCrew's public Trustpilot profile and its five-star feed sorted by recency. It extracts structured `__NEXT_DATA__` data (not the featured reviews or AI summary), validates the rating and total count, sorts reviews by publication date, deduplicates them, and stores exactly seven five-star reviews. Text is rendered with `textContent` and links open the original review.

Persistent cache: `$WC_DATA_DIR/trustpilot/woodencrew.json`, default `data/trustpilot/woodencrew.json`. Use persistent storage in production, as with the SEO module. Scheduler checks once a minute and fetches only when the last successful cache is 24 hours old. Concurrent requests share one refresh. Failed refreshes retain the successful cache and retry after an hour. No scraping occurs in the customer's browser. Public read-only endpoint `/api/trustpilot` serves cached data with a five-minute HTTP cache; a missing cache returns 503 and the storefront block stays hidden.

The app block uses the current app host `https://giftlinks.nikadevs.com/api/trustpilot` by default; the URL can be changed in the theme editor. Desktop displays rating/reviews and photos in two columns. Mobile stacks them with a 20px gap (10px base plus the requested extra 10px). Review rotation is 7000ms, with manual dots, pause/resume, and pause while hovered, focused, or the browser tab is hidden. Reduced-motion users start paused.

The photo collage uses up to nine distinct, successfully loaded review photo `currentSrc` URLs from the current product's Judge.me widget, laid out as 3 / 2 / 2 / 2 photos. No Judge.me API request or larger image URL is generated. The browser can reuse the same image resource/cache. Actual HTTP revalidation is controlled by the image host. A product Judge.me widget must be present and its photos must have loaded; if lazy-loaded, the collage fills when those photos load. It follows widget pagination/sorting when new photos are loaded. It never substitutes photos from another product. If fewer than nine photos are available, it displays the available photos.

## Validation (2026-10-11)

- `node --experimental-strip-types .tests/trustpilot.test.mjs`: parser fixtures.
- `node --experimental-strip-types .tests/trustpilot-cache.mjs`: concurrency, daily TTL, persistent storage, stale-on-error, retry throttle.
- `node .tests/trustpilot-browser.mjs`: Chromium UI test, 7 slides, 7000ms timer, pause, safe text, same photo URLs, desktop/mobile layout and no horizontal overflow. Local test resolves bundled Playwright and installed Chrome.
- Live fetch from this environment failed with DNS `ENOTFOUND www.trustpilot.com`. Trustpilot page contents were accessible through the web tool, but the raw structured payload could not be verified. Production sync remains to be checked.
- Shopify skill documentation search failed with `fetch failed`; its validator could not start because `@shopify/theme-check-common` is missing. Full app typecheck/build and Shopify Theme Check remain to be run in an environment with project dependencies.

Implementation is local only. No production deployment or theme activation was performed. After deploying the app and extension, inspect `/app/trustpilot` for the successful initial sync and add **Trustpilot Reviews** at the desired position in the product template.
