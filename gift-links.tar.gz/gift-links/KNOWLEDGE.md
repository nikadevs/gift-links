# Gift Links: полная база знаний (для человека и для другого ИИ)

Состояние на **2026-10-07**, версия **v9** (git-коммит `f147685`, ветка `gift-links`).
Живые данные Shopify из раздела 4 проверены запросом к Admin API 2026-10-07.

---

## 1. Что это и зачем

**Gift Links** — собственное (custom) Shopify-приложение магазина **WoodenCrew** (woodencrew.store; travel gear; владелец Roman Pshenichny). Тариф **Shopify, не Plus**.

Задача: покупатель из email-рассылки получает **бесплатный подарок в корзине автоматически** и вдобавок промокод. Работает двумя способами:
1. **по ссылке** `https://woodencrew.store/<любой путь>?gift=<linkKey>`; если в ссылке уже есть `?`, то `&gift=<linkKey>`;
2. **по коду**: покупатель ввёл код кампании в поле скидки корзины или cart drawer темы.

Подарок — **отдельный товар-копия с ценой $0** (тег `gift-links-gift`). Скрипт кладёт его в корзину, когда корзина подходит под условия, и убирает, когда перестаёт подходить. Промокод (например 10%) скрипт применяет через Cart AJAX API.

Почему так, а не через стандартную скидку Buy X Get Y, объяснено в разделе 6.

---

## 2. Где что лежит

| Что | Где |
|---|---|
| Эта папка (полный архив знаний) | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Shopify Development\gift-sales\` |
| Исходник с git-историей | `source/` в этой папке; то же самое в архиве `archives/gift-links-src-v9.tar.gz` |
| **Рабочий прод** | DigitalOcean droplet **134.209.119.24**, папка **`/opt/gift-links`**, pm2-процесс `gift-links`, порт **3107**, nginx + Let's Encrypt, домен **https://giftlinks.nikadevs.com** |
| Секреты | только на сервере: `/opt/gift-links/.env` (SHOPIFY_API_KEY, SHOPIFY_API_SECRET, SCOPES, PORT=3107, NODE_ENV=production, SHOPIFY_APP_URL). В эту папку **не копируются** |
| Залинкованный `shopify.app.toml` | только на сервере. В нём `client_id` (начинается с `c8e4e2fb921220ff09ab97f0a97598…`), `application_url = https://giftlinks.nikadevs.com`, redirect_urls. В `source/shopify.app.toml` `client_id` пустой, и это нормально |
| GitHub | `nikadevs/gift-links` (публичный). Там **только** собранный архив `gift-links.tar.gz` (сейчас v9) и `install.sh`, исходников нет. Через него сервер скачивает обновления |
| Приложение в Shopify | Dev Dashboard → приложение «Gift Links» (custom distribution, установлено в woodencrew). Версии extension: `gift-links-N` (была gift-links-4 после исправления scopes, дальше выше) |
| Claude Project | «WC - Shopify Aps Development», документ `claude/gift-links-handoff.md` (краткая версия этого файла) |
| Письма Gift Week | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Email Marketing\` (`GiftWeek-Email-1-Gift-Reveal.html`, `GiftWeek-Email-2-Last-Call.html`, `GiftWeek-Emails-Combined.html`). Копии лежат в `campaign-emails/` |

---

## 3. Архитектура и код

Стек: официальный шаблон **Shopify app на React Router** (`@shopify/shopify-app-react-router`, React Router 7.18), **Polaris web components** (`<s-page>`, `<s-section>`, `<s-text-field>`…), **App Bridge** (resourcePicker, toast), **Prisma + SQLite** (только для хранения сессий OAuth), Node ≥ 22.12. Scopes: **`read_products,read_discounts`** (больше не нужно; при config link они однажды слетели, см. раздел 7).

### 3.1 Хранение кампаний
Базы данных для кампаний нет. Весь конфиг лежит в одном **app-owned JSON metafield на AppInstallation**: namespace `gift_links`, key `config`, тип `json`.
```json
{ "version": 1, "campaigns": [ Campaign, ... ] }
```
Тема читает его в Liquid как `app.metafields.gift_links.config.value`. Витрина **не обращается к серверу приложения**: если сервер упадёт, витрина продолжит работать с последним сохранённым конфигом, перестанет работать только админка.

Тип `Campaign` (`app/campaigns.shared.ts`):
`id, name, active, linkKey, giftVariantId (числовой ID варианта строкой), giftTitle, giftImage, discountCode (один или несколько через запятую, UPPERCASE), triggerOnCode, minSubtotal (в валюте магазина, USD), addWhenCartEmpty, removeWhenIneligible, bannerText (≤140), landingPath, startsAt, endsAt (YYYY-MM-DD, end включительно), updatedAt`.

### 3.2 Файлы
| Файл | Назначение |
|---|---|
| `app/campaigns.shared.ts` | тип Campaign, `campaignLink(domain,c)` → `${domain}${landingPath}?gift=key`, `campaignStatus` |
| `app/campaigns.server.ts` | `loadConfig`/`saveConfig` (metafieldsSet на currentAppInstallation), `loadDiscountCodes` (`discountNodes(first:100, query:"method:code")`), `loadShopDomain`, `campaignFromForm` (валидация; коды → UPPERCASE, split по `[\s,]+`, join `,`) |
| `app/routes/app._index.tsx` | список кампаний (s-table): Copy link, Pause/Activate, Delete с подтверждением вторым кликом (window.confirm в iframe админки не используем) |
| `app/routes/app.campaigns.$id.tsx` | форма кампании. `CampaignRoute` ремаунтит `CampaignForm` через `key=id:updatedAt`. resourcePicker выбирает товар. s-select со скидками магазина + поле «…or type code(s)» |
| `app/routes/app.setup.tsx` | страница Setup guide |
| `app/routes/app.tsx` | навигация: Gift campaigns, Setup guide |
| `extensions/gift-links-embed/shopify.extension.toml` | theme extension, name "Gift Links" |
| `extensions/gift-links-embed/blocks/gift-links.liquid` | **app embed** (target body). (1) Если открыта страница товара с тегом `gift-links-gift`, делает редирект на главную (только такие товары, **другие $0 товары не трогает**). (2) Выводит конфиг в `<script id="gift-links-config" type="application/json">` и подключает `gift-links.js` с data-атрибутами. Настройки: banner_bg `#155F56`, banner_color `#FFFFFF`, hide_gift_pages (по умолчанию true; проверка `!= false`, потому что у старых установок значение nil), debug |
| `extensions/gift-links-embed/assets/gift-links.js` | логика витрины, ~500 строк, IIFE, без зависимостей (подробно в 3.3) |
| `deploy/install.sh` | установщик/обновлятор для дроплета (подробно в разделе 5) |
| `deploy/ecosystem.config.cjs`, `deploy/nginx-gift-links.conf`, `deploy/env.example` | конфиги прод-окружения |
| `README.md` | исходная инструкция на русском. **Внимание:** раздел «Как запустить акцию» там описывает BXGY-подход, который в итоге **не используется** (см. раздел 6). Правильный рецепт описан в разделе 4 этого файла |
| `tests/test.py` (в этой папке) | Playwright-харнесс с мок-корзиной, 6 сценариев |

### 3.3 Как работает `gift-links.js`
- Константы: `TTL_MS` = 7 дней (столько браузер «помнит» кампанию после клика), `LINE_PROP = "_gift_link"` (скрытое свойство строки, помечает **наш** подарок).
- `isLive(c)`: active, задан giftVariantId, сегодняшняя дата в пределах startsAt..endsAt.
- **Триггер по ссылке:** параметр `?gift=key` работает на любой странице. Скрипт запоминает кампанию в localStorage и убирает параметр из URL через history.replaceState (UTM-метки остаются).
- **Триггер по коду:** если `triggerOnCode` и код кампании есть в `cart.discount_codes`, кампания активируется.
- **sync()**, главный цикл:
  1. **Rogue-удаление:** строки, у которых variant_id равен варианту подарка любой кампании, `original_price === 0` и **нет** `_gift_link`, удаляются (так подарок нельзя положить вручную). Другие $0 товары (компоненты бандлов, PDF Travel Book) не затрагиваются, потому что их вариантов нет в кампаниях.
  2. Если живой кампании нет, удаляет только свои строки (с `_gift_link`).
  3. Eligibility: сумма **оплачиваемых** строк (`final_line_price > 0`, не подарок) / 100 / `Shopify.currency.rate` ≥ `minSubtotal`. Пересчёт по курсу нужен для мультивалюты. Если `addWhenCartEmpty` = false, нужен хотя бы один платный товар.
  4. Добавляет подарок через `/cart/add.js` с `properties: {_gift_link: campaignId}`, держит количество 1, убирает лишние строки.
  5. Если корзина перестала подходить и `removeWhenIneligible`, удаляет подарок.
  6. **Коды:** `campaignCodes(c)` разбивает строку; коды **сливаются** с уже применёнными в корзине и отправляются через `/cart/update.js {discount: "A,B"}`. Guard: не больше 2 попыток применить за 10 минут (`state.applyTries/applyTs`), чтобы не было цикла, если Shopify отказывает в коде.
- **Перехват** `fetch` и `XMLHttpRequest` на `/cart/add|change|update|clear`: после действий темы снова запускается sync.
- **refreshUI:** на `/cart` делает перезагрузку страницы (с защитой от цикла), на остальных страницах перерисовывает секции Dawn (`cart-icon-bubble`, `cart-drawer`) через Section Rendering API.
- **Фоллбек-редирект:** если Liquid-редирект не сработал, а `ShopifyAnalytics.meta` показывает, что открыт вариант подарка за $0, делается редирект на главную.
- Баннер внизу страницы (текст из кампании, закрытие запоминается). Лимит sync: 6 раз за 10 секунд. Отладка: `window.GiftLinks.sync()`; при включённом Debug в консоли пишутся сообщения `[Gift Links]`.

---

## 4. Текущая настройка в магазине (проверено 2026-10-07)

| Объект | Значение |
|---|---|
| Товар-подарок | «WoodenCrew™ Stain Remover Stick — Gift», product **15414953541951**, handle `woodencrew™-stain-remover-stick-gift`, ACTIVE, теги `gift-links-gift`, `hidden-gift` |
| Вариант подарка | **67648456524095**, цена **$0.00** |
| Коллекция | «All products – GWP» (`all-products-gwp`), id **519322894655** (осталась от BXGY-попытки; подарок из неё убран через collectionRemoveProducts) |
| Скидка | **GIFTSTICK**: DiscountCodeNode **1590990340415**, Basic, **10%**, без минимума, ACTIVE с 2026-10-06T19:25:45Z до **2026-10-12T19:30:00Z**, combinesWith: product = true, order = false, shipping = true. Сочетается со скидками бандлов Vitals |
| Кампания | id **`c_mux5ft69xhnw`**, linkKey **`giftweek`**, подарок = вариант 67648456524095, код GIFTSTICK |
| Ссылка | `https://woodencrew.store/?gift=giftweek` (или `…/любой-путь?gift=giftweek`) |
| App embed | включён в живой теме (Online Store → Themes → Customize → App embeds → Gift Links) |

**Рецепт новой акции (правильный):**
1. Сделать копию товара-подарка (productDuplicate), цена $0, тег `gift-links-gift`, статус Active, опубликовать в Online Store. Убрать из коллекций, поиска и фидов, где это возможно. Страницу закроет редирект.
2. Создать код (обычно Basic %, combinesWith.productDiscounts = true, иначе он не сложится с Vitals).
3. Gift Links → New campaign: товар, код, minSubtotal, даты, баннер → Save → Copy link.
4. Поставить ссылку (или `&gift=key`) на **все** кнопки письма в Omnisend.
5. Проверить в инкогнито: переход по ссылке → добавить товар → подарок $0 и код применены → чекаут.

---

## 5. Деплой и сервер

### Обновление (стандартная процедура)
1. Внести изменения в `source/` и сделать коммит.
2. Сборка: `npm ci && npm run build` (локально или в контейнере ИИ). Упаковать **`gift-links.tar.gz`** с корневой папкой `gift-links/`, внутри `build/`, `app/`, `extensions/` и остальное (без node_modules).
3. **Roman сам** загружает `gift-links.tar.gz` в GitHub-репо `nikadevs/gift-links` (main) через веб-интерфейс (Add file → Upload, заменить файл). ИИ этого не делает.
4. **Roman** в консоли дроплета выполняет:
```bash
rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && cd /opt/gift-links && rm -rf build && cp -r /tmp/gl/gift-links/build /tmp/gl/gift-links/app /tmp/gl/gift-links/extensions . && npx shopify app deploy --allow-updates && pm2 restart gift-links
```
   Если менялись зависимости (`package.json`), нужен полный `install.sh` (см. ниже) или `npm ci` на сервере.
5. Проверка, что сервер скачал новую версию: raw.githubusercontent кэширует файл до ~5 минут. Сравнивать md5 (`md5sum`) архива или давать файлам уникальные имена версий. Однажды Roman несколько раз заливал старый архив, потому что имена файлов совпадали.

### Полная установка / переустановка
`bash <(curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/install.sh)` от root. Что делает скрипт:
- добавляет swap 2G;
- ставит Node 22 и pm2;
- скачивает тарбол и **сохраняет** `.env`, `prisma/dev.sqlite`, `shopify.app*.toml`;
- выполняет `npm ci` и `npm run setup`;
- если приложение не залинковано, запускает `shopify app config link`;
- правит в toml `application_url` и `redirect_urls` через sed;
- выполняет `shopify app deploy --allow-updates`;
- создаёт `.env` (`touch .env && shopify app env pull`) и дописывает PORT, NODE_ENV, SHOPIFY_APP_URL;
- пишет `ecosystem.config.cjs`, который **сам читает .env** (pm2 не подхватывал .env через node_args);
- настраивает сайт nginx и certbot.

### Грабли Shopify CLI на сервере (решены)
- `xdg-open ENOENT` при логине → `ln -sf /bin/true /usr/local/bin/xdg-open`, ссылку для логина открыть вручную.
- Флаг `--force` не существует, правильный `--allow-updates`.
- `node: .env: not found` → `touch .env` перед `env pull`.
- Пустой `appUrl` → в .env не было SHOPIFY_APP_URL, а pm2 не грузил .env. Исправлено ecosystem, который сам читает .env.
- После `config link` scopes в toml перезаписались → вернули `read_products,read_discounts` и сделали повторный deploy.

---

## 6. Ключевые решения и почему (не повторять ошибок)

1. **BXGY не подошёл.** Скидка Buy X Get Y не засчитывает товары «buy», на которые уже действует другая товарная скидка (бандлы **Vitals**). Это правило Shopify. Поэтому сделали **копию подарка с ценой $0** и **отдельный код 10%** с `combinesWith.productDiscounts = true`.
2. **Стандартные скидки не добавляют товар в корзину сами**, поэтому нужен скрипт на витрине.
3. **Shopify Functions** (cart transform, checkout validation) в custom-приложениях доступны **только на Plus**, поэтому вся логика на витрине (theme app embed + Cart AJAX API). Код, введённый **на странице чекаута**, подарок добавить не может.
4. **Draft-товар нельзя положить в корзину** (422 «Cannot find variant»), поэтому подарок Active, а его страница закрыта редиректом по тегу `gift-links-gift`.
5. **Защита от бесплатной покупки подарка:** rogue-удаление строк без `_gift_link` плюс редирект со страницы товара. Бэкстоп в Shopify Flow (его создаёт Roman): заказ, где subtotal = 0 и есть только подарок, получает тег `gift-review` и **hold fulfillment**. **Без отмены.**
6. Привязка к **тегу**, а не к ID товара: подарки будут меняться каждую неделю.
7. Несколько кодов на кампанию (`A,B`), коды сливаются с уже применёнными.
8. Конфиг хранится в metafield, а не в базе: витрине не нужен сервер, нагрузки нет.

---

## 7. История (кратко)

- **2026-10-06.** Письма Gift Week (подарок Stain Remover Stick). Попытка BXGY GIFTSTICK провалилась из-за конфликта с Vitals. Создано приложение (`42ae877`) и установщик. Деплой на дроплет, DNS-поддомен giftlinks.nikadevs.com, SSL. Приложение установлено, app embed включён. Скидка GIFTSTICK пересоздана как 10% Basic, подарок сделан копией за $0. Добавлены несколько кодов на кампанию (`c3f4e94`) и rogue-удаление (`17fadca`).
- **2026-10-07.** Редирект со страниц подарков только по тегу (`4765ac4`), фоллбек на unset-настройку и через ShopifyAnalytics (`f147685`) → **v9 на проде, проверено на живом сайте**: подарок и 10% сочетаются с бандлами Vitals, на /cart нет цикла перезагрузок, редирект работает, $0 товары бандлов и PDF Travel Book не затронуты, подарок, добавленный вручную, удаляется.
- Покупатели переходили на сайт по ссылкам письма без `?gift=` и оставались без подарка. Заказы **#38664** и **#38665** дополнены подарком вручную через orderEditBegin/AddVariant/Commit: `notifyCustomer: false`, staffNote «Gift Week: free Stain Remover Stick added (email subscriber)», суммы не изменились.
- Roman получил промпт для временного Flow (до **2026-10-09T21:00:00Z**): заказ подписчика или повторного покупателя → Add order line item (подарок) бесплатно. Flow Roman создаёт сам.

---

## 8. Правила работы с Roman (обязательно)

- **Каждый ответ начинать с «Roman,».** Общение на русском, маркетинговые тексты на английском.
- **Никогда не врать, всегда проверять факты** (живые данные проверять запросом к API или в браузере, а не по памяти).
- Email-темы и прехедеры: **4–5 слов максимум**, без пунктуации, один эмодзи в начале.
- **Очень аккуратно:** не ломать $0 товары бандлов (**Vitals**, **Simple Bundles**) и **PDF Travel Book**, который добавляется собственными скриптами магазина. Любая логика, которая удаляет или меняет строки корзины, должна трогать только варианты подарков кампаний или строки с `_gift_link`.
- **Никогда не отменять заказы** (вредит репутации). Только тег, hold или ручная проверка.
- После тестов на живом сайте **вернуть корзину Roman в исходное состояние**.
- Изменения в заказах клиентов (orderEdit) делать только с явного согласия Roman, по конкретным номерам заказов, с `notifyCustomer: false`, если он не просил иначе.
- Действия, которые ИИ **не делает сам** (их делает Roman): production deploy на сервер, загрузка файлов в GitHub, создание и использование API-токенов (DigitalOcean и др.), правка DNS через API, работа в консоли дроплета, создание Flow с автоотменой или массовыми действиями, снятие товаров с публикации. ИИ готовит команды и инструкции.
- Напоминание: DigitalOcean-токен `claude-gift-links` Roman должен был удалить (для работы приложения он не нужен).

---

## 9. Тестирование

- `tests/test.py`: Playwright (`python3 test.py`), мок-корзина и мок-страница, сценарии: (1) переход по ссылке при пустой корзине (подарок не добавляется), (2) тема добавляет товар (появляются подарок и оба кода `GIFTSTICK,GIFTSTICK10`), (3) удаление платного товара (подарок уходит), (4) новый визит без ссылки (кампания запомнилась, подарок снова добавляется), (5) запуск по коду в новом браузере, (6) подарок добавлен вручную без свойства `_gift_link` (rogue-удаление). Путь к JS в начале файла поменять на `../source/extensions/gift-links-embed/assets/gift-links.js`.
- Живой тест: инкогнито → `woodencrew.store/?gift=giftweek` → добавить товар → проверить `/cart.js` (строка подарка с `_gift_link`, `discount_codes` содержит GIFTSTICK) → чекаут показывает подарок $0 и −10%. После теста очистить корзину.

---

## 10. Бэклог / идеи

1. **Триггер по `utm_campaign`** из Omnisend: активировать кампанию по любой ссылке письма, а не только с `?gift=`. В кампанию добавить поле `utmCampaign`, в JS проверять `URLSearchParams.get('utm_campaign')`. Закрывает проблему из раздела 7.
2. **Автосоздание $0 копии подарка** при выборе товара в админке: productDuplicate, цена 0, тег `gift-links-gift`, публикация. Нужен scope `write_products`.
3. Поддержка cart drawer не-Dawn тем (сейчас перерисовка секций рассчитана на Dawn).
4. Обновить `README.md` в исходнике: убрать устаревший BXGY-рецепт.
5. Предложено обновить скилл wc-email-subject (лимит 4–5 слов); статус неизвестен.

---

## 11. WoodenCrew Apps: модульное приложение (с 2026-10-07, v10)

Приложение Gift Links переименовано в **WoodenCrew Apps** (`name` в toml; `client_id`/`handle`, папка `/opt/gift-links`, pm2 `gift-links`, репо `nikadevs/gift-links` и extension `gift-links-embed` **не менялись**, чтобы не сломать установку и включённый embed). Внутри модули, у каждого свой конфиг-metafield и свой app embed:

| Модуль | Админка | Metafield (AppInstallation) | App embed | Файлы |
|---|---|---|---|---|
| Gift Links | `/app/gifts`, `/app/campaigns/:id` | `gift_links.config` | «Gift Links» | `campaigns.*.ts`, `gift-links.liquid/js` |
| Checkbox Upsell (замена AXE Checkbox Upsell) | `/app/upsells`, `/app/upsells/:id` | `wc_upsell.config` | «Checkbox Upsell» | `upsells.*.ts`, `checkbox-upsell.liquid`, `wc-checkbox-upsell.js/css` |

Главная `/app` — карточки модулей. Новый модуль = свой `*.shared.ts` + `*.server.ts` + роуты `app.<module>...` + блок в `extensions/gift-links-embed/blocks/` + карточка в `app._index.tsx` + пункт в `app.tsx`.

### Checkbox Upsell
- Оффер (`UpsellOffer`): товар-апселл (productId, productHandle, variantId), текст, подзаголовок, precheck, order, где показывать (`triggerAll` / productIds / collectionIds), `quantityMode` (`one` | `match` = как у основного товара), `oncePerCart`.
- **Liquid** (`checkbox-upsell.liquid`, target body) рендерит только подходящие офферы для текущего товара. Цена/compare-at/картинка/наличие берутся **живыми** через `all_products[productHandle]`; недоступный вариант не показывается. Не показывается на самом товаре-апселле и на страницах подарков `gift-links-gift`.
- **JS** (`wc-checkbox-upsell.js`): переносит список перед кнопкой Add to cart формы этого товара (селектор/позиция в настройках embed). Перехватывает `fetch` на `/cart/add[.js]`: если добавляется вариант ЭТОГО товара и есть отмеченные чекбоксы, превращает запрос в один `items[]` (основной + апселлы), `sections`/`sections_url` сохраняются, ответ отдаётся теме в обоих форматах (поля первой строки + `items` + `sections`), поэтому drawer темы Umino сразу рисует всё. Если комбинированный запрос отклонён (апселл распродан) — основной товар добавляется как обычно, апселлы отдельно, mini cart обновляется. Файлы в свойствах товара → тема добавляет сама, апселлы следом. Нативный submit формы (без AJAX) тоже поддержан.
- Строки апселла: скрытые свойства `_wc_upsell` (id оффера) и `_wc_upsell_for` (handle товара). У AXE были `__UpsellCheckboxId` и т.п.
- Строки плоские (не nested cart lines) — как у AXE; так безопаснее с Simple Bundles/Vitals.
- Ничего в корзине не удаляет. «Buy it now» (dynamic checkout) апселлы не добавляет (как и AXE).
- Тесты: `tests/test_upsell.py` (Playwright, мок Umino-формы, 9 сценариев × 2 порядка загрузки с хуком Gift Links) — все проходят. Liquid проверен LiquidJS-рендером (6 сценариев) и `shopify theme check`.

### AXE на 2026-10-07 (для переноса)
4 чекбокса: «Shipping Priority Upsell» (Skip The Line, коллекции All + Homepage, order 0, enabled, 1873 конверсии), «Each pillow in a gift box» (enabled), «3 in 1 Wireless Charger» (enabled), «Wireless Charger» (disabled). Перенос: создать офферы в WoodenCrew Apps → включить embed «Checkbox Upsell» → выключить embed AXE → проверить → удалить AXE.

---

## 12. Автодеплой (с v11, 2026-10-07)

Ручная процедура из раздела 5 больше не нужна. Схема **pull-based**: сервер сам забирает обновления, входящий SSH/ключи в GitHub не используются.

- **ИИ** собирает и тестирует, затем **пушит** новый `gift-links.tar.gz` в `nikadevs/gift-links` (main). Доступ: GitHub-коннектор claude.ai + Claude GitHub App на аккаунте nikadevs (установлены Roman 2026-10-07).
- **Сервер**: cron `/etc/cron.d/gift-links-deploy` каждые 2 минуты запускает `/opt/gift-links/deploy/auto-deploy.sh`:
  1. `git ls-remote` → если sha main изменился, качает `raw.githubusercontent.com/nikadevs/gift-links/<sha>/gift-links.tar.gz` (URL с sha, без кэша CDN);
  2. бэкап `build app extensions prisma package*.json` в `/opt/gift-links/.deploy-backups/` (хранятся 5 последних);
  3. ставит файлы; `npm ci && npm run setup` только если поменялся `package-lock.json`;
  4. `pm2 restart gift-links` + health check `http://127.0.0.1:$PORT/` (до 40 сек). Не ответил → **автооткат** на бэкап;
  5. `npx shopify app deploy --allow-updates --message "auto-deploy <sha>"` (токен `SHOPIFY_APP_AUTOMATION_TOKEN` из `/opt/gift-links/.deploy.env`, chmod 600; если файла нет — CLI-логин сервера);
  6. обновляет сами deploy-скрипты (атомарно), пишет `.deployed-sha`.
- **Не трогает**: `.env`, `.deploy.env`, `shopify.app*.toml`, `prisma/dev.sqlite`. Изменения scopes/toml всё ещё делаются вручную на сервере.
- **Статус**: https://giftlinks.nikadevs.com/deploy-status.json (status: running | ok | rolled_back | shopify_deploy_failed | download_failed | bad_archive, sha, время, хвост лога без строк с token/secret). Полный лог: `/var/log/gift-links-deploy.log`, последний прогон: `/opt/gift-links/.last-deploy.log`.
- Неудачный sha повторно не деплоится (записывается в `.deployed-sha`) — чинится новым коммитом. Ручной запуск: `/opt/gift-links/deploy/auto-deploy.sh --force`.
- Установка (однократно, Roman): `rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && bash /tmp/gl/gift-links/deploy/setup-auto-deploy.sh`
- Правило из раздела 8 обновлено с согласия Roman: **деплой приложения WoodenCrew Apps ИИ делает сам** (push в репозиторий). Консоль дроплета, DNS, API-токены по-прежнему за Roman.
- Ограничение: откат касается кода сервера; если `shopify app deploy` уже выпустил версию extensions, откатывать её нужно новым коммитом (или в Dev Dashboard → Versions → Release предыдущей).
