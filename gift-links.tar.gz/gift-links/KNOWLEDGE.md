# WoodenCrew Apps (бывш. Gift Links): полная база знаний (для человека и для другого ИИ)

Обновлено **2026-10-09 00:20 (Киев)**. **Новый чат: сначала прочитай раздел 0.**
Разделы 1–10 — модуль Gift Links (исторически, v9), 11 — Checkbox Upsell, 12 — автодеплой, 13 — SEO & Speed, 14 — как добавить новый модуль/приложение, 15 — Volume Discounts (v19).
Живые данные Shopify из раздела 4 проверены запросом к Admin API 2026-10-07.

---

## 0. START HERE — для нового чата этого проекта

**Что это.** Одно собственное (custom) Shopify-приложение **WoodenCrew Apps** (раньше называлось Gift Links / «Gift Sale») для магазина **woodencrew.store** (Shopify, **не Plus**). Внутри модули, как у Vitals. **Решение Roman: новые функции добавляем модулями в это приложение, а не отдельными приложениями** (раздел 14).

| Модуль | Админка | Статус |
|---|---|---|
| Gift Links | `/app/gifts` | на проде |
| Checkbox Upsell (замена AXE Checkbox Upsell) | `/app/upsells` | на проде, AXE заменён |
| Volume Discounts (как в Vitals) | `/app/volume` | **на проде, v27** (`woodencrew-apps-26`, GitHub `bff97ac`; блок 1:1 как Vitals — фото варианта + select); scopes одобрены; 3 оффера Vitals перенесены **выключенными**, $0-копии подарков созданы; app embed «Volume Discounts» выключен, Vitals работает как раньше (раздел 15) |
| Tracking (замена Track123; YunExpress Open API, страница трекинга, Omnisend, PayPal) | `/app/tracking` | на GitHub 2026-10-17; ждёт ключи YunExpress; все выходы выключены (раздел 25) |
| SEO & Speed (замена Tapita) | `/app/seo` | **на проде с v18** (2026-10-08 01:21 Киев, `woodencrew-apps-18`, GitHub `d4b4c36`); ждёт одобрения новых scopes Roman; app embed «SEO & Speed» выключен (раздел 13) |

**Текущее состояние (2026-10-09 ~00:15 Киев):** прод = **v27**: GitHub main `bff97ac`, Shopify `woodencrew-apps-26` (Active, проверено в Dev Dashboard; главная приложения открыта и проверена в админке). Исходник `source/` HEAD `1f0bbae`. v25 `932be2e`/`woodencrew-apps-24` — правки блока VD (Save белый, Show more options); v26 `233e503`/`-25` и v27 `bff97ac`/`-26` — главная как Vitals (раздел «Главная v26–v27» в конце). На 00:10 в нашем модуле оффер **GPS Wallet = Active** (включил Roman), в Vitals оффер GPS Wallet = Draft.

**Ранее (2026-10-08 ~23:40 Киев):** прод = **v24**: GitHub main `33d57aa`, Shopify `woodencrew-apps-23` (Active, проверено в Dev Dashboard и на витрине — ассеты `woodencrew-apps-23`), исходник `source/` коммит `07d621f` (включает v23 `e16b45b` Checkbox Upsell из другого чата — он задеплоен этим же архивом). Нумерация: в Shopify версия 23 = наш v24 (v23 отдельно не деплоился). Скрипт `wc-volume-discounts.js` на витрине загружается (embed включён), блока нет — все наши офферы Inactive.

**Ранее (2026-10-08 ~12:20):** прод = **v22**: GitHub main `8dec4e8`, Shopify `woodencrew-apps-22` («auto-deploy 8dec4e8», Active — проверено в Dev Dashboard), исходник `source/` коммит `1608f29`, архив `release/gift-links-v22-deploy.tar.gz` (md5 f06477aa…). Версии за день: v19 `ff41f5e` (модуль), v20 `1050c44` (защита подарков только по тегу, копии UNLISTED), v21 `493a630` (короткое имя подарка), v22 `8dec4e8` (копия через productSet). Scopes v19 Roman одобрил ~11:30. Новое: модуль Volume Discounts + главная Modules в стиле Vitals (список с иконками и бейджем Active). При открытии приложения Shopify просит одобрить новые права (Edit discounts, Publications) — это делает Roman.

**Состояние v18 (проверено 2026-10-08 ~01:15):**
- Прод = **v18**: GitHub `nikadevs/gift-links` main `d4b4c36`, версия в Shopify `woodencrew-apps-18` («auto-deploy d4b4c36»), deploy-status `ok` 2026-10-07T22:21:40Z; auto-deploy перенёс новые scopes в серверный toml. Проверено на витрине (страница подушки): ассеты `woodencrew-apps-18`, Gift Links и Checkbox Upsell работают (2 чекбокса), embed SEO & Speed выключен. Предыдущий прод v17 — `43e68af`.
- **v18 (SEO & Speed) запушен в GitHub** 2026-10-08 ~01:25 Киев: main `d4b4c36` (git `796ca93` + правки KNOWLEDGE), архив `release/gift-links-v18-deploy.tar.gz`. Код v17 (Gift Links, Checkbox Upsell v2) не менялся — проверено md5 всех файлов. После деплоя Roman одобряет новые scopes при открытии приложения; до этого старые модули работают как раньше, а правки SEO (meta/ALT/редиректы/скан темы) показывают сообщение о правах.
- Живая тема: app embed **Gift Links — On**, **Checkbox Upsell — On**; на странице подушки скрипта и чекбоксов **AXE больше нет**, скрипта Tapita тоже нет (проверено в браузере). Удалено ли само приложение AXE из магазина — не проверялось.
- Админка: `https://admin.shopify.com/store/woodencrew/apps/gift-links/app` (handle остался `gift-links`). Dev Dashboard: org `100333504`, app `432363503617` → Versions.

**Правила Roman** — раздел 8 (каждый ответ начинать с «Roman,», русский, не врать, проверять факты живыми данными, не ломать $0-строки бандлов и PDF Travel Book, никогда не отменять заказы, после тестов вернуть корзину). **После любого изменения обновлять этот файл и документ проекта** (см. ниже) — это прямое требование Roman.

**Где код.** Папка на компьютере Roman: `C:\Users\4elov\Google Drive Mirror\Claude\WC - Shopify Development\gift-sales\`. Работать через `device_bash` (в нём папка смонтирована как `$HOME/mnt/WC - Shopify Development/...`). Git-репозиторий — `gift-sales/source/` (история с 2026-10-06). Копия этого файла лежит и в `gift-sales/KNOWLEDGE.md`, и в документе проекта Claude `claude/gift-links-handoff.md`.

**Работа параллельно с другими чатами.** Над `source/` могут одновременно работать несколько чатов. Перед началом: `git log --oneline -5` в `source/` и прочитать свежий `KNOWLEDGE.md`. Править файлы точечно (python read-modify-write с проверкой якорей), не перезаписывать целиком чужие файлы, коммитить только свои файлы. Не пушить в GitHub чужие незаконченные версии без согласия.

**Как выкатить изменение (проверенный процесс, 2026-10-07):**
1. Правки в `source/`. Сборка — в рабочей копии **вне Google Drive**: `mkdir -p $HOME/work/app && cd source && tar --exclude=.git -cf - . | tar -xf - -C $HOME/work/app && cd $HOME/work/app && npm ci` (~30 с; `$HOME/work` живёт только в текущей сессии).
2. Проверки: `npm run typecheck`, `npx eslint app --ext .ts,.tsx`, `npx shopify theme check --path extensions/gift-links-embed`, `npm run build`. Браузерные тесты витрины — `tests/test_upsell.py`, `tests/test.py` (Playwright есть в облачном контейнере Claude, не на компьютере).
3. Коммит в `source/` (автор `Roman Pshenichny <4elove4ekfs@gmail.com>` + строки Co-Authored-By/Claude-Session). **Git в папке Google Drive требует разрешения на удаление** (`device_request_delete_permission` на `WC - Shopify Development`), иначе остаются `.git/*.lock`.
4. Архив: из `$HOME/work/app` упаковать `gift-links/` (без `node_modules`, `.git`, `.react-router`) в `gift-links.tar.gz`, копию — `release/gift-links-vN-deploy.tar.gz`. Подождать ~25 с: Google Drive временно делает hardlink, и `device_stage_files` отказывает (`nlink > 1`).
5. `device_stage_files` → облачный контейнер; `add_repo nikadevs/gift-links access=push`; `git clone --depth 1` в `/home/claude/gift-links`; заменить `gift-links.tar.gz`; commit; `git push origin main`. (GitHub-коннектор и Claude GitHub App на nikadevs установлены Roman 2026-10-07; Roman разрешил ИИ пушить сам.)
6. Сервер сам ставит версию за ≤2–4 мин (раздел 12). Проверка: Dev Dashboard → Versions — верхняя версия с текстом `auto-deploy <sha>`; потом открыть админку/витрину. `deploy-status.json` через WebFetch кэшируется 15 мин — сразу после деплоя ему не верить.
7. Обновить `KNOWLEDGE.md` (в `source/` и копию в `gift-sales/`) и документ проекта: `Projects project_write path=claude/gift-links-handoff.md local_path=<staged copy>`.

**Известные ограничения среды:** shell на компьютере не достаёт до дроплета и `giftlinks.nikadevs.com` (прокси 403) — консоль сервера только у Roman; автоматический фильтр безопасности сессии иногда блокирует действия (например открыть страницу загрузки GitHub) — не обходить, сообщить Roman; Shopify Admin API доступен через MCP-инструменты Shopify (только чтение по умолчанию; мутации заказов — только с согласия Roman).

---

## 1. Что это и зачем

**Gift Links** — собственное (custom) Shopify-приложение магазина **WoodenCrew** (woodencrew.store; travel gear; владелец Roman Pshenichny). Тариф **Shopify, не Plus**.

Задача: покупатель из email-рассылки получает **бесплатный подарок в корзине автоматически** и вдобавок промокод. Работает двумя способами:
1. **по ссылке** `https://woodencrew.store/<любой путь>?gift=<linkKey>`; если в ссылке уже есть `?`, то `&gift=<linkKey>`;
2. **по коду**: покупатель ввёл код кампании в поле скидки корзины или cart drawer темы.

Подарок — **отдельный товар-копия с ценой $0** (тег `gift-links-gift`). Скрипт кладёт его в корзину, когда корзина подходит под условия, и убирает, когда перестаёт подходить. Промокод (например 10%) скрипт применяет через Cart AJAX API.

Почему так, а не через стандартную скидку Buy X Get Y, объяснено в разделе 6.

---

## 2. Где что лежит

| Что | Где |
|---|---|
| Эта папка (полный архив знаний) | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Shopify Development\gift-sales\` |
| Исходник с git-историей | `source/` в этой папке; то же самое в архиве `archives/gift-links-src-v9.tar.gz` |
| **Рабочий прод** | DigitalOcean droplet **134.209.119.24**, папка **`/opt/gift-links`**, pm2-процесс `gift-links`, порт **3107**, nginx + Let's Encrypt, домен **https://giftlinks.nikadevs.com** |
| Секреты | только на сервере: `/opt/gift-links/.env` (SHOPIFY_API_KEY, SHOPIFY_API_SECRET, SCOPES, PORT=3107, NODE_ENV=production, SHOPIFY_APP_URL). В эту папку **не копируются** |
| Залинкованный `shopify.app.toml` | только на сервере. В нём `client_id` (начинается с `c8e4e2fb921220ff09ab97f0a97598…`), `application_url = https://giftlinks.nikadevs.com`, redirect_urls. В `source/shopify.app.toml` `client_id` пустой, и это нормально |
| GitHub | `nikadevs/gift-links` (публичный). Там **только** собранный архив `gift-links.tar.gz` (на 2026-10-08 — v17, коммит `43e68af`) и `install.sh`, исходников нет. Сервер забирает обновления отсюда сам (раздел 12) |
| Приложение в Shopify | Dev Dashboard → «WoodenCrew Apps» (бывш. «Gift Links»; custom distribution, установлено в woodencrew; app id `432363503617`). Версии: `gift-links-1…9`, затем `woodencrew-apps-10…17` |
| Claude Project | «WC - Shopify Aps Development», документ `claude/gift-links-handoff.md` (полная копия этого файла) |
| Релизные архивы | `gift-sales/release/gift-links-vN-deploy.tar.gz` (v9…v18) |
| Письма Gift Week | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Email Marketing\` (`GiftWeek-Email-1-Gift-Reveal.html`, `GiftWeek-Email-2-Last-Call.html`, `GiftWeek-Emails-Combined.html`). Копии лежат в `campaign-emails/` |

---

## 3. Архитектура и код

Стек: официальный шаблон **Shopify app на React Router** (`@shopify/shopify-app-react-router`, React Router 7.18), **Polaris web components** (`<s-page>`, `<s-section>`, `<s-text-field>`…), **App Bridge** (resourcePicker, toast), **Prisma + SQLite** (только для хранения сессий OAuth), Node ≥ 22.12. Scopes: **`read_products,read_discounts`** (больше не нужно; при config link они однажды слетели, см. раздел 7).

### 3.1 Хранение кампаний
Базы данных для кампаний нет. Весь конфиг лежит в одном **app-owned JSON metafield на AppInstallation**: namespace `gift_links`, key `config`, тип `json`.
```json
{ "version": 1, "campaigns": [ Campaign, ... ] }
```
Тема читает его в Liquid как `app.metafields.gift_links.config.value`. Витрина **не обращается к серверу приложения**: если сервер упадёт, витрина продолжит работать с последним сохранённым конфигом, перестанет работать только админка.

Тип `Campaign` (`app/campaigns.shared.ts`):
`id, name, active, linkKey, giftVariantId (числовой ID варианта строкой), giftTitle, giftImage, discountCode (один или несколько через запятую, UPPERCASE), triggerOnCode, minSubtotal (в валюте магазина, USD), addWhenCartEmpty, removeWhenIneligible, bannerText (≤140), landingPath, startsAt, endsAt (YYYY-MM-DD, end включительно), updatedAt`.

### 3.2 Файлы
| Файл | Назначение |
|---|---|
| `app/campaigns.shared.ts` | тип Campaign, `campaignLink(domain,c)` → `${domain}${landingPath}?gift=key`, `campaignStatus` |
| `app/campaigns.server.ts` | `loadConfig`/`saveConfig` (metafieldsSet на currentAppInstallation), `loadDiscountCodes` (`discountNodes(first:100, query:"method:code")`), `loadShopDomain`, `campaignFromForm` (валидация; коды → UPPERCASE, split по `[\s,]+`, join `,`) |
| `app/routes/app._index.tsx` | **с v10 — главная WoodenCrew Apps** (карточки модулей). Список кампаний переехал в `app/routes/app.gifts.tsx` (s-table: Copy link, Pause/Activate, Delete с подтверждением вторым кликом — window.confirm в iframe админки не используем) |
| `app/routes/app.campaigns.$id.tsx` | форма кампании. `CampaignRoute` ремаунтит `CampaignForm` через `key=id:updatedAt`. resourcePicker выбирает товар. s-select со скидками магазина + поле «…or type code(s)» |
| `app/routes/app.setup.tsx` | страница Setup guide |
| `app/routes/app.tsx` | навигация `s-app-nav`: Home (`rel="home"`, скрыт — название приложения и так ведёт на главную), Gift Links, Checkbox Upsell (+ SEO в v18). В сайдбаре Shopify помещается мало пунктов: лишние уходят под «Settings» |
| `extensions/gift-links-embed/shopify.extension.toml` | theme extension, name "Gift Links" |
| `extensions/gift-links-embed/blocks/gift-links.liquid` | **app embed** (target body). (1) Если открыта страница товара с тегом `gift-links-gift`, делает редирект на главную (только такие товары, **другие $0 товары не трогает**). (2) Выводит конфиг в `<script id="gift-links-config" type="application/json">` и подключает `gift-links.js` с data-атрибутами. Настройки: banner_bg `#155F56`, banner_color `#FFFFFF`, hide_gift_pages (по умолчанию true; проверка `!= false`, потому что у старых установок значение nil), debug |
| `extensions/gift-links-embed/assets/gift-links.js` | логика витрины, ~500 строк, IIFE, без зависимостей (подробно в 3.3) |
| `deploy/install.sh` | установщик/обновлятор для дроплета (подробно в разделе 5) |
| `deploy/ecosystem.config.cjs`, `deploy/nginx-gift-links.conf`, `deploy/env.example` | конфиги прод-окружения |
| `README.md` | исходная инструкция на русском. **Внимание:** раздел «Как запустить акцию» там описывает BXGY-подход, который в итоге **не используется** (см. раздел 6). Правильный рецепт описан в разделе 4 этого файла |
| `tests/test.py` (в этой папке) | Playwright-харнесс с мок-корзиной, 6 сценариев |

### 3.3 Как работает `gift-links.js`
- Константы: `TTL_MS` = 7 дней (столько браузер «помнит» кампанию после клика), `LINE_PROP = "_gift_link"` (скрытое свойство строки, помечает **наш** подарок).
- `isLive(c)`: active, задан giftVariantId, сегодняшняя дата в пределах startsAt..endsAt.
- **Триггер по ссылке:** параметр `?gift=key` работает на любой странице. Скрипт запоминает кампанию в localStorage и убирает параметр из URL через history.replaceState (UTM-метки остаются).
- **Триггер по коду:** если `triggerOnCode` и код кампании есть в `cart.discount_codes`, кампания активируется.
- **sync()**, главный цикл:
  1. **Rogue-удаление:** строки, у которых variant_id равен варианту подарка любой кампании, `original_price === 0` и **нет** `_gift_link`, удаляются (так подарок нельзя положить вручную). Другие $0 товары (компоненты бандлов, PDF Travel Book) не затрагиваются, потому что их вариантов нет в кампаниях.
  2. Если живой кампании нет, удаляет только свои строки (с `_gift_link`).
  3. Eligibility: сумма **оплачиваемых** строк (`final_line_price > 0`, не подарок) / 100 / `Shopify.currency.rate` ≥ `minSubtotal`. Пересчёт по курсу нужен для мультивалюты. Если `addWhenCartEmpty` = false, нужен хотя бы один платный товар.
  4. Добавляет подарок через `/cart/add.js` с `properties: {_gift_link: campaignId}`, держит количество 1, убирает лишние строки.
  5. Если корзина перестала подходить и `removeWhenIneligible`, удаляет подарок.
  6. **Коды:** `campaignCodes(c)` разбивает строку; коды **сливаются** с уже применёнными в корзине и отправляются через `/cart/update.js {discount: "A,B"}`. Guard: не больше 2 попыток применить за 10 минут (`state.applyTries/applyTs`), чтобы не было цикла, если Shopify отказывает в коде.
- **Перехват** `fetch` и `XMLHttpRequest` на `/cart/add|change|update|clear`: после действий темы снова запускается sync.
- **refreshUI:** на `/cart` делает перезагрузку страницы (с защитой от цикла), на остальных страницах перерисовывает секции Dawn (`cart-icon-bubble`, `cart-drawer`) через Section Rendering API.
- **Фоллбек-редирект:** если Liquid-редирект не сработал, а `ShopifyAnalytics.meta` показывает, что открыт вариант подарка за $0, делается редирект на главную.
- Баннер внизу страницы (текст из кампании, закрытие запоминается). Лимит sync: 6 раз за 10 секунд. Отладка: `window.GiftLinks.sync()`; при включённом Debug в консоли пишутся сообщения `[Gift Links]`.

---

## 4. Текущая настройка в магазине (проверено 2026-10-07)

| Объект | Значение |
|---|---|
| Товар-подарок | «WoodenCrew™ Stain Remover Stick — Gift», product **15414953541951**, handle `woodencrew™-stain-remover-stick-gift`, ACTIVE, теги `gift-links-gift`, `hidden-gift` |
| Вариант подарка | **67648456524095**, цена **$0.00** |
| Коллекция | «All products – GWP» (`all-products-gwp`), id **519322894655** (осталась от BXGY-попытки; подарок из неё убран через collectionRemoveProducts) |
| Скидка | **GIFTSTICK**: DiscountCodeNode **1590990340415**, Basic, **10%**, без минимума, ACTIVE с 2026-10-06T19:25:45Z до **2026-10-12T19:30:00Z**, combinesWith: product = true, order = false, shipping = true. Сочетается со скидками бандлов Vitals |
| Кампания | id **`c_mux5ft69xhnw`**, linkKey **`giftweek`**, подарок = вариант 67648456524095, код GIFTSTICK |
| Ссылка | `https://woodencrew.store/?gift=giftweek` (или `…/любой-путь?gift=giftweek`) |
| App embed | включён в живой теме (Online Store → Themes → Customize → App embeds → Gift Links) |

**Рецепт новой акции (правильный):**
1. Сделать копию товара-подарка (productDuplicate), цена $0, тег `gift-links-gift`, статус Active, опубликовать в Online Store. Убрать из коллекций, поиска и фидов, где это возможно. Страницу закроет редирект.
2. Создать код (обычно Basic %, combinesWith.productDiscounts = true, иначе он не сложится с Vitals).
3. Gift Links → New campaign: товар, код, minSubtotal, даты, баннер → Save → Copy link.
4. Поставить ссылку (или `&gift=key`) на **все** кнопки письма в Omnisend.
5. Проверить в инкогнито: переход по ссылке → добавить товар → подарок $0 и код применены → чекаут.

---

## 5. Деплой и сервер

> **Устарело с v11:** теперь работает автодеплой (раздел 12) и процесс из раздела 0. Ниже — ручной способ на случай, если автодеплой сломан.

### Обновление (ручной способ)
1. Внести изменения в `source/` и сделать коммит.
2. Сборка: `npm ci && npm run build` (локально или в контейнере ИИ). Упаковать **`gift-links.tar.gz`** с корневой папкой `gift-links/`, внутри `build/`, `app/`, `extensions/` и остальное (без node_modules).
3. **Roman сам** загружает `gift-links.tar.gz` в GitHub-репо `nikadevs/gift-links` (main) через веб-интерфейс (Add file → Upload, заменить файл). ИИ этого не делает.
4. **Roman** в консоли дроплета выполняет:
```bash
rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && cd /opt/gift-links && rm -rf build && cp -r /tmp/gl/gift-links/build /tmp/gl/gift-links/app /tmp/gl/gift-links/extensions . && npx shopify app deploy --allow-updates && pm2 restart gift-links
```
   Если менялись зависимости (`package.json`), нужен полный `install.sh` (см. ниже) или `npm ci` на сервере.
5. Проверка, что сервер скачал новую версию: raw.githubusercontent кэширует файл до ~5 минут. Сравнивать md5 (`md5sum`) архива или давать файлам уникальные имена версий. Однажды Roman несколько раз заливал старый архив, потому что имена файлов совпадали.

### Полная установка / переустановка
`bash <(curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/install.sh)` от root. Что делает скрипт:
- добавляет swap 2G;
- ставит Node 22 и pm2;
- скачивает тарбол и **сохраняет** `.env`, `prisma/dev.sqlite`, `shopify.app*.toml`;
- выполняет `npm ci` и `npm run setup`;
- если приложение не залинковано, запускает `shopify app config link`;
- правит в toml `application_url` и `redirect_urls` через sed;
- выполняет `shopify app deploy --allow-updates`;
- создаёт `.env` (`touch .env && shopify app env pull`) и дописывает PORT, NODE_ENV, SHOPIFY_APP_URL;
- пишет `ecosystem.config.cjs`, который **сам читает .env** (pm2 не подхватывал .env через node_args);
- настраивает сайт nginx и certbot.

### Грабли Shopify CLI на сервере (решены)
- `xdg-open ENOENT` при логине → `ln -sf /bin/true /usr/local/bin/xdg-open`, ссылку для логина открыть вручную.
- Флаг `--force` не существует, правильный `--allow-updates`.
- `node: .env: not found` → `touch .env` перед `env pull`.
- Пустой `appUrl` → в .env не было SHOPIFY_APP_URL, а pm2 не грузил .env. Исправлено ecosystem, который сам читает .env.
- После `config link` scopes в toml перезаписались → вернули `read_products,read_discounts` и сделали повторный deploy.

---

## 6. Ключевые решения и почему (не повторять ошибок)

1. **BXGY не подошёл.** Скидка Buy X Get Y не засчитывает товары «buy», на которые уже действует другая товарная скидка (бандлы **Vitals**). Это правило Shopify. Поэтому сделали **копию подарка с ценой $0** и **отдельный код 10%** с `combinesWith.productDiscounts = true`.
2. **Стандартные скидки не добавляют товар в корзину сами**, поэтому нужен скрипт на витрине.
3. **Shopify Functions** (cart transform, checkout validation) в custom-приложениях доступны **только на Plus**, поэтому вся логика на витрине (theme app embed + Cart AJAX API). Код, введённый **на странице чекаута**, подарок добавить не может.
4. **Draft-товар нельзя положить в корзину** (422 «Cannot find variant»), поэтому подарок Active, а его страница закрыта редиректом по тегу `gift-links-gift`.
5. **Защита от бесплатной покупки подарка:** rogue-удаление строк без `_gift_link` плюс редирект со страницы товара. Бэкстоп в Shopify Flow (его создаёт Roman): заказ, где subtotal = 0 и есть только подарок, получает тег `gift-review` и **hold fulfillment**. **Без отмены.**
6. Привязка к **тегу**, а не к ID товара: подарки будут меняться каждую неделю.
7. Несколько кодов на кампанию (`A,B`), коды сливаются с уже применёнными.
8. Конфиг хранится в metafield, а не в базе: витрине не нужен сервер, нагрузки нет.

---

## 7. История (кратко)

- **2026-10-06.** Письма Gift Week (подарок Stain Remover Stick). Попытка BXGY GIFTSTICK провалилась из-за конфликта с Vitals. Создано приложение (`42ae877`) и установщик. Деплой на дроплет, DNS-поддомен giftlinks.nikadevs.com, SSL. Приложение установлено, app embed включён. Скидка GIFTSTICK пересоздана как 10% Basic, подарок сделан копией за $0. Добавлены несколько кодов на кампанию (`c3f4e94`) и rogue-удаление (`17fadca`).
- **2026-10-07.** Редирект со страниц подарков только по тегу (`4765ac4`), фоллбек на unset-настройку и через ShopifyAnalytics (`f147685`) → **v9 на проде, проверено на живом сайте**: подарок и 10% сочетаются с бандлами Vitals, на /cart нет цикла перезагрузок, редирект работает, $0 товары бандлов и PDF Travel Book не затронуты, подарок, добавленный вручную, удаляется.
- Покупатели переходили на сайт по ссылкам письма без `?gift=` и оставались без подарка. Заказы **#38664** и **#38665** дополнены подарком вручную через orderEditBegin/AddVariant/Commit: `notifyCustomer: false`, staffNote «Gift Week: free Stain Remover Stick added (email subscriber)», суммы не изменились.
- Roman получил промпт для временного Flow (до **2026-10-09T21:00:00Z**): заказ подписчика или повторного покупателя → Add order line item (подарок) бесплатно. Flow Roman создаёт сам.
- **2026-10-07, днём–вечером (WoodenCrew Apps):** v10 переименование + модуль Checkbox Upsell; v11 автодеплой (Roman установил cron и Automation Token; первая попытка упала из-за дважды вставленного токена — 138 символов, исправлено); v12 ⓘ-попап у чекбокса; v13 таблицы на всю ширину; перенос 3 офферов из AXE; v14 статистика (scope `read_orders`, Roman одобрил); **v15 Checkbox Upsell v2 «watch the cart»** — v1 не работал на товарах с бандлом Vitals (Vitals сам добавляет товар и уводит на /cart, перехват запроса темы не срабатывал); v16 перезагрузка устаревшей /cart после редиректа (апселлы и подарок Gift Links); v17 таблица 14px, проверка app embed у Refresh, меню помещается. Всё проверено на живом сайте (подушка ×2 через Vitals → оба апселла в корзине), тестовые строки удалены.
- **2026-10-07 ночью:** модуль SEO & Speed (v18, раздел 13); 2026-10-08 ~01:25 запушен в GitHub (`d4b4c36`).

---

## 8. Правила работы с Roman (обязательно)

- **Каждый ответ начинать с «Roman,».** Общение на русском, маркетинговые тексты на английском.
- **Никогда не врать, всегда проверять факты** (живые данные проверять запросом к API или в браузере, а не по памяти).
- Email-темы и прехедеры: **4–5 слов максимум**, без пунктуации, один эмодзи в начале.
- **Очень аккуратно:** не ломать $0 товары бандлов (**Vitals**, **Simple Bundles**) и **PDF Travel Book**, который добавляется собственными скриптами магазина. Любая логика, которая удаляет или меняет строки корзины, должна трогать только варианты подарков кампаний или строки с `_gift_link`.
- **Никогда не отменять заказы** (вредит репутации). Только тег, hold или ручная проверка.
- После тестов на живом сайте **вернуть корзину Roman в исходное состояние**.
- Изменения в заказах клиентов (orderEdit) делать только с явного согласия Roman, по конкретным номерам заказов, с `notifyCustomer: false`, если он не просил иначе.
- **Деплой WoodenCrew Apps ИИ делает сам** — push архива в `nikadevs/gift-links` (Roman разрешил 2026-10-07; процесс в разделе 0).
- Тесты на живом магазине делать только на временных скрытых объектах (товар со статусом UNLISTED и скидки только на него), потом удалять и возвращать корзину.
- Действия, которые ИИ **не делает сам** (их делает Roman): работа в консоли дроплета, создание и использование API-токенов (DigitalOcean, Shopify Automation Token и др.), правка DNS через API, одобрение новых прав приложения (scopes) в админке, создание Flow с автоотменой или массовыми действиями, снятие товаров с публикации. ИИ готовит команды и инструкции.
- Всё, что сразу меняет то, что видят покупатели (включение/выключение app embed, новые чекбоксы на витрине и т.п.), — сначала спросить Roman.
- **После каждого изменения обновлять `KNOWLEDGE.md` и документ проекта `claude/gift-links-handoff.md`**, чтобы другие чаты проекта знали всё (требование Roman 2026-10-08).
- Напоминание: DigitalOcean-токен `claude-gift-links` Roman должен был удалить (для работы приложения он не нужен).

---

## 9. Тестирование

- `tests/test.py`: Playwright (`python3 test.py`), мок-корзина и мок-страница, сценарии: (1) переход по ссылке при пустой корзине (подарок не добавляется), (2) тема добавляет товар (появляются подарок и оба кода `GIFTSTICK,GIFTSTICK10`), (3) удаление платного товара (подарок уходит), (4) новый визит без ссылки (кампания запомнилась, подарок снова добавляется), (5) запуск по коду в новом браузере, (6) подарок добавлен вручную без свойства `_gift_link` (rogue-удаление). Путь к JS в начале файла поменять на `../source/extensions/gift-links-embed/assets/gift-links.js`.
- Живой тест: инкогнито → `woodencrew.store/?gift=giftweek` → добавить товар → проверить `/cart.js` (строка подарка с `_gift_link`, `discount_codes` содержит GIFTSTICK) → чекаут показывает подарок $0 и −10%. После теста очистить корзину.

---

## 10. Бэклог / идеи

1. **Триггер по `utm_campaign`** из Omnisend: активировать кампанию по любой ссылке письма, а не только с `?gift=`. В кампанию добавить поле `utmCampaign`, в JS проверять `URLSearchParams.get('utm_campaign')`. Закрывает проблему из раздела 7.
2. **Автосоздание $0 копии подарка** при выборе товара в админке: productDuplicate, цена 0, тег `gift-links-gift`, публикация. Нужен scope `write_products`.
3. Поддержка cart drawer не-Dawn тем (сейчас перерисовка секций рассчитана на Dawn).
4. Обновить `README.md` в исходнике: убрать устаревший BXGY-рецепт.
5. Предложено обновить скилл wc-email-subject (лимит 4–5 слов); статус неизвестен.

---

## 11. WoodenCrew Apps: модульное приложение (с 2026-10-07, v10)

Приложение Gift Links переименовано в **WoodenCrew Apps** (`name` в toml; `client_id`/`handle`, папка `/opt/gift-links`, pm2 `gift-links`, репо `nikadevs/gift-links` и extension `gift-links-embed` **не менялись**, чтобы не сломать установку и включённый embed). Внутри модули, у каждого свой конфиг-metafield и свой app embed:

| Модуль | Админка | Metafield (AppInstallation) | App embed | Файлы |
|---|---|---|---|---|
| Gift Links | `/app/gifts`, `/app/campaigns/:id` | `gift_links.config` | «Gift Links» | `campaigns.*.ts`, `gift-links.liquid/js` |
| Checkbox Upsell (замена AXE Checkbox Upsell) | `/app/upsells`, `/app/upsells/:id` | `wc_upsell.config` | «Checkbox Upsell» | `upsells.*.ts`, `checkbox-upsell.liquid`, `wc-checkbox-upsell.js/css` |

Главная `/app` — карточки модулей. Новый модуль = свой `*.shared.ts` + `*.server.ts` + роуты `app.<module>...` + блок в `extensions/gift-links-embed/blocks/` + карточка в `app._index.tsx` + пункт в `app.tsx`.

### Checkbox Upsell
- Оффер (`UpsellOffer`): товар-апселл (productId, productHandle, variantId), текст, подзаголовок, precheck, order, где показывать (`triggerAll` / productIds / collectionIds), `quantityMode` (`one` | `match` = как у основного товара), `oncePerCart`.
- **Liquid** (`checkbox-upsell.liquid`, target body) рендерит только подходящие офферы для текущего товара. Цена/compare-at/картинка/наличие берутся **живыми** через `all_products[productHandle]`; недоступный вариант не показывается. Не показывается на самом товаре-апселле и на страницах подарков `gift-links-gift`.
- **JS v2 «watch the cart»** (`wc-checkbox-upsell.js`, с v15). Подключается **на каждой странице** (элемент `#wcu-boot`), список `#wcu-root` — только на странице товара (переносится перед кнопкой Add to cart; селектор/позиция в настройках embed).
  1. Клик/submit по Add to cart (capture-фаза, до обработчиков темы и Vitals) → отмеченные чекбоксы + текущее количество товара в корзине пишутся в localStorage `wcUpsell.pending.v2` (живёт 2 мин).
  2. Скрипт следит за корзиной (хуки fetch/XHR на `/cart/*` + опрос раз в 1,5 с, пока есть pending) на этой и **следующей** странице (например /cart после редиректа Vitals). Как только количество этого товара выросло — добавляет апселлы одним `/cart/add.js` (`keepalive`); если один распродан — по одному. Затем обновляет mini cart (Umino `form-mini-cart`, Dawn) или перезагружает /cart один раз.
  3. Запросы темы и других приложений **не изменяются**. Если добавлен другой товар или галочки сняты — ничего не добавляется.
  - Почему так: v1 встраивался в запрос темы `/cart/add` и **не работал на товарах с бандлом Vitals** (Vitals добавляет товар своим запросом и сразу уводит на /cart). Cart Transform / Functions не используем — только Plus (раздел 6).
  - `quantityMode: match` = столько, сколько единиц добавилось; `oncePerCart` — не добавлять, если уже в корзине.
- **ⓘ-попап** (`infoText`, с v12): кнопка ⓘ у цены, текст в модальном окне (только текст, не HTML).
- **Маркер embed** `<div id="wcu-embed" hidden>` (с v17) — по нему админка проверяет, включён ли embed.
- Строки апселла: скрытые свойства `_wc_upsell` (id оффера) и `_wc_upsell_for` (handle товара). У AXE были `__UpsellCheckboxId` и т.п.
- Строки плоские (не nested cart lines) — как у AXE; так безопаснее с Simple Bundles/Vitals.
- Ничего в корзине не удаляет. «Buy it now» (dynamic checkout) апселлы не добавляет (как и AXE).
- **Админка `/app/upsells`** (v17): статистика за 7/30/60 дней — Revenue, Revenue Boost %, Conversions/Revenue по каждому чекбоксу. Считается Bulk Operation по заказам за 60 дней (больше Shopify не даёт; scope `read_orders`), строки с `_wc_upsell` **или** AXE `__UpsellCheckboxId` (история AXE тоже считается), кэш в metafield `wc_upsell.stats`, обновление раз в 6 ч или кнопкой Refresh (`app/upsell-stats.server.ts`). Рядом с Refresh — значок **App embed: On/Off** (`app/embed-status.server.ts`: сервер открывает главную магазина и ищет маркер; кэш 1 мин; при Off — красный баннер и кнопка «Turn on» = deep link `admin/themes/current/editor?context=apps&activateAppId=<client_id>/checkbox-upsell`). Таблица своя HTML (14px), т.к. у `s-table` фиксированный 13px.
- Тесты: `tests/test_upsell.py` (Playwright: мок Umino-страницы + /cart, Vitals-подобный виджет с кэшированным fetch и редиректом, нативный submit, распродан, once, другой товар, снятые галочки, истёкший pending, попап; 18 проверок × 2 порядка загрузки с хуком Gift Links = 36) — все проходят. Liquid — LiquidJS + `shopify theme check`.

### Офферы (перенесены из AXE 2026-10-07)
| Чекбокс (id) | Добавляет | Где | Order | Особое |
|---|---|---|---|---|
| 3 in 1 Wireless Charger (`u_muy80agm1at3`) | WoodenCrew™ 3 in 1 Wireless Foldable Charger, вариант 52410746372415 ($19.95/$34.95) | товар AirSlate GPS Wallet Tracker (`wallet-gps-tracker-card`) | −1 | ⓘ «Power all your essentials, anywhere. The ultimate universal 3-in-1 foldable charging station.» |
| Shipping Priority Upsell (`u_muy7sxmbsj5k`) | Skip The Line (Priority Processing), 49930585112895 ($2.50/$5.00), подзаголовок «Priority Processing» | коллекции All + Homepage | 0 | once per cart |
| Each pillow in a gift box (`u_muy7wab6v7tb`) | Each Pillow in Gift Box, 51625826091327 ($3.95/$7.95) | Travel Pillow, Travel Pillow Ultimate Kit | 1 | qty 1 (как в AXE) |

«Wireless Charger» из AXE (был выключен) не переносился. На витрине AXE больше не выводится (проверено 2026-10-08).

---

## 12. Автодеплой (с v11, 2026-10-07)

Ручная процедура из раздела 5 больше не нужна. Схема **pull-based**: сервер сам забирает обновления, входящий SSH/ключи в GitHub не используются.

- **ИИ** собирает и тестирует, затем **пушит** новый `gift-links.tar.gz` в `nikadevs/gift-links` (main). Доступ: GitHub-коннектор claude.ai + Claude GitHub App на аккаунте nikadevs (установлены Roman 2026-10-07).
- **Сервер**: cron `/etc/cron.d/gift-links-deploy` каждые 2 минуты запускает `/opt/gift-links/deploy/auto-deploy.sh`:
  1. `git ls-remote` → если sha main изменился, качает `raw.githubusercontent.com/nikadevs/gift-links/<sha>/gift-links.tar.gz` (URL с sha, без кэша CDN);
  2. бэкап `build app extensions prisma package*.json` в `/opt/gift-links/.deploy-backups/` (хранятся 5 последних);
  3. ставит файлы; `npm ci && npm run setup` только если поменялся `package-lock.json`;
  4. `pm2 restart gift-links` + health check `http://127.0.0.1:$PORT/` (до 40 сек). Не ответил → **автооткат** на бэкап;
  5. `npx shopify app deploy --allow-updates --message "auto-deploy <sha>"` (токен `SHOPIFY_APP_AUTOMATION_TOKEN` из `/opt/gift-links/.deploy.env`, chmod 600; если файла нет — CLI-логин сервера);
  6. обновляет сами deploy-скрипты (атомарно), пишет `.deployed-sha`.
- **Не трогает**: `.env`, `.deploy.env`, `prisma/dev.sqlite`, данные `data/`. В серверном `shopify.app.toml` меняет **только строку `scopes = "..."`** (с v14 копируется из релиза, шаг 4b; бэкап toml делается) — после этого Roman один раз одобряет новые права при открытии приложения. Остальной toml (client_id, URL) — только вручную на сервере.
- **Статус**: https://giftlinks.nikadevs.com/deploy-status.json (status: running | ok | rolled_back | shopify_deploy_failed | download_failed | bad_archive, sha, время, хвост лога без строк с token/secret). Полный лог: `/var/log/gift-links-deploy.log`, последний прогон: `/opt/gift-links/.last-deploy.log`.
- Неудачный sha повторно не деплоится (записывается в `.deployed-sha`) — чинится новым коммитом. Ручной запуск: `/opt/gift-links/deploy/auto-deploy.sh --force`.
- Установка (однократно, Roman): `rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && bash /tmp/gl/gift-links/deploy/setup-auto-deploy.sh`
- Правило из раздела 8 обновлено с согласия Roman: **деплой приложения WoodenCrew Apps ИИ делает сам** (push в репозиторий). Консоль дроплета, DNS, API-токены по-прежнему за Roman.
- Ограничение: откат касается кода сервера; если `shopify app deploy` уже выпустил версию extensions, откатывать её нужно новым коммитом (или в Dev Dashboard → Versions → Release предыдущей).

---

## 13. Модуль SEO & Speed (с v18, 2026-10-08) — замена Tapita

Админка `/app/seo` (вкладки Overview, Issues, Pages, Speed, Meta tags, Image ALT, Links & 404, Theme code, Settings). App embed «SEO & Speed» (`blocks/seo-speed.liquid`, target **head**), конфиг витрины — metafield `wc_seo.config` на AppInstallation (`instantNav: off|prefetch|prerender`, `track404`, `beaconUrl`).

### Что умеет
| Функция | Как | Данные |
|---|---|---|
| Аудит сайта | `seo/seo-crawl.server.ts`: robots.txt, sitemap (индекс + дочерние), страницы (quick = главная + ключевые/выборка, full = весь sitemap до `fullCrawlMax`, по умолчанию 300), 2 запроса параллельно с паузой, UA `WoodenCrewAudit/1.0`. Проверка ссылок (до 400, HEAD→GET, redirect manual), размеры видео и сторонних скриптов | `data/seo/<shop>/latest.json`, `reports/<id>.json` (12 последних), `history.json` |
| Проверки HTML | `seo/seo-html.server.ts` (node-html-parser, JS не исполняется): title/description (длина, дубли), H1, canonical, noindex/X-Robots-Tag, hreflang, OG, lang, viewport, мало текста, не-ASCII URL, JSON-LD (Product/ProductGroup offers price/currency/availability, image, brand/sku, return policy, shipping, rating, дубли Product/Organization/Article, Breadcrumb), картинки (alt, width/height, полноразмерные без width/srcset, lazy первая картинка), скорость (DOM > 3000, HTML > 600 KB, блокирующие script/CSS в head, сторонние домены ≥ 8, дубли скриптов, несколько jQuery, @font-face без font-display, iframe без lazy, mixed content), Liquid error | каталог проверок с «почему/как исправить/ссылка Google» — `seo/seo.shared.ts` `CHECKS` |
| PageSpeed | `seo/seo-psi.server.ts`: PSI API v5 (mobile+desktop), Lighthouse lab + CrUX (url или origin), CWV pass/fail по p75 (LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1), список невыполненных аудитов/insights с экономией (парсер проверен на реальном LHR Lighthouse 13.5), third parties, LCP-элемент | `psi.json` (400 прогонов) |
| Meta tags | products/collections: поле `seo`; pages/articles: metafields `global.title_tag/description_tag`; шаблон заполняет **только пустые** поля (`{title}`, `{shop}`, `{summary}`); Google-превью | Shopify |
| Hide from search | metafield `seo.hidden = 1` (number_integer) → Shopify ставит noindex,nofollow и убирает из sitemap | Shopify |
| Image ALT | список фото активных товаров, правка по одной, шаблон для пустых (`{title} - photo {n}`), `fileUpdate` | Shopify |
| Links & 404 | битые ссылки из аудита, лог 404 (embed шлёт `sendBeacon` на `https://giftlinks.nikadevs.com/api/seo/404` только на шаблоне 404; принимается только для установленных магазинов, лимит 20/мин на IP, ботовые пути отбрасываются), подсказка цели редиректа, создание/удаление `urlRedirect`, поиск петель и цепочек | `404.json` (до 2000 путей) |
| Theme code | read-only скан опубликованной темы: следы приложений (Tapita, AXE и др.), app embeds из settings_data.json, внешние/блокирующие скрипты в layout, крупные assets, неиспользуемые snippets | `theme-scan.json` |
| Instant navigation | Speculation Rules `moderate` (prefetch или prerender) для ссылок, кроме cart/checkout/account/apps. Shopify с июня 2025 уже даёт `conservative prefetch` всем магазинам. **По умолчанию Off** (правило: UX витрины меняем только с согласия Roman) | metafield |
| Автопроверки | `seo/seo-scheduler.server.ts` (стартует в `entry.server.tsx`): раз в 30 мин смотрит; quick-аудит раз в сутки, full — раз в 7 дней; PSI раз в сутки (главная + первый ключевой товар). Отключение: Settings или `WC_SEO_SCHEDULER=off` | — |

### Важно
- **PSI API без ключа фактически не работает**: проверено 2026-10-08 — анонимная квота Google исчерпана (`429 Quota exceeded … Queries per day`). Нужен бесплатный ключ (Google Cloud → PageSpeed Insights API → Credentials → API key). Ключ вводится в Settings (хранится только в `data/seo/<shop>/settings.json` на сервере) или `PSI_API_KEY` в `.env`.
- Данные модуля — файлы в `/opt/gift-links/data/seo/` (`WC_DATA_DIR`), auto-deploy их не трогает. Витрине они не нужны.
- Новые scopes (v18): `write_products, read_content, write_content, read_online_store_pages, write_online_store_pages, read_themes, read_online_store_navigation, write_online_store_navigation, read_files, write_files`. auto-deploy синхронизирует строку scopes; **Roman должен один раз одобрить обновление** при открытии приложения. До этого аудит и PageSpeed работают, а правки (meta, ALT, редиректы, скан темы) показывают сообщение о правах.
- Модуль ничего не меняет сам: все правки данных — только по кнопке Save; код темы не редактируется никогда.
- Новая зависимость `node-html-parser@7.0.1` → в деплое меняется package-lock → auto-deploy выполнит `npm ci`.

### Тесты (`.tests/` в исходнике, не входят в релиз)
`e2e-crawl.ts` (мок-магазин на реальных HTML WoodenCrew из woodencrew-seo/reports/2026-10-05: битая ссылка, ссылка на редирект, 404 в sitemap, редирект в sitemap, видео, 404-лог), `units.ts` (robots, подсказка редиректа, скан темы на фейковом admin), `beacon.ts` (404 endpoint), `ui-smoke.tsx` (SSR всех 9 страниц), парсер PSI на реальном LHR, Liquid embed (LiquidJS, 6 сценариев + `shopify theme check`), все GraphQL-операции проверены валидатором схемы Shopify, чтение — на живом магазине.

### Бэклог SEO
1. Search Console API (запросы, клики, индексация) — нужен Google OAuth-клиент.
2. llms.txt (у Tapita есть; польза для Google не подтверждена) — через redirect `/llms.txt` → app endpoint.
3. Организационная политика доставки/возврата в JSON-LD темы (`hasShippingService`, `hasMerchantReturnPolicy` на Organization) — только с реальными тарифами.
4. Аудит переводов/рынков (hreflang-ответные ссылки по всем рынкам).

---

## 14. Как добавить новый модуль (или «новое приложение»)

По умолчанию «новое приложение» = **новый модуль внутри WoodenCrew Apps** (решение Roman: одно приложение вместо многих). Отдельное Shopify-приложение — только если Roman прямо попросит: тогда нужны новое приложение в Dev Dashboard (создаёт Roman), свой порт/pm2-процесс/поддомен/SSL на дроплете и своя установка.

Шаги для модуля (по образцу Checkbox Upsell):
1. **Данные.** Если они нужны витрине — app-owned JSON metafield `wc_<module>.config` на `currentAppInstallation` (образец `app/upsells.server.ts`: load/save через `metafieldsSet`), витрина читает `app.metafields.wc_<module>.config.value`. Серверные/большие данные — файлы в `data/<module>/<shop>/` (образец SEO, раздел 13; auto-deploy их не трогает).
2. **Код админки.** `app/<module>.shared.ts` (типы), `app/<module>.server.ts`, роуты `app/routes/app.<module>._index.tsx` (список) и `app.<module>.$id.tsx` (форма). Polaris web components (`s-page inlineSize="large"`, `s-section`…), App Bridge `resourcePicker`. Без `window.confirm` (iframe) — подтверждение вторым кликом.
3. **Карточка** в `app/routes/app._index.tsx` (массив `modules`) и пункт в `app/routes/app.tsx` (`s-app-nav`; места в сайдбаре мало).
4. **Витрина. Без отдельного app embed (правило Roman 2026-10-14):** код модуля печатает embed Gift Links (`blocks/gift-links.liquid`, свой блок перед `{% schema %}`) только если `app.metafields.wc_<module>.config.enabled`; включение/выключение — кнопкой Turn on / Turn off на странице модуля (образец: Content Protection, Quick Links). Большие скрипты — файлы в `assets/`, подключаемые из этого блока. Маркер `<div id="wc-<module>-on" hidden>` + `checkEmbed()` из `app/embed-status.server.ts`. Расширение одно (`gift-links-embed`) — не переименовывать.
5. **Корзина.** Не трогать чужие строки: только свои, помеченные скрытым свойством `_wc_<module>`. Не изменять запросы темы/Vitals/Simple Bundles. Учитывать $0-строки бандлов и PDF Travel Book.
6. **Права.** Новые scopes — в `source/shopify.app.toml` (строка `scopes`); auto-deploy перенесёт; Roman одобрит. Нужны ли «protected customer data» — проверить заранее (для заказов Shopify показывает Roman экран с доступом к данным покупателей).
7. **Проверки и деплой** — раздел 0. Тесты витрины — Playwright с моком страницы (образец `tests/test_upsell.py`), Liquid — LiquidJS + theme check, GraphQL — валидатор схемы Shopify.
8. **Документация.** Новый раздел в этом файле (что делает, где файлы, данные, решения, тесты, бэклог) + обновить раздел 0 + документ проекта.


---

## 15. Модуль Volume Discounts (с v19, 2026-10-08) — замена Vitals Volume Discounts

Админка `/app/volume` (список как в Vitals: поиск, вкладки All/Active/Inactive/Scheduled, таблица Name+картинки товаров, Status, Type «Up to X% off», Impressions, Clicks, Click Rate, Orders, Revenue; Activate/Deactivate, Duplicate, Delete вторым кликом) и `/app/volume/:id` (форма + превью). App embed «Volume Discounts» (`blocks/volume-discounts.liquid`, target body, маркер `#wcvd-embed`). Конфиг — metafield `wc_vd.config` на AppInstallation, статистика заказов — `wc_vd.stats`, показы/клики — `data/vd/<shop>/events.json`.

### Что оставлено из Vitals (только то, что у нас используется)
Товары оффера (Applies to), расписание (start/end), название скидки для покупателя, тиры (количество, % скидки, бейдж «Top Pick», подарки), тир по умолчанию, сколько тиров видно до «Show more options», заголовок «Buy more, save more!». Шрифты/дизайн-настройки Vitals убраны — шрифт из темы; в embed только цвета (accent #177983, фон выбранного тира #ECF4F5, рамка #CECECE, текст #555555 — сняты с живого виджета Vitals), галочки «Show header» и «Show badge» (по умолчанию выкл. — на витрине Vitals заголовок и Top Pick скрыты), селектор/позиция, после добавления (на /cart или остаться), debug.

### Выбор вариантов — 1:1 как Vitals (v24)
С v24 (по просьбе Roman «точная 1:1 копия») свотчи убраны. У выбранного тира для каждой единицы (#1, #2…): фото выбранного варианта 35px + нативный select со всеми вариантами (стрелка-chevron, высота 36px). Подарок: фото выбранного варианта 70px (белая рамка 4px), название, select (только у выбранного тира), зачёркнутая цена справа. Бейдж «Save: $x» по центру нижней границы тира. Распроданные варианты в select — disabled с «- Sold out». Выбор запоминается в localStorage `wcvd.choice.v1`. Размеры/цвета/отступы сняты с computed styles живого виджета Vitals на /products/travel-pillow.

### Как устроена скидка (важно)
- Custom-приложениям на не-Plus **Shopify Functions недоступны** (документация), а Vitals — публичное приложение со своей Function. Поэтому скидка — **нативные автоматические скидки Shopify** «Amount off products», минимум N шт., товары оффера: **по одной на тир с полным %** (20% от 2 шт., 30% от 3 шт.; тир с тем же %, что предыдущий, своей скидки не получает).
- **Проверено вживую 2026-10-08** на временном UNLISTED-товаре: две автоматические скидки на одной строке **не складываются**, Shopify берёт лучшую (3 шт. → 30%, 2 шт. → 20%). Поэтому цепочка «20% + 12,5%» не используется. С промокодами (10hello и т.п.) складывается как раньше (combinesWith product/order/shipping = true).
- Shopify требует **уникальные названия** автоматических скидок → к названию добавляется невидимый суффикс из zero-width символов (так же делает Vitals: «Discount» + невидимые символы в заказах). Покупатель видит одно название. Статистика сравнивает названия без этих символов (`cleanTitle`).
- Новые скидки начинают применяться в корзине **не мгновенно** (в тесте ~1–2 мин).
- Количество считается **по всем товарам оффера вместе** (1 подушка + 1 сумка = «Buy 2») — так считает нативная скидка. В Vitals галочка «across different products» была выключена (каждый товар отдельно). Нужен «только один и тот же товар» → отдельный оффер на товар. Лимит Shopify — 25 активных автоматических скидок; форма считает и не даёт превысить. Один товар может быть только в одном активном оффере.
- Скидки создаются/удаляются при Save/Activate/Deactivate/Delete (`syncOfferDiscounts`). Если создание падает — созданные откатываются, оффер выключается, ошибка видна в форме и списке.
- Пока активен оффер Vitals на тех же товарах, обе автоскидки не складываются (берётся лучшая), но виджетов будет два → перед включением нашего оффера выключить оффер Vitals и включить embed.

### Подарки
- Подарок = **$0-копия товара** (как в Gift Links): кнопка «Make $0 gift copy» делает productDuplicate → все варианты $0 (compare-at = старая цена, показывается зачёркнутой), без учёта остатков (inventoryPolicy CONTINUE, tracked false), теги `gift-links-gift`, `wc-vd-gift`, `hidden-gift`, `seo.hidden = 1`, публикация в Online Store (канал ищется по `Publication.name`: у этого магазина `catalog` у публикаций = null). Форма не сохраняет подарок, который не $0 или не Active.
- Скрипт на каждой странице (`wc-volume-discounts.js`, sync): считает товары оффера в корзине → достигнутый тир → держит ровно по одной строке каждого подарка тира со свойством `_wc_vd_gift = <offerId>:<giftProductId>` (тот же подарок между тирами не пересоздаётся), лишние убирает. Строка варианта подарка за $0 **без** нашего свойства удаляется (нельзя купить подарок отдельно). Другие строки (Simple Bundles $0, PDF Travel Book, апселлы) не трогаются. Страница подарка редиректит на главную через Gift Links (тег `gift-links-gift`).
- Vitals-подарки сейчас — настоящие товары со скидкой 100% от их Function; у нас — $0-копии. Копии надо сделать один раз при настройке оффера.

### Витрина
- Блок ставится внутри `product-form` перед формой Add to cart (там же, где Vitals в Umino; селектор `form[action*='/cart/add']`). Тир по умолчанию выставляет количество в поле темы.
- Add to cart с тиром 2+ перехватывается (capture на document; Checkbox Upsell продолжает работать) → один `/cart/add.js` с выбранными вариантами (свойства формы `properties[...]` сохраняются) → sync подарков → /cart (или «остаться» + обновление mini cart Umino). Тир 1 — тема добавляет как обычно.
- Маяки показов/кликов: `POST https://giftlinks.nikadevs.com/api/vd/event` (только установленные магазины, лимит 60/мин на IP).

### Файлы
`app/vd.shared.ts`, `app/vd.server.ts`, `app/vd-stats.server.ts`, `app/routes/app.volume._index.tsx`, `app/routes/app.volume.$id.tsx`, `app/routes/api.vd.event.tsx`, `extensions/gift-links-embed/blocks/volume-discounts.liquid`, `assets/wc-volume-discounts.js/css`. Главная `app/routes/app._index.tsx` переделана под вид Vitals (свои SVG-иконки в оранжевых плитках). Scopes v19: + `write_discounts, read_publications, write_publications`.

### Тесты (`.tests/`)
`.tests/vd/test_vd.py` (Playwright, мок Umino + мок корзины, Liquid рендерится LiquidJS `render.mjs`, проверки: рендер, цены $55.92/Save $13.98, select-ы и смена фото варианта, скрытые header/badge, sold-out, перехват ATC и один add с 2 вариантами, подарки по тирам, удаление «ручных» $0, Simple Bundles не тронут, тир 1 через тему, ошибка add), `.tests/vd-smoke.tsx` (SSR главной/списка/формы, математика тиров, невидимые названия, агрегация статистики). typecheck, ESLint, theme check — чисто.

### Что дальше (для Roman)
1. Одобрить новые права при открытии приложения (Update).
2. Создать офферы (High Ticket, Low ticket, GPS Wallet) и $0-копии подарков (Anti-Scan Wallet, Luggage Scale, Secure Phone Strap, Fast Charger) — можно поручить ИИ.
3. Переключение: выключить оффер в Vitals → Activate наш → включить embed «Volume Discounts» → проверить страницу товара и корзину.


### Обновления v20–v22 (2026-10-08, после разговора с Roman)
- **Свои $0-товары Roman (WoodenCrew™ | RFID Anti-Scat Travel Wallet — Draft, | Luggage Scale — Draft, | GrabProof Phone Strap — Active) используются Simple Bundles. Статус НЕ менять, в подарки модуля НЕ брать** (требование Roman). Draft нельзя положить в корзину → для подарков нужны отдельные копии.
- Защита «$0-подарок нельзя купить отдельно» (удаление строки без `_wc_vd_gift`) работает **только для товаров с тегом `gift-links-gift`/`wc-vd-gift`** (`VdGift.guard`), чтобы никогда не трогать $0-части Simple Bundles. Тест: `.tests/vd/test_vd.py` (35 проверок).
- «Make $0 gift copy» создаёт **новый товар через productSet** (не productDuplicate: дубль наследовал все каналы — Google, Facebook, TikTok, Shop — и $0-подарок попадал бы в фиды; снимать с публикации ИИ не может — правило + блок инструмента). Копия: UNLISTED (в корзину кладётся, в коллекциях/поиске/рекомендациях не видна; проверено живым тестом 2026-10-08), те же опции/варианты/SKU, те же картинки (переиспользуются файлы), $0, compare-at = старая цена, без учёта остатков, теги `gift-links-gift, wc-vd-gift, hidden-gift`, `seo.hidden=1`, публикация только в Online Store. Shopify сам добавляет новые товары в AI-каналы **Microsoft Copilot** и **Meta AI and Muse** — снять их может только Roman (Products → товар → Sales channels).
- В форме у подарка есть **«Name in the block»** (как в Vitals: «Free Anti-Scan Wallet»), по умолчанию — название без «WoodenCrew™».
- Simple Bundles: скидка Vitals в корзине стоит на строке товара-бандла (проверено: AirSeat ×2 → 20% на строке `AirSeat Travel Cushion`, product 10027055841599), значит нативная скидка на этот товар работает так же. В офферы выбирать товары витрины («AirSeat Travel Cushion»), **не** компоненты «… | …».

### $0-копии подарков (созданы 2026-10-08 через админку модуля)
| Копия | Product ID | Value (compare-at) |
|---|---|---|
| RFID Anti-Scan Travel Wallet — Gift (5 цветов) | 15417569018175 | $19.95 |
| Luggage Scale — Gift | 15417570033983 | $29.95 |
| Grabproof Phone Secure Strap — Gift (3 цвета) | 15417570984255 | $22.95 |
| Wireless Fast Charger 15W — Gift | 15417572458815 | $19.95 |
| 3 in 1 Wireless Foldable Charger — Gift | 15417573671231 | $34.95 |
(Пробная копия кошелька через productDuplicate 15417556795711 удалена.)

### Офферы, перенесённые из Vitals (все **Inactive**)
| Оффер | ID | Товары | Тиры (шт: % + подарки) |
|---|---|---|---|
| High Ticket: 2 and 3 items 20-30% OFF | `vd_muzb4k0zuo8q` | 9: Kids Travel Pillow Set, Travel Pillow, Travel Pillow Ultimate Kit, 6Pcs Compress Packing Cubes, Compress Packing Cubes 7Pcs, AirSeat Travel Cushion, Expandable Anti-Theft Bag, Convertible Travel Bag, Mini Global Travel Charger 65W | 1: 0; 2: 20% «Top Pick» + Anti-Scan Wallet; 3: 30% + Luggage Scale; 4: 30% + Wallet + Secure Phone Strap; 5: 30% + Scale + Strap |
| GPS Wallet: 2 and 3 items 20-30% OFF | `vd_muzb9131j3sv` | AirSlate GPS Wallet Tracker | 1: 0; 2: 20% «Top Pick»; 3: 30% + Wireless Charger; 4: 30% + Wireless Charger; 5: 30% + 3in1 Wireless Charger |
| Low ticket: 2 and 3 items 20-30% OFF | (в списке /app/volume) | 13: Mini Air Pump, Portable Security Door Lock, 360° Migraine Headache Relief Cap, Luggage Scale, Compression Travel Socks, 3D Sleep Mask, RFID Anti-Scan Travel Wallet, Wireless Fast Charger 15W, 3 in 1 Wireless Foldable Charger, Foldable Travel Backpack, Anti-Grab Phone Secure Strap, Grabproof Phone Secure Strap, Stain Remover Stick for Clothes | 1: 0; 2: 20% «Top Pick»; 3/4/5: 30% + Anti-Scan Wallet |
Название скидки для покупателя: «Bundle discount» (в Vitals было «Discount»). Vitals-данные сняты из админки Vitals 2026-10-08 (офферы 942453, 1174109, 1227400).

### Переключение с Vitals (решает Roman)
1. Vitals → выключить оффер. 2. /app/volume → Activate наш (создаст автоскидки 20%/30%; применяются через ~1–2 мин). 3. Theme editor → App embeds → «Volume Discounts» On (по умолчанию стоит перед формой Add to cart, как у Vitals). 4. Проверить товар и корзину (подарок, скидка).

### v24 (2026-10-08 вечер) — блок 1:1 как Vitals
- Файлы: `wc-volume-discounts.js` (dropdown/variantImage, слушатель change), `wc-volume-discounts.css` (переписан по computed styles Vitals), `volume-discounts.liquid` (show_header/show_badge, новые цвета по умолчанию). Тест `.tests/vd/test_vd.py` — 0 ошибок. typecheck, ESLint, theme check — чисто.
- Деплой: GitHub `33d57aa` → Shopify `woodencrew-apps-23`. Архив собран из `git archive HEAD` + `build/` + `package-lock.json` (он в .gitignore, берётся из `source/`).
- В `.git` оставался пустой `HEAD.lock` от коммита v23 другого чата — удалён (git не работал).
- Превью в админке (форма оффера) ещё показывает старые квадратики — витрина не затронута.

### Исправление устаревшей ошибки PageSpeed (2026-10-08, Codex)
Google Cloud WoodenCrew Apps: уже разрешены IPv4 134.209.119.24 и IPv6 2604:a880:400:d1:0:5:11a:9001, ключ ограничен PageSpeed Insights API. Настройки ключа агент не менял. Повторные живые тесты подушки 23:49–23:50 Киев успешны: mobile 62, desktop 61; прежние 62/82 тоже успешны. Banнер показывал историческую ошибку, потому что loader выбирал последнюю ошибку за всю историю независимо от более новых успешных тестов.
Правка: latestPsiError в app/seo/seo.shared.ts выбирает последний запуск для каждой пары URL/strategy и показывает только ещё актуальную ошибку; app.seo.speed.tsx использует helper. История не удаляется, ошибки другого устройства не скрываются. .tests/psi-error.mjs: 5 проверок пройдены. TypeScript и production build пройдены в отдельной временной копии вне Google Drive. Витрина и настройки загрузки медиа не менялись. Релиз исправления пока не подтверждён; итог дописать после выкладки.
Результат проверки: targeted ESLint чисто; TypeScript и production build успешны; 5 regression checks пройдены. Архив gift-sales/release/gift-links-v25-psi-fix-deploy.tar.gz (508383 bytes) подготовлен, build включён, .env/node_modules/.git исключены. В публичный nikadevs/gift-links НЕ загружен: automatic approval review отклонил передачу полного архива исходного кода без явного подтверждения конкретного публичного получателя. Запрошено подтверждение Roman. Серверный релиз по-прежнему v24/33d57aa; патч в source не закоммичен. Документ внешнего Claude Project не обновлялся: соответствующего доступа в текущей среде нет; обе локальные KNOWLEDGE.md обновлены.

### Блок VD v25 (2026-10-09, по скриншоту Roman)
- Сумма в «Save:» белая: тема красила `b` в чёрный → `.wcvd .wcvd-save b{color:#fff}`.
- «Show more options»: тема давала `button:hover` с фоном → сброс фона/рамок/тени/text-transform, 15px, отступ `margin:-17px 0 20px`, при наведении только цвет `var(--color-link-hover,#555555)` (как ссылки темы Umino). Проверено инъекцией на живой странице подушки: правила темы перебиты (без !important у темы).
- Цена подарка уже = compare-at $0-копии (у Fast Charger 15W: оригинал $12.95 / compare-at $19.95, копия $0 / $19.95 → в блоке $19.95 зачёркнуто). Код не менялся, Roman переспрошен.

### Главная v26–v27 — копия карточки Vitals «What you've set up» (2026-10-09)
- `app/routes/app._index.tsx`. Размеры/цвета сняты пикселями со скриншота живой админки Vitals (DPR 2, CSS px): карточка 964px, радиус 12, фон страницы #f1f1f1; шапка — заголовок 15.2px/600, «Showing N active · M drafts» 11.4px; select 125×32 (Drafts first / Top earning / Recently edited — те же пункты, что у Vitals) + поиск 200×32; строки 65px, плитка иконки 42px (#f9f1e9, иконка #E8660E 28px), заголовок 12.6px/600, подстрока 11px; бейдж Active #affebf/#0c5132, Draft #e8e8e8/#616161; колонка «+$56K / earned, last 30 days» 150px; 3 кнопки 26px (edit, pin, X), видны при наведении на список; закреплённые — синяя полоса 3px слева и всегда сверху; список max-height 520px со скроллом; футер «N items» + «Setup guide →». Vitals, видимо, рендерит всё в масштабе ~0.95 — поэтому дробные px.
- Строки: 4 модуля (App · N offers) + все офферы VD, чекбоксы Checkbox Upsell, кампании Gift Links. Draft = выключенный оффер. Earned 30 дней — те же кэшированные данные, что на страницах модулей (`summarizeOffers`, `summarize`; Gift Links и SEO без выручки).
- Pin → metafield `wc_home.pins` (json) на AppInstallation. X у оффера: включён → выключить (тот же `toggle` маршрута модуля; у VD это удаляет его автоскидки), выключен → удалить; оба по второму клику («Deactivate?»/«Delete?»). X у модуля → редактор темы, App embeds (выключает Roman сам).
- Тест `.tests/home-smoke.tsx` (SSR: тексты, формат +$56K/+$1.6K/+$812, порядок pinned → drafts). Живой клик-тест поиска/пина не выполнен (классификатор браузера был недоступен).
- KNOWLEDGE.md в source не закоммичен: в нём же лежат незакоммиченные записи другого агента (PageSpeed, Codex).

## v28 SEO & Speed — Git publication, 2026-10-09 (Kyiv)

Roman explicitly approved publishing both fixes. Release archive pushed through native Git to public nikadevs/gift-links main: 31f36c805923a7b950f638cb2b57ccdf17f6bb61. Source commit: 44ca50c. Archive: release/gift-links-v28-seo-fix-deploy.tar.gz, SHA256 0E6A171E0AD389321D9CCB5B378039FF12366C5A87954A7D6F3F44A7DAFB9544. Base release bff97ac (v27) was checked immediately before push and preserved.

Changes: clear superseded PageSpeed errors per URL/device; treat HTTP 429 as an incomplete audit, reduce probe concurrency and stop remaining probes on rate limiting; identify missing links only from 404/410. Regression checks, TypeScript, targeted lint and production build passed. No storefront scripts, customer UX, media loading or offer configuration changed. Browser upload of obsolete v24 was not committed.

Native release checkout: C:\Users\4elov\AppData\Local\Temp\woodencrew-gift-links-release-git. Live deployment verification is in progress. Direct deploy-status.json browser navigation was blocked by client; verify through Shopify application instead. External Claude Project handoff document is not available through this session's tools.

v28 verification: Shopify admin /app/seo/speed reloaded after push; the historical API IP-restriction banner disappeared while existing home/product mobile and desktop results remained available. This confirms the updated backend is serving the Speed page. Evidence: woodencrew-seo/reports/pagespeed-v28-live-2026-10-09.png. Shopify extension release version and direct deployment status were not separately verified (status endpoint blocked by client); extension code was unchanged. No fresh full crawl was started, so historical crawl findings remain until the next audit.


## v29 Bundle Contents and Short Title — 2026-10-10 (Kyiv)

# Bundle Contents — prepared release v29

New module `/app/bundles` in WoodenCrew Apps. Movable theme app block `Bundle Contents`, target `section`; no new app embed. Displays selected product's Simple Bundles components or manually selected components. Existing bundle fulfillment/cart behavior is unchanged.

Automatic import reads every parent variant's `simple_bundles.bundled_variants`. Admin reads current component images, variant compare-at prices and `custom.short_title`, including Draft component products. Display snapshots are stored per product in merchant-owned `custom.wc_bundle_contents` JSON, with compareDigest to reject concurrent edits. Shared layouts are deduplicated. Refresh with Save & sync after changing bundle definitions, component images/prices/titles. Manual selection uses one selected variant per chosen product and is display-only.

Block: descending compare-at prices; three columns for six items, first item spans the left column for five items, equal two-column rows for two/four items. Free-component values only; total sums free compare-at values × component quantity. If a free component lacks compare-at, its value and the incomplete total are omitted. Base currency is retained and labelled when visitor currency differs. Images use Shopify CDN widths, lazy loading, fixed dimensions; Oswald from Shopify font picker, swap display. Font sizes scale to card width; titles never wrap. CSS ~2 KB, JS ~1.8 KB (about 0.8/0.7 KB gzip), loaded only for enabled configured product blocks.

Shopify definitions created: `custom.short_title` (Short Title, single line, pinned, max 80), `custom.wc_bundle_contents` (JSON). All 59 catalog products have reviewed Short Titles; all fit the mobile card at 320, 360 and 390 CSS px without truncation. CSV: `product-short-titles-2026-10-10.csv`; before values saved separately.

Roman approved compare-at values from mockup: Carry Bag 9760527843647, variant 49903227306303 = 5.95; Warranty 10128643916095, variant 51485630234943 = 12.95; GrabProof component 10490419249471, variants 55240477638975/55240477671743/55240477704511 = 12.95. Actual selling prices remain 0.00. Original compare-at values preserved in `bundle-compare-at-before.json`.

Prepared product configs (disabled): Travel Pillow Ultimate Kit 9550923497791 (free components only; 6 items), Expandable Anti-Theft Bag 10127244296511 (includes paid main component; 5 items). Total free values 68.70 / 70.80, based on real Shopify compare-at values; screenshot example prices were not substituted for existing prices. Adding/publishing the block in live theme needs Roman approval per project working rules.

Speed improvement: Checkbox Upsell's 16,547-byte script (5,375 gzip) is not loaded on pages without matching checkbox markup unless localStorage contains an unexpired pending add. Pending cart additions still load once and complete; no cart logic modified.

Validation: GraphQL schema + validation; Shopify toolkit Liquid validation for both blocks; TypeScript; targeted ESLint; production build; `.tests/bundle.test.mjs`; `.tests/bundle-browser.mjs` (real-data 5/6 layouts, variant changes, mobile widths, 59 short title widths); `.tests/upsell-loader.mjs` (absent/expired/corrupt pending = no script, valid pending = one load and one upsell add, main line preserved). Browser tests use a local mock store, not a live customer cart. Preview screenshots are under `reports/`.

External Claude Project document is not connected to this session. Both local KNOWLEDGE.md copies will be updated. Deployment verification pending.

## 20. Модуль Quick Links (2026-10-15, Claude) — замена Vitals «Quick Access Links»

- **Что делает:** тёмная полоса 40px вверху витрины только для того, кто залогинен в админку Shopify: Quick Admin Links · Shopify Admin · WoodenCrew Apps · Apps · Edit theme · **Edit product / collection / page / blog / blog post** (жёлтая, на соответствующих страницах). Справа «Customers will not see this bar.» и ×. Вид снят с живой полосы Vitals 2026-10-14 (#191919, 13px/22px, padding 9px 20px, жёлтый #fbff0b, fixed top, z-index 2147483646, перекрывает верх страницы — как у Vitals).
- **Лучше, чем у Vitals:** «Edit theme» открывает редактор сразу на текущей странице (`/admin/themes/<id>/editor?previewPath=<путь>`); вместо ссылки «Vitals» — «WoodenCrew Apps» (`/admin/apps/gift-links`).
- **Как узнаём, что это админ:** Shopify печатает `<script id="OnlineStorePreviewBarNextData" type="application/json">` (theme.id, pageSpecificData.resource) **только залогиненным в админку** (проверено 2026-10-14: в Chrome Roman он есть; с `?preview_theme_id=` — нет, и полоса Vitals тоже исчезает; Vitals использует этот же признак). Покупатели его не получают → полосы не видят. Не показывается в редакторе темы (`request.design_mode`) и внутри iframe. **Важно для Content Protection:** этот же признак можно использовать для «Disable when logged in Shopify Admin» (раздел 19 писал, что это невозможно, — возможно).
- **Ссылки:** Edit-ссылка строится в Liquid (`request.page_type` + `product.id`/`collection.id`/`page.id`/`article.id`/`blog.id`), запасной вариант — `pageSpecificData.resource` из JSON Shopify. ID темы — из JSON, иначе `Shopify.theme.id`. Ссылки относительные `/admin/...` (как у Vitals — домен магазина сам переводит в админку).
- **× скрывает** полосу в этом браузере (localStorage `wcQl.min`), тёмный уголок справа вверху возвращает. Телефон (≤600px): только «Quick Admin Links» + ☰, по ☰ — список.
- **Без отдельного app embed (правило Roman):** включается кнопкой Turn on / Turn off в `/app/quick-links`; код печатает embed **Gift Links** (`blocks/gift-links.liquid`, блок перед `{% schema %}`) только при `app.metafields.wc_ql.config.enabled`. Маркер `<div id="wc-ql-on" hidden>` (`QL_EMBED_MARKERS`) — страница модуля проверяет витрину. ~2 KB inline, без файлов и запросов; у покупателя скрипт только проверяет наличие элемента и выходит.
- **Файлы:** `app/ql.server.ts`, `app/routes/app.quick-links.tsx`, `QL_EMBED_MARKERS` в `app/embed-status.server.ts`, карточка `m:quick-links` (иконка `links`) в `app._index.tsx`, пункт меню «Quick Links» в `app.tsx`.
- **Тесты:** `.tests/ql/` (LiquidJS `render.mjs` + Playwright `t.py`, 14 проверок: полоса есть у админа и нет у покупателя, выкл. = ничего не печатается, редактор темы = ничего, ссылки product/collection, запасной вариант из JSON, ×/восстановление/после перезагрузки, телефон ☰). Theme check 0, typecheck, ESLint, build — чисто. Грабли: в inline `<script>` внутри Liquid нельзя писать `i<L.length` — парсер Theme Check принимает `<L` за тег (LiquidHTMLSyntaxError); писать `L.length>i`.
- **Переключение с Vitals:** `/app/quick-links` → Turn on; Vitals → Quick Access Links → Deactivate (иначе будут две полосы друг на друге).

### 2026-10-15 — Content Protection: выключена для залогиненных в админку (Claude, по просьбе Roman)
- Скрипт защиты первым делом проверяет `#OnlineStorePreviewBarNextData` (Shopify печатает его только залогиненным в админку — тот же признак, что у Quick Links, раздел 20). Если он есть — класс `html.wc-cp-off` и выход: правый клик, выделение, копирование, перетаскивание работают. Покупатели защиту получают как раньше. Обход `?wc_cp=off` оставлен для браузеров без входа в админку. Раздел «Off for you» на странице `/app/content-protection` переписан.
- Тест (LiquidJS + Playwright): с элементом — правый клик не блокируется, `user-select:auto`; без — блокируется, `user-select:none`. Theme check, typecheck, ESLint, build — чисто.

## 25. Модуль Tracking (2026-10-17, Claude) — замена Track123

- **Админка** `/app/tracking` (пункт меню «Tracking», карточка `m:tracking`). Вкладки: Shipments (поиск по заказу/YT/номеру последней мили, фильтр по статусу, кнопки Update и Page), Statistics (30/90 дней: доставлено, среднее время, проблемы, «нет сканов 7+ дней», по странам и по перевозчикам последней мили), Settings, Activity log.
- **Как сейчас работает Track123 (проверено 2026-10-17 по заказам):** склад делает 2–3 fulfillment на заказ с одним YT; Track123 меняет ссылку и пишет статусы только в ОДИН fulfillment, номер в Shopify остаётся YT, номер последней мили (Royal Mail QP…GB, GOFO GF…) показывается только на его странице `/apps/track123`.
- **Источник данных — бесплатный официальный YunExpress Open API** (open.yunexpress.cn, проверено по документации 2026-10-17):
  - токен `POST {https://openapi.yunexpress.cn | openapi-sbx}/openapi/oauth2/token` `{grantType:"client_credentials", appId, appSecret, sourceKey}` → `accessToken` (2 ч);
  - заголовки `token`, `date` (мс), `sign` = Base64(HmacSHA256(appSecret, "body=…&date=…&method=…&uri=…"));
  - `GET /v1/track-service/getAllForOPenApi?order_number=<YT или номер последней мили>` → `track_Info.tracking_number` (последняя миля), `last_mile_name`, `last_mile_site`, `interval_day`, `track_events[]` с `track_node_code`.
  - **Ключи (App ID, App secret, Source key) — из аккаунта YunExpress, с которого отправляет склад.** Пока их нет — модуль только импортирует номера.
  - Не проверено на живых ключах: входит ли query string в `uri` подписи — клиент пробует с ней и один раз без неё (`trk-yun.server.ts`).
  - Публичный yuntrack.com (`services.yuntrack.com/Track/Query`) подписан и с капчей — его НЕ используем (обход защиты).
- **Статусы** (`trk.shared.ts`): pending, info_received, in_transit, last_mile («Arrived in country» = передана местному перевозчику), out_for_delivery, attempt_fail, delivered, exception, returned, expired. Маппинг по кодам Trajectory Node Table + по тексту (у YunExpress нет кода «out for delivery»). Грабля: «Delivered to local carrier» — это передача, не доставка (покрыто тестом).
- **Движок** (`trk.server.ts`, запуск в `entry.server.tsx`, тик каждые 20 мин, `WC_TRK_SCHEDULER=off` выключает):
  1. импорт заказов `(fulfillment_status:shipped OR partial) updated_at>=…` → одна запись на номер, все fulfillmentIds;
  2. опрос YunExpress каждые `pollHours` (по умолчанию 6; out for delivery / attempt — каждые 3 ч), ≤300 номеров за тик, пауза 0,4 с; не-YunExpress номер после 4 пустых ответов больше не опрашивается;
  3. выходы — **всё выключено по умолчанию**: Shopify `fulfillmentEventCreate` на КАЖДЫЙ fulfillment с номером; `fulfillmentTrackingInfoUpdate` (тот же номер/перевозчик, ссылка на нашу страницу, `notifyCustomer:false`); Omnisend custom events; PayPal `trackers-batch` (transaction_id = Shopify CAPTURE.authorizationCode, carrier `YUNEXPRESS`/`GOFO_EXPRESS`/`UBI_LOGISTICS`/иначе `OTHER`+`carrier_name_other`).
  - Пока Track123 установлен — Shopify-выходы не включать (будут писать оба).
- **Omnisend:** `POST https://api.omnisend.com/api/events`, `Authorization: Omnisend-API-Key …`, `Omnisend-Version: 2026-03-15`; события `tracking in transit / arrived in country / out for delivery / delivery attempt / delivered / exception / returned`, одно событие на посылку и статус, только для сканов не старше 3 дней. Свойства: orderNumber, trackingNumber, carrier, lastMileNumber, lastMileCarrier, status, lastEvent, lastEventPlace, lastEventTime, trackingUrl, firstName, country. Письма Roman строит в Omnisend → Automation → триггер custom event (workflow на custom events шлют и отписавшимся — транзакционные).
- **Страница трекинга:** `/pages/track-order` (handle в настройках). Кнопка Turn on создаёт страницу (pageCreate, body `<div id="wc-trk"></div>`) и пишет metafield `wc_trk.config` `{enabled, endpoint, pageHandle}`; код печатает embed **Gift Links** (без отдельного embed), маркер `#wc-trk-on`. `assets/wc-tracking.js/.css` грузятся только на этой странице. Поиск: номер заказа + email или трек-номер (YT или номер последней мили), `?nums=` в ссылке. Данные — `POST /api/trk/lookup` (text/plain JSON, email не в URL; 40 запросов/мин/IP; ответ без адреса/имени/email). Галочка «Hide China first-mile scans».
- **Данные:** `$WC_DATA_DIR/trk/<shop>/{settings.json (ключи, в браузер не отдаются), shipments.json, log.json, state.json}`.
- **Новые scopes:** `read/write_merchant_managed_fulfillment_orders, read/write_third_party_fulfillment_orders, read/write_fulfillments` (fulfillmentEventCreate требует write_fulfillments) — Roman одобряет при открытии приложения.
- **Тесты** (`.tests/trk/`, не в релизе): `unit.ts` (парсер ответа из документации, реальные тексты Royal Mail, подпись), `engine.ts` (мок Admin API/YunExpress/Omnisend/PayPal: 2 fulfillment → 2 события, ссылки, Omnisend, PayPal CAP, повтор без дублей, lookup по номеру последней мили / заказу+email, неверный email), `page_test.py` (Playwright 390/1280 px). Запуск engine: `node --import <tsx>/dist/esm/index.mjs --import ./.tests/trk/register.mjs .tests/trk/engine.ts` (заглушка prisma).
- **Что дальше:** ключи YunExpress → Test number в Settings на реальном YT → Turn on → проверить 20–30 посылок против Track123 → Omnisend-ключ + workflows → PayPal-ключи → включить Shopify-выходы и удалить Track123 → редирект старых ссылок `/apps/track123?nums=` на `/pages/track-order` (Shopify URL redirect работает только когда путь отдаёт 404, т.е. после удаления Track123; сохраняется ли query — проверить) → поменять пункт меню «Track Order».
- Бэклог: блок «You may also like» на странице (у Track123 есть), ETA, отправка трек-номера на YunExpress-подписку (webhook) вместо опроса.

### 2026-10-27 — Tracking v2: разделы как у Track123, блок страницы трекинга, PayPal без YunExpress, тесты Omnisend (Claude)
- **Изучен Track123 в админке (2026-10-27):** разделы Dashboard, Tracking page (страницы + просмотры + переводы), Orders (вкладки по статусам, фильтры carrier/last-mile/destination, Export, Sync orders), Notification (To customers: In transit/Out for delivery/Delivered/Exception/Failed attempt **включены — Track123 сам шлёт письма** с support@woodencrew.store; To yourself — выкл.), Analytics (Shipments, Order-to-delivery time, Transit time, Tracking page, Exceptions, Notification, Shipment reviews), Settings (General: tracking link On, fulfillment events On, **Dropshipping mode On**; Integration: **PayPal Connected (D7U2K3V4L4M4W)** — Track123 уже грузит треки в PayPal; Omnisend/Klaviyo не подключены).
- **Админка модуля теперь как у Track123** (без Add-Ons и Billing), вкладки сверху (`app/trk-ui.tsx` `TrkNav`): `/app/tracking` Dashboard (настройка-чеклист, KPI 30 дней, «требуют внимания»: Failed attempt >3 д, Out for delivery >3 д, нет сканов >14 д, статусы, топ перевозчиков), `/app/tracking/page`, `/app/tracking/orders` (вкладки со счётчиками, поиск, период, carrier/last-mile/destination, Export CSV через `/app/tracking-export`, Sync orders, Update), `/app/tracking/notifications` (To customers / To yourself, тестовые события), `/app/tracking/analytics` (Shipments, Order-to-delivery time: processing/transit/order-to-delivery + распределения 0–3/4–7/8–11/12–15/16–30/30+ д, по странам и last-mile; Tracking page lookups; Exceptions; Notification), `/app/tracking/settings` (General / Integration / Activity log). `app.tracking.tsx` — layout с `<Outlet/>`; все действия — `app/trk-actions.server.ts`; данные Orders — `app/trk-orders.server.ts`.
- **Страница трекинга = app block «Order tracking»** (`blocks/tracking-page.liquid`, target section): Roman создаёт в редакторе темы шаблон страницы `page.track-order` и добавляет блок + любые секции темы (Products carousel = «You may also like» и т.д.). Тексты, названия статусов, цвет, ширина, отступы — настройки блока. Кнопка «Use template» ставит шаблон странице (`pageUpdate templateSuffix`), Turn on делает это сам, если шаблон уже есть (`pageTemplateState` читает `templates/page.track-order.json` опубликованной темы). Без шаблона работает старый путь: embed Gift Links монтирует трекер на `/pages/<handle>`. JS (`wc-tracking.js`) монтируется в блок, если он есть; двойное подключение (блок + embed) защищено `window.__wcTrkInit`.
- **Dropshipping mode** (как у Track123): скрыть китайские символы (`stripChinese`; сканы, ставшие пустыми, убираются), скрыть сканы по Китаю, показывать только перевозчика/номер последней мили (`lastMileOnly`). По умолчанию первое и третье включены.
- **PayPal работает без ключей YunExpress:** тик идёт, если включён автотрекинг **или** PayPal; PayPal-цикл ≤200 за тик. Кнопка «Test PayPal keys» — только токен + поиск последнего PayPal-платежа, ничего не отправляет. Включать после удаления Track123.
- **Omnisend:** все события с одним набором полей (`TRK_OMNISEND_FIELDS`, только строки — так требует Omnisend, имена полей фиксируются после первого события) + поле `isTest` (yes/no). Кнопки тестовых событий (по одному на каждый включённый статус; «To yourself» — событие `tracking store alert`). В workflow — фильтр триггера `isTest is not yes`. «To yourself»: то же событие на email владельца, статусы выбираются. Письма старше 3 дней не шлются.
- **Аналитика страницы:** `/api/trk/lookup` считает поиски по дням (`lookups.json`, сброс на диск раз в 30 с).
- Тесты `.tests/trk/`: `unit.ts`, `engine.ts`, `engine2.ts` (поля/строки Omnisend, to yourself, без дублей, старые новости, тестовые события, PayPal-тест без записи, аналитика, lookup: китайские символы, lastMileOnly, счётчик), `page_test.py` (Playwright: страница, блок с кастомными текстами, двойной скрипт, last-mile only), `ui-smoke.tsx` (SSR всех 6 страниц и вкладок; заглушки App Bridge и prisma: `register-ui.mjs`). typecheck, ESLint, theme check — чисто.
