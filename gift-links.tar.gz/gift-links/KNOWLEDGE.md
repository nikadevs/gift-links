# WoodenCrew Apps (бывш. Gift Links): полная база знаний (для человека и для другого ИИ)

Обновлено **2026-10-08 01:20 (Киев)**. **Новый чат: сначала прочитай раздел 0.**
Разделы 1–10 — модуль Gift Links (исторически, v9), 11 — Checkbox Upsell, 12 — автодеплой, 13 — SEO & Speed, 14 — как добавить новый модуль/приложение.
Живые данные Shopify из раздела 4 проверены запросом к Admin API 2026-10-07.

---

## 0. START HERE — для нового чата этого проекта

**Что это.** Одно собственное (custom) Shopify-приложение **WoodenCrew Apps** (раньше называлось Gift Links / «Gift Sale») для магазина **woodencrew.store** (Shopify, **не Plus**). Внутри модули, как у Vitals. **Решение Roman: новые функции добавляем модулями в это приложение, а не отдельными приложениями** (раздел 14).

| Модуль | Админка | Статус |
|---|---|---|
| Gift Links | `/app/gifts` | на проде |
| Checkbox Upsell (замена AXE Checkbox Upsell) | `/app/upsells` | на проде, AXE заменён |
| SEO & Speed (замена Tapita) | `/app/seo` | **на проде с v18** (2026-10-08 01:21 Киев, `woodencrew-apps-18`, GitHub `d4b4c36`); ждёт одобрения новых scopes Roman; app embed «SEO & Speed» выключен (раздел 13) |

**Текущее состояние (проверено 2026-10-08 ~01:15):**
- Прод = **v18**: GitHub `nikadevs/gift-links` main `d4b4c36`, версия в Shopify `woodencrew-apps-18` («auto-deploy d4b4c36»), deploy-status `ok` 2026-10-07T22:21:40Z; auto-deploy перенёс новые scopes в серверный toml. Проверено на витрине (страница подушки): ассеты `woodencrew-apps-18`, Gift Links и Checkbox Upsell работают (2 чекбокса), embed SEO & Speed выключен. Предыдущий прод v17 — `43e68af`.
- **v18 (SEO & Speed) запушен в GitHub** 2026-10-08 ~01:25 Киев: main `d4b4c36` (git `796ca93` + правки KNOWLEDGE), архив `release/gift-links-v18-deploy.tar.gz`. Код v17 (Gift Links, Checkbox Upsell v2) не менялся — проверено md5 всех файлов. После деплоя Roman одобряет новые scopes при открытии приложения; до этого старые модули работают как раньше, а правки SEO (meta/ALT/редиректы/скан темы) показывают сообщение о правах.
- Живая тема: app embed **Gift Links — On**, **Checkbox Upsell — On**; на странице подушки скрипта и чекбоксов **AXE больше нет**, скрипта Tapita тоже нет (проверено в браузере). Удалено ли само приложение AXE из магазина — не проверялось.
- Админка: `https://admin.shopify.com/store/woodencrew/apps/gift-links/app` (handle остался `gift-links`). Dev Dashboard: org `100333504`, app `432363503617` → Versions.

**Правила Roman** — раздел 8 (каждый ответ начинать с «Roman,», русский, не врать, проверять факты живыми данными, не ломать $0-строки бандлов и PDF Travel Book, никогда не отменять заказы, после тестов вернуть корзину). **После любого изменения обновлять этот файл и документ проекта** (см. ниже) — это прямое требование Roman.

**Где код.** Папка на компьютере Roman: `C:\Users\4elov\Google Drive Mirror\Claude\WC - Shopify Development\gift-sales\`. Работать через `device_bash` (в нём папка смонтирована как `$HOME/mnt/WC - Shopify Development/...`). Git-репозиторий — `gift-sales/source/` (история с 2026-10-06). Копия этого файла лежит и в `gift-sales/KNOWLEDGE.md`, и в документе проекта Claude `claude/gift-links-handoff.md`.

**Работа параллельно с другими чатами.** Над `source/` могут одновременно работать несколько чатов. Перед началом: `git log --oneline -5` в `source/` и прочитать свежий `KNOWLEDGE.md`. Править файлы точечно (python read-modify-write с проверкой якорей), не перезаписывать целиком чужие файлы, коммитить только свои файлы. Не пушить в GitHub чужие незаконченные версии без согласия.

**Как выкатить изменение (проверенный процесс, 2026-10-07):**
1. Правки в `source/`. Сборка — в рабочей копии **вне Google Drive**: `mkdir -p $HOME/work/app && cd source && tar --exclude=.git -cf - . | tar -xf - -C $HOME/work/app && cd $HOME/work/app && npm ci` (~30 с; `$HOME/work` живёт только в текущей сессии).
2. Проверки: `npm run typecheck`, `npx eslint app --ext .ts,.tsx`, `npx shopify theme check --path extensions/gift-links-embed`, `npm run build`. Браузерные тесты витрины — `tests/test_upsell.py`, `tests/test.py` (Playwright есть в облачном контейнере Claude, не на компьютере).
3. Коммит в `source/` (автор `Roman Pshenichny <4elove4ekfs@gmail.com>` + строки Co-Authored-By/Claude-Session). **Git в папке Google Drive требует разрешения на удаление** (`device_request_delete_permission` на `WC - Shopify Development`), иначе остаются `.git/*.lock`.
4. Архив: из `$HOME/work/app` упаковать `gift-links/` (без `node_modules`, `.git`, `.react-router`) в `gift-links.tar.gz`, копию — `release/gift-links-vN-deploy.tar.gz`. Подождать ~25 с: Google Drive временно делает hardlink, и `device_stage_files` отказывает (`nlink > 1`).
5. `device_stage_files` → облачный контейнер; `add_repo nikadevs/gift-links access=push`; `git clone --depth 1` в `/home/claude/gift-links`; заменить `gift-links.tar.gz`; commit; `git push origin main`. (GitHub-коннектор и Claude GitHub App на nikadevs установлены Roman 2026-10-07; Roman разрешил ИИ пушить сам.)
6. Сервер сам ставит версию за ≤2–4 мин (раздел 12). Проверка: Dev Dashboard → Versions — верхняя версия с текстом `auto-deploy <sha>`; потом открыть админку/витрину. `deploy-status.json` через WebFetch кэшируется 15 мин — сразу после деплоя ему не верить.
7. Обновить `KNOWLEDGE.md` (в `source/` и копию в `gift-sales/`) и документ проекта: `Projects project_write path=claude/gift-links-handoff.md local_path=<staged copy>`.

**Известные ограничения среды:** shell на компьютере не достаёт до дроплета и `giftlinks.nikadevs.com` (прокси 403) — консоль сервера только у Roman; автоматический фильтр безопасности сессии иногда блокирует действия (например открыть страницу загрузки GitHub) — не обходить, сообщить Roman; Shopify Admin API доступен через MCP-инструменты Shopify (только чтение по умолчанию; мутации заказов — только с согласия Roman).

---

## 1. Что это и зачем

**Gift Links** — собственное (custom) Shopify-приложение магазина **WoodenCrew** (woodencrew.store; travel gear; владелец Roman Pshenichny). Тариф **Shopify, не Plus**.

Задача: покупатель из email-рассылки получает **бесплатный подарок в корзине автоматически** и вдобавок промокод. Работает двумя способами:
1. **по ссылке** `https://woodencrew.store/<любой путь>?gift=<linkKey>`; если в ссылке уже есть `?`, то `&gift=<linkKey>`;
2. **по коду**: покупатель ввёл код кампании в поле скидки корзины или cart drawer темы.

Подарок — **отдельный товар-копия с ценой $0** (тег `gift-links-gift`). Скрипт кладёт его в корзину, когда корзина подходит под условия, и убирает, когда перестаёт подходить. Промокод (например 10%) скрипт применяет через Cart AJAX API.

Почему так, а не через стандартную скидку Buy X Get Y, объяснено в разделе 6.

---

## 2. Где что лежит

| Что | Где |
|---|---|
| Эта папка (полный архив знаний) | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Shopify Development\gift-sales\` |
| Исходник с git-историей | `source/` в этой папке; то же самое в архиве `archives/gift-links-src-v9.tar.gz` |
| **Рабочий прод** | DigitalOcean droplet **134.209.119.24**, папка **`/opt/gift-links`**, pm2-процесс `gift-links`, порт **3107**, nginx + Let's Encrypt, домен **https://giftlinks.nikadevs.com** |
| Секреты | только на сервере: `/opt/gift-links/.env` (SHOPIFY_API_KEY, SHOPIFY_API_SECRET, SCOPES, PORT=3107, NODE_ENV=production, SHOPIFY_APP_URL). В эту папку **не копируются** |
| Залинкованный `shopify.app.toml` | только на сервере. В нём `client_id` (начинается с `c8e4e2fb921220ff09ab97f0a97598…`), `application_url = https://giftlinks.nikadevs.com`, redirect_urls. В `source/shopify.app.toml` `client_id` пустой, и это нормально |
| GitHub | `nikadevs/gift-links` (публичный). Там **только** собранный архив `gift-links.tar.gz` (на 2026-10-08 — v17, коммит `43e68af`) и `install.sh`, исходников нет. Сервер забирает обновления отсюда сам (раздел 12) |
| Приложение в Shopify | Dev Dashboard → «WoodenCrew Apps» (бывш. «Gift Links»; custom distribution, установлено в woodencrew; app id `432363503617`). Версии: `gift-links-1…9`, затем `woodencrew-apps-10…17` |
| Claude Project | «WC - Shopify Aps Development», документ `claude/gift-links-handoff.md` (полная копия этого файла) |
| Релизные архивы | `gift-sales/release/gift-links-vN-deploy.tar.gz` (v9…v18) |
| Письма Gift Week | `C:\Users\4elov\Google Drive Mirror\Claude\WC - Email Marketing\` (`GiftWeek-Email-1-Gift-Reveal.html`, `GiftWeek-Email-2-Last-Call.html`, `GiftWeek-Emails-Combined.html`). Копии лежат в `campaign-emails/` |

---

## 3. Архитектура и код

Стек: официальный шаблон **Shopify app на React Router** (`@shopify/shopify-app-react-router`, React Router 7.18), **Polaris web components** (`<s-page>`, `<s-section>`, `<s-text-field>`…), **App Bridge** (resourcePicker, toast), **Prisma + SQLite** (только для хранения сессий OAuth), Node ≥ 22.12. Scopes: **`read_products,read_discounts`** (больше не нужно; при config link они однажды слетели, см. раздел 7).

### 3.1 Хранение кампаний
Базы данных для кампаний нет. Весь конфиг лежит в одном **app-owned JSON metafield на AppInstallation**: namespace `gift_links`, key `config`, тип `json`.
```json
{ "version": 1, "campaigns": [ Campaign, ... ] }
```
Тема читает его в Liquid как `app.metafields.gift_links.config.value`. Витрина **не обращается к серверу приложения**: если сервер упадёт, витрина продолжит работать с последним сохранённым конфигом, перестанет работать только админка.

Тип `Campaign` (`app/campaigns.shared.ts`):
`id, name, active, linkKey, giftVariantId (числовой ID варианта строкой), giftTitle, giftImage, discountCode (один или несколько через запятую, UPPERCASE), triggerOnCode, minSubtotal (в валюте магазина, USD), addWhenCartEmpty, removeWhenIneligible, bannerText (≤140), landingPath, startsAt, endsAt (YYYY-MM-DD, end включительно), updatedAt`.

### 3.2 Файлы
| Файл | Назначение |
|---|---|
| `app/campaigns.shared.ts` | тип Campaign, `campaignLink(domain,c)` → `${domain}${landingPath}?gift=key`, `campaignStatus` |
| `app/campaigns.server.ts` | `loadConfig`/`saveConfig` (metafieldsSet на currentAppInstallation), `loadDiscountCodes` (`discountNodes(first:100, query:"method:code")`), `loadShopDomain`, `campaignFromForm` (валидация; коды → UPPERCASE, split по `[\s,]+`, join `,`) |
| `app/routes/app._index.tsx` | **с v10 — главная WoodenCrew Apps** (карточки модулей). Список кампаний переехал в `app/routes/app.gifts.tsx` (s-table: Copy link, Pause/Activate, Delete с подтверждением вторым кликом — window.confirm в iframe админки не используем) |
| `app/routes/app.campaigns.$id.tsx` | форма кампании. `CampaignRoute` ремаунтит `CampaignForm` через `key=id:updatedAt`. resourcePicker выбирает товар. s-select со скидками магазина + поле «…or type code(s)» |
| `app/routes/app.setup.tsx` | страница Setup guide |
| `app/routes/app.tsx` | навигация `s-app-nav`: Home (`rel="home"`, скрыт — название приложения и так ведёт на главную), Gift Links, Checkbox Upsell (+ SEO в v18). В сайдбаре Shopify помещается мало пунктов: лишние уходят под «Settings» |
| `extensions/gift-links-embed/shopify.extension.toml` | theme extension, name "Gift Links" |
| `extensions/gift-links-embed/blocks/gift-links.liquid` | **app embed** (target body). (1) Если открыта страница товара с тегом `gift-links-gift`, делает редирект на главную (только такие товары, **другие $0 товары не трогает**). (2) Выводит конфиг в `<script id="gift-links-config" type="application/json">` и подключает `gift-links.js` с data-атрибутами. Настройки: banner_bg `#155F56`, banner_color `#FFFFFF`, hide_gift_pages (по умолчанию true; проверка `!= false`, потому что у старых установок значение nil), debug |
| `extensions/gift-links-embed/assets/gift-links.js` | логика витрины, ~500 строк, IIFE, без зависимостей (подробно в 3.3) |
| `deploy/install.sh` | установщик/обновлятор для дроплета (подробно в разделе 5) |
| `deploy/ecosystem.config.cjs`, `deploy/nginx-gift-links.conf`, `deploy/env.example` | конфиги прод-окружения |
| `README.md` | исходная инструкция на русском. **Внимание:** раздел «Как запустить акцию» там описывает BXGY-подход, который в итоге **не используется** (см. раздел 6). Правильный рецепт описан в разделе 4 этого файла |
| `tests/test.py` (в этой папке) | Playwright-харнесс с мок-корзиной, 6 сценариев |

### 3.3 Как работает `gift-links.js`
- Константы: `TTL_MS` = 7 дней (столько браузер «помнит» кампанию после клика), `LINE_PROP = "_gift_link"` (скрытое свойство строки, помечает **наш** подарок).
- `isLive(c)`: active, задан giftVariantId, сегодняшняя дата в пределах startsAt..endsAt.
- **Триггер по ссылке:** параметр `?gift=key` работает на любой странице. Скрипт запоминает кампанию в localStorage и убирает параметр из URL через history.replaceState (UTM-метки остаются).
- **Триггер по коду:** если `triggerOnCode` и код кампании есть в `cart.discount_codes`, кампания активируется.
- **sync()**, главный цикл:
  1. **Rogue-удаление:** строки, у которых variant_id равен варианту подарка любой кампании, `original_price === 0` и **нет** `_gift_link`, удаляются (так подарок нельзя положить вручную). Другие $0 товары (компоненты бандлов, PDF Travel Book) не затрагиваются, потому что их вариантов нет в кампаниях.
  2. Если живой кампании нет, удаляет только свои строки (с `_gift_link`).
  3. Eligibility: сумма **оплачиваемых** строк (`final_line_price > 0`, не подарок) / 100 / `Shopify.currency.rate` ≥ `minSubtotal`. Пересчёт по курсу нужен для мультивалюты. Если `addWhenCartEmpty` = false, нужен хотя бы один платный товар.
  4. Добавляет подарок через `/cart/add.js` с `properties: {_gift_link: campaignId}`, держит количество 1, убирает лишние строки.
  5. Если корзина перестала подходить и `removeWhenIneligible`, удаляет подарок.
  6. **Коды:** `campaignCodes(c)` разбивает строку; коды **сливаются** с уже применёнными в корзине и отправляются через `/cart/update.js {discount: "A,B"}`. Guard: не больше 2 попыток применить за 10 минут (`state.applyTries/applyTs`), чтобы не было цикла, если Shopify отказывает в коде.
- **Перехват** `fetch` и `XMLHttpRequest` на `/cart/add|change|update|clear`: после действий темы снова запускается sync.
- **refreshUI:** на `/cart` делает перезагрузку страницы (с защитой от цикла), на остальных страницах перерисовывает секции Dawn (`cart-icon-bubble`, `cart-drawer`) через Section Rendering API.
- **Фоллбек-редирект:** если Liquid-редирект не сработал, а `ShopifyAnalytics.meta` показывает, что открыт вариант подарка за $0, делается редирект на главную.
- Баннер внизу страницы (текст из кампании, закрытие запоминается). Лимит sync: 6 раз за 10 секунд. Отладка: `window.GiftLinks.sync()`; при включённом Debug в консоли пишутся сообщения `[Gift Links]`.

---

## 4. Текущая настройка в магазине (проверено 2026-10-07)

| Объект | Значение |
|---|---|
| Товар-подарок | «WoodenCrew™ Stain Remover Stick — Gift», product **15414953541951**, handle `woodencrew™-stain-remover-stick-gift`, ACTIVE, теги `gift-links-gift`, `hidden-gift` |
| Вариант подарка | **67648456524095**, цена **$0.00** |
| Коллекция | «All products – GWP» (`all-products-gwp`), id **519322894655** (осталась от BXGY-попытки; подарок из неё убран через collectionRemoveProducts) |
| Скидка | **GIFTSTICK**: DiscountCodeNode **1590990340415**, Basic, **10%**, без минимума, ACTIVE с 2026-10-06T19:25:45Z до **2026-10-12T19:30:00Z**, combinesWith: product = true, order = false, shipping = true. Сочетается со скидками бандлов Vitals |
| Кампания | id **`c_mux5ft69xhnw`**, linkKey **`giftweek`**, подарок = вариант 67648456524095, код GIFTSTICK |
| Ссылка | `https://woodencrew.store/?gift=giftweek` (или `…/любой-путь?gift=giftweek`) |
| App embed | включён в живой теме (Online Store → Themes → Customize → App embeds → Gift Links) |

**Рецепт новой акции (правильный):**
1. Сделать копию товара-подарка (productDuplicate), цена $0, тег `gift-links-gift`, статус Active, опубликовать в Online Store. Убрать из коллекций, поиска и фидов, где это возможно. Страницу закроет редирект.
2. Создать код (обычно Basic %, combinesWith.productDiscounts = true, иначе он не сложится с Vitals).
3. Gift Links → New campaign: товар, код, minSubtotal, даты, баннер → Save → Copy link.
4. Поставить ссылку (или `&gift=key`) на **все** кнопки письма в Omnisend.
5. Проверить в инкогнито: переход по ссылке → добавить товар → подарок $0 и код применены → чекаут.

---

## 5. Деплой и сервер

> **Устарело с v11:** теперь работает автодеплой (раздел 12) и процесс из раздела 0. Ниже — ручной способ на случай, если автодеплой сломан.

### Обновление (ручной способ)
1. Внести изменения в `source/` и сделать коммит.
2. Сборка: `npm ci && npm run build` (локально или в контейнере ИИ). Упаковать **`gift-links.tar.gz`** с корневой папкой `gift-links/`, внутри `build/`, `app/`, `extensions/` и остальное (без node_modules).
3. **Roman сам** загружает `gift-links.tar.gz` в GitHub-репо `nikadevs/gift-links` (main) через веб-интерфейс (Add file → Upload, заменить файл). ИИ этого не делает.
4. **Roman** в консоли дроплета выполняет:
```bash
rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && cd /opt/gift-links && rm -rf build && cp -r /tmp/gl/gift-links/build /tmp/gl/gift-links/app /tmp/gl/gift-links/extensions . && npx shopify app deploy --allow-updates && pm2 restart gift-links
```
   Если менялись зависимости (`package.json`), нужен полный `install.sh` (см. ниже) или `npm ci` на сервере.
5. Проверка, что сервер скачал новую версию: raw.githubusercontent кэширует файл до ~5 минут. Сравнивать md5 (`md5sum`) архива или давать файлам уникальные имена версий. Однажды Roman несколько раз заливал старый архив, потому что имена файлов совпадали.

### Полная установка / переустановка
`bash <(curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/install.sh)` от root. Что делает скрипт:
- добавляет swap 2G;
- ставит Node 22 и pm2;
- скачивает тарбол и **сохраняет** `.env`, `prisma/dev.sqlite`, `shopify.app*.toml`;
- выполняет `npm ci` и `npm run setup`;
- если приложение не залинковано, запускает `shopify app config link`;
- правит в toml `application_url` и `redirect_urls` через sed;
- выполняет `shopify app deploy --allow-updates`;
- создаёт `.env` (`touch .env && shopify app env pull`) и дописывает PORT, NODE_ENV, SHOPIFY_APP_URL;
- пишет `ecosystem.config.cjs`, который **сам читает .env** (pm2 не подхватывал .env через node_args);
- настраивает сайт nginx и certbot.

### Грабли Shopify CLI на сервере (решены)
- `xdg-open ENOENT` при логине → `ln -sf /bin/true /usr/local/bin/xdg-open`, ссылку для логина открыть вручную.
- Флаг `--force` не существует, правильный `--allow-updates`.
- `node: .env: not found` → `touch .env` перед `env pull`.
- Пустой `appUrl` → в .env не было SHOPIFY_APP_URL, а pm2 не грузил .env. Исправлено ecosystem, который сам читает .env.
- После `config link` scopes в toml перезаписались → вернули `read_products,read_discounts` и сделали повторный deploy.

---

## 6. Ключевые решения и почему (не повторять ошибок)

1. **BXGY не подошёл.** Скидка Buy X Get Y не засчитывает товары «buy», на которые уже действует другая товарная скидка (бандлы **Vitals**). Это правило Shopify. Поэтому сделали **копию подарка с ценой $0** и **отдельный код 10%** с `combinesWith.productDiscounts = true`.
2. **Стандартные скидки не добавляют товар в корзину сами**, поэтому нужен скрипт на витрине.
3. **Shopify Functions** (cart transform, checkout validation) в custom-приложениях доступны **только на Plus**, поэтому вся логика на витрине (theme app embed + Cart AJAX API). Код, введённый **на странице чекаута**, подарок добавить не может.
4. **Draft-товар нельзя положить в корзину** (422 «Cannot find variant»), поэтому подарок Active, а его страница закрыта редиректом по тегу `gift-links-gift`.
5. **Защита от бесплатной покупки подарка:** rogue-удаление строк без `_gift_link` плюс редирект со страницы товара. Бэкстоп в Shopify Flow (его создаёт Roman): заказ, где subtotal = 0 и есть только подарок, получает тег `gift-review` и **hold fulfillment**. **Без отмены.**
6. Привязка к **тегу**, а не к ID товара: подарки будут меняться каждую неделю.
7. Несколько кодов на кампанию (`A,B`), коды сливаются с уже применёнными.
8. Конфиг хранится в metafield, а не в базе: витрине не нужен сервер, нагрузки нет.

---

## 7. История (кратко)

- **2026-10-06.** Письма Gift Week (подарок Stain Remover Stick). Попытка BXGY GIFTSTICK провалилась из-за конфликта с Vitals. Создано приложение (`42ae877`) и установщик. Деплой на дроплет, DNS-поддомен giftlinks.nikadevs.com, SSL. Приложение установлено, app embed включён. Скидка GIFTSTICK пересоздана как 10% Basic, подарок сделан копией за $0. Добавлены несколько кодов на кампанию (`c3f4e94`) и rogue-удаление (`17fadca`).
- **2026-10-07.** Редирект со страниц подарков только по тегу (`4765ac4`), фоллбек на unset-настройку и через ShopifyAnalytics (`f147685`) → **v9 на проде, проверено на живом сайте**: подарок и 10% сочетаются с бандлами Vitals, на /cart нет цикла перезагрузок, редирект работает, $0 товары бандлов и PDF Travel Book не затронуты, подарок, добавленный вручную, удаляется.
- Покупатели переходили на сайт по ссылкам письма без `?gift=` и оставались без подарка. Заказы **#38664** и **#38665** дополнены подарком вручную через orderEditBegin/AddVariant/Commit: `notifyCustomer: false`, staffNote «Gift Week: free Stain Remover Stick added (email subscriber)», суммы не изменились.
- Roman получил промпт для временного Flow (до **2026-10-09T21:00:00Z**): заказ подписчика или повторного покупателя → Add order line item (подарок) бесплатно. Flow Roman создаёт сам.
- **2026-10-07, днём–вечером (WoodenCrew Apps):** v10 переименование + модуль Checkbox Upsell; v11 автодеплой (Roman установил cron и Automation Token; первая попытка упала из-за дважды вставленного токена — 138 символов, исправлено); v12 ⓘ-попап у чекбокса; v13 таблицы на всю ширину; перенос 3 офферов из AXE; v14 статистика (scope `read_orders`, Roman одобрил); **v15 Checkbox Upsell v2 «watch the cart»** — v1 не работал на товарах с бандлом Vitals (Vitals сам добавляет товар и уводит на /cart, перехват запроса темы не срабатывал); v16 перезагрузка устаревшей /cart после редиректа (апселлы и подарок Gift Links); v17 таблица 14px, проверка app embed у Refresh, меню помещается. Всё проверено на живом сайте (подушка ×2 через Vitals → оба апселла в корзине), тестовые строки удалены.
- **2026-10-07 ночью:** модуль SEO & Speed (v18, раздел 13); 2026-10-08 ~01:25 запушен в GitHub (`d4b4c36`).

---

## 8. Правила работы с Roman (обязательно)

- **Каждый ответ начинать с «Roman,».** Общение на русском, маркетинговые тексты на английском.
- **Никогда не врать, всегда проверять факты** (живые данные проверять запросом к API или в браузере, а не по памяти).
- Email-темы и прехедеры: **4–5 слов максимум**, без пунктуации, один эмодзи в начале.
- **Очень аккуратно:** не ломать $0 товары бандлов (**Vitals**, **Simple Bundles**) и **PDF Travel Book**, который добавляется собственными скриптами магазина. Любая логика, которая удаляет или меняет строки корзины, должна трогать только варианты подарков кампаний или строки с `_gift_link`.
- **Никогда не отменять заказы** (вредит репутации). Только тег, hold или ручная проверка.
- После тестов на живом сайте **вернуть корзину Roman в исходное состояние**.
- Изменения в заказах клиентов (orderEdit) делать только с явного согласия Roman, по конкретным номерам заказов, с `notifyCustomer: false`, если он не просил иначе.
- **Деплой WoodenCrew Apps ИИ делает сам** — push архива в `nikadevs/gift-links` (Roman разрешил 2026-10-07; процесс в разделе 0).
- Действия, которые ИИ **не делает сам** (их делает Roman): работа в консоли дроплета, создание и использование API-токенов (DigitalOcean, Shopify Automation Token и др.), правка DNS через API, одобрение новых прав приложения (scopes) в админке, создание Flow с автоотменой или массовыми действиями, снятие товаров с публикации. ИИ готовит команды и инструкции.
- Всё, что сразу меняет то, что видят покупатели (включение/выключение app embed, новые чекбоксы на витрине и т.п.), — сначала спросить Roman.
- **После каждого изменения обновлять `KNOWLEDGE.md` и документ проекта `claude/gift-links-handoff.md`**, чтобы другие чаты проекта знали всё (требование Roman 2026-10-08).
- Напоминание: DigitalOcean-токен `claude-gift-links` Roman должен был удалить (для работы приложения он не нужен).

---

## 9. Тестирование

- `tests/test.py`: Playwright (`python3 test.py`), мок-корзина и мок-страница, сценарии: (1) переход по ссылке при пустой корзине (подарок не добавляется), (2) тема добавляет товар (появляются подарок и оба кода `GIFTSTICK,GIFTSTICK10`), (3) удаление платного товара (подарок уходит), (4) новый визит без ссылки (кампания запомнилась, подарок снова добавляется), (5) запуск по коду в новом браузере, (6) подарок добавлен вручную без свойства `_gift_link` (rogue-удаление). Путь к JS в начале файла поменять на `../source/extensions/gift-links-embed/assets/gift-links.js`.
- Живой тест: инкогнито → `woodencrew.store/?gift=giftweek` → добавить товар → проверить `/cart.js` (строка подарка с `_gift_link`, `discount_codes` содержит GIFTSTICK) → чекаут показывает подарок $0 и −10%. После теста очистить корзину.

---

## 10. Бэклог / идеи

1. **Триггер по `utm_campaign`** из Omnisend: активировать кампанию по любой ссылке письма, а не только с `?gift=`. В кампанию добавить поле `utmCampaign`, в JS проверять `URLSearchParams.get('utm_campaign')`. Закрывает проблему из раздела 7.
2. **Автосоздание $0 копии подарка** при выборе товара в админке: productDuplicate, цена 0, тег `gift-links-gift`, публикация. Нужен scope `write_products`.
3. Поддержка cart drawer не-Dawn тем (сейчас перерисовка секций рассчитана на Dawn).
4. Обновить `README.md` в исходнике: убрать устаревший BXGY-рецепт.
5. Предложено обновить скилл wc-email-subject (лимит 4–5 слов); статус неизвестен.

---

## 11. WoodenCrew Apps: модульное приложение (с 2026-10-07, v10)

Приложение Gift Links переименовано в **WoodenCrew Apps** (`name` в toml; `client_id`/`handle`, папка `/opt/gift-links`, pm2 `gift-links`, репо `nikadevs/gift-links` и extension `gift-links-embed` **не менялись**, чтобы не сломать установку и включённый embed). Внутри модули, у каждого свой конфиг-metafield и свой app embed:

| Модуль | Админка | Metafield (AppInstallation) | App embed | Файлы |
|---|---|---|---|---|
| Gift Links | `/app/gifts`, `/app/campaigns/:id` | `gift_links.config` | «Gift Links» | `campaigns.*.ts`, `gift-links.liquid/js` |
| Checkbox Upsell (замена AXE Checkbox Upsell) | `/app/upsells`, `/app/upsells/:id` | `wc_upsell.config` | «Checkbox Upsell» | `upsells.*.ts`, `checkbox-upsell.liquid`, `wc-checkbox-upsell.js/css` |

Главная `/app` — карточки модулей. Новый модуль = свой `*.shared.ts` + `*.server.ts` + роуты `app.<module>...` + блок в `extensions/gift-links-embed/blocks/` + карточка в `app._index.tsx` + пункт в `app.tsx`.

### Checkbox Upsell
- Оффер (`UpsellOffer`): товар-апселл (productId, productHandle, variantId), текст, подзаголовок, precheck, order, где показывать (`triggerAll` / productIds / collectionIds), `quantityMode` (`one` | `match` = как у основного товара), `oncePerCart`.
- **Liquid** (`checkbox-upsell.liquid`, target body) рендерит только подходящие офферы для текущего товара. Цена/compare-at/картинка/наличие берутся **живыми** через `all_products[productHandle]`; недоступный вариант не показывается. Не показывается на самом товаре-апселле и на страницах подарков `gift-links-gift`.
- **JS v2 «watch the cart»** (`wc-checkbox-upsell.js`, с v15). Подключается **на каждой странице** (элемент `#wcu-boot`), список `#wcu-root` — только на странице товара (переносится перед кнопкой Add to cart; селектор/позиция в настройках embed).
  1. Клик/submit по Add to cart (capture-фаза, до обработчиков темы и Vitals) → отмеченные чекбоксы + текущее количество товара в корзине пишутся в localStorage `wcUpsell.pending.v2` (живёт 2 мин).
  2. Скрипт следит за корзиной (хуки fetch/XHR на `/cart/*` + опрос раз в 1,5 с, пока есть pending) на этой и **следующей** странице (например /cart после редиректа Vitals). Как только количество этого товара выросло — добавляет апселлы одним `/cart/add.js` (`keepalive`); если один распродан — по одному. Затем обновляет mini cart (Umino `form-mini-cart`, Dawn) или перезагружает /cart один раз.
  3. Запросы темы и других приложений **не изменяются**. Если добавлен другой товар или галочки сняты — ничего не добавляется.
  - Почему так: v1 встраивался в запрос темы `/cart/add` и **не работал на товарах с бандлом Vitals** (Vitals добавляет товар своим запросом и сразу уводит на /cart). Cart Transform / Functions не используем — только Plus (раздел 6).
  - `quantityMode: match` = столько, сколько единиц добавилось; `oncePerCart` — не добавлять, если уже в корзине.
- **ⓘ-попап** (`infoText`, с v12): кнопка ⓘ у цены, текст в модальном окне (только текст, не HTML).
- **Маркер embed** `<div id="wcu-embed" hidden>` (с v17) — по нему админка проверяет, включён ли embed.
- Строки апселла: скрытые свойства `_wc_upsell` (id оффера) и `_wc_upsell_for` (handle товара). У AXE были `__UpsellCheckboxId` и т.п.
- Строки плоские (не nested cart lines) — как у AXE; так безопаснее с Simple Bundles/Vitals.
- Ничего в корзине не удаляет. «Buy it now» (dynamic checkout) апселлы не добавляет (как и AXE).
- **Админка `/app/upsells`** (v17): статистика за 7/30/60 дней — Revenue, Revenue Boost %, Conversions/Revenue по каждому чекбоксу. Считается Bulk Operation по заказам за 60 дней (больше Shopify не даёт; scope `read_orders`), строки с `_wc_upsell` **или** AXE `__UpsellCheckboxId` (история AXE тоже считается), кэш в metafield `wc_upsell.stats`, обновление раз в 6 ч или кнопкой Refresh (`app/upsell-stats.server.ts`). Рядом с Refresh — значок **App embed: On/Off** (`app/embed-status.server.ts`: сервер открывает главную магазина и ищет маркер; кэш 1 мин; при Off — красный баннер и кнопка «Turn on» = deep link `admin/themes/current/editor?context=apps&activateAppId=<client_id>/checkbox-upsell`). Таблица своя HTML (14px), т.к. у `s-table` фиксированный 13px.
- Тесты: `tests/test_upsell.py` (Playwright: мок Umino-страницы + /cart, Vitals-подобный виджет с кэшированным fetch и редиректом, нативный submit, распродан, once, другой товар, снятые галочки, истёкший pending, попап; 18 проверок × 2 порядка загрузки с хуком Gift Links = 36) — все проходят. Liquid — LiquidJS + `shopify theme check`.

### Офферы (перенесены из AXE 2026-10-07)
| Чекбокс (id) | Добавляет | Где | Order | Особое |
|---|---|---|---|---|
| 3 in 1 Wireless Charger (`u_muy80agm1at3`) | WoodenCrew™ 3 in 1 Wireless Foldable Charger, вариант 52410746372415 ($19.95/$34.95) | товар AirSlate GPS Wallet Tracker (`wallet-gps-tracker-card`) | −1 | ⓘ «Power all your essentials, anywhere. The ultimate universal 3-in-1 foldable charging station.» |
| Shipping Priority Upsell (`u_muy7sxmbsj5k`) | Skip The Line (Priority Processing), 49930585112895 ($2.50/$5.00), подзаголовок «Priority Processing» | коллекции All + Homepage | 0 | once per cart |
| Each pillow in a gift box (`u_muy7wab6v7tb`) | Each Pillow in Gift Box, 51625826091327 ($3.95/$7.95) | Travel Pillow, Travel Pillow Ultimate Kit | 1 | qty 1 (как в AXE) |

«Wireless Charger» из AXE (был выключен) не переносился. На витрине AXE больше не выводится (проверено 2026-10-08).

---

## 12. Автодеплой (с v11, 2026-10-07)

Ручная процедура из раздела 5 больше не нужна. Схема **pull-based**: сервер сам забирает обновления, входящий SSH/ключи в GitHub не используются.

- **ИИ** собирает и тестирует, затем **пушит** новый `gift-links.tar.gz` в `nikadevs/gift-links` (main). Доступ: GitHub-коннектор claude.ai + Claude GitHub App на аккаунте nikadevs (установлены Roman 2026-10-07).
- **Сервер**: cron `/etc/cron.d/gift-links-deploy` каждые 2 минуты запускает `/opt/gift-links/deploy/auto-deploy.sh`:
  1. `git ls-remote` → если sha main изменился, качает `raw.githubusercontent.com/nikadevs/gift-links/<sha>/gift-links.tar.gz` (URL с sha, без кэша CDN);
  2. бэкап `build app extensions prisma package*.json` в `/opt/gift-links/.deploy-backups/` (хранятся 5 последних);
  3. ставит файлы; `npm ci && npm run setup` только если поменялся `package-lock.json`;
  4. `pm2 restart gift-links` + health check `http://127.0.0.1:$PORT/` (до 40 сек). Не ответил → **автооткат** на бэкап;
  5. `npx shopify app deploy --allow-updates --message "auto-deploy <sha>"` (токен `SHOPIFY_APP_AUTOMATION_TOKEN` из `/opt/gift-links/.deploy.env`, chmod 600; если файла нет — CLI-логин сервера);
  6. обновляет сами deploy-скрипты (атомарно), пишет `.deployed-sha`.
- **Не трогает**: `.env`, `.deploy.env`, `prisma/dev.sqlite`, данные `data/`. В серверном `shopify.app.toml` меняет **только строку `scopes = "..."`** (с v14 копируется из релиза, шаг 4b; бэкап toml делается) — после этого Roman один раз одобряет новые права при открытии приложения. Остальной toml (client_id, URL) — только вручную на сервере.
- **Статус**: https://giftlinks.nikadevs.com/deploy-status.json (status: running | ok | rolled_back | shopify_deploy_failed | download_failed | bad_archive, sha, время, хвост лога без строк с token/secret). Полный лог: `/var/log/gift-links-deploy.log`, последний прогон: `/opt/gift-links/.last-deploy.log`.
- Неудачный sha повторно не деплоится (записывается в `.deployed-sha`) — чинится новым коммитом. Ручной запуск: `/opt/gift-links/deploy/auto-deploy.sh --force`.
- Установка (однократно, Roman): `rm -rf /tmp/gl && mkdir /tmp/gl && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl && bash /tmp/gl/gift-links/deploy/setup-auto-deploy.sh`
- Правило из раздела 8 обновлено с согласия Roman: **деплой приложения WoodenCrew Apps ИИ делает сам** (push в репозиторий). Консоль дроплета, DNS, API-токены по-прежнему за Roman.
- Ограничение: откат касается кода сервера; если `shopify app deploy` уже выпустил версию extensions, откатывать её нужно новым коммитом (или в Dev Dashboard → Versions → Release предыдущей).

---

## 13. Модуль SEO & Speed (с v18, 2026-10-08) — замена Tapita

Админка `/app/seo` (вкладки Overview, Issues, Pages, Speed, Meta tags, Image ALT, Links & 404, Theme code, Settings). App embed «SEO & Speed» (`blocks/seo-speed.liquid`, target **head**), конфиг витрины — metafield `wc_seo.config` на AppInstallation (`instantNav: off|prefetch|prerender`, `track404`, `beaconUrl`).

### Что умеет
| Функция | Как | Данные |
|---|---|---|
| Аудит сайта | `seo/seo-crawl.server.ts`: robots.txt, sitemap (индекс + дочерние), страницы (quick = главная + ключевые/выборка, full = весь sitemap до `fullCrawlMax`, по умолчанию 300), 2 запроса параллельно с паузой, UA `WoodenCrewAudit/1.0`. Проверка ссылок (до 400, HEAD→GET, redirect manual), размеры видео и сторонних скриптов | `data/seo/<shop>/latest.json`, `reports/<id>.json` (12 последних), `history.json` |
| Проверки HTML | `seo/seo-html.server.ts` (node-html-parser, JS не исполняется): title/description (длина, дубли), H1, canonical, noindex/X-Robots-Tag, hreflang, OG, lang, viewport, мало текста, не-ASCII URL, JSON-LD (Product/ProductGroup offers price/currency/availability, image, brand/sku, return policy, shipping, rating, дубли Product/Organization/Article, Breadcrumb), картинки (alt, width/height, полноразмерные без width/srcset, lazy первая картинка), скорость (DOM > 3000, HTML > 600 KB, блокирующие script/CSS в head, сторонние домены ≥ 8, дубли скриптов, несколько jQuery, @font-face без font-display, iframe без lazy, mixed content), Liquid error | каталог проверок с «почему/как исправить/ссылка Google» — `seo/seo.shared.ts` `CHECKS` |
| PageSpeed | `seo/seo-psi.server.ts`: PSI API v5 (mobile+desktop), Lighthouse lab + CrUX (url или origin), CWV pass/fail по p75 (LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1), список невыполненных аудитов/insights с экономией (парсер проверен на реальном LHR Lighthouse 13.5), third parties, LCP-элемент | `psi.json` (400 прогонов) |
| Meta tags | products/collections: поле `seo`; pages/articles: metafields `global.title_tag/description_tag`; шаблон заполняет **только пустые** поля (`{title}`, `{shop}`, `{summary}`); Google-превью | Shopify |
| Hide from search | metafield `seo.hidden = 1` (number_integer) → Shopify ставит noindex,nofollow и убирает из sitemap | Shopify |
| Image ALT | список фото активных товаров, правка по одной, шаблон для пустых (`{title} - photo {n}`), `fileUpdate` | Shopify |
| Links & 404 | битые ссылки из аудита, лог 404 (embed шлёт `sendBeacon` на `https://giftlinks.nikadevs.com/api/seo/404` только на шаблоне 404; принимается только для установленных магазинов, лимит 20/мин на IP, ботовые пути отбрасываются), подсказка цели редиректа, создание/удаление `urlRedirect`, поиск петель и цепочек | `404.json` (до 2000 путей) |
| Theme code | read-only скан опубликованной темы: следы приложений (Tapita, AXE и др.), app embeds из settings_data.json, внешние/блокирующие скрипты в layout, крупные assets, неиспользуемые snippets | `theme-scan.json` |
| Instant navigation | Speculation Rules `moderate` (prefetch или prerender) для ссылок, кроме cart/checkout/account/apps. Shopify с июня 2025 уже даёт `conservative prefetch` всем магазинам. **По умолчанию Off** (правило: UX витрины меняем только с согласия Roman) | metafield |
| Автопроверки | `seo/seo-scheduler.server.ts` (стартует в `entry.server.tsx`): раз в 30 мин смотрит; quick-аудит раз в сутки, full — раз в 7 дней; PSI раз в сутки (главная + первый ключевой товар). Отключение: Settings или `WC_SEO_SCHEDULER=off` | — |

### Важно
- **PSI API без ключа фактически не работает**: проверено 2026-10-08 — анонимная квота Google исчерпана (`429 Quota exceeded … Queries per day`). Нужен бесплатный ключ (Google Cloud → PageSpeed Insights API → Credentials → API key). Ключ вводится в Settings (хранится только в `data/seo/<shop>/settings.json` на сервере) или `PSI_API_KEY` в `.env`.
- Данные модуля — файлы в `/opt/gift-links/data/seo/` (`WC_DATA_DIR`), auto-deploy их не трогает. Витрине они не нужны.
- Новые scopes (v18): `write_products, read_content, write_content, read_online_store_pages, write_online_store_pages, read_themes, read_online_store_navigation, write_online_store_navigation, read_files, write_files`. auto-deploy синхронизирует строку scopes; **Roman должен один раз одобрить обновление** при открытии приложения. До этого аудит и PageSpeed работают, а правки (meta, ALT, редиректы, скан темы) показывают сообщение о правах.
- Модуль ничего не меняет сам: все правки данных — только по кнопке Save; код темы не редактируется никогда.
- Новая зависимость `node-html-parser@7.0.1` → в деплое меняется package-lock → auto-deploy выполнит `npm ci`.

### Тесты (`.tests/` в исходнике, не входят в релиз)
`e2e-crawl.ts` (мок-магазин на реальных HTML WoodenCrew из woodencrew-seo/reports/2026-10-05: битая ссылка, ссылка на редирект, 404 в sitemap, редирект в sitemap, видео, 404-лог), `units.ts` (robots, подсказка редиректа, скан темы на фейковом admin), `beacon.ts` (404 endpoint), `ui-smoke.tsx` (SSR всех 9 страниц), парсер PSI на реальном LHR, Liquid embed (LiquidJS, 6 сценариев + `shopify theme check`), все GraphQL-операции проверены валидатором схемы Shopify, чтение — на живом магазине.

### Бэклог SEO
1. Search Console API (запросы, клики, индексация) — нужен Google OAuth-клиент.
2. llms.txt (у Tapita есть; польза для Google не подтверждена) — через redirect `/llms.txt` → app endpoint.
3. Организационная политика доставки/возврата в JSON-LD темы (`hasShippingService`, `hasMerchantReturnPolicy` на Organization) — только с реальными тарифами.
4. Аудит переводов/рынков (hreflang-ответные ссылки по всем рынкам).

---

## 14. Как добавить новый модуль (или «новое приложение»)

По умолчанию «новое приложение» = **новый модуль внутри WoodenCrew Apps** (решение Roman: одно приложение вместо многих). Отдельное Shopify-приложение — только если Roman прямо попросит: тогда нужны новое приложение в Dev Dashboard (создаёт Roman), свой порт/pm2-процесс/поддомен/SSL на дроплете и своя установка.

Шаги для модуля (по образцу Checkbox Upsell):
1. **Данные.** Если они нужны витрине — app-owned JSON metafield `wc_<module>.config` на `currentAppInstallation` (образец `app/upsells.server.ts`: load/save через `metafieldsSet`), витрина читает `app.metafields.wc_<module>.config.value`. Серверные/большие данные — файлы в `data/<module>/<shop>/` (образец SEO, раздел 13; auto-deploy их не трогает).
2. **Код админки.** `app/<module>.shared.ts` (типы), `app/<module>.server.ts`, роуты `app/routes/app.<module>._index.tsx` (список) и `app.<module>.$id.tsx` (форма). Polaris web components (`s-page inlineSize="large"`, `s-section`…), App Bridge `resourcePicker`. Без `window.confirm` (iframe) — подтверждение вторым кликом.
3. **Карточка** в `app/routes/app._index.tsx` (массив `modules`) и пункт в `app/routes/app.tsx` (`s-app-nav`; места в сайдбаре мало).
4. **Витрина.** Новый блок `extensions/gift-links-embed/blocks/<module>.liquid` (app embed, `target: body` или `head`) + assets. Выводить маркер `<div id="wc<module>-embed" hidden>` и проверять его через `checkEmbed()` из `app/embed-status.server.ts`. Расширение одно (`gift-links-embed`) — не переименовывать (сломает включённые embeds).
5. **Корзина.** Не трогать чужие строки: только свои, помеченные скрытым свойством `_wc_<module>`. Не изменять запросы темы/Vitals/Simple Bundles. Учитывать $0-строки бандлов и PDF Travel Book.
6. **Права.** Новые scopes — в `source/shopify.app.toml` (строка `scopes`); auto-deploy перенесёт; Roman одобрит. Нужны ли «protected customer data» — проверить заранее (для заказов Shopify показывает Roman экран с доступом к данным покупателей).
7. **Проверки и деплой** — раздел 0. Тесты витрины — Playwright с моком страницы (образец `tests/test_upsell.py`), Liquid — LiquidJS + theme check, GraphQL — валидатор схемы Shopify.
8. **Документация.** Новый раздел в этом файле (что делает, где файлы, данные, решения, тесты, бэклог) + обновить раздел 0 + документ проекта.
