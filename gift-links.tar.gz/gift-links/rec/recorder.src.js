/**
 * WoodenCrew Apps — Session Recordings, storefront recorder.
 *
 * Built into extensions/gift-links-embed/assets/wc-rec.js by
 * scripts/build-rec.mjs (esbuild, minified, rrweb record bundled in).
 *
 * Loaded ONLY by the tiny inline loader in blocks/gift-links.liquid, and only
 * when recording is switched on in the app (/app/recordings). The loader waits
 * for window "load" and then for browser idle time, so this file never
 * competes with the page's own resources (LCP, theme scripts).
 *
 * Privacy: every input value is masked, password fields always; customer
 * account pages are never recorded (the loader is not printed there).
 * Nothing in the page or cart is changed; no theme request is wrapped
 * (add-to-cart is detected passively with PerformanceObserver).
 */
import { record } from "@rrweb/record";

(function () {
  var cfg = window.__wcRec;
  if (!cfg || window.__wcRecOn) return;
  window.__wcRecOn = 1;
  if (navigator.webdriver) return; // headless crawlers / automation

  var IDLE_MS = 30 * 60 * 1000; // new session after 30 min without activity
  var FLUSH_MS = 5000; // send every 5 s
  var MAX_PAGE_MS = 30 * 60 * 1000; // stop recording one page after 30 min
  var MAX_PAGE_BYTES = 6 * 1024 * 1024; // or after ~6 MB of raw events
  var BEACON_MAX = 60000; // sendBeacon / keepalive body limit is 64 KB
  var REQ_MAX = 700000; // stay under nginx client_max_body_size (1 MB)

  var now = Date.now();
  function rid() {
    var a = new Uint8Array(8);
    (window.crypto || window.msCrypto).getRandomValues(a);
    var s = "";
    for (var i = 0; i < a.length; i++) s += (a[i] % 36).toString(36);
    return s;
  }
  function getJSON(store, key) {
    try {
      return JSON.parse(store.getItem(key) || "null");
    } catch (e) {
      return null;
    }
  }
  function setJSON(store, key, v) {
    try {
      store.setItem(key, JSON.stringify(v));
    } catch (e) {
      /* private mode / quota: recording still works for this page */
    }
  }

  // visitor (localStorage, survives visits) + session (localStorage, shared by
  // tabs, ends after 30 min idle) + page number inside the session
  var vid = getJSON(localStorage, "wcrec.v");
  if (!vid) {
    vid = rid() + rid();
    setJSON(localStorage, "wcrec.v", vid);
  }
  var ses = getJSON(localStorage, "wcrec.s");
  if (!ses || !ses.id || now - ses.last > IDLE_MS) {
    // session id starts with its start time (base36) — the server files it by day
    ses = { id: now.toString(36) + rid(), last: now, pages: 0 };
  }
  var page = ses.pages++;
  ses.last = now;
  setJSON(localStorage, "wcrec.s", ses);

  var base =
    cfg.e +
    "?shop=" +
    encodeURIComponent(cfg.s) +
    "&s=" +
    ses.id +
    "&v=" +
    vid +
    "&p=" +
    page;
  var seq = 0;
  var metaSent = false;
  var buf = [];
  var bufBytes = 0;
  var pageBytes = 0;
  var started = now;
  var stopFn = null;
  var flags = {};
  var meta = {
    url: location.pathname + location.search,
    title: document.title.slice(0, 200),
    ref: page === 0 ? document.referrer.slice(0, 300) : "",
    w: window.innerWidth,
    h: window.innerHeight,
    dpr: window.devicePixelRatio || 1,
    tz: (function () {
      try {
        return Intl.DateTimeFormat().resolvedOptions().timeZone || "";
      } catch (e) {
        return "";
      }
    })(),
    lang: navigator.language || "",
    touch: "ontouchstart" in window || navigator.maxTouchPoints > 0,
  };

  function touch() {
    var t = Date.now();
    if (t - ses.last > 10000) {
      ses.last = t;
      setJSON(localStorage, "wcrec.s", ses);
    }
  }

  var canZip =
    typeof CompressionStream === "function" && typeof Response === "function";

  function url(z) {
    return base + "&q=" + seq++ + "&z=" + z;
  }

  function sendNow(json) {
    // page is going away: no time for async compression
    var u = url(0);
    if (json.length <= BEACON_MAX && navigator.sendBeacon) {
      if (navigator.sendBeacon(u, new Blob([json], { type: "text/plain" })))
        return;
    }
    try {
      fetch(u, {
        method: "POST",
        body: json,
        keepalive: json.length <= BEACON_MAX,
        mode: "cors",
        credentials: "omit",
        headers: { "Content-Type": "text/plain" },
      });
    } catch (e) {
      /* ignore */
    }
  }

  function sendZip(json) {
    var u = url(1);
    return new Response(
      new Blob([json]).stream().pipeThrough(new CompressionStream("gzip")),
    )
      .arrayBuffer()
      .then(function (ab) {
        return fetch(u, {
          method: "POST",
          body: ab,
          keepalive: ab.byteLength <= BEACON_MAX,
          mode: "cors",
          credentials: "omit",
          headers: { "Content-Type": "text/plain" },
        });
      })
      .catch(function () {});
  }

  function payloads() {
    // split the buffer so no request exceeds REQ_MAX of raw JSON
    var out = [];
    var part = [];
    var size = 0;
    for (var i = 0; i < buf.length; i++) {
      var s = JSON.stringify(buf[i]);
      if (part.length && size + s.length > REQ_MAX) {
        out.push(part);
        part = [];
        size = 0;
      }
      part.push(s);
      size += s.length + 1;
    }
    if (part.length) out.push(part);
    buf = [];
    bufBytes = 0;
    return out.map(function (p, i) {
      var head =
        !metaSent && i === 0 ? '"m":' + JSON.stringify(meta) + "," : "";
      if (i === 0) metaSent = true;
      if (flags.atc || flags.co) {
        head += '"f":' + JSON.stringify(flags) + ",";
      }
      if (i === 0 && clicks.length) {
        head += '"c":' + JSON.stringify(clicks.splice(0, clicks.length)) + ",";
      }
      return "{" + head + '"e":[' + p.join(",") + "]}";
    });
  }

  function flush(unloading) {
    if (!buf.length) {
      // clicks made before the recording started (or on a stopped page)
      if (clicks.length) {
        var cj = '{"c":' + JSON.stringify(clicks.splice(0, clicks.length)) + ',"e":[]}';
        if (unloading || !canZip) sendNow(cj);
        else sendZip(cj);
      }
      return;
    }
    var list = payloads();
    for (var i = 0; i < list.length; i++) {
      if (unloading || !canZip) sendNow(list[i]);
      else sendZip(list[i]);
    }
  }

  function stop() {
    if (stopFn) {
      stopFn();
      stopFn = null;
    }
  }

  function custom(tag, payload) {
    try {
      record.addCustomEvent(tag, payload || {});
    } catch (e) {
      /* not recording */
    }
  }

  // Start only when the page is really quiet: the first full snapshot is one
  // synchronous task (≈40 ms desktop, ≈150 ms mid phone for a 1.3k-node page),
  // so we avoid running it while the visitor is touching/scrolling/typing.
  var lastInput = 0;
  function onInput() {
    lastInput = performance.now();
  }
  var inputEvents = ["pointerdown", "keydown", "touchstart", "wheel", "scroll"];
  for (var k = 0; k < inputEvents.length; k++) {
    window.addEventListener(inputEvents[k], onInput, {
      capture: true,
      passive: true,
    });
  }
  var waitedFrom = performance.now();
  function whenQuiet(cb) {
    var ric = window.requestIdleCallback;
    function check(dl) {
      var waited = performance.now() - waitedFrom;
      var quiet =
        performance.now() - lastInput > 1000 &&
        document.visibilityState === "visible";
      var idle = !dl || dl.didTimeout || dl.timeRemaining() >= 30;
      if (
        (quiet && idle) ||
        (waited > 8000 && document.visibilityState === "visible")
      ) {
        for (var j = 0; j < inputEvents.length; j++) {
          window.removeEventListener(inputEvents[j], onInput, {
            capture: true,
          });
        }
        cb();
      } else if (ric) ric(check, { timeout: 1500 });
      else setTimeout(check, 700);
    }
    if (ric) ric(check, { timeout: 1500 });
    else setTimeout(check, 700);
  }

  // ---- passive business events (no request of the theme is wrapped) ----
  try {
    new PerformanceObserver(function (list) {
      var es = list.getEntries();
      for (var i = 0; i < es.length; i++) {
        var n = es[i].name || "";
        if (/\/cart\/add(\.js)?(\?|$)/.test(n)) {
          flags.atc = 1;
          custom("Add to cart");
          tagCart();
        }
      }
    }).observe({ type: "resource", buffered: false });
  } catch (e) {
    /* old browser */
  }

  // Link a future order to this visitor: once per page, after an add to cart,
  // store the visitor id in a hidden cart attribute (_wc_rec). Shopify copies
  // cart attributes to the order, and the server matches orders → visitors.
  // Sent 2 s later so it never races the theme's / Vitals' own cart requests.
  var tagged = false;
  function tagCart() {
    if (tagged) return;
    tagged = true;
    setTimeout(function () {
      try {
        var root = (window.Shopify && window.Shopify.routes && window.Shopify.routes.root) || "/";
        fetch(root + "cart/update.js", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ attributes: { _wc_rec: vid } }),
          credentials: "same-origin",
          keepalive: true,
        }).catch(function () {});
      } catch (e) {
        /* ignore */
      }
    }, 2000);
  }
  document.addEventListener(
    "click",
    function (e) {
      var t = e.target;
      var el =
        t && t.closest
          ? t.closest(
              'a[href*="/checkout"],[name="checkout"],button[onclick*="checkout"]',
            )
          : null;
      if (el) {
        flags.co = 1;
        custom("Checkout click");
      }
      clickMap(e);
      if (el) flush(false);
    },
    { capture: true, passive: true },
  );

  // ---- click map: where people click on this page (aggregated on the server) ----
  // Computed only on a click (a few element look-ups), never on load/scroll.
  // Element = the clickable ancestor; we keep a short CSS path, a short label
  // (aria-label / alt / text — never input values) and the click position
  // inside the element (0..1) plus the page position as a fallback.
  var clicks = [];
  var CLICK_MAX = 300;
  function cssPath(el) {
    var parts = [];
    for (var d = 0; el && el.nodeType === 1 && d < 7; d++) {
      var tag = el.tagName.toLowerCase();
      if (tag === "html" || tag === "body") break;
      if (el.id && !/\d{6,}|[:\s]/.test(el.id)) {
        parts.unshift("#" + el.id.replace(/([^\w-])/g, "\\$1"));
        break;
      }
      var i = 1;
      for (var sb = el.previousElementSibling; sb; sb = sb.previousElementSibling) {
        if (sb.tagName === el.tagName) i++;
      }
      parts.unshift(tag + ":nth-of-type(" + i + ")");
      el = el.parentElement;
    }
    return parts.join(">");
  }
  function labelOf(el) {
    var tag = el.tagName.toLowerCase();
    var t =
      el.getAttribute("aria-label") ||
      el.getAttribute("alt") ||
      el.getAttribute("title") ||
      (/^(input|textarea|select)$/.test(tag)
        ? el.getAttribute("placeholder") || el.getAttribute("name") || el.type || tag
        : el.innerText || el.textContent || "");
    t = String(t || "").replace(/\s+/g, " ").trim().slice(0, 60);
    if (!t && el.getAttribute("href")) t = String(el.getAttribute("href")).split("?")[0].slice(0, 60);
    if (!t) {
      var img = el.querySelector && el.querySelector("img[alt]");
      if (img) t = String(img.getAttribute("alt")).slice(0, 60);
    }
    return t;
  }
  function clickMap(e) {
    try {
      if (clicks.length >= CLICK_MAX) return;
      var t = e.target;
      if (!t || t.nodeType !== 1) t = t && t.parentElement;
      if (!t) return;
      var el =
        t.closest(
          'a,button,input,select,textarea,label,summary,[role="button"],[role="link"],[role="tab"],[onclick],img,svg',
        ) || t;
      if (el.tagName.toLowerCase() === "svg" || el.closest("svg")) {
        el = (el.closest("svg") || el).parentElement || el;
        el = el.closest('a,button,label,[role="button"]') || el;
      }
      var r = el.getBoundingClientRect();
      var de = document.documentElement;
      clicks.push({
        s: cssPath(el),
        l: labelOf(el),
        t: el.tagName.toLowerCase(),
        rx: r.width ? Math.round(((e.clientX - r.left) / r.width) * 1000) / 1000 : 0.5,
        ry: r.height ? Math.round(((e.clientY - r.top) / r.height) * 1000) / 1000 : 0.5,
        x: Math.round(((e.clientX + window.scrollX) / Math.max(1, de.clientWidth)) * 1000) / 1000,
        y: Math.round(e.clientY + window.scrollY),
        w: de.clientWidth,
      });
    } catch (err) {
      /* never break the page */
    }
  }

  // send what is left (events and clicks) when the page is hidden or closed —
  // also for pages where the recorder never started
  document.addEventListener("visibilitychange", function () {
    if (document.visibilityState === "hidden") flush(true);
  });
  window.addEventListener("pagehide", function () {
    flush(true);
  });

  // register the page right away (tiny beacon), so even a page left before the
  // recording starts — e.g. /cart → checkout in 2 s — shows up in the visit
  sendNow('{"m":' + JSON.stringify(meta) + ',"e":[]}');

  // the cart page is short and important: record it at once
  if (/\/cart\/?$/.test(location.pathname)) start();
  else whenQuiet(start);

  function start() {
    started = Date.now();
    window.__wcRecOn = 2;
    stopFn = record({
      emit: function (ev) {
        buf.push(ev);
        // rough size: full snapshots dominate; count their JSON length once
        var n = ev.type === 2 ? JSON.stringify(ev).length : 200;
        bufBytes += n;
        pageBytes += n;
        if (
          ev.type === 3 &&
          ev.data &&
          (ev.data.source === 2 || ev.data.source === 5)
        )
          touch();
        if (pageBytes > MAX_PAGE_BYTES || Date.now() - started > MAX_PAGE_MS) {
          stop();
          flush(false);
        }
      },
      maskAllInputs: true,
      maskInputOptions: { password: true },
      blockClass: "wc-rec-block",
      blockSelector: "iframe, video, [data-wc-rec-block]",
      maskTextClass: "wc-rec-mask",
      maskTextSelector: "[data-wc-rec-mask]",
      slimDOMOptions: "all",
      inlineStylesheet: false,
      inlineImages: false,
      collectFonts: false,
      recordCanvas: false,
      recordCrossOriginIframes: false,
      sampling: {
        mousemove: 100,
        mouseInteraction: true,
        scroll: 150,
        media: 800,
        input: "last",
      },
    });

    setInterval(function () {
      if (document.visibilityState === "visible") flush(false);
    }, FLUSH_MS);
    // first send soon after the full snapshot, so short visits are kept too
    setTimeout(function () {
      flush(false);
    }, 1500);
  }
})();
