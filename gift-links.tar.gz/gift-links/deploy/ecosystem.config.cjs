// pm2 process file:  pm2 start deploy/ecosystem.config.cjs && pm2 save
module.exports = {
  apps: [
    {
      name: "gift-links",
      script: "npm",
      args: "run start",
      cwd: __dirname + "/..",
      env: { NODE_ENV: "production", PORT: "3000" },
    },
  ],
};
