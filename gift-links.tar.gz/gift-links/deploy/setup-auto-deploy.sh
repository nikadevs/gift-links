#!/usr/bin/env bash
# WoodenCrew Apps — one-time setup of pull-based auto deploy on the droplet (run as root).
#
#   rm -rf /tmp/gl && mkdir /tmp/gl \
#     && curl -fsSL https://raw.githubusercontent.com/nikadevs/gift-links/main/gift-links.tar.gz | tar -xz -C /tmp/gl \
#     && bash /tmp/gl/gift-links/deploy/setup-auto-deploy.sh
#
# What it does:
#   - installs deploy/auto-deploy.sh into /opt/gift-links/deploy/
#   - asks for the Shopify App Automation Token (Dev Dashboard → app → Settings)
#     and stores it in /opt/gift-links/.deploy.env (chmod 600, never leaves the server)
#     Enter = skip: then `shopify app deploy` uses the CLI login already on this server.
#   - adds /etc/cron.d/gift-links-deploy (every 2 minutes) + logrotate
#   - runs the first deploy right away
set -euo pipefail

APP_DIR=/opt/gift-links
SRC="$(cd "$(dirname "$0")" && pwd)"

[ "$(id -u)" -eq 0 ] || { echo "Run as root"; exit 1; }
[ -d "$APP_DIR" ] || { echo "$APP_DIR not found"; exit 1; }

command -v git >/dev/null 2>&1 || { apt-get update -qq && apt-get install -y -qq git; }
command -v flock >/dev/null 2>&1 || apt-get install -y -qq util-linux

install -d -m 755 "$APP_DIR/deploy"
install -m 755 "$SRC/auto-deploy.sh" "$APP_DIR/deploy/auto-deploy.sh"
install -m 755 "$SRC/setup-auto-deploy.sh" "$APP_DIR/deploy/setup-auto-deploy.sh"

if [ ! -s "$APP_DIR/.deploy.env" ]; then
  echo
  echo "Shopify App Automation Token:"
  echo "  dev.shopify.com → Apps → WoodenCrew Apps → Settings → App Automation Token → Generate"
  printf "Paste it here (input hidden, Enter = skip): "
  read -rs TOKEN || TOKEN=""
  echo
  if [ -n "$TOKEN" ]; then
    (umask 077 && printf 'SHOPIFY_APP_AUTOMATION_TOKEN=%s\n' "$TOKEN" >"$APP_DIR/.deploy.env")
    chmod 600 "$APP_DIR/.deploy.env"
    echo "Token saved to $APP_DIR/.deploy.env"
  else
    echo "No token — deploys will use the Shopify CLI login of this server."
  fi
fi
unset TOKEN

cat >/etc/cron.d/gift-links-deploy <<'EOF'
# WoodenCrew Apps auto deploy — checks nikadevs/gift-links every 2 minutes
*/2 * * * * root /opt/gift-links/deploy/auto-deploy.sh >/dev/null 2>&1
EOF
chmod 644 /etc/cron.d/gift-links-deploy

cat >/etc/logrotate.d/gift-links-deploy <<'EOF'
/var/log/gift-links-deploy.log {
  weekly
  rotate 8
  compress
  missingok
  notifempty
}
EOF
touch /var/log/gift-links-deploy.log

echo
echo "Running the first deploy (takes 1–3 minutes)…"
"$APP_DIR/deploy/auto-deploy.sh" --force || true
echo
echo "----- last deploy log -----"
tail -n 40 "$APP_DIR/.last-deploy.log" 2>/dev/null || tail -n 40 /var/log/gift-links-deploy.log
echo
echo "----- status -----"
node -e 'const s=require("/opt/gift-links/deploy-status.json");console.log(s.status+": "+s.message)' 2>/dev/null || cat "$APP_DIR/deploy-status.json"
echo
echo "Done. Status page: https://giftlinks.nikadevs.com/deploy-status.json"
