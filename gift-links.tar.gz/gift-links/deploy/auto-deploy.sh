#!/usr/bin/env bash
# WoodenCrew Apps — pull-based auto deploy.
#
# Cron runs this every 2 minutes on the droplet (see setup-auto-deploy.sh).
# When nikadevs/gift-links (main) has a new commit it:
#   1. downloads gift-links.tar.gz of THAT commit (sha-pinned URL, no CDN cache)
#   2. backs up build/ app/ extensions/ prisma/ package*.json
#   3. installs the new files (npm ci + setup only if package-lock changed)
#   4. restarts pm2 and health-checks the app  → on failure: rollback
#   5. runs `shopify app deploy` (extensions + app config)
#   6. writes deploy-status.json (served at https://giftlinks.nikadevs.com/deploy-status.json)
# Never touches .env, .deploy.env, shopify.app*.toml or prisma/dev.sqlite.
#
# Manual run:  /opt/gift-links/deploy/auto-deploy.sh --force
set -uo pipefail

APP_DIR=/opt/gift-links
REPO=nikadevs/gift-links
BRANCH=main
PM2_NAME=gift-links
STATE="$APP_DIR/.deployed-sha"
STATUS="$APP_DIR/deploy-status.json"
LOG=/var/log/gift-links-deploy.log
BACKUPS="$APP_DIR/.deploy-backups"
export HOME=/root
export PATH=/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin
export CI=1

exec 9>/var/lock/gift-links-deploy.lock
flock -n 9 || exit 0

FORCE=0
[ "${1:-}" = "--force" ] && FORCE=1

remote_sha() {
  if command -v git >/dev/null 2>&1; then
    git ls-remote "https://github.com/$REPO" "refs/heads/$BRANCH" 2>/dev/null | cut -f1
  else
    curl -fsS "https://api.github.com/repos/$REPO/commits/$BRANCH" 2>/dev/null |
      grep -m1 '"sha"' | sed -E 's/.*"sha": *"([0-9a-f]+)".*/\1/'
  fi
}

SHA="$(remote_sha)"
[ -n "$SHA" ] || exit 0
OLD="$(cat "$STATE" 2>/dev/null || true)"
if [ "$SHA" = "$OLD" ] && [ "$FORCE" = 0 ]; then exit 0; fi

WORK="$(mktemp -d /tmp/gl-deploy.XXXXXX)"
RUNLOG="$WORK/run.log"
STARTED="$(date -u +%FT%TZ)"
log() { echo "[$(date -u +%FT%TZ)] $*" | tee -a "$RUNLOG" >>"$LOG"; }
run() { "$@" >>"$RUNLOG" 2>&1; }

write_status() { # $1 status, $2 message
  STATUS_VALUE="$1" STATUS_MESSAGE="$2" SHA="$SHA" OLD="$OLD" STARTED="$STARTED" RUNLOG="$RUNLOG" OUT="$STATUS" \
    node -e '
      const fs = require("fs");
      let tail = [];
      try { tail = fs.readFileSync(process.env.RUNLOG, "utf8").split("\n"); } catch {}
      tail = tail.filter(l => l && !/(token|secret|password|shpat_|shpss_|atkn_)/i.test(l)).slice(-60);
      const s = { status: process.env.STATUS_VALUE, message: process.env.STATUS_MESSAGE,
        sha: process.env.SHA, previousSha: process.env.OLD || null,
        startedAt: process.env.STARTED, updatedAt: new Date().toISOString(), log: tail };
      fs.writeFileSync(process.env.OUT + ".tmp", JSON.stringify(s, null, 2));
      fs.renameSync(process.env.OUT + ".tmp", process.env.OUT);
    ' 2>>"$LOG"
}

finish() { # $1 status, $2 message — records the sha so a bad commit isn't retried forever
  log "$1: $2"
  write_status "$1" "$2"
  echo "$SHA" >"$STATE"
  cp "$RUNLOG" "$APP_DIR/.last-deploy.log" 2>/dev/null
  rm -rf "$WORK"
  ls -1dt "$BACKUPS"/* 2>/dev/null | tail -n +6 | xargs -r rm -rf
  exit 0
}

cd "$APP_DIR" || exit 1
log "=== deploy ${SHA:0:7} (was ${OLD:0:7}) ==="
write_status running "deploying ${SHA:0:7}"

# 1. download + unpack
if ! run curl -fsSL "https://raw.githubusercontent.com/$REPO/$SHA/gift-links.tar.gz" -o "$WORK/a.tgz"; then
  finish download_failed "could not download gift-links.tar.gz for ${SHA:0:7}"
fi
if ! run tar -xzf "$WORK/a.tgz" -C "$WORK"; then finish bad_archive "archive could not be extracted"; fi
NEW="$WORK/gift-links"
if [ ! -f "$NEW/build/server/index.js" ] || [ ! -d "$NEW/extensions" ]; then
  finish bad_archive "archive has no build/server/index.js or extensions/"
fi

# 2. backup
BK="$BACKUPS/$(date -u +%Y%m%dT%H%M%S)-${OLD:0:7}"
mkdir -p "$BK"
for p in build app extensions prisma package.json package-lock.json; do
  [ -e "$p" ] && cp -a "$p" "$BK/"
done
log "backup → $BK"

LOCK_CHANGED=0
cmp -s "$NEW/package-lock.json" package-lock.json || LOCK_CHANGED=1

restore() {
  log "rolling back from $BK"
  for p in build app extensions; do rm -rf "$p"; [ -e "$BK/$p" ] && cp -a "$BK/$p" .; done
  for p in package.json package-lock.json; do [ -e "$BK/$p" ] && cp -a "$BK/$p" .; done
  if [ "$LOCK_CHANGED" = 1 ]; then run npm ci --no-audit --no-fund; fi
  run pm2 restart "$PM2_NAME" --update-env
}

# 3. install files (prisma/dev.sqlite is kept: only schema + migrations are copied)
for p in build app extensions; do rm -rf "$p"; cp -a "$NEW/$p" .; done
mkdir -p prisma
cp -a "$NEW/prisma/schema.prisma" prisma/ 2>/dev/null
[ -d "$NEW/prisma/migrations" ] && { rm -rf prisma/migrations; cp -a "$NEW/prisma/migrations" prisma/; }
cp -a "$NEW/package.json" "$NEW/package-lock.json" .
if [ "$LOCK_CHANGED" = 1 ]; then
  log "package-lock changed → npm ci + setup"
  if ! run npm ci --no-audit --no-fund || ! run npm run setup; then
    restore
    finish rolled_back "npm ci / setup failed — previous version restored"
  fi
fi

# 4. restart + health check
PORT="$(grep -E '^PORT=' .env 2>/dev/null | tail -1 | cut -d= -f2 | tr -d '\r"')"
PORT="${PORT:-3107}"
run pm2 restart "$PM2_NAME" --update-env
healthy=0
for _ in $(seq 1 20); do
  sleep 2
  code="$(curl -s -o /dev/null -w '%{http_code}' "http://127.0.0.1:$PORT/" || true)"
  if [ -n "$code" ] && [ "$code" != "000" ] && [ "$code" -lt 500 ]; then healthy=1; break; fi
done
if [ "$healthy" != 1 ]; then
  restore
  finish rolled_back "app did not answer on :$PORT after restart (last HTTP $code) — previous version restored"
fi
log "app healthy on :$PORT"

# 4b. access scopes: copy ONLY the `scopes = "..."` line from the release toml into
#     the linked server toml (client_id / urls stay untouched). The merchant then
#     approves the new permission once in Shopify admin.
NEW_SCOPES="$(grep -E '^scopes *= *"[a-z_,]*"$' "$NEW/shopify.app.toml" 2>/dev/null | head -1)"
CUR_SCOPES="$(grep -E '^scopes *=' shopify.app.toml 2>/dev/null | head -1)"
if [ -n "$NEW_SCOPES" ] && [ -n "$CUR_SCOPES" ] && [ "$NEW_SCOPES" != "$CUR_SCOPES" ]; then
  cp -a shopify.app.toml "$BK/shopify.app.toml"
  sed -i "s|^scopes *=.*|$NEW_SCOPES|" shopify.app.toml
  log "scopes: $CUR_SCOPES → $NEW_SCOPES"
fi

# 5. Shopify: extensions + app config (uses App Automation Token if present)
if [ -f "$APP_DIR/.deploy.env" ]; then set -a; . "$APP_DIR/.deploy.env"; set +a; fi
if ! run npx shopify app deploy --allow-updates --no-color \
  --message "auto-deploy ${SHA:0:7}" \
  --source-control-url "https://github.com/$REPO/commit/$SHA"; then
  # self-update the deploy scripts anyway so a fix to this script can land
  for f in "$NEW"/deploy/*.sh; do [ -f "$f" ] && install -m 755 "$f" "$APP_DIR/deploy/.$(basename "$f").new" && mv -f "$APP_DIR/deploy/.$(basename "$f").new" "$APP_DIR/deploy/$(basename "$f")"; done
  finish shopify_deploy_failed "server updated and healthy, but 'shopify app deploy' failed (extensions not updated)"
fi

# 6. self-update deploy scripts (atomic rename — safe while this script runs)
mkdir -p "$APP_DIR/deploy"
for f in "$NEW"/deploy/*.sh; do
  [ -f "$f" ] || continue
  install -m 755 "$f" "$APP_DIR/deploy/.$(basename "$f").new"
  mv -f "$APP_DIR/deploy/.$(basename "$f").new" "$APP_DIR/deploy/$(basename "$f")"
done

finish ok "deployed ${SHA:0:7}"
