/**
 * Checkbox Upsell — offer storage.
 *
 * Same pattern as Gift Links: ONE app-owned JSON metafield on the
 * AppInstallation (namespace "wc_upsell", key "config"). The theme app embed
 * reads it in Liquid via `app.metafields.wc_upsell.config.value`, so the
 * storefront never calls this server.
 */
import {
  UPSELL_KEY,
  UPSELL_NAMESPACE,
  type UpsellConfig,
  type UpsellOffer,
} from "./upsells.shared";

export type { UpsellOffer, UpsellConfig } from "./upsells.shared";

type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

export const emptyUpsellConfig = (): UpsellConfig => ({
  version: 1,
  offers: [],
});

export async function loadUpsellConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcUpsellConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_upsell", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: {
      currentAppInstallation?: {
        id: string;
        metafield?: { value?: string | null } | null;
      };
    };
  };
  const installation = json.data?.currentAppInstallation;
  let config = emptyUpsellConfig();
  const raw = installation?.metafield?.value;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.offers)) config = parsed;
    } catch {
      // corrupted value — start fresh rather than crash the admin
    }
  }
  return { installationId: installation?.id ?? "", config };
}

export async function saveUpsellConfig(
  admin: AdminGraphql,
  installationId: string,
  config: UpsellConfig,
) {
  // keep the storefront order stable: by "order", then name
  config.offers.sort(
    (a, b) => a.order - b.order || a.name.localeCompare(b.name),
  );
  const res = await admin.graphql(
    `#graphql
    mutation WcUpsellSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        userErrors { field message }
      }
    }`,
    {
      variables: {
        metafields: [
          {
            ownerId: installationId,
            namespace: UPSELL_NAMESPACE,
            key: UPSELL_KEY,
            type: "json",
            value: JSON.stringify(config),
          },
        ],
      },
    },
  );
  const json = (await res.json()) as {
    data?: { metafieldsSet?: { userErrors: { message: string }[] } };
  };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}

const digits = (s: string) => s.replace(/\D/g, "");

/** Turns the submitted form (one JSON field "offer") into a validated offer. */
export function offerFromForm(
  form: FormData,
  id: string,
): { offer?: UpsellOffer; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  let o: Partial<UpsellOffer> = {};
  try {
    o = JSON.parse(String(form.get("offer") ?? "{}"));
  } catch {
    return { errors: { form: "Could not read the form — reload the page" } };
  }
  const str = (v: unknown, max = 200) => String(v ?? "").trim().slice(0, max);
  const list = (v: unknown) =>
    Array.isArray(v) ? v.map((x) => String(x)) : [];

  const name = str(o.name, 120);
  if (!name) errors.name = "Give the checkbox a name";
  const variantId = digits(str(o.variantId));
  const productHandle = str(o.productHandle, 255);
  if (!variantId || !productHandle)
    errors.product = "Pick the product to add when the box is ticked";
  const title = str(o.title, 120);
  if (!title) errors.title = "Write the text shown next to the checkbox";

  const productIds = list(o.productIds).map(digits).filter(Boolean);
  const collectionIds = list(o.collectionIds).map(digits).filter(Boolean);
  const triggerAll = Boolean(o.triggerAll);
  if (!triggerAll && !productIds.length && !collectionIds.length)
    errors.triggers = "Choose where to show it: all products, products or collections";

  const order = Math.round(Number(o.order ?? 0));

  if (Object.keys(errors).length) return { errors };

  return {
    errors,
    offer: {
      id,
      name,
      active: Boolean(o.active),
      productId: digits(str(o.productId)),
      productHandle,
      productTitle: str(o.productTitle, 255),
      variantId,
      variantTitle: str(o.variantTitle, 255),
      image: str(o.image, 1000),
      title,
      subtitle: str(o.subtitle, 160),
      infoText: str(o.infoText, 400),
      precheck: Boolean(o.precheck),
      order: Number.isFinite(order) ? order : 0,
      triggerAll,
      productIds,
      productTitles: list(o.productTitles).slice(0, productIds.length),
      collectionIds,
      collectionTitles: list(o.collectionTitles).slice(0, collectionIds.length),
      quantityMode: o.quantityMode === "match" ? "match" : "one",
      oncePerCart: Boolean(o.oncePerCart),
      updatedAt: new Date().toISOString(),
    },
  };
}
