import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { Link, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadTrkPageConfig } from "../trk-admin.server";
import { handleTrkAction } from "../trk-actions.server";
import { getLookups, getState, getTrkSettings, loadShipments } from "../trk-store.server";
import { computeStats, isTickRunning } from "../trk.server";
import { yunConfigured } from "../trk-yun.server";
import { TRK_STATUS_LABEL, TRK_STATUS_ORDER } from "../trk.shared";
import { Grid, HBars, Kpi, STATUS_COLOR, ShareBar, TrkNav, card, fmt, useTrkAction } from "../trk-ui";

/** Tracking → Dashboard (like Track123's dashboard). */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const [s, state, { config: page }, lookups] = await Promise.all([
    getTrkSettings(shop),
    getState(shop),
    loadTrkPageConfig(admin),
    getLookups(shop),
  ]);
  const all = [...(await loadShipments(shop)).values()];
  const since = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
  const look = Object.entries(lookups)
    .filter(([d]) => d >= since)
    .reduce((a, [, v]) => ({ lookups: a.lookups + v.lookups, found: a.found + v.found }), { lookups: 0, found: 0 });
  return {
    stats: computeStats(all, { days: 30 }),
    total: all.length,
    look,
    state,
    running: isTickRunning(shop),
    setup: {
      yun: yunConfigured(s),
      poll: s.pollEnabled,
      page: page.enabled,
      omnisend: s.omnisendEnabled && !!s.omnisendKey,
      paypal: s.paypalEnabled && !!s.paypalClientId,
      shopify: s.shopifyEvents && s.shopifyUrl,
    },
  };
};

export const action = async ({ request }: ActionFunctionArgs) => handleTrkAction(request);

export default function TrackingDashboard() {
  const d = useLoaderData<typeof loader>();
  const rv = useRevalidator();
  const { post, busy } = useTrkAction();
  const st = d.stats;
  const steps: [boolean, string, string][] = [
    [d.setup.yun, "YunExpress keys (carrier data)", "/app/tracking/settings?tab=integration"],
    [d.setup.poll, "Automatic tracking on", "/app/tracking"],
    [d.setup.page, "Tracking page on", "/app/tracking/page"],
    [d.setup.omnisend, "Customer emails via Omnisend", "/app/tracking/notifications"],
    [d.setup.paypal, "PayPal tracking sync (after Track123 is removed)", "/app/tracking/settings?tab=integration"],
    [d.setup.shopify, "Statuses + tracking links in Shopify orders (after Track123 is removed)", "/app/tracking/settings"],
  ];
  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {d.setup.poll ? <s-badge tone="success">Auto-tracking on</s-badge> : <s-badge>Auto-tracking off</s-badge>}
          <s-button
            variant={d.setup.poll ? "secondary" : "primary"}
            loading={busy("poll") || undefined}
            onClick={() => post({ intent: "poll", on: d.setup.poll ? "0" : "1" })}
          >
            {d.setup.poll ? "Turn off" : "Turn on"}
          </s-button>
          <s-button variant="secondary" disabled={d.running || undefined} loading={busy("run") || d.running || undefined} onClick={() => post({ intent: "run" })}>
            Sync now
          </s-button>
          <s-button variant="tertiary" loading={rv.state === "loading" || undefined} onClick={() => rv.revalidate()}>
            Refresh
          </s-button>
          <span style={{ fontSize: 12, color: "#616161" }}>
            Last sync: {fmt(d.state.lastTickAt) || "never"}
            {d.state.lastError ? ` · ${d.state.lastError}` : ""} · {d.total} shipments stored
          </span>
        </s-stack>
      </s-section>

      {steps.some(([ok]) => !ok) ? (
        <s-section heading="Setup">
          <div style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 13 }}>
            {steps.map(([ok, label, to]) => (
              <div key={label} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                <span style={{ width: 18, color: ok ? "#1b6b31" : "#8a8a8a" }}>{ok ? "✓" : "○"}</span>
                {ok ? <span>{label}</span> : <Link to={to}>{label}</Link>}
              </div>
            ))}
          </div>
        </s-section>
      ) : null}

      <s-section heading="Last 30 days">
        <Grid>
          <Kpi label="Exception" value={st.byStatus.exception} />
          <Kpi label="Failed attempt" value={st.byStatus.attempt_fail} />
          <Kpi label="Pending" value={st.byStatus.pending} />
          <Kpi label="Delivered" value={st.byStatus.delivered} hint={`${st.deliveryRate}% of ${st.total}`} />
          <Kpi label="Avg. transit time" value={st.transit.avg != null ? `${st.transit.avg} d` : "—"} />
          <Kpi label="Tracking page lookups" value={d.look.lookups} hint={`${d.look.found} found`} />
        </Grid>
      </s-section>

      <s-section heading="Shipments that need your attention">
        <div style={{ ...card, display: "flex", flexDirection: "column", gap: 8, fontSize: 13 }}>
          {(
            [
              ["Failed attempt", "stuck for more than 3 days", d.stats.perf.attemptStuck, "attempt_fail"],
              ["Out for delivery", "stuck for more than 3 days", d.stats.perf.outStuck, "out_for_delivery"],
              ["No updates", "more than 2 weeks", d.stats.perf.noUpdates, "stuck"],
            ] as const
          ).map(([t, sub, n, f]) => (
            <Link key={t} to={`/app/tracking/orders?status=${f}`} style={{ display: "flex", justifyContent: "space-between", color: "#303030", textDecoration: "none" }}>
              <span>
                <b>{t}</b> <span style={{ color: "#616161" }}>– {sub}</span>
              </span>
              <span>{n} ›</span>
            </Link>
          ))}
        </div>
      </s-section>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <div style={{ flex: "1 1 420px" }}>
          <s-section heading="Shipments by status">
            <ShareBar
              parts={TRK_STATUS_ORDER.map((k) => ({ key: k, value: st.byStatus[k], color: STATUS_COLOR[k], label: TRK_STATUS_LABEL[k] }))}
            />
          </s-section>
        </div>
        <div style={{ flex: "1 1 360px" }}>
          <s-section heading="Top carriers">
            <HBars rows={st.carriers.slice(0, 5).map((c) => ({ label: c.name, value: c.count }))} />
            <div style={{ height: 12 }} />
            <HBars rows={st.lastMile.slice(0, 5).map((c) => ({ label: `→ ${c.name}`, value: c.count, color: "#2fb3c2" }))} />
          </s-section>
        </div>
      </div>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
