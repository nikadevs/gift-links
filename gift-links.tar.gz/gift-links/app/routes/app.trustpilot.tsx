import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useFetcher } from "react-router";
import { authenticate } from "../shopify.server";
import { readTrustpilot, refreshTrustpilot, trustpilotError, importTrustpilotSnapshot } from "../trustpilot.server";
export async function loader({ request }: LoaderFunctionArgs) {
  await authenticate.admin(request);
  return { data: await readTrustpilot(), error: trustpilotError() };
}
export async function action({ request }: ActionFunctionArgs) {
  await authenticate.admin(request);
  const form = await request.formData();
  if (form.get("intent") === "import") {
    try {
      await importTrustpilotSnapshot(String(form.get("snapshot") || ""));
      return { error: "", message: "Browser snapshot saved successfully." };
    } catch (e) { return { error: (e as Error).message, message: "" }; }
  }
  await refreshTrustpilot(true);
  return { error: trustpilotError(), message: "" };
}
export default function Trustpilot() {
  const { data, error } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  return <s-page heading="Trustpilot Reviews"><s-section heading="WoodenCrew · daily cache">
    <s-paragraph>{data ? `${data.score} / 5 · ${data.label} · ${data.count} reviews` : "Waiting for the first successful sync."}</s-paragraph>
    <s-paragraph>{data ? `Last successful update: ${data.updatedAt}` : ""}</s-paragraph>
    <s-paragraph>{fetcher.data?.error || error}</s-paragraph>
    <s-paragraph>{fetcher.data?.message}</s-paragraph>
    <fetcher.Form method="post"><s-button type="submit" disabled={fetcher.state !== "idle"}>Sync now</s-button></fetcher.Form>
    <s-paragraph>Add the Trustpilot Reviews app block in the theme editor. Desktop: two columns. Mobile: stacked with a 20px gap. Five latest five-star reviews rotate every seven seconds, with bullets only. The card and logo link to the WoodenCrew Trustpilot profile. The collage reuses loaded product review photos from Judge.me.</s-paragraph>
    <s-paragraph>The server checks for an update every 24 hours. If direct requests fail, it tries a server browser. Your computer can be switched off. A failed update preserves the last successful snapshot and shows the error above.</s-paragraph>
    <s-section heading="Browser snapshot import">
      <s-paragraph>If Trustpilot blocks the server, a fresh public browser snapshot can be imported here using Shopify admin authentication. No paid Trustpilot API is needed.</s-paragraph>
      <fetcher.Form method="post">
        <input type="hidden" name="intent" value="import" />
        <s-text-area label="Trustpilot snapshot JSON" name="snapshot" rows={6} />
        <s-button type="submit" disabled={fetcher.state !== "idle"}>Import browser snapshot</s-button>
      </fetcher.Form>
    </s-section>
    {data?.reviews.map(r => <s-section key={r.id} heading={`${r.author} · ${r.date.slice(0, 10)}`}><s-paragraph>{r.text}</s-paragraph></s-section>)}
  </s-section></s-page>;
}
