import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useFetcher } from "react-router";
import { authenticate } from "../shopify.server";
import { readTrustpilot, refreshTrustpilot, trustpilotError, importTrustpilotSnapshot } from "../trustpilot.server";
export async function loader({ request }: LoaderFunctionArgs) {
  await authenticate.admin(request);
  return { data: await readTrustpilot(), error: trustpilotError() };
}
export async function action({ request }: ActionFunctionArgs) {
  await authenticate.admin(request);
  const form = await request.formData();
  if (form.get("intent") === "import") {
    try {
      await importTrustpilotSnapshot(String(form.get("snapshot") || ""));
      return { error: "", message: "Browser snapshot saved successfully." };
    } catch (e) { return { error: (e as Error).message, message: "" }; }
  }
  await refreshTrustpilot();
  return { error: trustpilotError(), message: "" };
}
export default function Trustpilot() {
  const { data, error } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  return <s-page heading="Trustpilot Reviews"><s-section heading="WoodenCrew · daily cache">
    <s-paragraph>{data ? `${data.score} / 5 · ${data.label} · ${data.count} reviews` : "Waiting for the first successful sync."}</s-paragraph>
    <s-paragraph>{data ? `Last successful update: ${data.updatedAt}` : ""}</s-paragraph>
    <s-paragraph>{fetcher.data?.error || error}</s-paragraph>
    <s-paragraph>{fetcher.data?.message}</s-paragraph>
    <fetcher.Form method="post"><s-button type="submit" disabled={fetcher.state !== "idle"}>Sync if due</s-button></fetcher.Form>
    <s-paragraph>Add the Trustpilot Reviews app block in the theme editor. Desktop: two columns. Mobile: stacked with a 20px gap. Seven latest five-star reviews rotate every seven seconds, with bullets only. The card and logo link to the WoodenCrew Trustpilot profile. The collage reuses loaded product review photos from Judge.me.</s-paragraph>
    <s-paragraph>The initial snapshot was captured from the public brand page on October 11, 2026. Direct scheduled requests currently receive HTTP 403 from Trustpilot; the last successful snapshot stays visible until the source can be refreshed.</s-paragraph>
    <s-section heading="Browser snapshot import">
      <s-paragraph>Daily Codex automation can read the public profile in Chrome and upload a fresh snapshot here. This replaces only the cached public reviews; it requires Shopify admin authentication. No paid Trustpilot API is needed.</s-paragraph>
      <fetcher.Form method="post">
        <input type="hidden" name="intent" value="import" />
        <s-text-area label="Trustpilot snapshot JSON" name="snapshot" rows={6} />
        <s-button type="submit" disabled={fetcher.state !== "idle"}>Import browser snapshot</s-button>
      </fetcher.Form>
    </s-section>
    {data?.reviews.map(r => <s-section key={r.id} heading={`${r.author} · ${r.date.slice(0, 10)}`}><s-paragraph>{r.text}</s-paragraph></s-section>)}
  </s-section></s-page>;
}
