import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useFetcher } from "react-router";
import { authenticate } from "../shopify.server";
import { readTrustpilot, refreshTrustpilot, trustpilotError } from "../trustpilot.server";
export async function loader({ request }: LoaderFunctionArgs) {
  await authenticate.admin(request);
  return { data: await readTrustpilot(), error: trustpilotError() };
}
export async function action({ request }: ActionFunctionArgs) {
  await authenticate.admin(request);
  await refreshTrustpilot();
  return { error: trustpilotError() };
}
export default function Trustpilot() {
  const { data, error } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  return <s-page heading="Trustpilot Reviews"><s-section heading="WoodenCrew · daily cache">
    <s-paragraph>{data ? `${data.score} / 5 · ${data.label} · ${data.count} reviews` : "Waiting for the first successful sync."}</s-paragraph>
    <s-paragraph>{data ? `Last successful update: ${data.updatedAt}` : ""}</s-paragraph>
    <s-paragraph>{fetcher.data?.error || error}</s-paragraph>
    <fetcher.Form method="post"><s-button type="submit" disabled={fetcher.state !== "idle"}>Sync if due</s-button></fetcher.Form>
    <s-paragraph>Add the Trustpilot Reviews app block in the theme editor. Desktop: two columns. Mobile: stacked with a 20px gap. Seven latest five-star reviews rotate every seven seconds. The collage reuses loaded product review photos from Judge.me.</s-paragraph>
    {data?.reviews.map(r => <s-section key={r.id} heading={`${r.author} · ${r.date.slice(0, 10)}`}><s-paragraph>{r.text}</s-paragraph></s-section>)}
  </s-section></s-page>;
}
