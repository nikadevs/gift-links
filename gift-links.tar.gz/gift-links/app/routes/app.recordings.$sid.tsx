import type { LoaderFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { getSession } from "../rec.server";

/** Old links to one recording → the visitor page, opened at that visit. */
export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { session, redirect } = await authenticate.admin(request);
  const m = await getSession(session.shop, String(params.sid ?? ""));
  if (!m) return redirect("/app/recordings");
  return redirect(`/app/recordings/v/${m.vid}?s=${m.id}`);
};
