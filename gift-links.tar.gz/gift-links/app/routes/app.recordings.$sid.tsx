import type { HeadersFunction, LinksFunction, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useNavigate } from "react-router";
import { useEffect, useRef, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import playerCss from "rrweb-player/dist/style.css?url";
import { authenticate } from "../shopify.server";
import { getSession } from "../rec.server";
import { fmtBytes, fmtDuration } from "../rec.shared";

/** Session Recordings — replay one visit (rrweb-player, loaded in the browser only). */
export const links: LinksFunction = () => [{ rel: "stylesheet", href: playerCss }];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const m = await getSession(session.shop, String(params.sid ?? ""));
  if (!m) throw new Response("Recording not found", { status: 404 });
  const { ua, ...rest } = m;
  return { rec: { ...rest, ua } };
};

type PlayerApi = {
  goto: (offset: number, play?: boolean) => void;
  getMetaData: () => { startTime: number; endTime: number; totalTime: number };
  $destroy?: () => void;
  triggerResize?: () => void;
};

const TAGS = { "Add to cart": "#2e7d32", "Checkout click": "#1565c0" };

export default function Recording() {
  const { rec } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const box = useRef<HTMLDivElement>(null);
  const player = useRef<PlayerApi | null>(null);
  const [state, setState] = useState<"loading" | "ready" | "empty" | "error">("loading");
  const [msg, setMsg] = useState("");
  const [start, setStart] = useState(0);

  useEffect(() => {
    let dead = false;
    (async () => {
      try {
        const res = await fetch(`/app/rec-events/${rec.id}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const events = (await res.json()) as { type: number; timestamp: number }[];
        events.sort((a, b) => a.timestamp - b.timestamp);
        if (dead) return;
        if (events.filter((e) => e.type === 2).length === 0) {
          setState("empty");
          return;
        }
        const { default: Player } = await import("rrweb-player");
        if (dead || !box.current) return;
        box.current.innerHTML = "";
        const width = Math.max(320, box.current.clientWidth);
        const height = Math.round(Math.min(window.innerHeight * 0.72, Math.max(360, width * 0.6)));
        const p = new Player({
          target: box.current,
          props: {
            // rrweb types are stricter than what we store; the data is rrweb's own
            events: events as never,
            width,
            height,
            autoPlay: true,
            skipInactive: true,
            speedOption: [1, 2, 4, 8],
            tags: TAGS,
            mouseTail: { strokeStyle: "#E8660E", lineWidth: 2, duration: 600 },
          },
        }) as unknown as PlayerApi;
        player.current = p;
        setStart(events[0].timestamp);
        setState("ready");
      } catch (e) {
        if (!dead) {
          setMsg(e instanceof Error ? e.message : String(e));
          setState("error");
        }
      }
    })();
    return () => {
      dead = true;
      player.current?.$destroy?.();
      player.current = null;
    };
  }, [rec.id]);

  const jump = (t: number) => {
    if (!player.current || !start) return;
    player.current.goto(Math.max(0, t - start), true);
  };

  return (
    <s-page inlineSize="large" heading={`Recording · ${new Date(rec.start).toLocaleString()}`}>
      <s-button slot="secondary-actions" onClick={() => navigate("/app/recordings")}>
        ← All recordings
      </s-button>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          <s-text>
            {fmtDuration(rec.end - rec.start)} · {rec.pages.length} page{rec.pages.length === 1 ? "" : "s"} ·{" "}
            {rec.device} · {rec.os} · {rec.browser} · {rec.w}×{rec.h}
          </s-text>
          {rec.atc ? <s-badge tone="success">Add to cart</s-badge> : null}
          {rec.checkout ? <s-badge tone="info">Checkout</s-badge> : null}
          <s-text color="subdued">
            {rec.utm || "direct"} · {rec.lang} {rec.tz} · {fmtBytes(rec.bytes)}
          </s-text>
        </s-stack>
      </s-section>
      <s-section>
        {state === "loading" ? <s-spinner accessibilityLabel="Loading recording" /> : null}
        {state === "empty" ? (
          <s-banner tone="warning">
            This recording has no page snapshot yet (the visitor left within a second, or data is still
            arriving). Try again in a few seconds.
          </s-banner>
        ) : null}
        {state === "error" ? <s-banner tone="critical">Couldn’t load the recording: {msg}</s-banner> : null}
        <div ref={box} style={{ width: "100%" }} />
      </s-section>
      <s-section heading="Pages in this visit">
        <ol style={{ margin: 0, paddingLeft: 20, fontSize: 14, lineHeight: 1.7 }}>
          {rec.pages.map((p) => (
            <li key={p.p}>
              <button
                type="button"
                onClick={() => jump(p.t)}
                style={{ background: "none", border: 0, padding: 0, color: "#005bd3", cursor: "pointer", font: "inherit", textAlign: "left" }}
              >
                {new Date(p.t).toLocaleTimeString()} — {p.url}
              </button>
              {p.title ? <span style={{ color: "#616161" }}> · {p.title}</span> : null}
            </li>
          ))}
        </ol>
        {rec.ref ? (
          <s-box paddingBlockStart="base">
            <s-text color="subdued">Referrer: {rec.ref}</s-text>
          </s-box>
        ) : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
