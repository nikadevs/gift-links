import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useEffect, useState } from "react";
import {
  useFetcher,
  useLoaderData,
  useNavigate,
  useRevalidator,
  useSearchParams,
} from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadUpsellConfig, saveUpsellConfig } from "../upsells.server";
import { offerTriggerSummary } from "../upsells.shared";
import {
  STATS_WINDOW_DAYS,
  getUpsellStats,
  summarize,
} from "../upsell-stats.server";

const PERIODS = [7, 30, 60];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const d = Number(url.searchParams.get("days"));
  const days = PERIODS.includes(d) ? d : 30;

  const [{ config }, stats] = await Promise.all([
    loadUpsellConfig(admin),
    getUpsellStats(admin),
  ]);
  const sum = summarize(
    stats,
    days,
    config.offers.map((o) => o.variantId),
  );
  return {
    days,
    stats: {
      status: stats.status,
      error: stats.error ?? "",
      computedAt: stats.computedAt ?? "",
      currency: stats.currency ?? "USD",
      windowDays: stats.windowDays || STATS_WINDOW_DAYS,
    },
    totals: {
      upsellRevenue: sum.upsellRevenue,
      conversions: sum.conversions,
      boostPct: sum.boostPct,
      sales: sum.sales,
      orders: sum.orders,
    },
    offers: config.offers.map((o) => ({
      ...o,
      where: offerTriggerSummary(o),
      conversions: sum.perVariant[o.variantId]?.conversions ?? 0,
      revenue: sum.perVariant[o.variantId]?.revenue ?? 0,
    })),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const id = String(form.get("id"));

  if (intent === "refresh-stats") {
    await getUpsellStats(admin, true);
    return { ok: true, intent };
  }

  const { installationId, config } = await loadUpsellConfig(admin);
  if (intent === "delete") {
    config.offers = config.offers.filter((o) => o.id !== id);
  } else if (intent === "toggle") {
    config.offers = config.offers.map((o) =>
      o.id === id
        ? { ...o, active: !o.active, updatedAt: new Date().toISOString() }
        : o,
    );
  }
  await saveUpsellConfig(admin, installationId, config);
  return { ok: true, intent };
};

function ago(iso: string) {
  if (!iso) return "never";
  const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
}

export default function Upsells() {
  const { offers, stats, totals, days } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const [, setParams] = useSearchParams();
  const [confirmId, setConfirmId] = useState("");

  const money = (n: number) => {
    try {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: stats.currency || "USD",
        maximumFractionDigits: n >= 1000 ? 0 : 2,
      }).format(n);
    } catch {
      return `$${n.toFixed(2)}`;
    }
  };

  // while the background collection runs, re-check every 4 s
  const running = stats.status === "running";
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => {
      if (revalidator.state === "idle") revalidator.revalidate();
    }, 4000);
    return () => clearInterval(t);
  }, [running, revalidator]);

  const submit = (intent: string, id = "") =>
    fetcher.submit({ intent, id }, { method: "POST" });

  const statusLine =
    stats.status === "running"
      ? "Collecting orders…"
      : stats.status === "no_access"
        ? "No access to orders yet"
        : stats.status === "error"
          ? `Could not update: ${stats.error}`
          : `Updated ${ago(stats.computedAt)}`;

  return (
    <s-page inlineSize="large" heading="Checkbox Upsell">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={() => navigate("/app/upsells/new")}
      >
        New checkbox
      </s-button>

      {stats.status === "no_access" ? (
        <s-banner tone="warning" heading="Allow the app to read orders">
          Statistics need the “Read orders” permission. Open the app from
          Shopify admin → Apps → WoodenCrew Apps and approve the updated
          permissions, then press Refresh.
        </s-banner>
      ) : null}

      <s-section>
        <s-stack direction="block" gap="base">
          <s-stack
            direction="inline"
            gap="base"
            alignItems="center"
            justifyContent="space-between"
          >
            <s-stack direction="inline" gap="small-200" alignItems="center">
              {PERIODS.map((p) => (
                <s-button
                  key={p}
                  variant={p === days ? "primary" : "secondary"}
                  onClick={() => setParams({ days: String(p) })}
                >
                  {`Last ${p} days`}
                </s-button>
              ))}
            </s-stack>
            <s-stack direction="inline" gap="small-200" alignItems="center">
              <s-text color="subdued">{statusLine}</s-text>
              <s-button
                variant="tertiary"
                onClick={() => submit("refresh-stats")}
                {...(running || fetcher.state !== "idle"
                  ? { disabled: true }
                  : {})}
              >
                Refresh
              </s-button>
            </s-stack>
          </s-stack>
          <s-grid gridTemplateColumns="1fr 1fr" gap="base">
            <s-box padding="base" border="base" borderRadius="base">
              <s-stack direction="block" gap="small-200">
                <s-text type="strong">Revenue</s-text>
                <s-heading>{money(totals.upsellRevenue)}</s-heading>
                <s-text color="subdued">
                  {`${totals.conversions} upsell${totals.conversions === 1 ? "" : "s"} sold`}
                </s-text>
              </s-stack>
            </s-box>
            <s-box padding="base" border="base" borderRadius="base">
              <s-stack direction="block" gap="small-200">
                <s-text type="strong">Revenue Boost from Upsells</s-text>
                <s-heading>{`${totals.boostPct}%`}</s-heading>
                <s-text color="subdued">
                  {`of ${money(totals.sales)} store sales (${totals.orders} orders)`}
                </s-text>
              </s-stack>
            </s-box>
          </s-grid>
          <s-text color="subdued">
            {`Counts order lines added by these checkboxes, including AXE Checkbox Upsell history. Shopify shares the last ${stats.windowDays} days of orders with apps.`}
          </s-text>
        </s-stack>
      </s-section>

      <s-section heading="How it works">
        <s-ordered-list>
          <s-list-item>Pick the product the checkbox adds.</s-list-item>
          <s-list-item>
            Choose where it shows: all products, some products or collections.
          </s-list-item>
          <s-list-item>
            Shopper ticks it → it is added in the same request as the main
            product, at its normal price (use compare-at price for the
            strike-through).
          </s-list-item>
        </s-ordered-list>
        <s-paragraph>
          The app embed “Checkbox Upsell” must be on in your theme.{" "}
          <s-link href="/app/setup">Setup guide</s-link>
        </s-paragraph>
      </s-section>

      {offers.length === 0 ? (
        <s-section>
          <s-stack direction="block" gap="base" alignItems="center">
            <s-heading>No checkboxes yet</s-heading>
            <s-paragraph>
              Add a checkbox like “Skip The Line” or “Gift box” above the Add to
              cart button. When the shopper ticks it, that product goes into the
              cart together with the main product.
            </s-paragraph>
            <s-button
              variant="primary"
              onClick={() => navigate("/app/upsells/new")}
            >
              Create first checkbox
            </s-button>
          </s-stack>
        </s-section>
      ) : (
        <s-section padding="none">
          <s-table>
            <s-table-header-row>
              <s-table-header>Checkbox</s-table-header>
              <s-table-header>Adds to cart</s-table-header>
              <s-table-header>Shown on</s-table-header>
              <s-table-header>Order</s-table-header>
              <s-table-header>Status</s-table-header>
              <s-table-header format="numeric">Conversions</s-table-header>
              <s-table-header format="numeric">Revenue</s-table-header>
              <s-table-header>Actions</s-table-header>
            </s-table-header-row>
            <s-table-body>
              {offers.map((o) => (
                <s-table-row key={o.id}>
                  <s-table-cell>
                    <s-stack direction="block" gap="none">
                      <s-link href={`/app/upsells/${o.id}`}>{o.name}</s-link>
                      <s-text color="subdued">{o.title}</s-text>
                    </s-stack>
                  </s-table-cell>
                  <s-table-cell>
                    <s-stack
                      direction="inline"
                      gap="small-200"
                      alignItems="center"
                    >
                      {o.image ? (
                        <s-thumbnail src={o.image} alt="" size="small-200" />
                      ) : null}
                      <s-text>
                        {o.productTitle || `Variant ${o.variantId}`}
                      </s-text>
                    </s-stack>
                  </s-table-cell>
                  <s-table-cell>{o.where}</s-table-cell>
                  <s-table-cell>{String(o.order)}</s-table-cell>
                  <s-table-cell>
                    <s-badge tone={o.active ? "success" : "neutral"}>
                      {o.active ? "Enabled" : "Disabled"}
                    </s-badge>
                  </s-table-cell>
                  <s-table-cell>{String(o.conversions)}</s-table-cell>
                  <s-table-cell>{money(o.revenue)}</s-table-cell>
                  <s-table-cell>
                    <s-stack direction="inline" gap="small-200">
                      <s-button onClick={() => submit("toggle", o.id)}>
                        {o.active ? "Disable" : "Enable"}
                      </s-button>
                      <s-button
                        tone="critical"
                        variant="tertiary"
                        onClick={() => {
                          if (confirmId === o.id) {
                            setConfirmId("");
                            submit("delete", o.id);
                          } else setConfirmId(o.id);
                        }}
                      >
                        {confirmId === o.id
                          ? "Click again to delete"
                          : "Delete"}
                      </s-button>
                    </s-stack>
                  </s-table-cell>
                </s-table-row>
              ))}
            </s-table-body>
          </s-table>
        </s-section>
      )}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
