import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useEffect, useState } from "react";
import {
  Link,
  useFetcher,
  useLoaderData,
  useNavigate,
  useRevalidator,
  useSearchParams,
} from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadUpsellConfig, saveUpsellConfig } from "../upsells.server";
import { offerTriggerSummary } from "../upsells.shared";
import { loadShopDomain } from "../campaigns.server";
import {
  STATS_WINDOW_DAYS,
  getUpsellStats,
  summarize,
} from "../upsell-stats.server";
import {
  UPSELL_EMBED_MARKERS,
  checkEmbed,
  embedActivateUrl,
} from "../embed-status.server";

const PERIODS = [7, 30, 60];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const d = Number(url.searchParams.get("days"));
  const days = PERIODS.includes(d) ? d : 30;

  const [{ config }, stats, domain] = await Promise.all([
    loadUpsellConfig(admin),
    getUpsellStats(admin),
    loadShopDomain(admin),
  ]);
  const embed = await checkEmbed(domain, UPSELL_EMBED_MARKERS);
  const sum = summarize(
    stats,
    days,
    config.offers.map((o) => o.variantId),
  );
  return {
    days,
    embed: {
      state: embed,
      // eslint-disable-next-line no-undef
      activateUrl: embedActivateUrl(session.shop, process.env.SHOPIFY_API_KEY || "", "checkbox-upsell"),
    },
    stats: {
      status: stats.status,
      error: stats.error ?? "",
      computedAt: stats.computedAt ?? "",
      currency: stats.currency ?? "USD",
      windowDays: stats.windowDays || STATS_WINDOW_DAYS,
    },
    totals: {
      upsellRevenue: sum.upsellRevenue,
      conversions: sum.conversions,
      boostPct: sum.boostPct,
      sales: sum.sales,
      orders: sum.orders,
    },
    offers: config.offers.map((o) => ({
      ...o,
      where: offerTriggerSummary(o),
      conversions: sum.perVariant[o.variantId]?.conversions ?? 0,
      revenue: sum.perVariant[o.variantId]?.revenue ?? 0,
    })),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const id = String(form.get("id"));

  if (intent === "refresh-stats") {
    const domain = await loadShopDomain(admin);
    await Promise.all([
      getUpsellStats(admin, true),
      checkEmbed(domain, UPSELL_EMBED_MARKERS, true),
    ]);
    return { ok: true, intent };
  }

  const { installationId, config } = await loadUpsellConfig(admin);
  if (intent === "delete") {
    config.offers = config.offers.filter((o) => o.id !== id);
  } else if (intent === "toggle") {
    config.offers = config.offers.map((o) =>
      o.id === id
        ? { ...o, active: !o.active, updatedAt: new Date().toISOString() }
        : o,
    );
  }
  await saveUpsellConfig(admin, installationId, config);
  return { ok: true, intent };
};

function ago(iso: string) {
  if (!iso) return "never";
  const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
}

/* Our own table: Polaris s-table has a fixed 13px font, this one is 14px. */
const TABLE_CSS = `
.wcu-table{width:100%;border-collapse:collapse;font-size:14px;line-height:20px;color:#303030}
.wcu-table th{font-weight:550;text-align:left;color:#616161;background:#f7f7f7;padding:9px 12px;border-bottom:1px solid #e3e3e3;white-space:nowrap}
.wcu-table td{padding:10px 12px;border-bottom:1px solid #ebebeb;vertical-align:middle}
.wcu-table tr:last-child td{border-bottom:0}
.wcu-table tbody tr:hover td{background:#fafafa}
.wcu-table .num{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.wcu-table .sub{color:#616161}
.wcu-table a.name{color:#005bd3;text-decoration:none;font-weight:500}
.wcu-table a.name:hover{text-decoration:underline}
.wcu-table .prod{display:flex;align-items:center;gap:10px}
.wcu-table .prod img{width:32px;height:32px;object-fit:contain;border:1px solid #e3e3e3;border-radius:6px;background:#fff;flex:none}
.wcu-table .acts{display:flex;align-items:center;gap:8px;justify-content:flex-end;white-space:nowrap}
`;

export default function Upsells() {
  const { offers, stats, totals, days, embed } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const [, setParams] = useSearchParams();
  const [confirmId, setConfirmId] = useState("");

  const money = (n: number) => {
    try {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: stats.currency || "USD",
        maximumFractionDigits: n >= 1000 ? 0 : 2,
      }).format(n);
    } catch {
      return `$${n.toFixed(2)}`;
    }
  };

  // while the background collection runs, re-check every 4 s
  const running = stats.status === "running";
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => {
      if (revalidator.state === "idle") revalidator.revalidate();
    }, 4000);
    return () => clearInterval(t);
  }, [running, revalidator]);

  const submit = (intent: string, id = "") =>
    fetcher.submit({ intent, id }, { method: "POST" });

  const statusLine =
    stats.status === "running"
      ? "Collecting orders…"
      : stats.status === "no_access"
        ? "No access to orders yet"
        : stats.status === "error"
          ? `Could not update: ${stats.error}`
          : `Updated ${ago(stats.computedAt)}`;

  const embedBadge =
    embed.state === "on" ? (
      <s-badge tone="success">App embed: On</s-badge>
    ) : embed.state === "off" ? (
      <s-badge tone="critical">App embed: Off</s-badge>
    ) : (
      <s-badge tone="warning">App embed: can’t check</s-badge>
    );

  return (
    <s-page inlineSize="large" heading="Checkbox Upsell">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={() => navigate("/app/upsells/new")}
      >
        New checkbox
      </s-button>

      {stats.status === "no_access" ? (
        <s-banner tone="warning" heading="Allow the app to read orders">
          Statistics need the “Read orders” permission. Open the app from
          Shopify admin → Apps → WoodenCrew Apps and approve the updated
          permissions, then press Refresh.
        </s-banner>
      ) : null}

      {embed.state === "off" ? (
        <s-banner tone="critical" heading="Checkbox Upsell is switched off in your theme">
          Shoppers don’t see the checkboxes. Turn on the app embed “Checkbox
          Upsell” in the theme editor and press Save.{" "}
          <s-link href={embed.activateUrl} target="_blank">
            Turn on
          </s-link>
        </s-banner>
      ) : null}

      <s-section>
        <s-stack direction="block" gap="base">
          <s-stack
            direction="inline"
            gap="base"
            alignItems="center"
            justifyContent="space-between"
          >
            <s-stack direction="inline" gap="small-200" alignItems="center">
              {PERIODS.map((p) => (
                <s-button
                  key={p}
                  variant={p === days ? "primary" : "secondary"}
                  onClick={() => setParams({ days: String(p) })}
                >
                  {`Last ${p} days`}
                </s-button>
              ))}
            </s-stack>
            <s-stack direction="inline" gap="small-200" alignItems="center">
              {embedBadge}
              {embed.state !== "on" ? (
                <s-button
                  variant="secondary"
                  href={embed.activateUrl}
                  target="_blank"
                >
                  {embed.state === "off" ? "Turn on" : "Open theme editor"}
                </s-button>
              ) : null}
              <s-text color="subdued">{statusLine}</s-text>
              <s-button
                variant="tertiary"
                onClick={() => submit("refresh-stats")}
                {...(running || fetcher.state !== "idle"
                  ? { disabled: true }
                  : {})}
              >
                Refresh
              </s-button>
            </s-stack>
          </s-stack>
          <s-grid gridTemplateColumns="1fr 1fr" gap="base">
            <s-box padding="base" border="base" borderRadius="base">
              <s-stack direction="block" gap="small-200">
                <s-text type="strong">Revenue</s-text>
                <s-heading>{money(totals.upsellRevenue)}</s-heading>
                <s-text color="subdued">
                  {`${totals.conversions} upsell${totals.conversions === 1 ? "" : "s"} sold`}
                </s-text>
              </s-stack>
            </s-box>
            <s-box padding="base" border="base" borderRadius="base">
              <s-stack direction="block" gap="small-200">
                <s-text type="strong">Revenue Boost from Upsells</s-text>
                <s-heading>{`${totals.boostPct}%`}</s-heading>
                <s-text color="subdued">
                  {`of ${money(totals.sales)} store sales (${totals.orders} orders)`}
                </s-text>
              </s-stack>
            </s-box>
          </s-grid>
          <s-text color="subdued">
            {`Counts order lines added by these checkboxes, including AXE Checkbox Upsell history. Shopify shares the last ${stats.windowDays} days of orders with apps.`}
          </s-text>
        </s-stack>
      </s-section>

      {offers.length === 0 ? (
        <s-section>
          <s-stack direction="block" gap="base" alignItems="center">
            <s-heading>No checkboxes yet</s-heading>
            <s-paragraph>
              Add a checkbox like “Skip The Line” or “Gift box” above the Add to
              cart button. When the shopper ticks it, that product goes into the
              cart together with the main product.
            </s-paragraph>
            <s-button
              variant="primary"
              onClick={() => navigate("/app/upsells/new")}
            >
              Create first checkbox
            </s-button>
          </s-stack>
        </s-section>
      ) : (
        <s-section padding="none">
          <style>{TABLE_CSS}</style>
          <table className="wcu-table">
            <thead>
              <tr>
                <th>Checkbox</th>
                <th>Adds to cart</th>
                <th>Shown on</th>
                <th>Order</th>
                <th>Status</th>
                <th className="num">Conversions</th>
                <th className="num">Revenue</th>
                <th className="num">Actions</th>
              </tr>
            </thead>
            <tbody>
              {offers.map((o) => (
                <tr key={o.id}>
                  <td>
                    <Link className="name" to={`/app/upsells/${o.id}`}>
                      {o.name}
                    </Link>
                    <div className="sub">{o.title}</div>
                  </td>
                  <td>
                    <div className="prod">
                      {o.image ? <img src={o.image} alt="" /> : null}
                      <span>{o.productTitle || `Variant ${o.variantId}`}</span>
                    </div>
                  </td>
                  <td>{o.where}</td>
                  <td>{String(o.order)}</td>
                  <td>
                    <s-badge tone={o.active ? "success" : "neutral"}>
                      {o.active ? "Enabled" : "Disabled"}
                    </s-badge>
                  </td>
                  <td className="num">{String(o.conversions)}</td>
                  <td className="num">{money(o.revenue)}</td>
                  <td>
                    <div className="acts">
                      <s-button onClick={() => submit("toggle", o.id)}>
                        {o.active ? "Disable" : "Enable"}
                      </s-button>
                      <s-button
                        tone="critical"
                        variant="tertiary"
                        onClick={() => {
                          if (confirmId === o.id) {
                            setConfirmId("");
                            submit("delete", o.id);
                          } else setConfirmId(o.id);
                        }}
                      >
                        {confirmId === o.id
                          ? "Click again to delete"
                          : "Delete"}
                      </s-button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </s-section>
      )}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
