import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useState } from "react";
import { useFetcher, useLoaderData, useNavigate } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadUpsellConfig, saveUpsellConfig } from "../upsells.server";
import { offerTriggerSummary } from "../upsells.shared";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const { config } = await loadUpsellConfig(admin);
  return {
    offers: config.offers.map((o) => ({
      ...o,
      where: offerTriggerSummary(o),
    })),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const id = String(form.get("id"));
  const { installationId, config } = await loadUpsellConfig(admin);

  if (intent === "delete") {
    config.offers = config.offers.filter((o) => o.id !== id);
  } else if (intent === "toggle") {
    config.offers = config.offers.map((o) =>
      o.id === id
        ? { ...o, active: !o.active, updatedAt: new Date().toISOString() }
        : o,
    );
  }
  await saveUpsellConfig(admin, installationId, config);
  return { ok: true, intent };
};

export default function Upsells() {
  const { offers } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const [confirmId, setConfirmId] = useState("");

  const submit = (intent: string, id: string) =>
    fetcher.submit({ intent, id }, { method: "POST" });

  return (
    <s-page heading="Checkbox Upsell">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={() => navigate("/app/upsells/new")}
      >
        New checkbox
      </s-button>

      {offers.length === 0 ? (
        <s-section>
          <s-stack direction="block" gap="base" alignItems="center">
            <s-heading>No checkboxes yet</s-heading>
            <s-paragraph>
              Add a checkbox like “Skip The Line” or “Gift box” above the Add to
              cart button. When the shopper ticks it, that product goes into the
              cart together with the main product.
            </s-paragraph>
            <s-button
              variant="primary"
              onClick={() => navigate("/app/upsells/new")}
            >
              Create first checkbox
            </s-button>
          </s-stack>
        </s-section>
      ) : (
        <s-section padding="none">
          <s-table>
            <s-table-header-row>
              <s-table-header>Checkbox</s-table-header>
              <s-table-header>Adds to cart</s-table-header>
              <s-table-header>Shown on</s-table-header>
              <s-table-header>Order</s-table-header>
              <s-table-header>Status</s-table-header>
              <s-table-header>Actions</s-table-header>
            </s-table-header-row>
            <s-table-body>
              {offers.map((o) => (
                <s-table-row key={o.id}>
                  <s-table-cell>
                    <s-stack direction="block" gap="none">
                      <s-link href={`/app/upsells/${o.id}`}>{o.name}</s-link>
                      <s-text color="subdued">{o.title}</s-text>
                    </s-stack>
                  </s-table-cell>
                  <s-table-cell>
                    <s-stack
                      direction="inline"
                      gap="small-200"
                      alignItems="center"
                    >
                      {o.image ? (
                        <s-thumbnail src={o.image} alt="" size="small-200" />
                      ) : null}
                      <s-text>{o.productTitle || `Variant ${o.variantId}`}</s-text>
                    </s-stack>
                  </s-table-cell>
                  <s-table-cell>{o.where}</s-table-cell>
                  <s-table-cell>{String(o.order)}</s-table-cell>
                  <s-table-cell>
                    <s-badge tone={o.active ? "success" : "neutral"}>
                      {o.active ? "Enabled" : "Disabled"}
                    </s-badge>
                  </s-table-cell>
                  <s-table-cell>
                    <s-stack direction="inline" gap="small-200">
                      <s-button onClick={() => submit("toggle", o.id)}>
                        {o.active ? "Disable" : "Enable"}
                      </s-button>
                      <s-button
                        tone="critical"
                        variant="tertiary"
                        onClick={() => {
                          if (confirmId === o.id) {
                            setConfirmId("");
                            submit("delete", o.id);
                          } else setConfirmId(o.id);
                        }}
                      >
                        {confirmId === o.id ? "Click again to delete" : "Delete"}
                      </s-button>
                    </s-stack>
                  </s-table-cell>
                </s-table-row>
              ))}
            </s-table-body>
          </s-table>
        </s-section>
      )}

      <s-section slot="aside" heading="How it works">
        <s-ordered-list>
          <s-list-item>Pick the product the checkbox adds.</s-list-item>
          <s-list-item>
            Choose where it shows: all products, some products or collections.
          </s-list-item>
          <s-list-item>
            Shopper ticks it → it is added in the same request as the main
            product, at its normal price (use compare-at price for the
            strike-through).
          </s-list-item>
        </s-ordered-list>
        <s-paragraph>
          The app embed “Checkbox Upsell” must be on in your theme.{" "}
          <s-link href="/app/setup">Setup guide</s-link>
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
