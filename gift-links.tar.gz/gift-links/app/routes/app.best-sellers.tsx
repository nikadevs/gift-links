import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useEffect } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { BSP_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadBestSellingCollections, loadBspConfig, saveBspConfig } from "../bsp.server";

/**
 * Best Sellers Protection (replacement for Vitals «Best Sellers Protection»):
 * hides the "Best selling" sort option on collection and search pages.
 * No separate app embed: Turn on / Turn off writes wc_bsp.config.enabled;
 * the Gift Links embed prints the code.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config }, domain, defaults] = await Promise.all([
    loadBspConfig(admin),
    loadShopDomain(admin),
    loadBestSellingCollections(admin).catch(() => null),
  ]);
  const live = config.enabled
    ? await checkEmbed(domain, BSP_EMBED_MARKERS, url.searchParams.has("refresh"))
    : "off";
  return { config, live, domain, defaults };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadBspConfig(admin);
  const enabled = form.get("enabled") === "1";
  try {
    await saveBspConfig(admin, installationId, { ...config, enabled, updatedAt: new Date().toISOString() });
    return { ok: true as const, error: "", enabled };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e), enabled: config.enabled };
  }
};

export default function BestSellers() {
  const { config, live, domain, defaults } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const busy = fetcher.state !== "idle";

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      shopify.toast.show(
        fetcher.data.enabled ? "Best Sellers Protection turned on" : "Best Sellers Protection turned off",
      );
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const toggle = () => {
    const fd = new FormData();
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };

  return (
    <s-page inlineSize="large" heading="Best Sellers Protection">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? <s-badge tone="success">Active</s-badge> : <s-badge>Inactive</s-badge>}
          <s-button variant={config.enabled ? "secondary" : "primary"} loading={busy || undefined} onClick={toggle}>
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: code present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              <s-button variant="tertiary" href={`${domain || ""}/collections/all`} target="_blank">
                Open a collection
              </s-button>
            </>
          ) : null}
        </s-stack>
        {config.enabled && live === "off" ? (
          <s-banner tone="critical">
            The storefront doesn’t have the Best Sellers Protection code yet. It is printed by the “Gift
            Links” app embed — it must stay on (Theme editor → App embeds). Changes can take a minute to
            appear (theme cache).
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
      </s-section>

      <s-section heading="What it does">
        <s-paragraph>
          Prevent competitors from snooping around, by automatically hiding the “Best selling” sort
          option on your collection pages.
        </s-paragraph>
        <s-unordered-list>
          <s-list-item>
            Hides “Best selling” in the theme’s sort menu (dropdown, list or links) on collection and
            search pages.
          </s-list-item>
          <s-list-item>
            A link opened with <s-text type="strong">?sort_by=best-selling</s-text> is reloaded without
            it, so the page shows the collection’s normal order.
          </s-list-item>
          <s-list-item>
            You keep seeing the option while you are logged in to the Shopify admin in this browser.
          </s-list-item>
          <s-list-item>No extra files or requests: a few lines of CSS and JS, only on collection and search pages.</s-list-item>
        </s-unordered-list>
      </s-section>

      {defaults && defaults.length ? (
        <s-section heading="Collections sorted by best selling by default">
          <s-banner tone="warning">
            These collections are sorted by “Best selling” by default, so their page already shows
            products in sales order — hiding the menu option can’t hide that. To protect them, change
            “Sort” in the collection’s Products block (for example to “Manually”).
          </s-banner>
          <s-unordered-list>
            {defaults.map((c) => (
              <s-list-item key={c.id}>
                <s-link href={`shopify://admin/collections/${c.id.split("/").pop()}`} target="_top">
                  {c.title}
                </s-link>{" "}
                <s-text color="subdued">/collections/{c.handle}</s-text>
              </s-list-item>
            ))}
          </s-unordered-list>
        </s-section>
      ) : null}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
