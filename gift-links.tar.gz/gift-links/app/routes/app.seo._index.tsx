import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useEffect } from "react";
import { useFetcher, useLoaderData, useNavigate, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import {
  ensureEmbedConfig,
  jobStates,
  seoAuth,
  seoEmbedState,
} from "../seo/seo-context.server";
import { getHistory, getLatestReport, getPsiRuns, getSettings } from "../seo/seo-store.server";
import { startCrawl } from "../seo/seo-crawl.server";
import { startPsi } from "../seo/seo-psi.server";
import { cwvStatus, latestRuns } from "../seo/seo.shared";
import { check, fmtMs, type Finding } from "../seo/seo.shared";
import {
  FIX_LINK,
  SevBadge,
  SeoTabs,
  ago,
  groupFindings,
  scoreTone,
} from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, shop, origin } = await seoAuth(request);
  const [report, history, runs, jobs, settings, embed] = await Promise.all([
    getLatestReport(shop),
    getHistory(shop),
    getPsiRuns(shop),
    jobStates(shop),
    getSettings(shop),
    seoEmbedState(shop, origin),
    ensureEmbedConfig(admin),
  ]);
  const latest = latestRuns(runs).sort((a, b) => a.url.localeCompare(b.url));
  const findings: Finding[] = [...(report?.findings ?? [])];
  const home = latest.find((r) => r.strategy === "mobile" && new URL(r.url).pathname === "/");
  if (home && cwvStatus(home.field) === "fail")
    findings.push({
      check: "cwv_fail",
      url: home.url,
      detail: `mobile, ${home.field?.scope === "origin" ? "whole site" : "this URL"}`,
    });
  const groups = groupFindings(findings).filter((g) => g.def.severity !== "info");
  const psiError = runs.length && runs[runs.length - 1].error ? runs[runs.length - 1].error : "";
  return {
    origin,
    hasKey: !!(settings.psiKey || process.env.PSI_API_KEY),
    report: report
      ? {
          finishedAt: report.finishedAt,
          mode: report.mode,
          checked: report.checked,
          score: report.score,
          linksChecked: report.linksChecked,
          notes: report.notes,
        }
      : null,
    counts: {
      critical: findings.filter((f) => check(f.check).severity === "critical").length,
      high: findings.filter((f) => check(f.check).severity === "high").length,
      other: findings.filter((f) => ["medium", "low"].includes(check(f.check).severity)).length,
    },
    top: groups.slice(0, 10).map((g) => ({
      id: g.def.id,
      title: g.def.title,
      severity: g.def.severity,
      count: g.count,
      why: g.def.why,
      fixIn: g.def.fixIn,
    })),
    history: history.slice(-30),
    psi: latest.map((r) => ({
      url: r.url,
      strategy: r.strategy,
      at: r.at,
      performance: r.scores.performance,
      seo: r.scores.seo,
      lcp: r.lab.lcp,
      tbt: r.lab.tbt,
      cls: r.lab.cls,
      field: r.field
        ? {
            scope: r.field.scope,
            status: cwvStatus(r.field),
            lcp: r.field.lcp?.p75,
            inp: r.field.inp?.p75,
            cls: r.field.cls?.p75,
          }
        : null,
    })),
    psiError,
    jobs,
    embed,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { shop, origin } = await seoAuth(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  if (intent === "quick" || intent === "full") {
    const ok = await startCrawl(shop, origin, intent);
    return { ok, intent };
  }
  if (intent === "psi") {
    const settings = await getSettings(shop);
    const report = await getLatestReport(shop);
    const product =
      settings.keyPaths.find((p) => p.includes("/products/")) ??
      report?.pages.find((p) => p.kind === "product" && p.status === 200)?.url;
    const urls = [`${origin}/`, ...(product ? [new URL(product, origin).href] : [])];
    const ok = await startPsi(shop, urls);
    return { ok, intent };
  }
  return { ok: false, intent };
};

function Spark({ points }: { points: number[] }) {
  if (points.length < 2) return null;
  const w = 220;
  const h = 40;
  const min = Math.min(...points, 50);
  const max = 100;
  const xy = points.map((p, i) => [
    (i / (points.length - 1)) * w,
    h - ((p - min) / (max - min || 1)) * (h - 4) - 2,
  ]);
  return (
    <svg className="wcs-spark" width={w} height={h} viewBox={`0 0 ${w} ${h}`} aria-label="Score trend">
      <polyline
        points={xy.map((p) => p.join(",")).join(" ")}
        fill="none"
        stroke="#005bd3"
        strokeWidth="2"
      />
    </svg>
  );
}

export default function SeoOverview() {
  const d = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const running = d.jobs.crawl.status === "running" || d.jobs.psi.status === "running";

  useEffect(() => {
    if (!running && fetcher.state === "idle" && !fetcher.data) return;
    const t = setInterval(() => {
      if (revalidator.state === "idle") revalidator.revalidate();
    }, 3000);
    const stop = setTimeout(() => clearInterval(t), running ? 30 * 60 * 1000 : 8000);
    return () => {
      clearInterval(t);
      clearTimeout(stop);
    };
  }, [running, fetcher.state, fetcher.data, revalidator]);

  const run = (intent: string) => fetcher.submit({ intent }, { method: "POST" });
  const busy = fetcher.state !== "idle";

  const mobileHome = d.psi.find((p) => p.strategy === "mobile" && new URL(p.url).pathname === "/");
  const desktopHome = d.psi.find((p) => p.strategy === "desktop" && new URL(p.url).pathname === "/");

  return (
    <s-page inlineSize="large" heading="SEO & Speed">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={() => run("quick")}
        {...(d.jobs.crawl.status === "running" || busy ? { disabled: true } : {})}
      >
        Run audit
      </s-button>
      <s-button
        slot="secondary-actions"
        onClick={() => run("full")}
        {...(d.jobs.crawl.status === "running" || busy ? { disabled: true } : {})}
      >
        Full sitemap audit
      </s-button>
      <s-button
        slot="secondary-actions"
        onClick={() => run("psi")}
        {...(d.jobs.psi.status === "running" || busy ? { disabled: true } : {})}
      >
        Test speed (PageSpeed)
      </s-button>

      <SeoTabs />

      {d.embed.state === "off" ? (
        <s-banner tone="info" heading="Turn on the “SEO & Speed” app embed for the 404 log and instant navigation">
          The audit works without it. The embed adds nothing visible: it only reports
          “page not found” visits to this app and (if you switch it on in Speed) preloads
          the next page.{" "}
          <s-link href={d.embed.activateUrl} target="_blank">
            Turn on
          </s-link>
        </s-banner>
      ) : null}

      {!d.hasKey ? (
        <s-banner tone="warning" heading="Add a free PageSpeed API key">
          Google’s PageSpeed API without a key is shared by everyone and is almost always
          over its daily limit. Create a key (free, 25,000 tests/day) and paste it in{" "}
          <s-link href="/app/seo/settings">Settings</s-link>.
        </s-banner>
      ) : null}

      {d.jobs.crawl.status === "running" || d.jobs.psi.status === "running" ? (
        <s-banner tone="info" heading="Working…">
          {[d.jobs.crawl.status === "running" ? d.jobs.crawl.progress : "", d.jobs.psi.status === "running" ? d.jobs.psi.progress : ""]
            .filter(Boolean)
            .join(" · ")}
        </s-banner>
      ) : null}
      {d.jobs.crawl.status === "error" ? (
        <s-banner tone="critical" heading="Audit failed">
          {d.jobs.crawl.error}
        </s-banner>
      ) : null}
      {d.psiError && d.jobs.psi.status !== "running" ? (
        <s-banner tone="warning" heading="Last PageSpeed test failed">
          {d.psiError}
        </s-banner>
      ) : null}

      <s-section>
        <div className="wcs-kpis">
          <div className="wcs-kpi">
            <div className="k">Health score</div>
            <div className={`v ${scoreTone(d.report?.score)}`}>{d.report ? d.report.score : "—"}</div>
            <div className="s">
              {d.report
                ? `${d.report.checked} pages · ${d.report.mode} audit · ${ago(d.report.finishedAt)}`
                : "Run the first audit"}
            </div>
            <Spark points={d.history.map((h) => h.score)} />
          </div>
          <div className="wcs-kpi">
            <div className="k">Issues</div>
            <div className={`v ${d.counts.critical ? "critical" : d.counts.high ? "warning" : "success"}`}>
              {d.counts.critical + d.counts.high + d.counts.other}
            </div>
            <div className="s">{`${d.counts.critical} critical · ${d.counts.high} high · ${d.counts.other} medium/low`}</div>
          </div>
          <div className="wcs-kpi">
            <div className="k">Mobile speed (home, lab)</div>
            <div className={`v ${scoreTone(mobileHome?.performance)}`}>{mobileHome?.performance ?? "—"}</div>
            <div className="s">
              {mobileHome ? `LCP ${fmtMs(mobileHome.lcp)} · TBT ${fmtMs(mobileHome.tbt)} · ${ago(mobileHome.at)}` : "No test yet"}
            </div>
          </div>
          <div className="wcs-kpi">
            <div className="k">Desktop speed (home, lab)</div>
            <div className={`v ${scoreTone(desktopHome?.performance)}`}>{desktopHome?.performance ?? "—"}</div>
            <div className="s">
              {desktopHome ? `LCP ${fmtMs(desktopHome.lcp)} · TBT ${fmtMs(desktopHome.tbt)}` : "No test yet"}
            </div>
          </div>
          <div className="wcs-kpi">
            <div className="k">Core Web Vitals (real users)</div>
            <div
              className={`v ${mobileHome?.field?.status === "pass" ? "success" : mobileHome?.field?.status === "fail" ? "critical" : ""}`}
            >
              {mobileHome?.field?.status === "pass" ? "Passed" : mobileHome?.field?.status === "fail" ? "Failed" : "—"}
            </div>
            <div className="s">
              {mobileHome?.field
                ? `Mobile, 28 days, ${mobileHome.field.scope === "origin" ? "whole site" : "home page"}: LCP ${fmtMs(mobileHome.field.lcp)} · INP ${fmtMs(mobileHome.field.inp)} · CLS ${mobileHome.field.cls ?? "—"}`
                : "From Google’s Chrome UX Report"}
            </div>
          </div>
        </div>
      </s-section>

      <s-section heading="Fix first">
        {d.top.length === 0 ? (
          <s-paragraph>
            {d.report ? "No problems found in the checked pages." : "Run an audit to see what to fix."}
          </s-paragraph>
        ) : (
          <table className="wcs-table">
            <thead>
              <tr>
                <th>Issue</th>
                <th>Severity</th>
                <th className="num">Found</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {d.top.map((t) => (
                <tr key={t.id}>
                  <td>
                    <a
                      href={`/app/seo/issues#${t.id}`}
                      onClick={(e) => {
                        e.preventDefault();
                        navigate(`/app/seo/issues?check=${t.id}`);
                      }}
                    >
                      {t.title}
                    </a>
                    <div className="sub">{t.why}</div>
                  </td>
                  <td>
                    <SevBadge severity={t.severity} />
                  </td>
                  <td className="num">{t.count}</td>
                  <td className="num">
                    {FIX_LINK[t.fixIn] ? (
                      <s-button variant="tertiary" onClick={() => navigate(FIX_LINK[t.fixIn]!.href)}>
                        {FIX_LINK[t.fixIn]!.label}
                      </s-button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
        {d.report?.notes?.length ? (
          <s-paragraph>
            <s-text color="subdued">{d.report.notes.join(" ")}</s-text>
          </s-paragraph>
        ) : null}
      </s-section>

      <s-section slot="aside" heading="How it works">
        <s-paragraph>
          The audit downloads your public pages like Google does (without running app
          scripts), checks titles, descriptions, headings, canonical/noindex, structured
          data, links, images and what slows the page down.
        </s-paragraph>
        <s-paragraph>
          Every day it re-checks key pages automatically and once a week the whole sitemap.
          PageSpeed tests the home page and a product on mobile and desktop.
        </s-paragraph>
        <s-paragraph>
          Fixes that change data (meta tags, ALT text, redirects, hiding pages) are done only
          when you press Save. Theme code is never changed by the app.
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
