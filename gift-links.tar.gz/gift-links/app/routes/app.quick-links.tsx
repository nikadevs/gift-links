import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useEffect } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { QL_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadQlConfig, saveQlConfig } from "../ql.server";

/**
 * Quick Links (replacement for Vitals «Quick Access Links»): a bar with admin
 * links at the top of the storefront, visible only to people logged in to the
 * Shopify admin. No separate app embed: Turn on / Turn off writes
 * wc_ql.config.enabled; the Gift Links embed prints the code.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config }, domain] = await Promise.all([loadQlConfig(admin), loadShopDomain(admin)]);
  const live = config.enabled
    ? await checkEmbed(domain, QL_EMBED_MARKERS, url.searchParams.has("refresh"))
    : "off";
  return { config, live, domain };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadQlConfig(admin);
  const enabled = form.get("enabled") === "1";
  try {
    await saveQlConfig(admin, installationId, { ...config, enabled, updatedAt: new Date().toISOString() });
    return { ok: true as const, error: "", enabled };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e), enabled: config.enabled };
  }
};

export default function QuickLinks() {
  const { config, live, domain } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const busy = fetcher.state !== "idle";

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      shopify.toast.show(fetcher.data.enabled ? "Quick Links turned on" : "Quick Links turned off");
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const toggle = () => {
    const fd = new FormData();
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };

  return (
    <s-page inlineSize="large" heading="Quick Links">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? <s-badge tone="success">Active</s-badge> : <s-badge>Inactive</s-badge>}
          <s-button variant={config.enabled ? "secondary" : "primary"} loading={busy || undefined} onClick={toggle}>
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: code present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              <s-button variant="tertiary" href={domain || "/"} target="_blank">
                Open store
              </s-button>
            </>
          ) : null}
        </s-stack>
        {config.enabled && live === "off" ? (
          <s-banner tone="critical">
            The storefront doesn’t have the Quick Links code yet. It is printed by the “Gift Links” app
            embed — it must stay on (Theme editor → App embeds). Changes can take a minute to appear
            (theme cache).
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
      </s-section>

      <s-section heading="What it does">
        <s-paragraph>
          Quickly access the most important sections of your Shopify admin using a bar at the top of
          the store that only appears when you are logged in to the admin. Customers never see it.
        </s-paragraph>
        <s-unordered-list>
          <s-list-item>Shopify Admin, WoodenCrew Apps, Apps</s-list-item>
          <s-list-item>Edit theme — opens the theme editor on the page you are looking at</s-list-item>
          <s-list-item>
            Edit product / collection / page / blog / blog post — shown in yellow on those pages
          </s-list-item>
          <s-list-item>
            × hides the bar in this browser (a small dark corner at the top right brings it back); on a
            phone the links open with the ☰ button
          </s-list-item>
        </s-unordered-list>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
