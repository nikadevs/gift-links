import type { ActionFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { processOrderNow } from "../gb.server";

/**
 * orders/create → Bundles v2 adds the bundle items to the new order right away
 * (Order Editing, $0). Answers Shopify immediately; the work runs after the
 * response. The 30-second check in gb.server.ts catches anything missed here.
 */
export const action = async ({ request }: ActionFunctionArgs) => {
  const { shop, payload } = await authenticate.webhook(request);
  const id = (payload as { admin_graphql_api_id?: string } | null)?.admin_graphql_api_id;
  if (id) {
    setTimeout(() => {
      processOrderNow(shop, id).catch((e) => console.warn(`[wc-gb] webhook ${shop} ${id}:`, (e as Error).message));
    }, 0);
  }
  return new Response();
};
