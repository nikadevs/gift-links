import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useRevalidator, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import {
  HDCB_EMBED_MARKERS,
  checkEmbed,
  embedActivateUrl,
} from "../embed-status.server";

/**
 * Hide Dynamic Checkout Buttons (replacement for the Vitals module).
 * Everything happens in the theme app embed "Hide Checkout Buttons"
 * (blocks/hide-checkout-buttons.liquid): a small CSS rule in <head>.
 * This page only shows whether the embed is on and links to it.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const domain = await loadShopDomain(admin);
  const state = await checkEmbed(domain, HDCB_EMBED_MARKERS, url.searchParams.has("refresh"));
  return {
    state,
    // eslint-disable-next-line no-undef
    editorUrl: embedActivateUrl(session.shop, process.env.SHOPIFY_API_KEY || "", "hide-checkout-buttons"),
  };
};

const REASONS = [
  "The button sends shoppers to PayPal / Apple Pay / Google Pay / Amazon Pay before they see shipping costs — extra friction.",
  "Discount codes can't be entered in the payment provider's window.",
  "Our Volume Discounts, Gift Links and Checkbox Upsell logic runs in the cart — a checkout started from these buttons skips it.",
  "Shoppers may think express pay is the only payment method.",
  "The buttons don't match the theme design.",
];

export default function CheckoutButtons() {
  const { state, editorUrl } = useLoaderData<typeof loader>();
  const rv = useRevalidator();
  const badge =
    state === "on" ? (
      <s-badge tone="success">App embed: On</s-badge>
    ) : state === "off" ? (
      <s-badge tone="critical">App embed: Off</s-badge>
    ) : (
      <s-badge tone="warning">App embed: can’t check</s-badge>
    );
  return (
    <s-page inlineSize="large" heading="Hide Dynamic Checkout Buttons">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {badge}
          <s-button href={editorUrl} target="_blank">
            {state === "on" ? "Settings in theme editor" : "Turn on in theme editor"}
          </s-button>
          <s-button
            variant="tertiary"
            loading={rv.state === "loading" || undefined}
            onClick={() => {
              window.history.replaceState(null, "", "?refresh=1");
              rv.revalidate();
            }}
          >
            Refresh
          </s-button>
        </s-stack>
      </s-section>
      <s-section heading="What it does">
        <s-paragraph>
          Hides the express-pay buttons (Buy it now, Shop Pay, PayPal, Apple Pay, Google Pay,
          Amazon Pay) on product pages and in the cart / cart drawer. Shoppers still see and can use
          the same payment methods on the checkout page.
        </s-paragraph>
        <s-paragraph>
          It is a tiny CSS rule printed in the page &lt;head&gt; by the app embed, so the buttons are
          hidden before the page is drawn — no flash, no extra script or request. Where to hide
          (product pages / cart) is set in the embed settings.
        </s-paragraph>
      </s-section>
      <s-section heading="Why hide them">
        <s-unordered-list>
          {REASONS.map((r) => (
            <s-list-item key={r}>{r}</s-list-item>
          ))}
        </s-unordered-list>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
