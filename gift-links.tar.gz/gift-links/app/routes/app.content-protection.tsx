import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { CP_EMBED_MARKERS, checkEmbed, embedActivateUrl } from "../embed-status.server";
import { loadCpConfig, saveCpConfig, type CpConfig } from "../cp.server";

/**
 * Content Protection (replacement for the Vitals module).
 * Settings → metafield wc_cp.config; storefront → app embed "Content Protection"
 * (blocks/content-protection.liquid, inline in <head>).
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config, saved }, domain] = await Promise.all([loadCpConfig(admin), loadShopDomain(admin)]);
  const state = await checkEmbed(domain, CP_EMBED_MARKERS, url.searchParams.has("refresh"));
  return {
    config,
    saved,
    state,
    domain,
    // eslint-disable-next-line no-undef
    editorUrl: embedActivateUrl(session.shop, process.env.SHOPIFY_API_KEY || "", "content-protection"),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadCpConfig(admin);
  const next: CpConfig = {
    ...config,
    shortcuts: form.get("shortcuts") === "1",
    rightClick: form.get("rightClick") === "1",
    selection: form.get("selection") === "1",
    drag: form.get("drag") === "1",
    updatedAt: new Date().toISOString(),
  };
  try {
    await saveCpConfig(admin, installationId, next);
    return { ok: true as const, error: "" };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e) };
  }
};

type Key = "shortcuts" | "rightClick" | "selection" | "drag";

const Kbd = ({ children }: { children: string }) => (
  <span
    style={{
      background: "#f1f1f1",
      borderRadius: 6,
      padding: "2px 8px",
      marginLeft: 6,
      fontFamily: "inherit",
      fontSize: 13,
      color: "#4a4a4a",
    }}
  >
    {children}
  </span>
);

export default function ContentProtection() {
  const { config, saved, state, domain, editorUrl } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const [v, setV] = useState<Record<Key, boolean>>({
    shortcuts: config.shortcuts,
    rightClick: config.rightClick,
    selection: config.selection,
    drag: config.drag,
  });
  const dirty =
    !saved ||
    v.shortcuts !== config.shortcuts ||
    v.rightClick !== config.rightClick ||
    v.selection !== config.selection ||
    v.drag !== config.drag;

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      shopify.toast.show("Content Protection saved");
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const save = () => {
    const fd = new FormData();
    (Object.keys(v) as Key[]).forEach((k) => fd.set(k, v[k] ? "1" : "0"));
    fetcher.submit(fd, { method: "post" });
  };

  const box = (k: Key, label: ReactNode) => (
    <label style={{ display: "flex", gap: 10, alignItems: "center", cursor: "pointer", fontSize: 14 }}>
      <input
        type="checkbox"
        checked={v[k]}
        onChange={(e) => setV({ ...v, [k]: e.currentTarget.checked })}
        style={{ width: 18, height: 18, accentColor: "#303030", margin: 0 }}
      />
      <span>{label}</span>
    </label>
  );

  const badge =
    state === "on" ? (
      <s-badge tone="success">App embed: On</s-badge>
    ) : state === "off" ? (
      <s-badge tone="critical">App embed: Off</s-badge>
    ) : (
      <s-badge tone="warning">App embed: can’t check</s-badge>
    );

  return (
    <s-page inlineSize="large" heading="Content Protection">
      <s-button
        slot="primary-action"
        variant="primary"
        disabled={!dirty || undefined}
        loading={fetcher.state !== "idle" || undefined}
        onClick={save}
      >
        Save
      </s-button>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {badge}
          <s-button href={editorUrl} target="_blank">
            {state === "on" ? "Open in theme editor" : "Turn on in theme editor"}
          </s-button>
          <s-button
            variant="tertiary"
            loading={rv.state === "loading" || undefined}
            onClick={() => {
              window.history.replaceState(null, "", "?refresh=1");
              rv.revalidate();
            }}
          >
            Refresh
          </s-button>
        </s-stack>
        {fetcher.data && !fetcher.data.ok ? (
          <s-banner tone="critical">{fetcher.data.error}</s-banner>
        ) : null}
      </s-section>

      <s-section heading="Settings">
        <div style={{ display: "grid", gap: 16 }}>
          <div>
            {box("shortcuts", "Disable common shortcuts")}
            <ul style={{ margin: "8px 0 0 28px", padding: 0, lineHeight: "30px", fontSize: 14 }}>
              <li>Copy<Kbd>ctrl+c</Kbd></li>
              <li>Cut<Kbd>ctrl+x</Kbd></li>
              <li>View Source<Kbd>ctrl+u</Kbd></li>
              <li>Save<Kbd>ctrl+s</Kbd></li>
            </ul>
          </div>
          {box("rightClick", "Disable right click on text and images")}
          {box(
            "selection",
            <>
              Disable text selection using the mouse or the<Kbd>ctrl + a</Kbd> keyboard shortcut
            </>,
          )}
          {box("drag", "Disable dragging & dropping on your images and text")}
        </div>
      </s-section>

      <s-section heading="Turn it off for yourself">
        <s-paragraph>
          The storefront can’t tell whether you are logged in to the Shopify admin (Vitals’ option
          for this didn’t work either: protection was on in a browser logged in to the admin). Open
          this link once in each browser you use — protection stays off in that browser until you
          open the second link. It is also always off in the theme editor.
        </s-paragraph>
        <s-stack direction="inline" gap="base">
          <s-button href={`${domain}/?wc_cp=off`} target="_blank">
            Turn off in this browser
          </s-button>
          <s-button variant="tertiary" href={`${domain}/?wc_cp=on`} target="_blank">
            Turn back on
          </s-button>
        </s-stack>
      </s-section>

      <s-section heading="Good to know">
        <s-unordered-list>
          <s-list-item>
            Sliders and carousels keep working: the module never blocks mouse-down, touch or scroll
            events — only right click, dragging, copy/cut and Ctrl/⌘ + U, S, A.
          </s-list-item>
          <s-list-item>
            Form fields (search, email, discount code, review forms) stay fully usable: typing,
            selecting, copy and paste work there.
          </s-list-item>
          <s-list-item>
            To let shoppers copy a specific text (for example a discount code), give its element the
            class <code>wc-allow-copy</code>.
          </s-list-item>
          <s-list-item>
            This stops casual copying only. Screenshots, developer tools or disabling JavaScript
            can’t be blocked by any app.
          </s-list-item>
        </s-unordered-list>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
