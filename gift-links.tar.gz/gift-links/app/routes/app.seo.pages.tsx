import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { Fragment, useMemo, useState } from "react";
import { useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import { getLatestReport } from "../seo/seo-store.server";
import { check, fmtBytes, fmtMs, type PageKind } from "../seo/seo.shared";
import { SevBadge, SeoTabs, ago, pathOf } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { shop } = await seoAuth(request);
  const report = await getLatestReport(shop);
  const byUrl: Record<string, Array<{ check: string; detail?: string }>> = {};
  for (const f of report?.findings ?? []) (byUrl[f.url] ??= []).push({ check: f.check, detail: f.detail });
  return {
    finishedAt: report?.finishedAt ?? "",
    pages: (report?.pages ?? []).map((p) => ({ ...p, findings: byUrl[p.url] ?? [] })),
  };
};

type SortKey = "issues" | "path" | "html" | "dom" | "ms" | "words";

export default function SeoPages() {
  const { pages, finishedAt } = useLoaderData<typeof loader>();
  const [kind, setKind] = useState<PageKind | "">("");
  const [sort, setSort] = useState<SortKey>("issues");
  const [open, setOpen] = useState("");

  const rows = useMemo(() => {
    const list = pages.filter((p) => !kind || p.kind === kind);
    const val = (p: (typeof pages)[number]) =>
      sort === "issues"
        ? -p.findings.filter((f) => check(f.check).severity !== "info").length
        : sort === "html"
          ? -p.htmlBytes
          : sort === "dom"
            ? -p.domNodes
            : sort === "ms"
              ? -p.ms
              : sort === "words"
                ? p.words
                : 0;
    return list.sort((a, b) => val(a) - val(b) || a.url.localeCompare(b.url));
  }, [pages, kind, sort]);

  const kinds = [...new Set(pages.map((p) => p.kind))];

  const lenCls = (n: number, min: number, max: number) =>
    n === 0 ? "bad" : n > max || n < min ? "warn" : "ok";

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Pages">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <SeoTabs />
      <s-section>
        <div className="wcs-filters">
          <select value={kind} onChange={(e) => setKind(e.target.value as PageKind | "")}>
            <option value="">All page types</option>
            {kinds.map((k) => (
              <option key={k} value={k}>
                {k}
              </option>
            ))}
          </select>
          <select value={sort} onChange={(e) => setSort(e.target.value as SortKey)}>
            <option value="issues">Sort: most issues</option>
            <option value="html">Sort: largest HTML</option>
            <option value="dom">Sort: most elements</option>
            <option value="ms">Sort: slowest server answer</option>
            <option value="words">Sort: least text</option>
            <option value="path">Sort: URL</option>
          </select>
          <span style={{ color: "#616161", fontSize: 13, marginLeft: "auto" }}>
            {finishedAt ? `${pages.length} pages · ${ago(finishedAt)}` : "No audit yet"}
          </span>
        </div>
      </s-section>
      <s-section padding="none">
        <div className="wcs-scroll">
          <table className="wcs-table">
            <thead>
              <tr>
                <th>Page</th>
                <th className="num">Status</th>
                <th className="num">Title</th>
                <th className="num">Descr.</th>
                <th className="num">H1</th>
                <th className="num">Words</th>
                <th className="num">HTML</th>
                <th className="num">Elements</th>
                <th className="num">Server</th>
                <th className="num">Issues</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((p) => {
                const real = p.findings.filter((f) => check(f.check).severity !== "info");
                return (
                  <Fragment key={p.url}>
                    <tr onClick={() => setOpen(open === p.url ? "" : p.url)} style={{ cursor: "pointer" }}>
                      <td className="url">
                        <div>{pathOf(p.url)}</div>
                        <div className="sub">{p.title || "—"}</div>
                      </td>
                      <td className={`num ${p.status === 200 ? "" : "bad"}`}>{p.status || "ERR"}</td>
                      <td className={`num ${lenCls(p.title.length, 20, 60)}`}>{p.title.length}</td>
                      <td className={`num ${lenCls(p.description.length, 70, 160)}`}>{p.description.length}</td>
                      <td className={`num ${p.h1.length === 1 && p.h1[0] ? "ok" : "warn"}`}>{p.h1.length}</td>
                      <td className="num">{p.words}</td>
                      <td className="num">{fmtBytes(p.htmlBytes)}</td>
                      <td className="num">{p.domNodes}</td>
                      <td className="num">{fmtMs(p.ms)}</td>
                      <td className="num">{real.length}</td>
                    </tr>
                    {open === p.url ? (
                      <tr>
                        <td colSpan={10}>
                          <div className="sub">
                            <a href={p.url} target="_blank" rel="noreferrer">
                              Open page
                            </a>
                            {" · "}Canonical: {p.canonical || "—"}
                            {p.robots ? ` · Robots: ${p.robots}` : ""}
                            {" · "}Schema: {p.schemaTypes.join(", ") || "none"}
                            {" · "}Images: {p.images} ({p.imagesNoAlt} without alt)
                            {" · "}Scripts: {p.scripts}
                            {p.thirdPartyHosts.length ? ` (${p.thirdPartyHosts.join(", ")})` : ""}
                          </div>
                          <div className="sub">Description: {p.description || "—"}</div>
                          <div className="sub">H1: {p.h1.join(" | ") || "—"}</div>
                          <ul style={{ margin: "6px 0", paddingLeft: 18 }}>
                            {p.findings.map((f, i) => (
                              <li key={i}>
                                <SevBadge severity={check(f.check).severity} /> {check(f.check).title}
                                {f.detail ? <span className="sub"> — {f.detail}</span> : null}
                              </li>
                            ))}
                          </ul>
                        </td>
                      </tr>
                    ) : null}
                  </Fragment>
                );
              })}
            </tbody>
          </table>
        </div>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
