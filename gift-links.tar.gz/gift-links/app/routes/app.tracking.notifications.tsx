import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { Link, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { handleTrkAction } from "../trk-actions.server";
import { getTrkSettings, loadShipments } from "../trk-store.server";
import {
  TRK_ADMIN_EVENT,
  TRK_OMNISEND_EVENT,
  TRK_OMNISEND_FIELDS,
  TRK_STATUS_LABEL,
  TRK_STATUS_ORDER,
  type TrkStatus,
} from "../trk.shared";
import { Check, Field, STATUS_COLOR, TrkNav, card, input, useTrkAction } from "../trk-ui";

/**
 * Tracking → Notification (like Track123): emails to customers and to yourself.
 * Sending is done by Omnisend: the app sends a custom event per status change,
 * the email itself is an Omnisend workflow triggered by that event.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const s = await getTrkSettings(session.shop);
  const all = [...(await loadShipments(session.shop)).values()];
  const since = Date.now() - 30 * 86400000;
  const sent: Record<string, number> = {};
  for (const r of all) {
    for (const [k, v] of Object.entries(r.notified)) {
      if (v.startsWith("skipped") || Date.parse(v) < since) continue;
      sent[k] = (sent[k] ?? 0) + 1;
    }
  }
  return {
    s: {
      omnisendEnabled: s.omnisendEnabled,
      omnisendStatuses: s.omnisendStatuses,
      adminAlertsEnabled: s.adminAlertsEnabled,
      adminEmail: s.adminEmail,
      adminStatuses: s.adminStatuses,
      shopifyEvents: s.shopifyEvents,
      updatedAt: s.updatedAt,
    },
    hasKey: !!s.omnisendKey,
    sent,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => handleTrkAction(request);

const CUSTOMER_STATUSES = TRK_STATUS_ORDER.filter((k) => TRK_OMNISEND_EVENT[k]);
const DESC: Partial<Record<TrkStatus, string>> = {
  in_transit: "Parcel left the warehouse / is on the way",
  last_mile: "Arrived in the customer's country, handed to the local carrier (new tracking number)",
  out_for_delivery: "With the courier today",
  attempt_fail: "Delivery attempt failed / waiting for pickup",
  delivered: "Delivered",
  exception: "Customs hold, delay, lost or damaged",
  returned: "Returned to sender",
};

export default function TrackingNotifications() {
  const d = useLoaderData<typeof loader>();
  const { post, busy } = useTrkAction();
  const [tab, setTab] = useState<"customers" | "yourself">("customers");
  const [f, setF] = useState(d.s);
  const [testEmail, setTestEmail] = useState(d.s.adminEmail);
  const dirty = JSON.stringify(f) !== JSON.stringify(d.s);
  const save = (next: typeof f) => {
    setF(next);
    post({ intent: "save", settings: JSON.stringify(next) });
  };
  const toggleStatus = (key: "omnisendStatuses" | "adminStatuses", st: TrkStatus) => {
    const list = f[key];
    save({ ...f, [key]: list.includes(st) ? list.filter((x) => x !== st) : [...list, st] });
  };

  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      {!d.hasKey ? (
        <s-banner tone="warning">
          Emails are sent by Omnisend. Add the Omnisend API key in <Link to="/app/tracking/settings?tab=integration">Settings → Integration</Link> first.
        </s-banner>
      ) : null}
      <s-section>
        <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
          <s-button variant={tab === "customers" ? "primary" : "secondary"} onClick={() => setTab("customers")}>
            To customers
          </s-button>
          <s-button variant={tab === "yourself" ? "primary" : "secondary"} onClick={() => setTab("yourself")}>
            To yourself
          </s-button>
        </div>

        {tab === "customers" ? (
          <>
            <s-stack direction="inline" gap="base" alignItems="center">
              {f.omnisendEnabled ? <s-badge tone="success">Sending on</s-badge> : <s-badge>Sending off</s-badge>}
              <s-button
                variant={f.omnisendEnabled ? "secondary" : "primary"}
                disabled={!d.hasKey || undefined}
                onClick={() => save({ ...f, omnisendEnabled: !f.omnisendEnabled })}
              >
                {f.omnisendEnabled ? "Turn off" : "Turn on"}
              </s-button>
              <span style={{ fontSize: 12, color: "#616161" }}>
                While Track123 is installed it also emails customers — turn its notifications off first, or customers get two emails.
              </span>
            </s-stack>
            <div style={{ ...card, marginTop: 12, padding: 0 }}>
              {CUSTOMER_STATUSES.map((st, i) => {
                const on = f.omnisendStatuses.includes(st);
                return (
                  <div key={st} style={{ display: "flex", alignItems: "center", gap: 12, padding: 12, borderTop: i ? "1px solid #f1f1f1" : undefined }}>
                    <span style={{ width: 32, height: 32, borderRadius: 8, background: STATUS_COLOR[st], flex: "none" }} />
                    <div style={{ flex: 1, fontSize: 13 }}>
                      <b>{TRK_STATUS_LABEL[st]}</b> {on ? <s-badge tone="success">On</s-badge> : <s-badge>Off</s-badge>}
                      <div style={{ color: "#616161" }}>
                        {DESC[st]} · Omnisend event “{TRK_OMNISEND_EVENT[st]}”
                        {d.sent[TRK_OMNISEND_EVENT[st]] ? ` · ${d.sent[TRK_OMNISEND_EVENT[st]]} sent in 30 days` : ""}
                      </div>
                    </div>
                    <s-button variant="secondary" onClick={() => toggleStatus("omnisendStatuses", st)}>
                      {on ? "Turn off" : "Turn on"}
                    </s-button>
                  </div>
                );
              })}
            </div>
          </>
        ) : (
          <>
            <Check
              label="Email me when a parcel gets one of these statuses"
              checked={f.adminAlertsEnabled}
              onChange={(v) => save({ ...f, adminAlertsEnabled: v })}
            />
            <Field label="Receiver" hint={`Omnisend event “${TRK_ADMIN_EVENT}” is sent to this email; property “status” tells which status.`}>
              <div style={{ display: "flex", gap: 6, maxWidth: 420 }}>
                <input style={input} type="email" value={f.adminEmail} onChange={(e) => setF({ ...f, adminEmail: e.target.value })} />
                <s-button disabled={!dirty || undefined} onClick={() => save(f)}>
                  Save
                </s-button>
              </div>
            </Field>
            <div style={{ ...card, padding: 0 }}>
              {TRK_STATUS_ORDER.filter((k) => k !== "pending" && k !== "info_received").map((st, i) => {
                const on = f.adminStatuses.includes(st);
                return (
                  <div key={st} style={{ display: "flex", alignItems: "center", gap: 12, padding: 10, borderTop: i ? "1px solid #f1f1f1" : undefined, fontSize: 13 }}>
                    <span style={{ width: 24, height: 24, borderRadius: 6, background: STATUS_COLOR[st], flex: "none" }} />
                    <span style={{ flex: 1 }}>
                      <b>{TRK_STATUS_LABEL[st]}</b> {on ? <s-badge tone="success">On</s-badge> : <s-badge>Off</s-badge>}
                    </span>
                    <s-button variant="secondary" onClick={() => toggleStatus("adminStatuses", st)}>
                      {on ? "Turn off" : "Turn on"}
                    </s-button>
                  </div>
                );
              })}
            </div>
          </>
        )}
      </s-section>

      <s-section heading="Set up the emails in Omnisend">
        <ol style={{ margin: 0, paddingLeft: 18, fontSize: 13, lineHeight: 1.7 }}>
          <li>Send test events (below) — custom events appear in Omnisend’s trigger list only after the first event.</li>
          <li>
            Omnisend → Automation → Create workflow → Create from scratch → trigger <b>Custom event</b> → choose e.g. “{TRK_OMNISEND_EVENT.in_transit}”. Add
            a trigger filter <b>isTest is not yes</b> so test events never email anyone.
          </li>
          <li>
            In the email use the event fields as personalization tags: {TRK_OMNISEND_FIELDS.filter((x) => x !== "isTest").join(", ")}. Put{" "}
            <b>trackingUrl</b> on the button.
          </li>
          <li>Workflows on custom events also send to unsubscribed contacts — right for shipping emails (transactional).</li>
          <li>Repeat for each status, then Turn on sending above.</li>
        </ol>
        <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap", marginTop: 12 }}>
          <input style={{ ...input, width: 280 }} type="email" placeholder="Your email for test events" value={testEmail} onChange={(e) => setTestEmail(e.target.value)} />
          <s-button disabled={!d.hasKey || !testEmail || undefined} loading={busy("omnisendTest") || undefined} onClick={() => post({ intent: "omnisendTest", email: testEmail })}>
            Send test events (customers)
          </s-button>
          <s-button
            variant="secondary"
            disabled={!d.hasKey || !testEmail || undefined}
            loading={busy("omnisendTest") || undefined}
            onClick={() => post({ intent: "omnisendTest", email: testEmail, admin: "1" })}
          >
            Send test event (to yourself)
          </s-button>
        </div>
      </s-section>

      <s-section heading="Shopify’s own emails">
        <s-paragraph>
          When “Send shipping statuses to Shopify” is on (Settings), Shopify itself can send its built-in “Out for delivery” and “Delivered” emails
          (Settings → Notifications → Shipping updates in Shopify admin). Use either those or Omnisend, not both. Currently:{" "}
          {f.shopifyEvents ? <s-badge tone="success">statuses go to Shopify</s-badge> : <s-badge>off</s-badge>}
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
