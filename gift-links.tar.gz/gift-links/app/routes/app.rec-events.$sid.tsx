import type { LoaderFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { readEvents } from "../rec.server";

/** Session Recordings — all rrweb events of one recording (for the player). */
export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const json = await readEvents(session.shop, String(params.sid ?? ""));
  if (json === null) return new Response("[]", { status: 404, headers: { "Content-Type": "application/json" } });
  return new Response(json, {
    headers: { "Content-Type": "application/json", "Cache-Control": "private, no-store" },
  });
};
