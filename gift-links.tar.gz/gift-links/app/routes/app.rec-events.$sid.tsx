import type { LoaderFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { readEvents } from "../rec.server";

/** Session Recordings — rrweb events of one recording (?p=N → only that page). */
export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const p = new URL(request.url).searchParams.get("p");
  const page = p !== null && /^\d{1,4}$/.test(p) ? Number(p) : undefined;
  const json = await readEvents(session.shop, String(params.sid ?? ""), page);
  if (json === null) return new Response("[]", { status: 404, headers: { "Content-Type": "application/json" } });
  return new Response(json, {
    headers: { "Content-Type": "application/json", "Cache-Control": "private, no-store" },
  });
};
