import { readFile } from "node:fs/promises";

/**
 * Public, read-only status of the last auto deploy (written by
 * deploy/auto-deploy.sh). Contains only the commit, timestamps, result and a
 * log tail with secret-looking lines removed — no tokens, no shop data.
 */
const STATUS_FILE =
  // eslint-disable-next-line no-undef
  process.env.DEPLOY_STATUS_FILE || "/opt/gift-links/deploy-status.json";

export const loader = async () => {
  const headers = {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  };
  try {
    const raw = await readFile(STATUS_FILE, "utf8");
    return new Response(raw, { headers });
  } catch {
    return new Response(JSON.stringify({ status: "unknown" }), {
      status: 404,
      headers,
    });
  }
};
