import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useEffect, useState } from "react";
import { useFetcher, useLoaderData, useNavigate } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import {
  activateProduct,
  deactivateProduct,
  ensureOrderWebhook,
  gbState,
  inspectProduct,
  loadGb,
  prepareProduct,
  publishCatalog,
  removeProduct,
  runGbTick,
} from "../gb.server";

/**
 * Bundles v2: catalog bundle products (normal products for Google /
 * Facebook / TikTok) whose free extras are added in the cart and, as a
 * backstop, into the order. See app/gb.shared.ts.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const { config } = await loadGb(admin);
  const scopes = await admin
    .graphql(`#graphql
      query WcGbScopes { currentAppInstallation { accessScopes { handle } } }`)
    .then((r) => r.json())
    .then((j: { data?: { currentAppInstallation?: { accessScopes: { handle: string }[] } } }) =>
      (j.data?.currentAppInstallation?.accessScopes ?? []).map((s) => s.handle),
    )
    .catch(() => [] as string[]);
  const editId = url.searchParams.get("product");
  const views = await Promise.all(
    [...new Set([...config.products.map((p) => p.productId), ...(editId ? [editId.split("/").pop()!] : [])])].map((id) =>
      inspectProduct(admin, id, config).catch((e) => ({ error: (e as Error).message, id })),
    ),
  );
  const state = await gbState(session.shop);
  const hook = await ensureOrderWebhook(session.shop, admin);
  return {
    config,
    views,
    editId: editId ? editId.split("/").pop()! : "",
    canEditOrders: scopes.includes("write_order_edits"),
    hook: hook ?? null,
    state: { lastRunAt: state.lastRunAt, lastError: state.lastError, log: state.log.slice(-20).reverse() },
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent") || "");
  const pid = String(form.get("productId") || "");
  try {
    if (intent === "save") {
      const chosen = JSON.parse(String(form.get("gifts") || "{}")) as Record<string, string[]>;
      const r = await prepareProduct(admin, pid, chosen);
      return { ok: true as const, message: ["Bundle items saved", ...r.notes].join(" · ") };
    }
    if (intent === "on") {
      const r = await activateProduct(admin, pid);
      return { ok: true as const, message: `On: bundle items are added to new orders; Shopify bundle removed from ${r.removedNative} variant(s)` };
    }
    if (intent === "off") {
      await deactivateProduct(admin, pid);
      return { ok: true as const, message: "Off: bundle items are no longer added" };
    }
    if (intent === "remove") {
      await removeProduct(admin, pid);
      return { ok: true as const, message: "Removed from Bundles v2" };
    }
    if (intent === "publish") {
      const r = await publishCatalog(admin, pid);
      const bad = r.filter((x) => x.error);
      if (bad.length) return { ok: false as const, message: bad.map((x) => `${x.name}: ${x.error}`).join("; ") };
      return { ok: true as const, message: `Published to ${r.map((x) => x.name).join(", ")}` };
    }
    if (intent === "hook") {
      const h = await ensureOrderWebhook(session.shop, admin, true);
      if (!h?.ok) return { ok: false as const, message: `Webhook: ${h?.error || "failed"}` };
      return { ok: true as const, message: "Webhook connected: new orders are processed right away" };
    }
    if (intent === "tick") {
      const r = await runGbTick(session.shop, admin);
      return { ok: true as const, message: r.skipped ? "Nothing to check (no product switched on)" : `Orders checked, bundle items added to ${r.fixed}` };
    }
    throw new Error("Unknown action");
  } catch (e) {
    return { ok: false as const, message: e instanceof Error ? e.message : String(e) };
  }
};

type Data = ReturnType<typeof useLoaderData<typeof loader>>;
type View = Exclude<Data["views"][number], { error: string }>;

function Editor({ view, saved }: { view: View; saved: Record<string, { src: number }[]> | null }) {
  const fetcher = useFetcher<typeof action>();
  const shopify = useAppBridge();
  const [pick, setPick] = useState<Record<string, string[]>>(() =>
    Object.fromEntries(view.variants.map((v) => [v.id, v.comps.filter((c) => c.gift).map((c) => c.variantId)])),
  );
  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) shopify.toast.show(fetcher.data.message);
  }, [fetcher.state, fetcher.data, shopify]);
  const toggle = (vid: string, cid: string) =>
    setPick((p) => ({ ...p, [vid]: p[vid]?.includes(cid) ? p[vid].filter((x) => x !== cid) : [...(p[vid] || []), cid] }));
  const save = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("productId", view.id);
    fd.set("gifts", JSON.stringify(pick));
    fetcher.submit(fd, { method: "post" });
  };
  const noComps = view.variants.every((v) => !v.comps.length);
  return (
    <div style={{ border: "1px solid #c9cccf", borderRadius: 10, padding: 14, background: "#fafbfb", marginTop: 8 }}>
      <s-stack gap="base">
        <s-text type="strong">Bundle items per variant</s-text>
        {noComps ? (
          <s-banner tone="warning">
            This product has no components in the Bundles module. Add them there (Edit) first, then come back.
          </s-banner>
        ) : null}
        <s-paragraph>
          Ticked = added to the order at $0 right after it is placed. Unticked = the main item: it is the product
          itself (its name is in the order). Items that are Draft, not on the Online Store or not $0 get a hidden
          $0 copy with the same name (made once, originals unchanged).
        </s-paragraph>
        {view.variants.map((v) => (
          <div key={v.id} style={{ borderTop: "1px solid #ebebeb", paddingTop: 8 }}>
            <div style={{ fontSize: 13, marginBottom: 4 }}>
              <b>{v.title}</b> · ${v.price.toFixed(2)}
              {saved && !saved[v.id.split("/").pop()!] ? <span style={{ color: "#8a6116" }}> · not saved yet</span> : null}
            </div>
            {v.comps.map((c) => (
              <label key={c.variantId} style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 13, padding: "2px 0" }}>
                <input type="checkbox" checked={!!pick[v.id]?.includes(c.variantId)} onChange={() => toggle(v.id, c.variantId)} />
                <span>
                  {c.qty > 1 ? `${c.qty} × ` : ""}
                  {c.title}
                </span>
                <span style={{ color: "#616161" }}>${c.price.toFixed(2)}</span>
                {c.needsCopy && pick[v.id]?.includes(c.variantId) ? (
                  <s-badge tone="warning">{c.copyVariant ? "uses $0 copy" : "$0 copy will be made"}</s-badge>
                ) : null}
                {!pick[v.id]?.includes(c.variantId) ? <s-badge tone="info">main item</s-badge> : null}
              </label>
            ))}
          </div>
        ))}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.message}</s-banner> : null}
        <s-stack direction="inline" gap="base">
          <s-button variant="primary" loading={fetcher.state !== "idle" || undefined} onClick={save} disabled={noComps || undefined}>
            Save bundle items
          </s-button>
        </s-stack>
      </s-stack>
    </div>
  );
}

export default function BundlesV2() {
  const { config, views, editId, canEditOrders, hook, state } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const shopify = useAppBridge();
  const navigate = useNavigate();
  const [confirm, setConfirm] = useState("");
  const busy = fetcher.state !== "idle";

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) shopify.toast.show(fetcher.data.message);
  }, [fetcher.state, fetcher.data, shopify]);

  const run = (intent: string, productId = "", needConfirm = false) => {
    const key = `${intent}:${productId}`;
    if (needConfirm && confirm !== key) {
      setConfirm(key);
      return;
    }
    setConfirm("");
    const fd = new FormData();
    fd.set("intent", intent);
    fd.set("productId", productId);
    fetcher.submit(fd, { method: "post" });
  };
  const pick = async () => {
    const r = await shopify.resourcePicker({ type: "product", action: "select", multiple: false });
    if (r?.[0]) navigate(`/app/bundles-v2?product=${encodeURIComponent(r[0].id.split("/").pop()!)}`);
  };

  return (
    <s-page inlineSize="large" heading="Bundles v2">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-section>
        <s-stack gap="base">
          <s-paragraph>
            For products that must stay in Google, Facebook and TikTok: the product is a normal product (no Shopify
            bundle components — those channels refuse bundles). The cart and checkout show only the product; right
            after an order is placed (checked every 30 seconds) the app adds the bundle items to the order at $0
            (Order Editing, no email to the customer), so the warehouse sees every item.
          </s-paragraph>
          {!canEditOrders ? (
            <s-banner tone="critical">
              The app doesn’t have the “Edit orders” permission yet, so bundle items can’t be added to orders. Open
              the app from Shopify admin → Apps and accept the update (write_order_edits).
            </s-banner>
          ) : null}
          {hook && !hook.ok ? (
            <s-banner tone="warning">
              Instant processing (orders/create webhook) is not connected: {hook.error}. Orders are still checked every
              30 seconds. To connect: Dev Dashboard → Apps → WoodenCrew Apps → Settings → Access requests → Protected
              customer data → Manage → Customer data (reason: add bundle items to new orders) → Save, then click
              “Connect webhook”.
            </s-banner>
          ) : null}
          <s-stack direction="inline" gap="base" alignItems="center">
            <s-button onClick={pick}>Add product</s-button>
            {hook?.ok ? (
              <s-badge tone="success">Webhook: on (instant)</s-badge>
            ) : (
              <s-button variant="tertiary" loading={busy || undefined} onClick={() => run("hook")}>
                Connect webhook
              </s-button>
            )}
            <s-button variant="tertiary" loading={busy || undefined} onClick={() => run("tick")}>
              Check orders now
            </s-button>
            <s-text color="subdued">
              Order check: {state.lastRunAt ? new Date(state.lastRunAt).toLocaleString() : "not run yet"}
              {state.lastError ? ` · error: ${state.lastError}` : ""}
            </s-text>
          </s-stack>
          {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.message}</s-banner> : null}
        </s-stack>
      </s-section>

      {views.map((v) => {
        if ("error" in v) {
          return (
            <s-section key={v.id}>
              <s-banner tone="critical">
                Product {v.id}: {v.error}
              </s-banner>
            </s-section>
          );
        }
        const pid = v.id.split("/").pop()!;
        const entry = config.products.find((p) => p.productId === pid) || null;
        const native = v.variants.some((x) => x.requiresComponents || x.nativeCount > 0);
        return (
          <s-section key={v.id}>
            <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
              {v.image ? <img src={v.image} alt="" width={36} height={36} style={{ objectFit: "cover", borderRadius: 6 }} /> : null}
              <s-link href={`shopify://admin/products/${pid}`} target="_top">
                {v.title}
              </s-link>
              {entry?.active ? <s-badge tone="success">On</s-badge> : entry ? <s-badge>Off</s-badge> : <s-badge tone="warning">Not saved</s-badge>}
              {native ? <s-badge tone="critical">Shopify bundle (blocked by Google/FB/TikTok)</s-badge> : <s-badge tone="success">Normal product</s-badge>}
              {v.channels.map((c) => (
                <s-badge key={c.name} tone={c.published ? "success" : undefined}>
                  {c.name}: {c.published ? "yes" : "no"}
                </s-badge>
              ))}
              <span style={{ flex: 1 }} />
              {entry && !entry.active ? (
                <s-button variant="primary" loading={busy || undefined} onClick={() => run("on", pid, true)}>
                  {confirm === `on:${pid}` ? "Click again: switch on + remove Shopify bundle" : "Switch on"}
                </s-button>
              ) : null}
              {entry?.active && !native && v.channels.some((c) => !c.published && !/online store/i.test(c.name)) ? (
                <s-button loading={busy || undefined} onClick={() => run("publish", pid)}>
                  Publish to Google / Facebook / TikTok
                </s-button>
              ) : null}
              {entry?.active ? (
                <s-button variant="tertiary" tone="critical" loading={busy || undefined} onClick={() => run("off", pid, true)}>
                  {confirm === `off:${pid}` ? "Click again to confirm" : "Switch off"}
                </s-button>
              ) : null}
              {entry && !entry.active ? (
                <s-button variant="tertiary" tone="critical" loading={busy || undefined} onClick={() => run("remove", pid, true)}>
                  {confirm === `remove:${pid}` ? "Click again to confirm" : "Remove"}
                </s-button>
              ) : null}
            </div>
            {entry ? (
              <div style={{ fontSize: 13, marginTop: 8 }}>
                {Object.entries(entry.variants).map(([vid, gifts]) => {
                  const vv = v.variants.find((x) => x.id.endsWith(`/${vid}`));
                  return (
                    <div key={vid}>
                      <b>{vv?.title ?? vid}</b>: {gifts.map((g) => `${g.q > 1 ? `${g.q}× ` : ""}${g.title}${g.v !== g.src ? " ($0 copy)" : ""}`).join(", ")}
                    </div>
                  );
                })}
              </div>
            ) : null}
            {editId === pid || !entry ? (
              <Editor view={v} saved={entry ? Object.fromEntries(Object.entries(entry.variants).map(([k, g]) => [k, g])) : null} />
            ) : (
              <div style={{ marginTop: 8 }}>
                <s-button variant="tertiary" onClick={() => navigate(`/app/bundles-v2?product=${pid}`)}>
                  Edit bundle items
                </s-button>
              </div>
            )}
          </s-section>
        );
      })}

      <s-section heading="Order check log">
        {state.log.length ? (
          <div style={{ fontSize: 13 }}>
            {state.log.map((l, i) => (
              <div key={i} style={{ color: l.ok ? undefined : "#8e1f0b" }}>
                {new Date(l.at).toLocaleString()} · {l.order} · {l.text}
              </div>
            ))}
          </div>
        ) : (
          <s-text color="subdued">No orders needed bundle items yet.</s-text>
        )}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
