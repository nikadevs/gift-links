import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { CSSProperties, ReactNode } from "react";
import { useEffect, useMemo, useRef, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { FAV_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadFavConfig, saveFavConfig } from "../fav.server";
import {
  FAV_ANIMS,
  FAV_INTERVALS,
  FAV_POSITIONS,
  FAV_SHAPES,
  normalizeFav,
  type FavConfig,
} from "../fav.shared";

/**
 * Favicon Cart Count (replacement for Vitals «Favicon Cart Count»): the number of
 * items in the cart over the store favicon in the browser tab. Same settings as
 * Vitals. No separate app embed: Turn on / Turn off writes wc_fav.config.enabled;
 * the Gift Links embed prints the code (assets/wc-favicon.js).
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config }, domain] = await Promise.all([loadFavConfig(admin), loadShopDomain(admin)]);
  const live = config.enabled
    ? await checkEmbed(domain, FAV_EMBED_MARKERS, url.searchParams.has("refresh"))
    : "off";
  return { config, live, domain };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadFavConfig(admin);
  const intent = String(form.get("intent") || "");
  let next: FavConfig = config;
  if (intent === "toggle") next = { ...config, enabled: form.get("enabled") === "1" };
  else if (intent === "save") {
    try {
      next = { ...normalizeFav(JSON.parse(String(form.get("config") || "{}"))), enabled: config.enabled };
    } catch {
      return { ok: false as const, error: "Bad form data", intent, enabled: config.enabled };
    }
  } else return { ok: false as const, error: "Unknown action", intent, enabled: config.enabled };
  next.updatedAt = new Date().toISOString();
  try {
    await saveFavConfig(admin, installationId, next);
    return { ok: true as const, error: "", intent, enabled: next.enabled };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e), intent, enabled: config.enabled };
  }
};

const lbl: CSSProperties = { display: "block", fontSize: 13, marginBottom: 4, color: "#303030" };
const input: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  fontSize: 13,
  background: "#fdfdfd",
};

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <span style={lbl}>{label}</span>
      {children}
    </div>
  );
}

function Select<T extends string | number>({
  value,
  options,
  onChange,
}: {
  value: T;
  options: { value: T; label: string }[];
  onChange: (v: T) => void;
}) {
  return (
    <select
      style={input}
      value={String(value)}
      onChange={(e) => {
        const o = options.find((x) => String(x.value) === e.target.value);
        if (o) onChange(o.value);
      }}
    >
      {options.map((o) => (
        <option key={String(o.value)} value={String(o.value)}>
          {o.label}
        </option>
      ))}
    </select>
  );
}

function Color({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div style={{ flex: 1, minWidth: 180 }}>
      <span style={lbl}>{label}</span>
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <input
          type="color"
          value={`#${/^[0-9a-f]{6}$/i.test(value) ? value : "000000"}`}
          onChange={(e) => onChange(e.target.value.slice(1))}
          style={{ width: 32, height: 32, padding: 0, border: "1px solid #ccc", borderRadius: 8, background: "none" }}
        />
        <span style={{ position: "relative", flex: 1 }}>
          <span style={{ position: "absolute", left: 10, top: 7, color: "#8a8a8a", fontSize: 13 }}>#</span>
          <input
            style={{ ...input, paddingLeft: 22 }}
            value={value}
            maxLength={7}
            onChange={(e) => onChange(e.target.value.replace(/^#/, "").trim())}
          />
        </span>
      </div>
    </div>
  );
}

/* Same drawing as extensions/gift-links-embed/assets/wc-favicon.js (keep in sync). */
function drawBadge(ctx: CanvasRenderingContext2D, S: number, c: FavConfig, n: number, p: number) {
  const t = n > 99 ? "99+" : String(n);
  let h = S * 0.6;
  let w = t.length === 1 ? h : t.length === 2 ? h * 1.4 : S;
  const left = c.position.includes("left");
  const top = c.position.startsWith("top");
  let x = left ? 0 : S - w;
  let y = top ? 0 : S - h;
  let a = 1;
  const k = 1 - Math.pow(1 - p, 3);
  if (c.animation === "fade") a = k;
  else if (c.animation === "pop" || c.animation === "popFade") {
    const nw = w * k;
    const nh = h * k;
    x = left ? x : x + (w - nw);
    y = top ? y : y + (h - nh);
    w = nw;
    h = nh;
    if (c.animation === "popFade") a = k;
  } else if (c.animation === "slide") {
    y = top ? -h + (y + h) * k : y + (S - y) * (1 - k);
  }
  if (w <= 0.5 || h <= 0.5) return;
  ctx.globalAlpha = a;
  ctx.fillStyle = `#${c.bg}`;
  if (c.shape === "circle") {
    ctx.beginPath();
    if (w - h < 0.5) ctx.arc(x + w / 2, y + h / 2, h / 2, 0, 2 * Math.PI);
    else {
      const r = h / 2;
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + w - r, y);
      ctx.arc(x + w - r, y + r, r, -Math.PI / 2, Math.PI / 2);
      ctx.lineTo(x + r, y + h);
      ctx.arc(x + r, y + r, r, Math.PI / 2, (3 * Math.PI) / 2);
      ctx.closePath();
    }
    ctx.fill();
  } else ctx.fillRect(x, y, w, h);
  const fs = h * (t.length === 1 ? 0.85 : t.length === 2 ? 0.75 : 0.6);
  if (fs >= 3) {
    ctx.fillStyle = `#${c.color}`;
    ctx.font = `bold ${Math.round(fs)}px Arial, Helvetica, sans-serif`;
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(t, x + w / 2, y + h / 2 + h * 0.06);
  }
  ctx.globalAlpha = 1;
}

/** Browser-tab mock: sample icon + badge, animated and repeated like on the storefront. */
function Preview({ c, n }: { c: FavConfig; n: number }) {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const cv = ref.current;
    const ctx = cv?.getContext("2d");
    if (!cv || !ctx) return;
    const S = 64;
    let timer: ReturnType<typeof setTimeout> | undefined;
    let start = Date.now();
    const icon = () => {
      ctx.clearRect(0, 0, S, S);
      ctx.fillStyle = "#1f3a33";
      ctx.beginPath();
      ctx.arc(S / 2, S / 2, S * 0.42, 0, 2 * Math.PI);
      ctx.fill();
      ctx.fillStyle = "#fff";
      ctx.font = `bold ${S * 0.42}px Georgia, serif`;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText("W", S / 2, S / 2 + 2);
    };
    const step = () => {
      const p = c.animation === "none" ? 1 : Math.min(1, (Date.now() - start) / 400);
      icon();
      drawBadge(ctx, S, c, n, p);
      if (p < 1) timer = setTimeout(step, 40);
      else if (c.interval && c.animation !== "none")
        timer = setTimeout(() => {
          start = Date.now();
          step();
        }, c.interval * 1000);
    };
    step();
    return () => clearTimeout(timer);
  }, [c, n]);
  return (
    <div style={{ background: "#dee1e6", borderRadius: 10, padding: "10px 10px 0", maxWidth: 320 }}>
      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          background: "#fff",
          borderRadius: "8px 8px 0 0",
          padding: "8px 12px",
          fontSize: 12,
          color: "#3c4043",
        }}
      >
        <canvas ref={ref} width={64} height={64} style={{ width: 32, height: 32, flex: "none" }} />
        <span style={{ overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>
          Comfiest Travel Pillow | WoodenCrew
        </span>
      </div>
    </div>
  );
}

export default function FaviconCart() {
  const { config, live, domain } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const [c, setC] = useState<FavConfig>(config);
  const [n, setN] = useState(4);
  const busy = fetcher.state !== "idle";
  const dirty = useMemo(
    () =>
      JSON.stringify({ ...c, enabled: 0, updatedAt: 0 }) !== JSON.stringify({ ...config, enabled: 0, updatedAt: 0 }),
    [c, config],
  );

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      if (fetcher.data.intent === "toggle")
        shopify.toast.show(fetcher.data.enabled ? "Favicon Cart Count turned on" : "Favicon Cart Count turned off");
      else shopify.toast.show("Saved");
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const set = <K extends keyof FavConfig>(k: K, v: FavConfig[K]) => setC((p) => ({ ...p, [k]: v }));
  const toggle = () => {
    const fd = new FormData();
    fd.set("intent", "toggle");
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };
  const save = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("config", JSON.stringify(c));
    fetcher.submit(fd, { method: "post" });
  };
  const preview = normalizeFav(c);

  return (
    <s-page inlineSize="large" heading="Favicon Cart Count">
      <s-button
        slot="primary-action"
        variant="primary"
        disabled={!dirty || busy || undefined}
        loading={(busy && fetcher.formData?.get("intent") === "save") || undefined}
        onClick={save}
      >
        Save
      </s-button>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? <s-badge tone="success">Active</s-badge> : <s-badge>Inactive</s-badge>}
          <s-button
            variant={config.enabled ? "secondary" : "primary"}
            loading={(busy && fetcher.formData?.get("intent") === "toggle") || undefined}
            onClick={toggle}
          >
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: code present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              <s-button variant="tertiary" href={domain || "/"} target="_blank">
                Open store
              </s-button>
            </>
          ) : null}
        </s-stack>
        {config.enabled && live === "off" ? (
          <s-banner tone="critical">
            The storefront doesn’t have the Favicon Cart Count code yet. It is printed by the “Gift Links” app
            embed — it must stay on (Theme editor → App embeds). Changes can take a minute to appear (theme
            cache).
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
        {dirty ? <s-banner tone="info">Unsaved changes — press Save.</s-banner> : null}
      </s-section>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", alignItems: "flex-start" }}>
        <div style={{ flex: "1 1 420px", minWidth: 300 }}>
          <s-section heading="Settings">
            <Field label="Shape">
              <Select value={c.shape} options={FAV_SHAPES} onChange={(v) => set("shape", v)} />
            </Field>
            <Field label="The location of the bullet.">
              <Select value={c.position} options={FAV_POSITIONS} onChange={(v) => set("position", v)} />
            </Field>
            <Field label="Animation">
              <Select value={c.animation} options={FAV_ANIMS} onChange={(v) => set("animation", v)} />
            </Field>
            <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 14 }}>
              <Color label="Badge color" value={c.bg} onChange={(v) => set("bg", v)} />
              <Color label="Text color" value={c.color} onChange={(v) => set("color", v)} />
            </div>
            <Field label="Animation repetition interval">
              <Select value={c.interval} options={FAV_INTERVALS} onChange={(v) => set("interval", v)} />
            </Field>
          </s-section>
        </div>
        <div style={{ flex: "1 1 280px", minWidth: 260 }}>
          <s-section heading="Preview">
            <Preview c={preview} n={n} />
            <div style={{ display: "flex", gap: 6, marginTop: 12, alignItems: "center", fontSize: 13 }}>
              Items in cart:
              {[1, 4, 12, 120].map((v) => (
                <s-button key={v} variant={v === n ? "primary" : "secondary"} onClick={() => setN(v)}>
                  {v > 99 ? "99+" : String(v)}
                </s-button>
              ))}
            </div>
          </s-section>
        </div>
      </div>

      <s-section heading="How it works">
        <s-unordered-list>
          <s-list-item>
            Shows the number of items in the cart over the store favicon, so the browser tab stands out when the
            visitor switches to another tab. Nothing is shown while the cart is empty.
          </s-list-item>
          <s-list-item>
            Updates right after the theme or an app changes the cart (add, change, remove) — the theme’s requests
            are not modified.
          </s-list-item>
          <s-list-item>
            Needs a favicon in the theme (Theme settings → Logo → Favicon). Browsers on phones usually don’t show
            favicons in tabs, so it’s mainly visible on desktop — same as Vitals.
          </s-list-item>
          <s-list-item>Speed: one small deferred script; the icon is redrawn only when the cart has items.</s-list-item>
        </s-unordered-list>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
