import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import {
  redirect,
  useActionData,
  useFetcher,
  useLoaderData,
  useNavigate,
  useNavigation,
  useSubmit,
} from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import {
  MAX_TIERS,
  blankOffer,
  blankTier,
  discountSteps,
  type VdGift,
  type VdOffer,
  type VdTier,
} from "../vd.shared";
import {
  giftInfo,
  loadVdConfig,
  makeGiftCopy,
  newOfferId,
  offerFromForm,
  saveVdConfig,
  syncOfferDiscounts,
  type GiftCheck,
} from "../vd.server";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const { config } = await loadVdConfig(admin);
  const offer = params.id === "new" ? blankOffer() : config.offers.find((o) => o.id === params.id);
  if (!offer) throw redirect("/app/volume");
  return { offer };
};

type GiftResult = { intent: "gift"; tier: number; check?: GiftCheck; notes?: string[]; error?: string };

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent") ?? "save");

  if (intent === "gift-info" || intent === "gift-copy") {
    const tier = Number(form.get("tier"));
    const pid = String(form.get("productId") ?? "");
    try {
      if (intent === "gift-info") return { intent: "gift", tier, check: await giftInfo(admin, pid) } as GiftResult;
      const r = await makeGiftCopy(admin, pid);
      return { intent: "gift", tier, check: r, notes: r.notes } as GiftResult;
    } catch (e) {
      const msg = (e as Error).message;
      return {
        intent: "gift",
        tier,
        error: /access|scope|denied/i.test(msg)
          ? "No permission yet — open the app once and approve the new permissions, then try again."
          : msg,
      } as GiftResult;
    }
  }

  const { installationId, config } = await loadVdConfig(admin);
  const id = params.id === "new" ? newOfferId() : String(params.id);
  const prev = config.offers.find((o) => o.id === id);
  const { offer, errors } = await offerFromForm(admin, form, id, config.offers);
  if (!offer) return { intent: "save", errors };

  const synced = await syncOfferDiscounts(admin, offer, prev?.discountIds ?? []);
  const idx = config.offers.findIndex((o) => o.id === id);
  if (idx >= 0) config.offers[idx] = synced;
  else config.offers.push(synced);
  try {
    await saveVdConfig(admin, installationId, config);
  } catch (e) {
    return { intent: "save", errors: { form: (e as Error).message } };
  }
  return redirect(`/app/volume/${id}?saved=1`);
};

type FieldEvent = Event & { currentTarget: { value?: string; checked?: boolean } };
const val = (e: Event) => String((e as FieldEvent).currentTarget?.value ?? "");
const chk = (e: Event) => Boolean((e as FieldEvent).currentTarget?.checked);
const num = (gid: string) => gid.replace(/\D/g, "");

type PickedProduct = {
  id: string;
  title: string;
  images?: { originalSrc?: string; url?: string }[];
};

export default function VolumeRoute() {
  const data = useLoaderData<typeof loader>();
  return <OfferForm key={`${data.offer.id}:${data.offer.updatedAt}`} offer={data.offer} />;
}

const CSS = `
.vdf-tier{border:1px solid #e3e3e3;border-radius:12px;padding:14px;background:#fff}
.vdf-tier h3{margin:0;font-size:14px;font-weight:650}
.vdf-row{display:flex;gap:10px;align-items:center}
.vdf-gift{display:flex;flex-wrap:wrap;gap:10px;align-items:center;border:1px dashed #d4d4d4;border-radius:10px;padding:8px}
.vdf-gift .nm{flex:1 1 220px}
.vdf-gift img{width:40px;height:40px;object-fit:contain;border-radius:6px;background:#fff;border:1px solid #eee}
.vdf-gift .t{flex:1 1 260px;font-size:13px;line-height:18px}
.vdf-warn{color:#8e1f0b}
.vdf-prod{display:flex;gap:10px;align-items:center;padding:6px 0;border-bottom:1px solid #f1f1f1}
.vdf-prod:last-child{border-bottom:0}
.vdf-prod img{width:36px;height:36px;object-fit:contain;border:1px solid #e3e3e3;border-radius:6px;background:#fff}
.vdf-prod span{flex:1;font-size:13px}
/* preview, close to the storefront block */
.vdp{font-size:14px;color:#1a1a1a}
.vdp-h{display:flex;align-items:center;gap:10px;font-weight:700;font-size:16px;margin:4px 0 12px}
.vdp-h:before,.vdp-h:after{content:"";flex:1;height:1px;background:#cfcfcf}
.vdp-t{position:relative;border:1px solid #d9d9d9;border-radius:8px;padding:14px 12px;margin-bottom:14px}
.vdp-t.on{border-color:#1e7b85;background:#eaf3f4}
.vdp-badge{position:absolute;top:-10px;left:12px;background:#1e7b85;color:#fff;font-size:11px;font-weight:700;padding:1px 8px;border-radius:4px}
.vdp-line{display:flex;align-items:center;gap:10px}
.vdp-radio{width:20px;height:20px;border-radius:50%;border:2px solid #555;flex:none;display:grid;place-items:center}
.vdp-t.on .vdp-radio{border-color:#1e7b85}
.vdp-t.on .vdp-radio:after{content:"";width:10px;height:10px;border-radius:50%;background:#1e7b85}
.vdp-gift{display:flex;align-items:center;gap:8px;margin:10px 0 0 30px;font-size:13px}
.vdp-gift img{width:36px;height:36px;object-fit:contain}
.vdp-gift s{margin-left:auto;color:#777}
.vdp-save{position:absolute;bottom:-11px;left:50%;transform:translateX(-50%);background:#1e7b85;color:#fff;font-size:12px;font-weight:700;padding:1px 10px;border-radius:4px;white-space:nowrap}
.vdp-sw{display:flex;gap:4px;margin:8px 0 0 30px}
.vdp-sw i{width:30px;height:30px;border:1px solid #ccc;border-radius:4px;background:#f6f6f6}
.vdp-sw i:first-child{border:2px solid #1a1a1a}
.vdp-more{color:#1e7b85;text-decoration:underline;font-size:13px}
`;

function OfferForm({ offer }: { offer: VdOffer }) {
  const actionData = useActionData<typeof action>();
  const errors: Record<string, string> =
    actionData && "errors" in actionData ? ((actionData.errors as Record<string, string>) ?? {}) : {};
  const [o, setO] = useState<VdOffer>(offer);
  const [pending, setPending] = useState<Record<number, GiftCheck | null>>({});
  const [giftMsg, setGiftMsg] = useState<Record<number, string>>({});
  const gf = useFetcher<GiftResult>();
  const submit = useSubmit();
  const nav = useNavigation();
  const navigate = useNavigate();
  const shopify = useAppBridge();
  const isNew = offer.id === "new";
  const saving = nav.state === "submitting" && nav.formData?.get("intent") === "save";

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("saved")) shopify.toast.show("Offer saved");
  }, [offer.updatedAt, shopify]);

  // gift lookups / copies come back here (result of an async server call,
  // so syncing it into local form state from an effect is intended)
  useEffect(() => {
    /* eslint-disable react-hooks/set-state-in-effect */
    const r = gf.data;
    if (!r || gf.state !== "idle" || r.intent !== "gift") return;
    if (r.error) {
      setGiftMsg((m) => ({ ...m, [r.tier]: r.error ?? "" }));
      return;
    }
    if (!r.check) return;
    if (r.check.isFree) {
      setO((prev) => ({
        ...prev,
        tiers: prev.tiers.map((t, i) =>
          i === r.tier && !t.gifts.some((g) => g.productId === r.check!.gift.productId)
            ? { ...t, gifts: [...t.gifts, r.check!.gift] }
            : t,
        ),
      }));
      setPending((p) => ({ ...p, [r.tier]: null }));
      setGiftMsg((m) => ({
        ...m,
        [r.tier]: r.notes?.length ? `Copy created. Note: ${r.notes.join("; ")}` : "",
      }));
      if (r.notes) shopify.toast.show("$0 gift copy created");
    } else {
      setPending((p) => ({ ...p, [r.tier]: r.check ?? null }));
      setGiftMsg((m) => ({ ...m, [r.tier]: "" }));
    }
    /* eslint-enable react-hooks/set-state-in-effect */
  }, [gf.data, gf.state, shopify]);

  const set = <K extends keyof VdOffer>(k: K, v: VdOffer[K]) => setO((prev) => ({ ...prev, [k]: v }));
  const setTier = (i: number, patch: Partial<VdTier>) =>
    setO((prev) => ({ ...prev, tiers: prev.tiers.map((t, j) => (j === i ? { ...t, ...patch } : t)) }));

  const pickProducts = async () => {
    const selected = (await shopify.resourcePicker({
      type: "product",
      multiple: true,
      filter: { variants: false, draft: false, archived: false },
      selectionIds: o.productIds.map((id) => ({ id: `gid://shopify/Product/${id}` })),
    })) as PickedProduct[] | undefined;
    if (!selected) return;
    setO((prev) => ({
      ...prev,
      productIds: selected.map((p) => num(p.id)),
      productTitles: selected.map((p) => p.title),
      productImages: selected.map((p) => p.images?.[0]?.originalSrc ?? p.images?.[0]?.url ?? ""),
    }));
  };

  const removeProduct = (i: number) =>
    setO((prev) => ({
      ...prev,
      productIds: prev.productIds.filter((_, j) => j !== i),
      productTitles: prev.productTitles.filter((_, j) => j !== i),
      productImages: prev.productImages.filter((_, j) => j !== i),
    }));

  const pickGift = async (tier: number) => {
    const selected = (await shopify.resourcePicker({
      type: "product",
      multiple: false,
      filter: { variants: false, draft: false, archived: false },
    })) as PickedProduct[] | undefined;
    const p = selected?.[0];
    if (!p) return;
    gf.submit({ intent: "gift-info", tier: String(tier), productId: num(p.id) }, { method: "POST" });
  };

  const makeCopy = (tier: number, productId: string) =>
    gf.submit({ intent: "gift-copy", tier: String(tier), productId }, { method: "POST" });

  const addTier = () =>
    setO((prev) => {
      const last = prev.tiers[prev.tiers.length - 1];
      return {
        ...prev,
        tiers: [...prev.tiers, blankTier((last?.qty ?? 0) + 1, last?.percent ?? 0)],
      };
    });
  const removeTier = (i: number) =>
    setO((prev) => ({
      ...prev,
      tiers: prev.tiers.filter((_, j) => j !== i),
      defaultTier: Math.min(prev.defaultTier, prev.tiers.length - 2),
    }));

  const save = () => {
    const fd = new FormData();
    fd.append("intent", "save");
    fd.append("offer", JSON.stringify(o));
    submit(fd, { method: "POST" });
  };

  const steps = discountSteps(o.tiers);
  const giftBusy = gf.state !== "idle";

  return (
    <s-page heading={isNew ? "New volume discount" : o.name || "Volume discount"}>
      <s-link slot="breadcrumb-actions" href="/app/volume">
        Volume Discounts
      </s-link>
      <s-button slot="primary-action" variant="primary" onClick={save} {...(saving ? { loading: true } : {})}>
        Save
      </s-button>
      <s-button slot="secondary-actions" onClick={() => navigate("/app/volume")}>
        Cancel
      </s-button>
      <style>{CSS}</style>

      {errors.form ? (
        <s-banner tone="critical" heading="Could not save">
          {errors.form}
        </s-banner>
      ) : null}
      {Object.keys(errors).length && !errors.form ? (
        <s-banner tone="critical" heading="Fix these first">
          {Object.values(errors).join(" · ")}
        </s-banner>
      ) : null}
      {o.discountError ? (
        <s-banner tone="critical" heading="Shopify discount problem">
          {o.discountError}
        </s-banner>
      ) : null}

      <s-section heading="Offer">
        <s-stack direction="block" gap="base">
          <s-text-field
            label="Internal name"
            details="Only you see this."
            value={o.name}
            error={errors.name}
            onInput={(e: Event) => set("name", val(e))}
          />
          <s-switch
            label="Offer is active"
            details="When you save an active offer, the app creates its Shopify automatic discounts right away. Switch the same offer off in Vitals first, otherwise shoppers see two blocks (Shopify gives only the bigger of the two discounts)."
            checked={o.active}
            onChange={(e: Event) => set("active", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section heading="Applies to">
        <s-stack direction="block" gap="base">
          <s-stack direction="inline" gap="base" alignItems="center" justifyContent="space-between">
            <s-text type="strong">{`${o.productIds.length} product${o.productIds.length === 1 ? "" : "s"} selected`}</s-text>
            <s-button onClick={pickProducts}>{o.productIds.length ? "Edit products" : "Select products"}</s-button>
          </s-stack>
          <div>
            {o.productIds.map((id, i) => (
              <div className="vdf-prod" key={id}>
                {o.productImages[i] ? <img src={o.productImages[i]} alt="" /> : null}
                <span>{o.productTitles[i] || `Product ${id}`}</span>
                <s-button variant="tertiary" tone="critical" onClick={() => removeProduct(i)}>
                  Remove
                </s-button>
              </div>
            ))}
          </div>
          {errors.products ? <s-text tone="critical">{errors.products}</s-text> : null}
          <s-text color="subdued">
            Quantities add up across all products of the offer (1 pillow + 1 bag = “Buy 2”) — that is
            how Shopify’s own discounts count. For “same product only”, make a separate offer per product.
          </s-text>
        </s-stack>
      </s-section>

      <s-section heading="Tiers">
        <s-stack direction="block" gap="base">
          {o.tiers.map((t, i) => (
            <div className="vdf-tier" key={i}>
              <s-stack direction="block" gap="base">
                <s-stack direction="inline" gap="base" alignItems="center" justifyContent="space-between">
                  <h3>{`Tier #${i + 1}`}</h3>
                  <s-stack direction="inline" gap="small-200" alignItems="center">
                    <s-checkbox
                      label="Selected by default"
                      checked={o.defaultTier === i}
                      onChange={() => set("defaultTier", i)}
                    />
                    {o.tiers.length > 1 ? (
                      <s-button variant="tertiary" tone="critical" onClick={() => removeTier(i)}>
                        Delete tier
                      </s-button>
                    ) : null}
                  </s-stack>
                </s-stack>
                <s-grid gridTemplateColumns="1fr 1fr 1fr" gap="base">
                  <s-number-field
                    label="Quantity"
                    min={1}
                    max={99}
                    step={1}
                    value={String(t.qty)}
                    onInput={(e: Event) => setTier(i, { qty: Number(val(e) || 0) })}
                  />
                  <s-number-field
                    label="Discount, % off"
                    min={0}
                    max={90}
                    step={1}
                    suffix="%"
                    value={String(t.percent)}
                    onInput={(e: Event) => setTier(i, { percent: Number(val(e) || 0) })}
                  />
                  <s-text-field
                    label="Badge (optional)"
                    placeholder="e.g. Top Pick"
                    value={t.label}
                    onInput={(e: Event) => setTier(i, { label: val(e) })}
                  />
                </s-grid>
                <s-stack direction="block" gap="small-200">
                  {t.gifts.map((g: VdGift) => (
                    <div className="vdf-gift" key={g.productId}>
                      {g.image ? <img src={g.image} alt="" /> : null}
                      <div className="t">
                        <b>{`Free ${g.name || g.title}`}</b>
                        <br />
                        <span style={{ color: "#616161" }}>{g.title}</span>
                        <br />
                        {`${g.variants.length} variant${g.variants.length === 1 ? "" : "s"} · $0 · value ${g.value ? `$${g.value}` : "—"} · ${g.guard ? "protected: can't be bought alone" : "no gift-links-gift tag: not removed if added by hand"}`}
                      </div>
                      <div className="nm">
                      <s-text-field
                        label="Name in the block"
                        value={g.name ?? ""}
                        placeholder={g.title}
                        onInput={(e: Event) =>
                          setTier(i, {
                            gifts: t.gifts.map((x) => (x.productId === g.productId ? { ...x, name: val(e) } : x)),
                          })
                        }
                      />
                      </div>
                      <s-button
                        variant="tertiary"
                        tone="critical"
                        onClick={() => setTier(i, { gifts: t.gifts.filter((x) => x.productId !== g.productId) })}
                      >
                        Remove
                      </s-button>
                    </div>
                  ))}
                  {pending[i] ? (
                    <div className="vdf-gift">
                      {pending[i]!.gift.image ? <img src={pending[i]!.gift.image} alt="" /> : null}
                      <div className="t vdf-warn">
                        {`“${pending[i]!.gift.title}” costs $${pending[i]!.price}. A gift must be a $0 copy, otherwise the shopper pays for it.`}
                      </div>
                      <s-button
                        variant="primary"
                        onClick={() => makeCopy(i, pending[i]!.gift.productId)}
                        {...(giftBusy ? { loading: true } : {})}
                      >
                        Make $0 gift copy
                      </s-button>
                    </div>
                  ) : null}
                  {giftMsg[i] ? <s-text tone="critical">{giftMsg[i]}</s-text> : null}
                  <s-stack direction="inline" gap="small-200">
                    <s-button onClick={() => pickGift(i)} {...(giftBusy ? { disabled: true } : {})}>
                      Add gift
                    </s-button>
                  </s-stack>
                </s-stack>
              </s-stack>
            </div>
          ))}
          {errors.tiers ? <s-text tone="critical">{errors.tiers}</s-text> : null}
          {errors.gifts ? <s-text tone="critical">{errors.gifts}</s-text> : null}
          {o.tiers.length < MAX_TIERS ? <s-button onClick={addTier}>Add new tier</s-button> : null}
          <s-text color="subdued">
            {steps.length
              ? `Shopify automatic discounts this creates: ${steps
                  .map((s) => `${s.total}% from ${s.qty} items`)
                  .join(", ")}. Shopify applies the best one that the cart reaches.`
              : "No tier has a discount — only gifts."}
          </s-text>
        </s-stack>
      </s-section>

      <s-section heading="Discount & schedule">
        <s-stack direction="block" gap="base">
          <s-text-field
            label="Discount name"
            details="Customers see it in the cart and at checkout."
            value={o.discountTitle}
            onInput={(e: Event) => set("discountTitle", val(e))}
          />
          <s-grid gridTemplateColumns="1fr 1fr" gap="base">
            <s-date-field
              label="Starts (optional)"
              value={o.startsAt}
              onChange={(e: Event) => set("startsAt", val(e))}
            />
            <s-date-field
              label="Ends (optional, inclusive)"
              value={o.endsAt}
              error={errors.dates}
              onChange={(e: Event) => set("endsAt", val(e))}
            />
          </s-grid>
        </s-stack>
      </s-section>

      <s-section heading="Block">
        <s-stack direction="block" gap="base">
          <s-text-field
            label="Header"
            value={o.header}
            placeholder="Buy more, save more!"
            onInput={(e: Event) => set("header", val(e))}
          />
          <s-number-field
            label="Tiers shown before “Show more options”"
            min={1}
            max={MAX_TIERS}
            step={1}
            value={String(o.visibleTiers)}
            onInput={(e: Event) => set("visibleTiers", Number(val(e) || 3))}
          />
          <s-text color="subdued">
            Colours, position and fonts come from the theme (theme editor → App embeds → Volume Discounts).
          </s-text>
        </s-stack>
      </s-section>

      <s-section slot="aside" heading="Preview">
        <Preview o={o} />
      </s-section>
    </s-page>
  );
}

function Preview({ o }: { o: VdOffer }) {
  const price = 39.95;
  const usd = (n: number) => `$${n.toFixed(2)}`;
  return (
    <div className="vdp">
      {o.header ? <div className="vdp-h">{o.header}</div> : null}
      {o.tiers.slice(0, Math.max(1, o.visibleTiers)).map((t, i) => {
        const full = price * t.qty;
        const total = full * (1 - t.percent / 100);
        return (
          <div key={i} className={`vdp-t${i === o.defaultTier ? " on" : ""}`}>
            {t.label ? <span className="vdp-badge">{t.label}</span> : null}
            <div className="vdp-line">
              <span className="vdp-radio" />
              <span style={{ flex: 1 }}>
                {`Buy `}
                <b>{t.qty}</b>
                {t.percent > 0 ? (
                  <>
                    {` with `}
                    <b>{`${t.percent}%`}</b>
                    {` off`}
                  </>
                ) : (
                  ` for ${usd(price)}`
                )}
              </span>
              <b>{usd(total)}</b>
            </div>
            {i === o.defaultTier && t.qty > 1 ? (
              <div className="vdp-sw">
                <i />
                <i />
                <i />
                <i />
              </div>
            ) : null}
            {t.gifts.map((g) => (
              <div className="vdp-gift" key={g.productId}>
                {g.image ? <img src={g.image} alt="" /> : null}
                <span>{`Free ${g.name || g.title}`}</span>
                {g.value ? <s>{`$${g.value}`}</s> : null}
              </div>
            ))}
            {t.percent > 0 ? <span className="vdp-save">{`Save: ${usd(full - total)}`}</span> : null}
          </div>
        );
      })}
      {o.tiers.length > o.visibleTiers ? <span className="vdp-more">Show more options</span> : null}
      <p style={{ color: "#616161", fontSize: 12 }}>Example price $39.95. The store shows real prices.</p>
    </div>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
