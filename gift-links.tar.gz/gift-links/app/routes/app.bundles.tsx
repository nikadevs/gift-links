import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { Link, useFetcher, useLoaderData, useNavigate, useRouteError } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { buildBundle, listBundleProducts, loadBundleProduct, saveBundle, saveFields } from "../bundles.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const id = new URL(request.url).searchParams.get("product");
  if (!id) return { selection: null, products: await listBundleProducts(admin) };
  const selection = await loadBundleProduct(admin, id);
  return { selection, products: [] };
};
export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const id = String(form.get("product"));
  try {
    const loaded = await loadBundleProduct(admin, id);
    if (String(form.get("digest") || "") !== (loaded.product.config?.compareDigest || "")) throw new Error("This bundle was edited elsewhere. Reload before saving.");
    if (form.get("intent") === "disable") {
      if (!loaded.config) throw new Error("No saved bundle display.");
      await saveBundle(admin, id, { ...loaded.config, enabled: false }, loaded.product.config?.compareDigest ?? null);
      return { ok: true, message: "Bundle display disabled." };
    }
    const manualVariantIds: unknown = JSON.parse(String(form.get("manualIds") || "[]"));
    if (!Array.isArray(manualVariantIds) || manualVariantIds.some(id => typeof id !== "string")) throw new Error("Invalid component selection.");
    const preview = await buildBundle(admin, id, form.get("includePaid") === "on", form.get("enabled") === "on", manualVariantIds);
    const allowed = new Set(preview.preview.panels.flatMap(p => p.items.map(i => i.productId)));
    const fields: Record<string, unknown>[] = [];
    for (const [key, value] of form.entries()) {
      if (!key.startsWith("short:")) continue;
      const ownerId = key.slice(6);
      const title = String(value).trim();
      if (!allowed.has(ownerId) || !title) continue;
      if (title.length > 80) throw new Error("Short Title must be 80 characters or fewer.");
      fields.push({ ownerId, namespace: "custom", key: "short_title", type: "single_line_text_field", value: title });
    }
    if (fields.length) await saveFields(admin, fields);
    const refreshed = fields.length ? await buildBundle(admin, id, preview.preview.includePaid, preview.preview.enabled, manualVariantIds) : preview;
    await saveBundle(admin, id, refreshed.preview, loaded.product.config?.compareDigest ?? null);
    return { ok: true, message: "Bundle contents synced. Prices, images and Short Titles were refreshed from Shopify." };
  } catch (error) { return { ok: false, message: error instanceof Error ? error.message : "Could not save bundle contents." }; }
};
export default function Bundles() {
  const shopify = useAppBridge();
  const { selection, products } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const [picking, setPicking] = useState(false);
  const selectionKey = `${selection?.product.id}:${selection?.config?.updatedAt}`;
  const [manualSelection, setManualSelection] = useState<{key: string; ids: string[]}>({key: "", ids: []});
  const manualIds = manualSelection.key === selectionKey ? manualSelection.ids : selection?.config?.manualVariantIds || [];
  const setManualIds = (ids: string[]) => setManualSelection({key: selectionKey, ids});
  async function pickComponents() {
    const products = await shopify.resourcePicker({ type: "product", action: "select", multiple: true });
    if (products) setManualIds(products.map(p => p.variants[0]?.id).filter((id): id is string => !!id).slice(0, 24));
  }
  async function pick() {
    setPicking(true);
    try {
      const products = await shopify.resourcePicker({ type: "product", action: "select", multiple: false });
      if (products?.[0]) navigate(`/app/bundles?product=${encodeURIComponent(products[0].id)}`);
    } finally { setPicking(false); }
  }
  const items = [...new Map(selection?.config?.panels.flatMap(p => p.items).map(i => [i.productId, i]) || []).values()];
  return <s-page heading="Bundle Contents">
    <s-link slot="breadcrumb-actions" href="/app">WoodenCrew Apps</s-link>
    <s-button slot="primary-action" variant="primary" onClick={pick} {...(picking ? { disabled: true } : {})}>Choose product</s-button>
    {fetcher.data ? <s-banner tone={fetcher.data.ok ? "success" : "critical"}>{fetcher.data.message}</s-banner> : null}
    {!selection ? <s-section heading="Configured products">
      {products.length ? <div style={{ display: "grid", gap: 12 }}>{products.map(product => <div key={product.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 16, padding: "12px 0", borderBottom: "1px solid #e5e5e5" }}>
        <div><Link to={`/app/bundles?product=${encodeURIComponent(product.id)}`} style={{ fontWeight: 600 }}>{product.title}</Link><div style={{ marginTop: 4, color: "#616161" }}>{product.enabled ? "Enabled" : "Disabled"} · {product.variants} variants</div></div>
        <Link to={`/app/bundles?product=${encodeURIComponent(product.id)}`}>Edit</Link>
      </div>)}</div> : <s-paragraph>No products configured yet. Use Choose product to set up your first bundle display.</s-paragraph>}
    </s-section> : null}
    <s-section heading="What's included?">
      <s-paragraph>Display the free components from Simple Bundles, or choose included products manually. Add the Bundle Contents app block in the theme editor and drag it to the desired position. Only products with a saved, enabled configuration show the block. This module displays contents; fulfillment and cart additions remain controlled by your existing bundle setup.</s-paragraph>
      <s-paragraph>The storefront uses saved display data, including Draft components, with no API calls. Sync after changing Simple Bundles, compare-at prices, images or Short Titles. Items sort by compare-at price, highest first. Missing compare-at prices are left blank and excluded from total savings.</s-paragraph>
    </s-section>
    {selection ? <s-section heading={selection.product.title}>
      <fetcher.Form method="post" key={`${selection.product.id}:${selection.config?.updatedAt || "new"}`}>
        <input type="hidden" name="product" value={selection.product.id}/>
        <input type="hidden" name="digest" value={selection.product.config?.compareDigest || ""}/>
        <input type="hidden" name="manualIds" value={JSON.stringify(manualIds)}/>
        <p><button type="button" onClick={pickComponents}>Choose included products manually</button> {manualIds.length ? <><span>{manualIds.length} component variants selected · </span><button type="button" onClick={() => setManualIds([])}>Use Simple Bundles instead</button></> : <span>Automatic import from Simple Bundles</span>}</p>
        <p><label><input type="checkbox" name="enabled" defaultChecked={selection.config?.enabled ?? false}/> Enable display for this product</label></p>
        {!manualIds.length ? <p><label><input type="checkbox" name="includePaid" defaultChecked={selection.config?.includePaid ?? false}/> Also show paid components (including the main product)</label></p> : null}
        <p>{selection.variants.length} variants · Last sync: {selection.config?.updatedAt || "Never"}</p>
        {items.length ? <div style={{display:"grid",gap:12}}>{items.map(item => <div key={item.productId} style={{display:"grid",gridTemplateColumns:"56px 1fr",gap:12,alignItems:"center"}}>
          {item.image ? <img src={item.image} alt="" width="56" height="56" loading="lazy" style={{objectFit:"contain"}}/> : <span/>}
          <label>Short Title<input aria-label={`Short Title for ${item.title}`} name={`short:${item.productId}`} defaultValue={item.title} maxLength={80} style={{display:"block",width:"100%",padding:8}}/>
            {item.value === null ? <span style={{color:"#b42318"}}>Compare-at price missing — edit the component variant in Shopify.</span> : null}
          </label>
        </div>)}</div> : <p>Sync once to import components, then edit their Short Titles here or in Shopify product metafields.</p>}
        <p><button type="submit" name="intent" value="sync" disabled={fetcher.state !== "idle"}>Save &amp; sync contents</button></p>
        {selection.config?.enabled ? <button type="submit" name="intent" value="disable" disabled={fetcher.state !== "idle"}>Disable display</button> : null}
      </fetcher.Form>
    </s-section> : null}
  </s-page>;
}
export function ErrorBoundary() { return boundary.error(useRouteError()); }
export const headers: HeadersFunction = args => boundary.headers(args);
