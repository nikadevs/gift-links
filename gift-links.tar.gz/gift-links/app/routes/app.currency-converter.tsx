import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { CSSProperties, ReactNode } from "react";
import { useEffect, useMemo, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { CC_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import type { CcConfig, CcPos } from "../cc.shared";
import { CC_DEFAULTS, normalizeCc } from "../cc.shared";
import { loadCcConfig, loadShopCurrencies, saveCcConfig } from "../cc.server";

/**
 * Currency Converter (replacement for Vitals «Currency Converter»).
 * No separate app embed: Turn on / Turn off and Save write wc_cc.config; the
 * Gift Links embed prints the switcher + assets/wc-currency.js when enabled.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config, saved }, domain, currencies] = await Promise.all([
    loadCcConfig(admin),
    loadShopDomain(admin),
    loadShopCurrencies(admin),
  ]);
  const live = config.enabled
    ? await checkEmbed(domain, CC_EMBED_MARKERS, url.searchParams.has("refresh"))
    : "off";
  return { config, saved, live, domain, base: currencies.base, shopCurrencies: currencies.list };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadCcConfig(admin);
  const intent = String(form.get("intent") || "");
  let next: CcConfig = config;
  if (intent === "toggle") next = { ...config, enabled: form.get("enabled") === "1" };
  else if (intent === "save") {
    let raw: Record<string, unknown> = {};
    try {
      raw = JSON.parse(String(form.get("config") || "{}"));
    } catch {
      return { ok: false as const, error: "Bad form data", intent };
    }
    next = normalizeCc({ ...raw, enabled: config.enabled });
  } else return { ok: false as const, error: "Unknown action", intent };
  next.updatedAt = new Date().toISOString();
  try {
    await saveCcConfig(admin, installationId, next);
    return { ok: true as const, error: "", intent, enabled: next.enabled };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e), intent };
  }
};

const POS_LABELS: Record<CcPos, string> = {
  menu: "Menu",
  top_left: "Top left",
  top_right: "Top right",
  bottom_left: "Bottom left",
  bottom_right: "Bottom right",
};

const box: CSSProperties = {
  border: "1px solid #e3e3e3",
  borderRadius: 12,
  background: "#fff",
  marginBottom: 12,
  overflow: "hidden",
};
const input: CSSProperties = {
  boxSizing: "border-box",
  width: "100%",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  font: "inherit",
  fontSize: 13,
  background: "#fdfdfd",
};
const hint: CSSProperties = { color: "#616161", fontSize: 12, lineHeight: "16px", margin: "2px 0 0" };
const lbl: CSSProperties = { display: "block", fontSize: 13, margin: "12px 0 4px" };

function Panel({ title, children, open: o = false }: { title: string; children: ReactNode; open?: boolean }) {
  const [open, setOpen] = useState(o);
  return (
    <div style={box}>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        style={{
          all: "unset",
          boxSizing: "border-box",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          width: "100%",
          padding: "14px 16px",
          fontWeight: 650,
          fontSize: 13,
          cursor: "pointer",
        }}
      >
        {title}
        <span style={{ transform: open ? "rotate(180deg)" : "none", transition: "transform .15s" }}>⌄</span>
      </button>
      {open ? <div style={{ padding: "0 16px 16px" }}>{children}</div> : null}
    </div>
  );
}

function Check({
  checked,
  onChange,
  label,
  help,
}: {
  checked: boolean;
  onChange: (v: boolean) => void;
  label: string;
  help?: string;
}) {
  return (
    <label style={{ display: "flex", gap: 8, alignItems: "flex-start", margin: "10px 0", fontSize: 13, cursor: "pointer" }}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} style={{ marginTop: 2 }} />
      <span>
        {label}
        {help ? <span style={{ ...hint, display: "block" }}>{help}</span> : null}
      </span>
    </label>
  );
}

function Color({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <span style={lbl}>{label}</span>
      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <input
          type="color"
          value={`#${/^[0-9a-f]{6}$/i.test(value) ? value : "000000"}`}
          onChange={(e) => onChange(e.target.value.slice(1))}
          style={{ width: 32, height: 32, padding: 0, border: "1px solid #ccc", borderRadius: 8, background: "none" }}
        />
        <span style={{ position: "relative", flex: 1 }}>
          <span style={{ position: "absolute", left: 10, top: 7, color: "#8a8a8a", fontSize: 13 }}>#</span>
          <input
            style={{ ...input, paddingLeft: 22 }}
            value={value}
            maxLength={7}
            onChange={(e) => onChange(e.target.value.replace(/^#/, "").trim())}
          />
        </span>
      </div>
    </div>
  );
}

function PosSelect({ value, onChange }: { value: CcPos; onChange: (v: CcPos) => void }) {
  return (
    <select style={input} value={value} onChange={(e) => onChange(e.target.value as CcPos)}>
      {(Object.keys(POS_LABELS) as CcPos[]).map((p) => (
        <option key={p} value={p}>
          {POS_LABELS[p]}
        </option>
      ))}
    </select>
  );
}

/** Small mock of the storefront switcher with the current colours. */
function Preview({ c, base }: { c: CcConfig; base: string }) {
  const [open, setOpen] = useState(true);
  const list = c.currencies.length ? c.currencies : [base];
  const sel = list[0];
  const t = `#${c.text}`;
  return (
    <div style={{ ...box, padding: 20, background: "#f6f6f7", minHeight: 360 }}>
      <div style={{ fontSize: 12, color: "#616161", marginBottom: 10 }}>Preview</div>
      <div style={{ background: "#fff", borderRadius: 8, padding: "18px 20px", fontFamily: "inherit", position: "relative" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <strong style={{ fontSize: 18, letterSpacing: 0.5 }}>WOODENCREW</strong>
          <button
            type="button"
            onClick={() => setOpen(!open)}
            style={{
              all: "unset",
              display: "flex",
              alignItems: "center",
              gap: 8,
              height: 32,
              border: "1px solid transparent",
              borderRadius: 4,
              background: `#${c.bg}`,
              color: t,
              fontSize: 14,
              fontWeight: 500,
              cursor: "pointer",
            }}
          >
            {c.flags ? <span style={{ fontSize: 11, opacity: 0.6 }}>[flag]</span> : null}
            {sel}
            <svg viewBox="0 0 20 20" width="20" height="20" style={{ transform: open ? "rotate(180deg)" : "none" }}>
              <path d="M6.5 8.5 10 12l3.5-3.5" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" />
            </svg>
          </button>
        </div>
        {open ? (
          <div
            style={{
              position: "absolute",
              left: 150,
              top: 56,
              minWidth: 73,
              maxHeight: 250,
              overflowY: "auto",
              background: `#${c.bg}`,
              border: "1px solid #000",
              borderRadius: 4,
              boxShadow: "0 2px 8px rgba(0,0,0,.15)",
              color: t,
              fontSize: 14,
              fontWeight: 500,
              lineHeight: "19.6px",
              zIndex: 2,
            }}
          >
            {list.map((code) => (
              <div key={code} style={{ padding: "12px 8px", background: code === sel ? `#${c.activeBg}` : "transparent" }}>
                {code}
              </div>
            ))}
          </div>
        ) : null}
        <div style={{ marginTop: 24, height: 120, borderRadius: 6, background: "#f1f1f1" }} />
        <div style={{ marginTop: 10, fontSize: 13, color: "#616161" }}>Product title</div>
        <div style={{ fontSize: 13 }}>
          <s style={{ color: "#999" }}>$59.95</s> $34.95{c.showCode ? ` ${sel}` : ""}
        </div>
      </div>
    </div>
  );
}

export default function CurrencyConverter() {
  const { config, saved, live, domain, base, shopCurrencies } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const [c, setC] = useState<CcConfig>(config);
  const [add, setAdd] = useState("");
  const busy = fetcher.state !== "idle";
  const dirty = useMemo(() => JSON.stringify({ ...c, enabled: 0, updatedAt: 0 }) !== JSON.stringify({ ...config, enabled: 0, updatedAt: 0 }), [c, config]);

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      if (fetcher.data.intent === "toggle")
        shopify.toast.show(fetcher.data.enabled ? "Currency Converter turned on" : "Currency Converter turned off");
      else shopify.toast.show("Saved");
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const set = <K extends keyof CcConfig>(k: K, v: CcConfig[K]) => setC((p) => ({ ...p, [k]: v }));
  const enabledShop = shopCurrencies.filter((x) => x.enabled);
  const nameOf = (code: string) => shopCurrencies.find((x) => x.code === code)?.name || code;
  const addable = enabledShop.filter((x) => !c.currencies.includes(x.code));
  const notEnabled = c.currencies.filter((code) => shopCurrencies.length && !enabledShop.some((x) => x.code === code));

  const toggle = () => {
    const fd = new FormData();
    fd.set("intent", "toggle");
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };
  const save = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("config", JSON.stringify(c));
    fetcher.submit(fd, { method: "post" });
  };
  const move = (i: number, d: number) => {
    const l = [...c.currencies];
    const j = i + d;
    if (j < 0 || j >= l.length) return;
    [l[i], l[j]] = [l[j], l[i]];
    set("currencies", l);
  };

  return (
    <s-page inlineSize="large" heading="Currency Converter">
      <s-button slot="primary-action" variant="primary" disabled={!dirty || busy || undefined} loading={(busy && fetcher.formData?.get("intent") === "save") || undefined} onClick={save}>
        Save
      </s-button>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? <s-badge tone="success">Active</s-badge> : <s-badge>Inactive</s-badge>}
          <s-button variant={config.enabled ? "secondary" : "primary"} loading={(busy && fetcher.formData?.get("intent") === "toggle") || undefined} onClick={toggle}>
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: switcher present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              <s-button variant="tertiary" href={domain || "/"} target="_blank">
                Open store
              </s-button>
            </>
          ) : null}
        </s-stack>
        {!saved ? (
          <s-paragraph>
            Settings below are pre-filled with the values Vitals Currency Converter uses on this store. Press Save
            to keep them.
          </s-paragraph>
        ) : null}
        {config.enabled && live === "off" ? (
          <s-banner tone="critical">
            The storefront doesn’t have the switcher yet. It is printed by the “Gift Links” app embed — it must stay
            on (Theme editor → App embeds). Changes can take a minute to appear (theme cache).
          </s-banner>
        ) : null}
        {config.enabled ? (
          <s-banner tone="warning">
            If Vitals Currency Converter is still Active, the store shows two switchers. Deactivate it in Vitals.
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
      </s-section>

      <div style={{ display: "grid", gridTemplateColumns: "minmax(280px, 340px) 1fr", gap: 16, alignItems: "start" }}>
        <div>
          <Panel title="Currencies" open>
            <p style={{ ...hint, fontSize: 13, lineHeight: "18px" }}>
              Currencies shown in the switcher, in this order. Only currencies enabled in Shopify (Settings → Markets)
              can be picked: the price, cart and checkout are converted by Shopify itself. Store currency:{" "}
              <b>{base}</b>.
            </p>
            <div style={{ display: "flex", gap: 6, margin: "10px 0" }}>
              <select style={input} value={add} onChange={(e) => setAdd(e.target.value)}>
                <option value="">Add another currency…</option>
                {addable.map((x) => (
                  <option key={x.code} value={x.code}>
                    {x.code} ({x.name})
                  </option>
                ))}
              </select>
              <s-button
                disabled={!add || undefined}
                onClick={() => {
                  if (add) set("currencies", [...c.currencies, add]);
                  setAdd("");
                }}
              >
                Add
              </s-button>
            </div>
            <s-stack direction="inline" gap="small-200">
              <s-button tone="critical" variant="primary" onClick={() => set("currencies", c.currencies.filter((x) => x === base))}>
                Remove all
              </s-button>
              <s-button onClick={() => set("currencies", [...c.currencies, ...addable.map((x) => x.code)])}>Add all</s-button>
            </s-stack>
            <div style={{ marginTop: 10 }}>
              {c.currencies.map((code, i) => (
                <div
                  key={code}
                  style={{ display: "flex", alignItems: "center", gap: 6, padding: "8px 0", borderTop: i ? "1px solid #ebebeb" : "none", fontSize: 13 }}
                >
                  <span style={{ display: "flex", flexDirection: "column", lineHeight: "10px" }}>
                    <button type="button" aria-label="Move up" onClick={() => move(i, -1)} style={{ all: "unset", cursor: "pointer", color: i ? "#303030" : "#ccc", fontSize: 10 }}>▲</button>
                    <button type="button" aria-label="Move down" onClick={() => move(i, 1)} style={{ all: "unset", cursor: "pointer", color: i < c.currencies.length - 1 ? "#303030" : "#ccc", fontSize: 10 }}>▼</button>
                  </span>
                  <span style={{ flex: 1 }}>
                    <b>{code}</b> <span style={{ color: "#616161" }}>({nameOf(code)})</span>
                  </span>
                  {code === base ? (
                    <s-badge>Default</s-badge>
                  ) : (
                    <button
                      type="button"
                      aria-label={`Remove ${code}`}
                      onClick={() => set("currencies", c.currencies.filter((x) => x !== code))}
                      style={{ all: "unset", cursor: "pointer", color: "#8a8a8a", padding: "0 4px" }}
                    >
                      🗑
                    </button>
                  )}
                </div>
              ))}
            </div>
            {notEnabled.length ? (
              <p style={{ ...hint, color: "#8e1f0b" }}>
                Not enabled in Shopify Markets, hidden on the storefront: {notEnabled.join(", ")}
              </p>
            ) : null}
          </Panel>

          <Panel title="Display settings">
            <p style={{ ...hint, fontSize: 13, lineHeight: "18px", background: "#eaf4ff", borderRadius: 8, padding: 10 }}>
              The switcher is placed next to the store logo (Menu) or fixed in a corner of the screen. If the theme
              has its own currency selector, keep only one of them visible.
            </p>
            <Check checked={c.showDesktop} onChange={(v) => set("showDesktop", v)} label="Show on desktop" />
            <span style={lbl}>Desktop position</span>
            <PosSelect value={c.desktopPos} onChange={(v) => set("desktopPos", v)} />
            <Check checked={c.showMobile} onChange={(v) => set("showMobile", v)} label="Show on mobile" />
            <span style={lbl}>Mobile position</span>
            <PosSelect value={c.mobilePos} onChange={(v) => set("mobilePos", v)} />
            <Check
              checked={c.showCode}
              onChange={(v) => set("showCode", v)}
              label="Display currency name"
              help="Adds the currency code after prices: “$10 USD” instead of “$10”."
            />
            <Check
              checked={c.hoverOriginal}
              onChange={(v) => set("hoverOriginal", v)}
              label="Show price in the store’s currency on mouse over"
            />
            <Check checked={c.flags} onChange={(v) => set("flags", v)} label="Display flags" help="Flag images load from flagcdn.com only when this is on." />
            <span style={lbl}>Tooltip font size</span>
            <input
              style={input}
              type="number"
              min={8}
              max={30}
              value={c.tooltipSize}
              onChange={(e) => set("tooltipSize", Number(e.target.value))}
            />
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
              <Color label="Background color" value={c.bg} onChange={(v) => set("bg", v)} />
              <Color label="Active background color" value={c.activeBg} onChange={(v) => set("activeBg", v)} />
              <Color label="Border color" value={c.border} onChange={(v) => set("border", v)} />
              <Color label="Text color" value={c.text} onChange={(v) => set("text", v)} />
            </div>
          </Panel>

          <Panel title="Conversion options">
            <Check
              checked={c.autoConvert}
              onChange={(v) => set("autoConvert", v)}
              label="Automatically convert currency based on location"
              help="On the first visit the store switches to the currency of the visitor’s country (Shopify geolocation). A currency picked by hand is never overridden."
            />
            <Check
              checked={c.onlyListed}
              onChange={(v) => set("onlyListed", v)}
              label="Only convert automatically if the user’s currency is listed above"
            />
            <p style={{ ...hint, fontSize: 13, lineHeight: "18px" }}>
              Rounding: prices are converted by Shopify Markets and are the real prices charged at checkout, so they
              follow Shopify’s rounding rules (Settings → Markets → Products and pricing). The app doesn’t change them,
              which keeps the storefront price and the checkout price identical.
            </p>
          </Panel>

          <Panel title="Cart notice">
            <Check
              checked={c.cartNotice}
              onChange={(v) => set("cartNotice", v)}
              label="Enable cart notice"
              help="A short text on the cart page when the visitor’s currency differs from the store currency."
            />
            <span style={lbl}>Cart notice message</span>
            <input style={input} value={c.cartNoticeText} onChange={(e) => set("cartNoticeText", e.target.value)} />
            <p style={hint}>
              {"{{ visible_currency }}"} = the visitor’s currency, {"{{ default_currency }}"} = {base}. With Shopify
              Markets the checkout is in the visitor’s currency, so keep the wording accurate.
            </p>
            <Color label="Background color" value={c.cartNoticeBg} onChange={(v) => set("cartNoticeBg", v)} />
          </Panel>

          <Panel title="Custom CSS">
            <p style={hint}>Added after the switcher styles on the storefront. Classes: .wc-cc, .wc-cc--menu, .wc-cc-btn, .wc-cc-list, .wc-cc-opt.</p>
            <textarea
              style={{ ...input, height: 160, padding: 8, fontFamily: "monospace", fontSize: 12 }}
              value={c.customCss}
              onChange={(e) => set("customCss", e.target.value)}
            />
            <s-button variant="tertiary" onClick={() => set("customCss", CC_DEFAULTS.customCss)}>
              Reset to default
            </s-button>
          </Panel>
        </div>
        <Preview c={c} base={base} />
      </div>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
