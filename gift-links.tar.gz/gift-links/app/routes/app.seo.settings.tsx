import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useState } from "react";
import { useFetcher, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import { getSettings, saveSettings } from "../seo/seo-store.server";
import { SeoTabs } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { shop, origin } = await seoAuth(request);
  const s = await getSettings(shop);
  return {
    origin,
    keySet: !!s.psiKey,
    keyHint: s.psiKey ? `${s.psiKey.slice(0, 4)}…${s.psiKey.slice(-4)}` : "",
    // eslint-disable-next-line no-undef
    envKey: !!process.env.PSI_API_KEY,
    keyPaths: s.keyPaths.join("\n"),
    autoDaily: s.autoDaily,
    autoPsi: s.autoPsi,
    fullCrawlMax: s.fullCrawlMax,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { shop, origin } = await seoAuth(request);
  const form = await request.formData();
  const s = await getSettings(shop);
  const key = String(form.get("psiKey") ?? "").trim();
  if (form.get("clearKey") === "1") s.psiKey = "";
  else if (key) {
    if (!/^[A-Za-z0-9_-]{20,60}$/.test(key)) return { ok: false, message: "That doesn’t look like a Google API key" };
    s.psiKey = key;
  }
  const host = new URL(origin).host;
  s.keyPaths = String(form.get("keyPaths") ?? "")
    .split(/\s+/)
    .map((p) => p.trim())
    .filter(Boolean)
    .map((p) => {
      try {
        const u = new URL(p, origin);
        return u.host === host ? u.pathname + u.search : "";
      } catch {
        return "";
      }
    })
    .filter(Boolean)
    .slice(0, 40);
  s.autoDaily = form.get("autoDaily") === "on";
  s.autoPsi = form.get("autoPsi") === "on";
  const max = Number(form.get("fullCrawlMax"));
  s.fullCrawlMax = Number.isFinite(max) ? Math.min(2000, Math.max(20, Math.round(max))) : 300;
  await saveSettings(shop, s);
  return { ok: true, message: "Settings saved" };
};

export default function SeoSettings() {
  const d = useLoaderData<typeof loader>();
  const f = useFetcher<typeof action>();
  const [key, setKey] = useState("");
  const [paths, setPaths] = useState(d.keyPaths);
  const [autoDaily, setAutoDaily] = useState(d.autoDaily);
  const [autoPsi, setAutoPsi] = useState(d.autoPsi);
  const [max, setMax] = useState(String(d.fullCrawlMax));

  const save = (clearKey = false) =>
    f.submit(
      {
        psiKey: key,
        clearKey: clearKey ? "1" : "",
        keyPaths: paths,
        ...(autoDaily ? { autoDaily: "on" } : {}),
        ...(autoPsi ? { autoPsi: "on" } : {}),
        fullCrawlMax: max,
      },
      { method: "POST" },
    );

  return (
    <s-page heading="SEO & Speed — Settings">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button slot="primary-action" variant="primary" onClick={() => save()} {...(f.state !== "idle" ? { disabled: true } : {})}>
        Save
      </s-button>
      <SeoTabs />
      {f.data && f.state === "idle" ? <s-banner tone={f.data.ok ? "success" : "critical"}>{f.data.message}</s-banner> : null}

      <s-section heading="Google PageSpeed API key">
        <s-paragraph>
          {d.keySet
            ? `A key is saved (${d.keyHint}).`
            : d.envKey
              ? "Using the key from the server (.env PSI_API_KEY)."
              : "No key yet — speed tests will usually fail with “quota exceeded”."}
        </s-paragraph>
        <s-ordered-list>
          <s-list-item>
            Open{" "}
            <s-link href="https://console.cloud.google.com/apis/library/pagespeedonline.googleapis.com" target="_blank">
              PageSpeed Insights API in Google Cloud
            </s-link>{" "}
            (any Google account), create a project if asked and press Enable.
          </s-list-item>
          <s-list-item>
            APIs & Services → Credentials → Create credentials → API key. Restrict it to
            “PageSpeed Insights API”.
          </s-list-item>
          <s-list-item>Paste it below and press Save. Free, no billing needed.</s-list-item>
        </s-ordered-list>
        <div className="wcs-filters">
          <input
            style={{ flex: 1, minWidth: 280 }}
            type="password"
            autoComplete="off"
            placeholder={d.keySet ? "Paste a new key to replace" : "AIza…"}
            value={key}
            onChange={(e) => setKey(e.target.value)}
          />
          {d.keySet ? (
            <s-button tone="critical" variant="tertiary" onClick={() => save(true)}>
              Remove key
            </s-button>
          ) : null}
        </div>
        <s-paragraph>
          <s-text color="subdued">
            The key is stored only on the app server (not in Shopify, not in the theme).
          </s-text>
        </s-paragraph>
      </s-section>

      <s-section heading="Daily checks">
        <s-stack direction="block" gap="small-200">
          <label>
            <input type="checkbox" checked={autoDaily} onChange={(e) => setAutoDaily(e.target.checked)} /> Audit
            key pages every day, the whole sitemap once a week
          </label>
          <label>
            <input type="checkbox" checked={autoPsi} onChange={(e) => setAutoPsi(e.target.checked)} /> PageSpeed
            test every day (home + first key product, mobile + desktop)
          </label>
          <label>
            Max pages in a full audit{" "}
            <input type="number" min={20} max={2000} value={max} onChange={(e) => setMax(e.target.value)} style={{ width: 90 }} />
          </label>
        </s-stack>
      </s-section>

      <s-section heading="Key pages">
        <s-paragraph>
          One URL or path per line. Used by the daily audit and the speed test (first product
          path). Empty = home + a sample of products, collections, blog and pages from the sitemap.
        </s-paragraph>
        <textarea
          className="wcs-input"
          style={{ minHeight: 160, fontFamily: "monospace" }}
          value={paths}
          placeholder={`/\n/products/pillow-deep-sleep-set\n/collections/sleep-comfort\n/blogs/travel`}
          onChange={(e) => setPaths(e.target.value)}
        />
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
