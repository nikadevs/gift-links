import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { Outlet, useLoaderData, useRouteError } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { AppProvider } from "@shopify/shopify-app-react-router/react";

import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  await authenticate.admin(request);

  // eslint-disable-next-line no-undef
  return { apiKey: process.env.SHOPIFY_API_KEY || "" };
};

export default function App() {
  const { apiKey } = useLoaderData<typeof loader>();

  return (
    <AppProvider apiKey={apiKey}>
      <s-app-nav>
        {/* rel="home": the app name in the sidebar already opens /app, so this
            link is hidden — keeps the module list short enough to fit */}
        <s-link href="/app" {...{ rel: "home" }}>
          Home
        </s-link>
        <s-link href="/app/volume">Volume Discounts</s-link>
        <s-link href="/app/features">Features with Image Slider</s-link>
        <s-link href="/app/gifts">Gift Links</s-link>
        <s-link href="/app/upsells">Checkbox Upsell</s-link>
        <s-link href="/app/tracking">Tracking</s-link>
        <s-link href="/app/native-bundles">Bundles</s-link>
        <s-link href="/app/bundles-v2">Bundles v2</s-link>
        <s-link href="/app/bundles">Bundle Contents</s-link>
        <s-link href="/app/trustpilot">Trustpilot Reviews</s-link>
        <s-link href="/app/seo">SEO &amp; Speed</s-link>
        <s-link href="/app/recordings">Session Recordings</s-link>
        <s-link href="/app/checkout-buttons">Checkout Buttons</s-link>
        <s-link href="/app/sticky-atc">Sticky Add to Cart</s-link>
        <s-link href="/app/content-protection">Content Protection</s-link>
        <s-link href="/app/quick-links">Quick Links</s-link>
        <s-link href="/app/best-sellers">Best Sellers Protection</s-link>
        <s-link href="/app/sale-banner">Sale Banner</s-link>
        <s-link href="/app/cart-summary">Cart Summary</s-link>
        <s-link href="/app/favicon-cart">Favicon Cart Count</s-link>
        <s-link href="/app/currency-converter">Currency Converter</s-link>
      </s-app-nav>
      <Outlet />
    </AppProvider>
  );
}

// Shopify needs React Router to catch some thrown responses, so that their headers are included in the response.
export function ErrorBoundary() {
  return boundary.error(useRouteError());
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
