import type { ActionFunctionArgs } from "react-router";
import prisma from "../db.server";
import { record404 } from "../seo/seo-store.server";

/**
 * 404 beacon from the storefront (theme app embed “SEO & Speed”, only on the
 * 404 template). navigator.sendBeacon → text/plain JSON:
 *   { shop: "x.myshopify.com", path: "/products/old", ref: "https://google.com/" }
 * Accepted only for shops that installed the app. No personal data stored.
 */
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const shopCache = new Map<string, { ok: boolean; at: number }>();
const ipHits = new Map<string, { n: number; at: number }>();

async function knownShop(shop: string) {
  const hit = shopCache.get(shop);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.ok;
  const n = await prisma.session.count({ where: { shop } });
  shopCache.set(shop, { ok: n > 0, at: Date.now() });
  return n > 0;
}

export const loader = () => new Response(null, { status: 204, headers: CORS });

export const action = async ({ request }: ActionFunctionArgs) => {
  if (request.method === "OPTIONS")
    return new Response(null, { status: 204, headers: CORS });
  try {
    const ip =
      request.headers.get("x-forwarded-for")?.split(",")[0].trim() ?? "local";
    const now = Date.now();
    const r = ipHits.get(ip);
    if (r && now - r.at < 60000) {
      if (++r.n > 20) return new Response(null, { status: 204, headers: CORS });
    } else ipHits.set(ip, { n: 1, at: now });
    if (ipHits.size > 5000) ipHits.clear();

    const raw = (await request.text()).slice(0, 2000);
    const body = JSON.parse(raw) as { shop?: string; path?: string; ref?: string };
    const shop = String(body.shop ?? "").toLowerCase();
    if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop))
      return new Response(null, { status: 204, headers: CORS });
    if (!(await knownShop(shop)))
      return new Response(null, { status: 204, headers: CORS });

    let path = String(body.path ?? "").split(/[?#]/)[0].slice(0, 300);
    if (!path.startsWith("/")) return new Response(null, { status: 204, headers: CORS });
    if (/\.(php|asp|aspx|env|git|sql|bak)$|wp-(admin|login|content|includes)|xmlrpc/i.test(path))
      return new Response(null, { status: 204, headers: CORS }); // bot noise
    path = path.replace(/\/+$/, "") || "/";

    let ref = "";
    try {
      if (body.ref) {
        const u = new URL(String(body.ref));
        ref = u.host + (u.pathname.length > 1 ? u.pathname.slice(0, 120) : "");
      }
    } catch {
      /* ignore */
    }
    await record404(shop, path, ref);
  } catch {
    /* never fail a beacon */
  }
  return new Response(null, { status: 204, headers: CORS });
};
