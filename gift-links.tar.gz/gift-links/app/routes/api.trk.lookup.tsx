import type { ActionFunctionArgs } from "react-router";
import prisma from "../db.server";
import { getTrkSettings, loadShipments, recordLookup, trkShopExists } from "../trk-store.server";
import {
  TRK_STATUS_LABEL,
  isOriginEvent,
  stripChinese,
  progressRank,
  type TrkSettings,
  type TrkShipment,
} from "../trk.shared";

/**
 * Public lookup for the storefront tracking page (/pages/<handle>).
 *   POST /api/trk/lookup  text/plain JSON {shop, nums}            (tracking or last-mile number)
 *   POST /api/trk/lookup  text/plain JSON {shop, order, email}    (email never in a URL)
 * Returns only shipping data: status, carrier, scans, order number. No address, no
 * name, no items. Order lookup needs the matching order email. 40 lookups/min/IP.
 */
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Cache-Control": "no-store",
};
const shopCache = new Map<string, { ok: boolean; at: number }>();
const ipHits = new Map<string, { n: number; at: number }>();

async function knownShop(shop: string) {
  const hit = shopCache.get(shop);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.ok;
  const ok = (await prisma.session.count({ where: { shop } })) > 0 && (await trkShopExists(shop));
  shopCache.set(shop, { ok, at: Date.now() });
  return ok;
}

const json = (data: unknown, status = 200) => Response.json(data, { status, headers: CORS });

function view(r: TrkShipment, s: TrkSettings) {
  const hideOrigin = s.hideOriginEvents;
  const steps = ["info_received", "in_transit", "last_mile", "out_for_delivery", "delivered"] as const;
  const rank = progressRank(r.status);
  const firstAt = (st: string) => [...r.events].reverse().find((e) => e.status === st)?.at ?? "";
  const clean = (t: string) => (s.hideChinese ? stripChinese(t) : t);
  const events = (hideOrigin ? r.events.filter((e) => !isOriginEvent(e)) : r.events)
    .map((e) => ({ ...e, text: clean(e.text), place: clean(e.place) }))
    .filter((e) => e.text)
    .slice(0, 80);
  const lm = s.lastMileOnly && !!r.lastMileNumber;
  return {
    number: r.number,
    lastMileOnly: lm,
    order: r.orderName,
    carrier: r.carrier || "YunExpress",
    lastMileNumber: r.lastMileNumber,
    lastMileCarrier: r.lastMileCarrier,
    lastMileSite: /^https?:\/\//i.test(r.lastMileSite) ? r.lastMileSite : "",
    status: r.status,
    statusLabel: TRK_STATUS_LABEL[r.status],
    statusAt: r.statusAt,
    shippedAt: r.shippedAt,
    deliveredAt: r.deliveredAt,
    transitDays: r.transitDays,
    country: r.country,
    steps: steps.map((st) => ({
      key: st,
      label: st === "info_received" ? "Order ready" : TRK_STATUS_LABEL[st],
      done: st === "info_received" || !!firstAt(st) || progressRank(st) <= rank,
      at: st === "info_received" ? r.shippedAt : firstAt(st),
    })),
    events: events.map((e) => ({ at: e.at, local: e.local ?? "", text: e.text, place: e.place })),
    updatedAt: r.lastPolledAt,
  };
}

export const loader = () => json({ error: "Use POST" }, 405);

export async function action({ request }: ActionFunctionArgs) {
  if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
  let body: Record<string, unknown> = {};
  try {
    body = JSON.parse((await request.text()).slice(0, 2000));
  } catch {
    return json({ error: "Bad request" }, 400);
  }
  const get = (k: string) => String(body[k] ?? "");
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0].trim() ?? "local";
  const now = Date.now();
  const hit = ipHits.get(ip);
  if (hit && now - hit.at < 60000) {
    if (++hit.n > 40) return json({ error: "Too many requests, try again in a minute" }, 429);
  } else ipHits.set(ip, { n: 1, at: now });
  if (ipHits.size > 5000) ipHits.clear();

  const shop = get("shop").toLowerCase();
  if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop) || !(await knownShop(shop))) {
    return json({ error: "Unknown store" }, 404);
  }
  const s = await getTrkSettings(shop);
  const m = await loadShipments(shop);
  const nums = get("nums")
    .split(/[\s,]+/)
    .map((x) => x.trim().toUpperCase())
    .filter((x) => /^[A-Z0-9-]{6,40}$/.test(x))
    .slice(0, 5);
  let found: TrkShipment[] = [];
  if (nums.length) {
    const all = [...m.values()];
    for (const n of nums) {
      const r = m.get(n) ?? all.find((x) => x.lastMileNumber.toUpperCase() === n);
      if (r && !found.includes(r)) found.push(r);
    }
  } else {
    const order = get("order").replace(/[^0-9a-z-]/gi, "");
    const email = get("email").trim().toLowerCase();
    if (!order || !email) return json({ error: "Enter your order number and email" }, 400);
    found = [...m.values()].filter(
      (r) => r.orderName.replace(/^#/, "").toLowerCase() === order.toLowerCase() && r.email.toLowerCase() === email,
    );
  }
  recordLookup(shop, found.length > 0);
  if (!found.length) {
    return json({ results: [], message: "We could not find this shipment yet. Tracking appears within 24 hours after your order ships." });
  }
  return json({ results: found.map((r) => view(r, s)) });
}
