import type { HeadersFunction } from "react-router";
import { Outlet } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";

/**
 * Tracking (replacement for Track123) — layout for the module pages:
 * Dashboard, Tracking page, Orders, Notification, Analytics, Settings
 * (same sections as Track123 without Add-Ons and Billing).
 */
export default function TrackingLayout() {
  return <Outlet />;
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
