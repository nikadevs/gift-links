import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { CSSProperties, ReactNode } from "react";
import { useEffect, useState } from "react";
import { Link, useFetcher, useLoaderData, useRevalidator, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { TRK_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { ensureTrackingPage, loadTrkPageConfig, saveTrkPageConfig } from "../trk-admin.server";
import {
  addLog,
  getLog,
  getState,
  getTrkSettings,
  loadShipments,
  saveShipments,
  saveTrkSettings,
  withShop,
} from "../trk-store.server";
import { applyOutputs, computeStats, importOrders, isTickRunning, refreshOne, runTick } from "../trk.server";
import { yunConfigured, yunTrack } from "../trk-yun.server";
import {
  TRK_OMNISEND_EVENT,
  TRK_STATUS_LABEL,
  TRK_STATUS_ORDER,
  maskEmail,
  normalizeTrkSettings,
  publicSettings,
  type TrkSettingsPublic,
  type TrkStatus,
} from "../trk.shared";

/**
 * Tracking (replacement for Track123): carrier data from the YunExpress Open API
 * (free), Shopify fulfillment events, tracking page, Omnisend emails, PayPal sync.
 * Every output that changes orders or messages customers is OFF until switched on.
 */
const PAGE = 50;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const tab = url.searchParams.get("tab") || "shipments";
  const [settings, state, { config: page }, domain, log] = await Promise.all([
    getTrkSettings(shop),
    getState(shop),
    loadTrkPageConfig(admin),
    loadShopDomain(admin),
    getLog(shop),
  ]);
  const all = [...(await loadShipments(shop)).values()].sort((a, b) => (a.shippedAt < b.shippedAt ? 1 : -1));
  const status = url.searchParams.get("status") || "";
  const q = (url.searchParams.get("q") || "").trim().toUpperCase();
  const pg = Math.max(1, Number(url.searchParams.get("page")) || 1);
  const filtered = all.filter(
    (r) =>
      (!status || r.status === status || (status === "errors" && !!r.lastError)) &&
      (!q ||
        r.number.toUpperCase().includes(q) ||
        r.lastMileNumber.toUpperCase().includes(q) ||
        r.orderName.toUpperCase().replace("#", "").includes(q.replace("#", ""))),
  );
  const rows = filtered.slice((pg - 1) * PAGE, pg * PAGE).map((r) => ({
    number: r.number,
    order: r.orderName,
    orderId: r.orderId.split("/").pop() ?? "",
    email: maskEmail(r.email),
    country: r.country,
    carrier: r.carrier,
    lastMile: r.lastMileCarrier ? `${r.lastMileCarrier} ${r.lastMileNumber}`.trim() : r.lastMileNumber,
    status: r.status,
    statusAt: r.statusAt,
    lastEvent: r.events[0]?.text ?? "",
    lastEventAt: r.events[0]?.at ?? "",
    shippedAt: r.shippedAt,
    transitDays: r.transitDays,
    fulfillments: r.fulfillmentIds.length,
    paypal: r.paypal.state,
    emails: Object.keys(r.notified).filter((k) => !r.notified[k].startsWith("skipped")).length,
    error: r.lastError,
    polledAt: r.lastPolledAt,
  }));
  const live = page.enabled ? await checkEmbed(domain, TRK_EMBED_MARKERS, url.searchParams.has("refresh")) : "off";
  return {
    tab,
    settings: publicSettings(settings),
    yunReady: yunConfigured(settings),
    state,
    running: isTickRunning(shop),
    page,
    pageUrl: domain ? `${domain}/pages/${settings.pageHandle}` : "",
    live,
    domain,
    stats30: computeStats(all, 30),
    stats90: computeStats(all, 90),
    total: all.length,
    filteredTotal: filtered.length,
    rows,
    pg,
    log: log.slice(0, 150),
    appUrl: process.env.SHOPIFY_APP_URL || "",
  };
};

type ActionResult = { ok: boolean; intent: string; message: string; test?: unknown };

export const action = async ({ request }: ActionFunctionArgs): Promise<ActionResult> => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const form = await request.formData();
  const intent = String(form.get("intent") || "");
  const done = (ok: boolean, message: string, extra: Partial<ActionResult> = {}): ActionResult => ({ ok, intent, message, ...extra });
  try {
    if (intent === "save") {
      const cur = await getTrkSettings(shop);
      const patch = JSON.parse(String(form.get("settings") || "{}")) as Record<string, unknown>;
      // secrets: empty = keep, "__clear__" = remove
      for (const k of ["yunAppSecret", "yunSourceKey", "omnisendKey", "paypalSecret"] as const) {
        const v = String(patch[k] ?? "");
        patch[k] = v === "__clear__" ? "" : v ? v : cur[k];
      }
      const next = normalizeTrkSettings({ ...cur, ...patch });
      await saveTrkSettings(shop, next);
      return done(true, "Saved");
    }
    if (intent === "poll") {
      const cur = await getTrkSettings(shop);
      const on = form.get("on") === "1";
      if (on && !yunConfigured(cur)) return done(false, "Enter the YunExpress keys first (Settings).");
      await saveTrkSettings(shop, { ...cur, pollEnabled: on });
      if (on) void runTick(shop).catch(() => {});
      return done(true, on ? "Automatic tracking is on — first sync started" : "Automatic tracking is off");
    }
    if (intent === "run") {
      if (isTickRunning(shop)) return done(false, "A sync is already running");
      void runTick(shop, { force: true }).catch((e) => console.warn("[wc-trk] run:", (e as Error).message));
      return done(true, "Sync started — reload in a minute to see the result");
    }
    if (intent === "import") {
      const s = await getTrkSettings(shop);
      const r = await withShop(shop, () => importOrders(shop, admin as never, s, s.importDays));
      await addLog(shop, [{ at: new Date().toISOString(), kind: "import", ok: true, text: `${r.added} new numbers, ${r.total} total` }]);
      return done(true, `Imported: ${r.added} new tracking numbers (${r.total} total). Carrier data comes with the next sync.`);
    }
    if (intent === "test") {
      const s = await getTrkSettings(shop);
      const number = String(form.get("number") || "").trim();
      if (!number) return done(false, "Enter a tracking number");
      if (!yunConfigured(s)) return done(false, "Enter the YunExpress keys first");
      const r = await yunTrack(s, number, true);
      const rawText = JSON.stringify(r.raw ?? null);
      return done(true, r.found ? `Found: ${r.events.length} scans` : "YunExpress returned no data for this number", {
        test: { ...r, raw: rawText.length > 6000 ? `${rawText.slice(0, 6000)}…` : rawText },
      });
    }
    if (intent === "refresh") {
      const number = String(form.get("number") || "").trim().toUpperCase();
      const msg = await withShop(shop, async () => {
        const s = await getTrkSettings(shop);
        const m = await loadShipments(shop);
        const rec = m.get(number);
        if (!rec) return "Unknown number";
        if (rec.source === "none") rec.source = "yunexpress";
        await refreshOne(s, rec);
        const log: Parameters<typeof addLog>[1] = [];
        const domain = await loadShopDomain(admin);
        await applyOutputs(admin as never, s, rec, domain, log);
        await saveShipments(shop);
        await addLog(shop, log);
        return rec.lastError ? `Error: ${rec.lastError}` : `Updated: ${TRK_STATUS_LABEL[rec.status]}`;
      });
      return done(!msg.startsWith("Error") && msg !== "Unknown number", msg);
    }
    if (intent === "page") {
      const on = form.get("on") === "1";
      const s = await getTrkSettings(shop);
      await saveTrkSettings(shop, s); // creates the shop folder (public lookup only answers for it)
      const { installationId, config } = await loadTrkPageConfig(admin);
      let created = false;
      if (on) created = (await ensureTrackingPage(admin, s.pageHandle)).created;
      await saveTrkPageConfig(admin, installationId, {
        ...config,
        enabled: on,
        endpoint: (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, ""),
        pageHandle: s.pageHandle,
        updatedAt: new Date().toISOString(),
      });
      return done(true, on ? (created ? "Tracking page created and turned on" : "Tracking page turned on") : "Tracking page turned off");
    }
    return done(false, "Unknown action");
  } catch (e) {
    return done(false, (e as Error).message.slice(0, 400));
  }
};

// ---------------------------------------------------------------------------
// UI

const lbl: CSSProperties = { display: "block", fontSize: 13, marginBottom: 4, color: "#303030" };
const input: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  fontSize: 13,
  background: "#fdfdfd",
};
const th: CSSProperties = { textAlign: "left", padding: "8px 10px", borderBottom: "1px solid #e3e3e3", fontWeight: 600, whiteSpace: "nowrap", fontSize: 13 };
const td: CSSProperties = { padding: "8px 10px", borderBottom: "1px solid #f1f1f1", verticalAlign: "top", fontSize: 13 };

const TONE: Record<TrkStatus, "success" | "info" | "warning" | "critical" | undefined> = {
  pending: undefined,
  info_received: undefined,
  in_transit: "info",
  last_mile: "info",
  out_for_delivery: "info",
  attempt_fail: "warning",
  delivered: "success",
  exception: "critical",
  returned: "critical",
  expired: "warning",
};

function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <span style={lbl}>{label}</span>
      {children}
      {hint ? <div style={{ fontSize: 12, color: "#616161", marginTop: 4 }}>{hint}</div> : null}
    </div>
  );
}

function Check({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <label style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 12, fontSize: 13, cursor: "pointer" }}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} style={{ marginTop: 2 }} />
      <span>
        {label}
        {hint ? <span style={{ display: "block", fontSize: 12, color: "#616161", marginTop: 2 }}>{hint}</span> : null}
      </span>
    </label>
  );
}

const fmt = (iso: string) => {
  if (!iso) return "";
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "" : d.toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
};

export default function Tracking() {
  const data = useLoaderData<typeof loader>();
  const [params, setParams] = useSearchParams();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const busy = fetcher.state !== "idle";
  const tab = data.tab;

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      if (fetcher.data.ok) shopify.toast.show(fetcher.data.message);
      else shopify.toast.show(fetcher.data.message, { isError: true });
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const post = (fields: Record<string, string>) => {
    const fd = new FormData();
    for (const [k, v] of Object.entries(fields)) fd.set(k, v);
    fetcher.submit(fd, { method: "post" });
  };
  const go = (patch: Record<string, string>) => {
    const p = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) (v ? p.set(k, v) : p.delete(k));
    setParams(p);
  };

  const s = data.settings;
  const tabs: [string, string][] = [
    ["shipments", `Shipments (${data.total})`],
    ["stats", "Statistics"],
    ["settings", "Settings"],
    ["log", "Activity log"],
  ];

  return (
    <s-page inlineSize="large" heading="Tracking">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {s.pollEnabled ? <s-badge tone="success">Auto-tracking on</s-badge> : <s-badge>Auto-tracking off</s-badge>}
          <s-button
            variant={s.pollEnabled ? "secondary" : "primary"}
            loading={(busy && fetcher.formData?.get("intent") === "poll") || undefined}
            onClick={() => post({ intent: "poll", on: s.pollEnabled ? "0" : "1" })}
          >
            {s.pollEnabled ? "Turn off" : "Turn on"}
          </s-button>
          <s-button
            variant="secondary"
            disabled={data.running || !data.yunReady || undefined}
            loading={(busy && fetcher.formData?.get("intent") === "run") || data.running || undefined}
            onClick={() => post({ intent: "run" })}
          >
            Sync now
          </s-button>
          <s-button variant="tertiary" loading={rv.state === "loading" || undefined} onClick={() => rv.revalidate()}>
            Refresh
          </s-button>
          <span style={{ fontSize: 12, color: "#616161" }}>
            Last sync: {fmt(data.state.lastTickAt) || "never"}
            {data.state.lastError ? ` · ${data.state.lastError}` : ""}
          </span>
        </s-stack>
        {!data.yunReady ? (
          <s-banner tone="warning">
            Carrier data comes from the YunExpress Open API (free for YunExpress customers). Enter the App ID, App
            secret and Source key in Settings — they come from the YunExpress account the warehouse ships with.
          </s-banner>
        ) : null}
        <div style={{ display: "flex", gap: 6, marginTop: 12, flexWrap: "wrap" }}>
          {tabs.map(([k, l]) => (
            <s-button key={k} variant={tab === k ? "primary" : "secondary"} onClick={() => go({ tab: k, page: "", status: "", q: "" })}>
              {l}
            </s-button>
          ))}
        </div>
      </s-section>

      {tab === "shipments" ? <Shipments data={data} go={go} post={post} busy={busy} /> : null}
      {tab === "stats" ? <Stats data={data} /> : null}
      {tab === "settings" ? <Settings key={s.updatedAt} data={data} post={post} busy={busy} lastResult={fetcher.data} /> : null}
      {tab === "log" ? <LogView data={data} /> : null}
    </s-page>
  );
}

type Data = ReturnType<typeof useLoaderData<typeof loader>>;

function Shipments({ data, go, post, busy }: { data: Data; go: (p: Record<string, string>) => void; post: (f: Record<string, string>) => void; busy: boolean }) {
  const [params] = useSearchParams();
  const [q, setQ] = useState(params.get("q") || "");
  const pages = Math.max(1, Math.ceil(data.filteredTotal / PAGE));
  const counts = data.stats90.byStatus;
  return (
    <s-section>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12, alignItems: "center" }}>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            go({ q, page: "" });
          }}
          style={{ display: "flex", gap: 6 }}
        >
          <input style={{ ...input, width: 260 }} placeholder="Order or tracking number" value={q} onChange={(e) => setQ(e.target.value)} />
          <s-button onClick={() => go({ q, page: "" })}>Search</s-button>
        </form>
        <select style={{ ...input, width: 220 }} value={params.get("status") || ""} onChange={(e) => go({ status: e.target.value, page: "" })}>
          <option value="">All statuses</option>
          {TRK_STATUS_ORDER.map((k) => (
            <option key={k} value={k}>
              {TRK_STATUS_LABEL[k]} ({counts[k] ?? 0} in 90 days)
            </option>
          ))}
          <option value="errors">With errors</option>
        </select>
        <s-button variant="tertiary" loading={(busy && undefined) || undefined} onClick={() => post({ intent: "import" })}>
          Import shipped orders now
        </s-button>
      </div>
      {!data.rows.length ? (
        <s-paragraph>
          No shipments yet. “Import shipped orders now” reads fulfilled orders of the last days from Shopify (nothing is
          changed in the orders).
        </s-paragraph>
      ) : (
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th style={th}>Order</th>
                <th style={th}>Tracking</th>
                <th style={th}>Status</th>
                <th style={th}>Last event</th>
                <th style={th}>Shipped</th>
                <th style={th}>Days</th>
                <th style={th}></th>
              </tr>
            </thead>
            <tbody>
              {data.rows.map((r) => (
                <tr key={r.number}>
                  <td style={td}>
                    <a href={`shopify://admin/orders/${r.orderId}`} target="_top" style={{ color: "#005bd3" }}>
                      #{r.order.replace("#", "")}
                    </a>
                    <div style={{ color: "#616161", fontSize: 12 }}>
                      {r.country} {r.email}
                    </div>
                  </td>
                  <td style={td}>
                    <div>{r.number}</div>
                    <div style={{ color: "#616161", fontSize: 12 }}>{r.lastMile ? `→ ${r.lastMile}` : r.carrier}</div>
                  </td>
                  <td style={td}>
                    <s-badge tone={TONE[r.status as TrkStatus]}>{TRK_STATUS_LABEL[r.status as TrkStatus]}</s-badge>
                    <div style={{ color: "#616161", fontSize: 12, marginTop: 4 }}>
                      {r.paypal === "ok" ? "PayPal ✓ " : r.paypal === "error" ? "PayPal ✗ " : ""}
                      {r.emails ? `${r.emails} email${r.emails > 1 ? "s" : ""}` : ""}
                    </div>
                  </td>
                  <td style={{ ...td, maxWidth: 320 }}>
                    <div>{r.lastEvent || (r.error ? "" : "—")}</div>
                    <div style={{ color: r.error ? "#b42318" : "#616161", fontSize: 12 }}>{r.error || fmt(r.lastEventAt)}</div>
                  </td>
                  <td style={td}>{fmt(r.shippedAt)}</td>
                  <td style={td}>{r.transitDays ?? ""}</td>
                  <td style={td}>
                    <s-button variant="tertiary" onClick={() => post({ intent: "refresh", number: r.number })}>
                      Update
                    </s-button>
                    {data.pageUrl ? (
                      <s-button variant="tertiary" href={`${data.pageUrl}?nums=${encodeURIComponent(r.number)}`} target="_blank">
                        Page
                      </s-button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      {pages > 1 ? (
        <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12 }}>
          <s-button disabled={data.pg <= 1 || undefined} onClick={() => go({ page: String(data.pg - 1) })}>
            ← Previous
          </s-button>
          <span style={{ fontSize: 13 }}>
            Page {data.pg} of {pages} · {data.filteredTotal} shipments
          </span>
          <s-button disabled={data.pg >= pages || undefined} onClick={() => go({ page: String(data.pg + 1) })}>
            Next →
          </s-button>
        </div>
      ) : null}
    </s-section>
  );
}

function Stats({ data }: { data: Data }) {
  const [range, setRange] = useState<30 | 90>(30);
  const st = range === 30 ? data.stats30 : data.stats90;
  const cards: [string, string | number][] = [
    ["Shipments", st.total],
    ["Delivered", st.byStatus.delivered],
    ["Avg. delivery time", st.avgDeliveryDays != null ? `${st.avgDeliveryDays} days` : "—"],
    ["In transit", st.byStatus.in_transit + st.byStatus.last_mile + st.byStatus.out_for_delivery],
    ["Problems", st.byStatus.exception + st.byStatus.attempt_fail + st.byStatus.returned],
    ["No scan for 7+ days", st.stuck],
  ];
  return (
    <>
      <s-section>
        <div style={{ display: "flex", gap: 6, marginBottom: 12 }}>
          {([30, 90] as const).map((d) => (
            <s-button key={d} variant={range === d ? "primary" : "secondary"} onClick={() => setRange(d)}>
              Last {d} days
            </s-button>
          ))}
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(160px, 1fr))", gap: 12 }}>
          {cards.map(([l, v]) => (
            <div key={l} style={{ border: "1px solid #e3e3e3", borderRadius: 10, padding: 12 }}>
              <div style={{ fontSize: 12, color: "#616161" }}>{l}</div>
              <div style={{ fontSize: 22, fontWeight: 600, marginTop: 4 }}>{v}</div>
            </div>
          ))}
        </div>
      </s-section>
      <s-section heading="By status">
        <table style={{ borderCollapse: "collapse", minWidth: 320 }}>
          <tbody>
            {TRK_STATUS_ORDER.filter((k) => st.byStatus[k]).map((k) => (
              <tr key={k}>
                <td style={td}>{TRK_STATUS_LABEL[k]}</td>
                <td style={{ ...td, textAlign: "right" }}>{st.byStatus[k]}</td>
                <td style={{ ...td, width: 200 }}>
                  <div style={{ height: 8, borderRadius: 4, background: "#155F56", width: `${Math.round((st.byStatus[k] / Math.max(1, st.total)) * 100)}%` }} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </s-section>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
        <div style={{ flex: "1 1 360px" }}>
          <s-section heading="Delivery time by country">
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Country</th>
                  <th style={th}>Delivered</th>
                  <th style={th}>Avg. days</th>
                  <th style={th}>On the way</th>
                </tr>
              </thead>
              <tbody>
                {st.byCountry.map((c) => (
                  <tr key={c.country}>
                    <td style={td}>{c.country}</td>
                    <td style={td}>{c.delivered}</td>
                    <td style={td}>{c.avg ?? "—"}</td>
                    <td style={td}>{c.active}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </s-section>
        </div>
        <div style={{ flex: "1 1 360px" }}>
          <s-section heading="Delivery time by last-mile carrier">
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Carrier</th>
                  <th style={th}>Delivered</th>
                  <th style={th}>Avg. days</th>
                </tr>
              </thead>
              <tbody>
                {st.byCarrier.map((c) => (
                  <tr key={c.carrier}>
                    <td style={td}>{c.carrier}</td>
                    <td style={td}>{c.delivered}</td>
                    <td style={td}>{c.avg ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </s-section>
        </div>
      </div>
    </>
  );
}

type Form = TrkSettingsPublic & { yunAppSecret: string; yunSourceKey: string; omnisendKey: string; paypalSecret: string };

function Settings({ data, post, busy, lastResult }: { data: Data; post: (f: Record<string, string>) => void; busy: boolean; lastResult?: ActionResult }) {
  const [f, setF] = useState<Form>({ ...data.settings, yunAppSecret: "", yunSourceKey: "", omnisendKey: "", paypalSecret: "" });
  const [num, setNum] = useState("");
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));
  const save = () => {
    const { hasYunSecret, hasYunSourceKey, hasOmnisendKey, hasPaypalSecret, ...rest } = f;
    void hasYunSecret;
    void hasYunSourceKey;
    void hasOmnisendKey;
    void hasPaypalSecret;
    post({ intent: "save", settings: JSON.stringify(rest) });
  };
  const secret = (k: "yunAppSecret" | "yunSourceKey" | "omnisendKey" | "paypalSecret", has: boolean, label: string) => (
    <Field label={label} hint={has ? "Saved. Leave empty to keep it." : undefined}>
      <input style={input} type="password" autoComplete="off" value={f[k]} placeholder={has ? "••••••••" : ""} onChange={(e) => set(k, e.target.value)} />
    </Field>
  );
  const test = lastResult?.intent === "test" ? (lastResult.test as Record<string, unknown> | undefined) : undefined;
  return (
    <>
      <s-section heading="1. Carrier data — YunExpress Open API (free)">
        <s-paragraph>
          Keys come from the YunExpress customer account that ships the parcels (open.yunexpress.cn → user center → API:
          App ID, App secret and Source key). Usually the warehouse has this account.
        </s-paragraph>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
          <Field label="App ID">
            <input style={input} value={f.yunAppId} onChange={(e) => set("yunAppId", e.target.value)} />
          </Field>
          {secret("yunAppSecret", f.hasYunSecret, "App secret")}
          {secret("yunSourceKey", f.hasYunSourceKey, "Source key")}
        </div>
        <Check label="Sandbox (test environment)" checked={f.yunSandbox} onChange={(v) => set("yunSandbox", v)} />
        <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
          <input style={{ ...input, width: 260 }} placeholder="YT… number to test the keys" value={num} onChange={(e) => setNum(e.target.value)} />
          <s-button
            disabled={!data.yunReady || !num || undefined}
            loading={(busy && undefined) || undefined}
            onClick={() => post({ intent: "test", number: num })}
          >
            Test number
          </s-button>
          {!data.yunReady ? <span style={{ fontSize: 12, color: "#616161" }}>Save the keys first</span> : null}
        </div>
        {test ? (
          <div style={{ marginTop: 12, fontSize: 13 }}>
            <div>
              Last mile: <b>{String(test.lastMileCarrier || "—")}</b> {String(test.lastMileNumber || "")} · scans:{" "}
              {Array.isArray(test.events) ? test.events.length : 0}
            </div>
            <ul style={{ margin: "8px 0", paddingLeft: 18 }}>
              {(Array.isArray(test.events) ? (test.events as { at: string; text: string; place: string; status: TrkStatus }[]) : [])
                .slice(0, 8)
                .map((e, i) => (
                  <li key={i}>
                    {fmt(e.at)} — {e.text} {e.place ? `(${e.place})` : ""} → <i>{TRK_STATUS_LABEL[e.status]}</i>
                  </li>
                ))}
            </ul>
            <details>
              <summary style={{ cursor: "pointer" }}>Raw response</summary>
              <pre style={{ whiteSpace: "pre-wrap", fontSize: 11, maxHeight: 300, overflow: "auto", background: "#f6f6f6", padding: 8 }}>
                {String(test.raw ?? "")}
              </pre>
            </details>
          </div>
        ) : null}
      </s-section>

      <s-section heading="2. Sync">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
          <Field label="Check each parcel every (hours)">
            <input style={input} type="number" min={2} max={48} value={f.pollHours} onChange={(e) => set("pollHours", Number(e.target.value))} />
          </Field>
          <Field label="First import: orders of the last (days)">
            <input style={input} type="number" min={1} max={90} value={f.importDays} onChange={(e) => set("importDays", Number(e.target.value))} />
          </Field>
          <Field label="Stop tracking after (days)">
            <input style={input} type="number" min={20} max={180} value={f.maxDays} onChange={(e) => set("maxDays", Number(e.target.value))} />
          </Field>
        </div>
      </s-section>

      <s-section heading="3. Shopify orders">
        <s-banner tone="warning">
          While Track123 is still installed, keep these off — otherwise both apps write statuses and links.
        </s-banner>
        <Check
          label="Post shipping statuses to Shopify (In transit, Out for delivery, Delivered…)"
          hint="On every fulfillment with the number — the warehouse makes 2–3 per order; Track123 updates only one. Customers don't get Shopify emails from this."
          checked={f.shopifyEvents}
          onChange={(v) => set("shopifyEvents", v)}
        />
        <Check
          label="Point the tracking link of every fulfillment to our tracking page"
          hint="Same number and carrier, only the link changes. No email is sent to the customer."
          checked={f.shopifyUrl}
          onChange={(v) => set("shopifyUrl", v)}
        />
      </s-section>

      <s-section heading="4. Customer emails — Omnisend">
        <s-paragraph>
          The app sends Omnisend custom events; emails are built in Omnisend → Automation → Create workflow → trigger
          “custom event”. Each event is sent once per parcel, only for scans of the last 3 days.
        </s-paragraph>
        <Check label="Send events to Omnisend" checked={f.omnisendEnabled} onChange={(v) => set("omnisendEnabled", v)} />
        {secret("omnisendKey", f.hasOmnisendKey, "Omnisend API key (Store settings → API keys)")}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 4 }}>
          {TRK_STATUS_ORDER.filter((k) => TRK_OMNISEND_EVENT[k]).map((k) => (
            <Check
              key={k}
              label={`${TRK_STATUS_LABEL[k]} → “${TRK_OMNISEND_EVENT[k]}”`}
              checked={f.omnisendStatuses.includes(k)}
              onChange={(v) => set("omnisendStatuses", v ? [...f.omnisendStatuses, k] : f.omnisendStatuses.filter((x) => x !== k))}
            />
          ))}
        </div>
        <div style={{ fontSize: 12, color: "#616161" }}>
          Event properties: orderNumber, trackingNumber, carrier, lastMileNumber, lastMileCarrier, status, lastEvent,
          lastEventPlace, lastEventTime, trackingUrl, firstName, country.
        </div>
      </s-section>

      <s-section heading="5. PayPal tracking">
        <s-paragraph>
          For orders paid with PayPal the tracking number is added to the PayPal transaction (fewer disputes, faster
          release of funds). Keys: developer.paypal.com → Apps &amp; Credentials → Live → your app.
        </s-paragraph>
        <Check label="Send tracking to PayPal" checked={f.paypalEnabled} onChange={(v) => set("paypalEnabled", v)} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
          <Field label="Client ID">
            <input style={input} value={f.paypalClientId} onChange={(e) => set("paypalClientId", e.target.value)} />
          </Field>
          {secret("paypalSecret", f.hasPaypalSecret, "Secret")}
        </div>
      </s-section>

      <s-section heading="6. Tracking page">
        <s-stack direction="inline" gap="base" alignItems="center">
          {data.page.enabled ? <s-badge tone="success">Page on</s-badge> : <s-badge>Page off</s-badge>}
          <s-button variant={data.page.enabled ? "secondary" : "primary"} onClick={() => post({ intent: "page", on: data.page.enabled ? "0" : "1" })}>
            {data.page.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {data.page.enabled ? (
            data.live === "on" ? (
              <s-badge tone="success">Storefront: code present</s-badge>
            ) : data.live === "off" ? (
              <s-badge tone="critical">Storefront: not found</s-badge>
            ) : (
              <s-badge tone="warning">Storefront: can’t check</s-badge>
            )
          ) : null}
          {data.pageUrl ? (
            <s-button variant="tertiary" href={data.pageUrl} target="_blank">
              Open page
            </s-button>
          ) : null}
        </s-stack>
        <div style={{ marginTop: 12 }}>
          <Field label="Page handle" hint={`Page address: /pages/${f.pageHandle}. Turn on creates the page if it doesn't exist.`}>
            <input style={{ ...input, maxWidth: 300 }} value={f.pageHandle} onChange={(e) => set("pageHandle", e.target.value)} />
          </Field>
          <Check
            label="Hide China first-mile scans on the page"
            hint="Customers see only the scans from customs/arrival onwards."
            checked={f.hideOriginEvents}
            onChange={(v) => set("hideOriginEvents", v)}
          />
        </div>
      </s-section>

      <s-section>
        <s-button variant="primary" loading={(busy && undefined) || undefined} onClick={save}>
          Save settings
        </s-button>
      </s-section>
    </>
  );
}

function LogView({ data }: { data: Data }) {
  return (
    <s-section>
      {!data.log.length ? (
        <s-paragraph>Nothing yet.</s-paragraph>
      ) : (
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={th}>Time</th>
              <th style={th}>Type</th>
              <th style={th}>Order</th>
              <th style={th}>Number</th>
              <th style={th}>Result</th>
            </tr>
          </thead>
          <tbody>
            {data.log.map((l, i) => (
              <tr key={i}>
                <td style={td}>{fmt(l.at)}</td>
                <td style={td}>{l.kind}</td>
                <td style={td}>{l.order ?? ""}</td>
                <td style={td}>{l.number ?? ""}</td>
                <td style={{ ...td, color: l.ok ? undefined : "#b42318" }}>{l.text}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
      <div style={{ marginTop: 12 }}>
        <Link to="?tab=shipments">← Shipments</Link>
      </div>
    </s-section>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
