import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useState } from "react";
import { useFetcher, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import {
  AccessError,
  listProductImages,
  updateAlts,
} from "../seo/seo-admin.server";
import { altTemplate, type ImageRow } from "../seo/seo-admin.shared";
import { fmtBytes } from "../seo/seo.shared";
import { SeoTabs } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, name } = await seoAuth(request);
  try {
    return { images: await listProductImages(admin), shopName: name, error: "" };
  } catch (e) {
    return {
      images: [] as ImageRow[],
      shopName: name,
      error:
        e instanceof AccessError
          ? "Approve the app’s new permissions (Shopify admin → Apps → WoodenCrew Apps) to edit image ALT text."
          : (e as Error).message,
    };
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, name } = await seoAuth(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  try {
    if (intent === "save") {
      await updateAlts(admin, [{ id: String(form.get("id")), alt: String(form.get("alt") ?? "").trim() }]);
      return { ok: true, message: "Saved", id: String(form.get("id")) };
    }
    if (intent === "bulk") {
      const tpl = String(form.get("template") ?? "").trim();
      if (!tpl) return { ok: false, message: "Template is empty", id: "" };
      const missing = (await listProductImages(admin)).filter((i) => !i.alt.trim());
      const items = missing.map((i) => ({ id: i.id, alt: altTemplate(tpl, i, name) })).filter((x) => x.alt);
      await updateAlts(admin, items.slice(0, 500));
      return { ok: true, message: `Added ALT text to ${Math.min(items.length, 500)} images`, id: "" };
    }
  } catch (e) {
    return {
      ok: false,
      id: "",
      message:
        e instanceof AccessError
          ? "No permission yet — approve the app’s new permissions in Shopify admin → Apps → WoodenCrew Apps."
          : (e as Error).message,
    };
  }
  return { ok: false, message: "Unknown action", id: "" };
};

function AltRow({ img }: { img: ImageRow }) {
  const f = useFetcher<typeof action>();
  const [alt, setAlt] = useState(img.alt);
  return (
    <tr>
      <td style={{ width: 60 }}>{img.url ? <img className="thumb" src={img.url} alt="" /> : null}</td>
      <td style={{ width: "28%" }}>
        <div>{img.productTitle}</div>
        <div className="sub">
          {`Image ${img.position} · ${img.width ?? "?"}×${img.height ?? "?"}`}
          {img.fileSize ? ` · original ${fmtBytes(img.fileSize)}` : ""}
        </div>
      </td>
      <td>
        <input
          className="wcs-input"
          value={alt}
          placeholder="Describe the image (what a blind shopper should hear)"
          onChange={(e) => setAlt(e.target.value)}
        />
        <div className={`wcs-count ${alt.length > 125 ? "over" : ""}`}>{alt.length}/125</div>
      </td>
      <td style={{ width: 110 }}>
        <s-button
          onClick={() => f.submit({ intent: "save", id: img.id, alt }, { method: "POST" })}
          {...(alt === img.alt || f.state !== "idle" ? { disabled: true } : {})}
        >
          Save
        </s-button>
        {f.data && f.state === "idle" ? (
          <div style={{ fontSize: 12, color: f.data.ok ? "#0c6e3d" : "#b42318" }}>{f.data.message}</div>
        ) : null}
      </td>
    </tr>
  );
}

export default function SeoImages() {
  const { images, shopName, error } = useLoaderData<typeof loader>();
  const bulk = useFetcher<typeof action>();
  const [show, setShow] = useState<"missing" | "all" | "heavy">("missing");
  const [tpl, setTpl] = useState("{title} - photo {n}");
  const missing = images.filter((i) => !i.alt.trim());
  const heavy = images.filter((i) => (i.fileSize ?? 0) > 1.5 * 1024 * 1024);
  const list = show === "missing" ? missing : show === "heavy" ? heavy : images;
  const sample = missing[0] ?? images[0];

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Image ALT">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <SeoTabs />
      {error ? <s-banner tone="critical">{error}</s-banner> : null}
      <s-section>
        <div className="wcs-kpis">
          <div className="wcs-kpi">
            <div className="k">Product images</div>
            <div className="v">{images.length}</div>
            <div className="s">active products</div>
          </div>
          <div className="wcs-kpi">
            <div className="k">Without ALT text</div>
            <div className={`v ${missing.length ? "warning" : "success"}`}>{missing.length}</div>
            <div className="s">in product data</div>
          </div>
          <div className="wcs-kpi">
            <div className="k">Originals over 1.5 MB</div>
            <div className="v">{heavy.length}</div>
            <div className="s">CDN still serves resized copies</div>
          </div>
        </div>
      </s-section>
      <s-section heading="Fill all missing ALT texts">
        <div className="wcs-filters">
          <input style={{ flex: 1, minWidth: 260 }} value={tpl} onChange={(e) => setTpl(e.target.value)} />
          <s-button
            variant="primary"
            onClick={() => bulk.submit({ intent: "bulk", template: tpl }, { method: "POST" })}
            {...(!missing.length || bulk.state !== "idle" ? { disabled: true } : {})}
          >
            {`Fill ${missing.length} images`}
          </s-button>
        </div>
        <s-paragraph>
          <s-text color="subdued">
            {`Variables: {title} = product name, {n} = image number, {shop} = ${shopName}. Existing ALT texts are not changed.`}
            {sample ? ` Example: “${altTemplate(tpl, sample, shopName)}”.` : ""}{" "}
            A template is a quick baseline; a few words about what is on each photo (colour,
            in use, packaging) is better for Google Images and screen readers.
          </s-text>
        </s-paragraph>
        {bulk.data && bulk.state === "idle" ? (
          <s-banner tone={bulk.data.ok ? "success" : "critical"}>{bulk.data.message}</s-banner>
        ) : null}
      </s-section>
      <s-section padding="none">
        <div style={{ padding: "10px 12px" }} className="wcs-filters">
          <select value={show} onChange={(e) => setShow(e.target.value as typeof show)}>
            <option value="missing">Missing ALT ({missing.length})</option>
            <option value="all">All images ({images.length})</option>
            <option value="heavy">Large originals ({heavy.length})</option>
          </select>
        </div>
        <div className="wcs-scroll">
          <table className="wcs-table">
            <tbody>
              {list.slice(0, 400).map((img) => (
                <AltRow key={`${img.id}|${img.alt}`} img={img} />
              ))}
            </tbody>
          </table>
        </div>
        {list.length > 400 ? (
          <s-paragraph>{`Showing 400 of ${list.length}.`}</s-paragraph>
        ) : null}
      </s-section>
      <s-section>
        <s-text color="subdued">
          Your theme may already print the product title as alt when the field is empty, so
          the storefront can look fine while the data is empty — the audit’s “Images without
          alt text” check looks at the real page. Image compression is left to Shopify’s CDN
          (automatic WebP/AVIF and resizing); the app does not re-compress your originals.
        </s-text>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
