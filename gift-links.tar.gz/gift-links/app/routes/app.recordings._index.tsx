import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { Link, useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { useEffect, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { checkEmbed } from "../embed-status.server";
import {
  deleteSession,
  diskInfo,
  getShopSettings,
  listSessions,
  loadRecConfig,
  lowDisk,
  setRecEnabled,
  startRecScheduler,
} from "../rec.server";
import { REC_RETENTION_DAYS, fmtBytes, fmtDuration, type RecListItem } from "../rec.shared";

/**
 * Session Recordings — the only on/off switch for the storefront recorder.
 * On = metafield wc_rec.config.enabled → the Gift Links app embed prints the
 * idle-time loader (no separate app embed, nothing to switch in the theme).
 */
const REC_MARKER = /id="wc-rec-on"/;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  startRecScheduler();
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const sp = url.searchParams;
  const filter = {
    days: [1, 3, 7, 14].includes(Number(sp.get("days"))) ? Number(sp.get("days")) : 7,
    device: ["mobile", "tablet", "desktop"].includes(sp.get("device") ?? "") ? String(sp.get("device")) : "",
    minSec: [0, 10, 30, 60, 180].includes(Number(sp.get("min"))) ? Number(sp.get("min")) : 0,
    atc: sp.get("atc") === "1",
    url: (sp.get("url") ?? "").slice(0, 100),
    page: Math.max(0, Number(sp.get("page")) || 0),
  };
  const [{ config }, settings, disk, list] = await Promise.all([
    loadRecConfig(admin),
    getShopSettings(session.shop),
    diskInfo(),
    listSessions(session.shop, filter),
  ]);
  let storefront: "on" | "off" | "unknown" | "" = "";
  if (config.enabled) {
    const domain = await loadShopDomain(admin);
    storefront = await checkEmbed(domain, REC_MARKER, sp.has("refresh"));
  }
  return {
    enabled: config.enabled && settings.enabled,
    storefront,
    filter,
    list,
    disk: { free: Number.isFinite(disk.free) ? disk.free : 0, total: disk.total, low: lowDisk(disk.free) },
    retention: settings.retentionDays || REC_RETENTION_DAYS,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  try {
    if (intent === "enable" || intent === "disable") {
      await setRecEnabled(admin, session.shop, intent === "enable");
      return { ok: true };
    }
    if (intent === "delete") {
      await deleteSession(session.shop, String(form.get("sid") ?? ""));
      return { ok: true };
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
  return { ok: false, error: "Unknown action" };
};

const fmtTime = (ts: number) =>
  new Date(ts).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });

function pathOnly(u: string) {
  const s = u.split("?")[0] || "/";
  return s.length > 48 ? `${s.slice(0, 47)}…` : s;
}

const th: React.CSSProperties = { textAlign: "left", padding: "8px 10px", fontWeight: 600, borderBottom: "1px solid #e3e3e3", whiteSpace: "nowrap" };
const td: React.CSSProperties = { padding: "8px 10px", borderBottom: "1px solid #f1f1f1", verticalAlign: "top" };

export default function Recordings() {
  const { enabled, storefront, filter, list, disk, retention } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [confirm, setConfirm] = useState("");
  const [urlQ, setUrlQ] = useState(filter.url);
  const busy = fetcher.state !== "idle";

  const go = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    next.delete("refresh");
    for (const [k, v] of Object.entries(patch)) {
      if (v) next.set(k, v);
      else next.delete(k);
    }
    if (!("page" in patch)) next.delete("page");
    navigate(`?${next.toString()}`);
  };

  useEffect(() => {
    const t = setTimeout(() => {
      if (urlQ !== filter.url) go({ url: urlQ });
    }, 500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlQ]);

  const toggle = () =>
    fetcher.submit({ intent: enabled ? "disable" : "enable" }, { method: "post" });

  const err = fetcher.data && !fetcher.data.ok ? fetcher.data.error : "";

  return (
    <s-page inlineSize="large" heading="Session Recordings">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {enabled ? <s-badge tone="success">Recording: On</s-badge> : <s-badge>Recording: Off</s-badge>}
          <s-button variant={enabled ? "secondary" : "primary"} loading={busy || undefined} onClick={toggle}>
            {enabled ? "Turn off recording" : "Turn on recording"}
          </s-button>
          {enabled && storefront === "on" ? <s-badge tone="success">Storefront: recorder present</s-badge> : null}
          {enabled && storefront === "off" ? <s-badge tone="warning">Storefront: not detected yet</s-badge> : null}
          {enabled && storefront ? (
            <s-button variant="tertiary" onClick={() => navigate("?refresh=1")}>
              Check again
            </s-button>
          ) : null}
        </s-stack>
        {err ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="critical">{err}</s-banner>
          </s-box>
        ) : null}
        {enabled && storefront === "off" ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="warning">
              The storefront home page doesn’t show the recorder yet. Shopify may need a minute to refresh
              the page cache. The recorder is loaded by the “Gift Links” app embed — it must stay on in
              the theme (it is on now).
            </s-banner>
          </s-box>
        ) : null}
        {disk.low ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="critical">
              Less than 1.5 GB free on the server disk ({fmtBytes(disk.free)}) — new recordings are paused
              until space is freed.
            </s-banner>
          </s-box>
        ) : null}
        <s-box paddingBlockStart="base">
          <s-paragraph>
            Records what visitors do on every store page (scroll, clicks, taps, page changes) to replay
            later. Typed text is always hidden; customer account pages and checkout are not recorded.
            The recorder (≈25 KB) loads only after the page has fully loaded and the browser is idle,
            sends compressed data every few seconds and never changes the cart or the theme’s requests.
            Recordings are kept {retention} days on our server.
          </s-paragraph>
        </s-box>
      </s-section>

      <s-section>
        <s-stack direction="inline" gap="base" alignItems="end">
          <s-select label="Period" value={String(filter.days)} onChange={(e) => go({ days: e.currentTarget.value })}>
            <s-option value="1">Today</s-option>
            <s-option value="3">3 days</s-option>
            <s-option value="7">7 days</s-option>
            <s-option value="14">14 days</s-option>
          </s-select>
          <s-select label="Device" value={filter.device} onChange={(e) => go({ device: e.currentTarget.value })}>
            <s-option value="">All</s-option>
            <s-option value="mobile">Mobile</s-option>
            <s-option value="tablet">Tablet</s-option>
            <s-option value="desktop">Desktop</s-option>
          </s-select>
          <s-select label="Duration" value={String(filter.minSec)} onChange={(e) => go({ min: e.currentTarget.value })}>
            <s-option value="0">Any</s-option>
            <s-option value="10">10 s +</s-option>
            <s-option value="30">30 s +</s-option>
            <s-option value="60">1 min +</s-option>
            <s-option value="180">3 min +</s-option>
          </s-select>
          <s-text-field
            label="Visited page contains"
            placeholder="/products/travel-pillow"
            value={urlQ}
            onInput={(e) => setUrlQ(e.currentTarget.value)}
          />
          <s-checkbox
            label="Added to cart"
            checked={filter.atc || undefined}
            onChange={(e) => go({ atc: e.currentTarget.checked ? "1" : "" })}
          />
        </s-stack>
        <s-box paddingBlockStart="base">
          <s-text color="subdued">
            {list.matched} of {list.total} recordings · {list.withAtc} with add to cart · {fmtBytes(list.bytes)} stored
            {disk.total ? ` · server disk free ${fmtBytes(disk.free)} of ${fmtBytes(disk.total)}` : ""}
          </s-text>
        </s-box>
        <div style={{ overflowX: "auto", marginTop: 12 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr>
                <th style={th}>Started</th>
                <th style={th}>Duration</th>
                <th style={th}>Pages</th>
                <th style={th}>Landing → last page</th>
                <th style={th}>Device</th>
                <th style={th}>Source</th>
                <th style={th}>Events</th>
                <th style={th} />
              </tr>
            </thead>
            <tbody>
              {list.items.map((r: RecListItem) => (
                <tr key={r.id}>
                  <td style={td}>
                    <Link to={`/app/recordings/${r.id}`}>{fmtTime(r.start)}</Link>
                  </td>
                  <td style={td}>{fmtDuration(r.duration)}</td>
                  <td style={td}>{r.pages.length}</td>
                  <td style={{ ...td, maxWidth: 360 }}>
                    <div title={r.pages[0]?.url}>{pathOnly(r.pages[0]?.url ?? "")}</div>
                    {r.pages.length > 1 ? (
                      <div style={{ color: "#616161" }} title={r.pages[r.pages.length - 1].url}>
                        → {pathOnly(r.pages[r.pages.length - 1].url)}
                      </div>
                    ) : null}
                  </td>
                  <td style={td}>
                    {r.device} · {r.os} · {r.browser}
                    <div style={{ color: "#616161" }}>
                      {r.w}×{r.h}
                    </div>
                  </td>
                  <td style={td}>{r.utm || "direct"}</td>
                  <td style={td}>
                    <s-stack direction="inline" gap="small-200">
                      {r.atc ? <s-badge tone="success">Add to cart</s-badge> : null}
                      {r.checkout ? <s-badge tone="info">Checkout</s-badge> : null}
                      {r.clicks ? <s-text color="subdued">{r.clicks} clicks</s-text> : null}
                    </s-stack>
                  </td>
                  <td style={{ ...td, whiteSpace: "nowrap" }}>
                    <s-stack direction="inline" gap="small-200">
                      <s-button variant="primary" onClick={() => navigate(`/app/recordings/${r.id}`)}>
                        Play
                      </s-button>
                      <s-button
                        variant="tertiary"
                        tone="critical"
                        onClick={() => {
                          if (confirm === r.id) {
                            setConfirm("");
                            fetcher.submit({ intent: "delete", sid: r.id }, { method: "post" });
                          } else setConfirm(r.id);
                        }}
                      >
                        {confirm === r.id ? "Delete?" : "Delete"}
                      </s-button>
                    </s-stack>
                  </td>
                </tr>
              ))}
              {!list.items.length ? (
                <tr>
                  <td style={{ ...td, color: "#616161", padding: 24 }} colSpan={8}>
                    {enabled
                      ? "No recordings for these filters yet. New visits appear here within a few seconds."
                      : "Recording is off. Turn it on to start collecting visits."}
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
        {list.pages > 1 ? (
          <s-box paddingBlockStart="base">
            <s-stack direction="inline" gap="base" alignItems="center">
              <s-button disabled={filter.page <= 0 || undefined} onClick={() => go({ page: String(filter.page - 1) })}>
                ← Newer
              </s-button>
              <s-text>
                Page {filter.page + 1} of {list.pages}
              </s-text>
              <s-button
                disabled={filter.page + 1 >= list.pages || undefined}
                onClick={() => go({ page: String(filter.page + 1) })}
              >
                Older →
              </s-button>
            </s-stack>
          </s-box>
        ) : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
