import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { useEffect, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { checkEmbed } from "../embed-status.server";
import {
  diskInfo,
  getShopSettings,
  listVisitors,
  parseFilter,
  filterQuery,
  storedSince,
  deleteVisitor,
  loadRecConfig,
  lowDisk,
  setRecEnabled,
  startRecScheduler,
} from "../rec.server";
import { recOrders, startRecOrderSync } from "../rec-orders.server";
import { REC_RETENTION_DAYS, cleanSource, fmtBytes, fmtDuration, locationLabel } from "../rec.shared";
import type { RecVisitor } from "../rec.server";

/**
 * Session Recordings — the only on/off switch for the storefront recorder.
 * On = metafield wc_rec.config.enabled → the Gift Links app embed prints the
 * idle-time loader (no separate app embed, nothing to switch in the theme).
 */
const REC_MARKER = /id="wc-rec-on"/;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  startRecScheduler();
  startRecOrderSync();
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const sp = url.searchParams;
  const filter = parseFilter(sp);
  const since = await storedSince(session.shop);
  const [{ config }, settings, disk, list] = await Promise.all([
    loadRecConfig(admin),
    getShopSettings(session.shop),
    diskInfo(),
    listVisitors(session.shop, filter),
  ]);
  const allOrders = await recOrders(session.shop);
  const orders: Record<string, { id: string; name: string; total: string; cur: string }[]> = {};
  for (const v of list.items) {
    const o = allOrders[v.vid];
    if (o?.length) orders[v.vid] = o.map(({ id, name, total, cur }) => ({ id, name, total, cur }));
  }
  let storefront: "on" | "off" | "unknown" | "" = "";
  if (config.enabled) {
    const domain = await loadShopDomain(admin);
    storefront = await checkEmbed(domain, REC_MARKER, sp.has("refresh"));
  }
  const handleRes = await admin.graphql(`#graphql
    query WcRecAppHandle { currentAppInstallation { app { handle } } }`);
  const handleJson = (await handleRes.json()) as {
    data?: { currentAppInstallation?: { app?: { handle?: string } } };
  };
  const appHandle = handleJson.data?.currentAppInstallation?.app?.handle || "gift-links";
  const store = session.shop.replace(/\.myshopify\.com$/, "");
  return {
    adminBase: `https://admin.shopify.com/store/${store}/apps/${appHandle}/app/recordings/v/`,
    fq: filterQuery(filter),
    enabled: config.enabled && settings.enabled,
    storefront,
    filter,
    list,
    orders,
    disk: { free: Number.isFinite(disk.free) ? disk.free : 0, total: disk.total, low: lowDisk(disk.free) },
    retention: settings.retentionDays || REC_RETENTION_DAYS,
    since,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  try {
    if (intent === "enable" || intent === "disable") {
      await setRecEnabled(admin, session.shop, intent === "enable");
      return { ok: true };
    }
    if (intent === "delete") {
      await deleteVisitor(session.shop, String(form.get("vid") ?? ""));
      return { ok: true };
    }
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : String(e) };
  }
  return { ok: false, error: "Unknown action" };
};

const fmtTime = (ts: number) =>
  new Date(ts).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });

function pathOnly(u: string) {
  return u.split("?")[0] || "/";
}

export default function Recordings() {
  const { enabled, storefront, filter, list, orders, disk, retention, adminBase, since, fq } = useLoaderData<typeof loader>();
  const openUrl = (vid: string) => `${adminBase}${vid}${fq ? `?${fq}` : ""}`;
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [confirm, setConfirm] = useState("");
  const [urlQ, setUrlQ] = useState(filter.url);
  const busy = fetcher.state !== "idle";

  const go = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    next.delete("refresh");
    for (const [k, v] of Object.entries(patch)) {
      if (v) next.set(k, v);
      else next.delete(k);
    }
    if (!("page" in patch)) next.delete("page");
    navigate(`?${next.toString()}`);
  };

  useEffect(() => {
    const t = setTimeout(() => {
      if (urlQ !== filter.url) go({ url: urlQ });
    }, 500);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [urlQ]);

  const toggle = () =>
    fetcher.submit({ intent: enabled ? "disable" : "enable" }, { method: "post" });

  const err = fetcher.data && !fetcher.data.ok ? fetcher.data.error : "";

  return (
    <s-page inlineSize="large" heading="Session Recordings">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {enabled ? <s-badge tone="success">Recording: On</s-badge> : <s-badge>Recording: Off</s-badge>}
          <s-button variant={enabled ? "secondary" : "primary"} loading={busy || undefined} onClick={toggle}>
            {enabled ? "Turn off recording" : "Turn on recording"}
          </s-button>
          {enabled && storefront === "on" ? <s-badge tone="success">Storefront: recorder present</s-badge> : null}
          {enabled && storefront === "off" ? <s-badge tone="warning">Storefront: not detected yet</s-badge> : null}
          {enabled && storefront ? (
            <s-button variant="tertiary" onClick={() => navigate("?refresh=1")}>
              Check again
            </s-button>
          ) : null}
        </s-stack>
        {err ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="critical">{err}</s-banner>
          </s-box>
        ) : null}
        {enabled && storefront === "off" ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="warning">
              The storefront home page doesn’t show the recorder yet. Shopify may need a minute to refresh
              the page cache. The recorder is loaded by the “Gift Links” app embed — it must stay on in
              the theme (it is on now).
            </s-banner>
          </s-box>
        ) : null}
        {disk.low ? (
          <s-box paddingBlockStart="base">
            <s-banner tone="critical">
              Less than 1.5 GB free on the server disk ({fmtBytes(disk.free)}) — new recordings are paused
              until space is freed.
            </s-banner>
          </s-box>
        ) : null}
        <s-box paddingBlockStart="base">
          <s-paragraph>
            Records what visitors do on every store page (scroll, clicks, taps, page changes) to replay
            later. Typed text is always hidden; customer account pages and checkout are not recorded.
            The recorder (≈25 KB) loads only after the page has fully loaded and the browser is idle,
            sends compressed data every few seconds and never changes the theme’s requests. After an add
            to cart it saves the visitor id in a hidden cart attribute (_wc_rec), so the order can be
            linked to the recording (orders are checked every 15 min).
            Recordings are kept {retention} days on our server; if the server disk gets
            short of space, the oldest days are removed first so recording never stops
            {since ? ` (stored since ${since})` : ""}.
          </s-paragraph>
        </s-box>
      </s-section>

      <s-section>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(170px, 1fr))", gap: 12, alignItems: "end" }}>
          <s-select label="Period" value={String(filter.days)} onChange={(e) => go({ days: e.currentTarget.value })}>
            <s-option value="1">Today</s-option>
            <s-option value="3">3 days</s-option>
            <s-option value="7">7 days</s-option>
            <s-option value="14">14 days</s-option>
            <s-option value="30">30 days</s-option>
          </s-select>
          <s-select label="Device" value={filter.device} onChange={(e) => go({ device: e.currentTarget.value })}>
            <s-option value="">All</s-option>
            <s-option value="mobile">Mobile</s-option>
            <s-option value="tablet">Tablet</s-option>
            <s-option value="desktop">Desktop</s-option>
          </s-select>
          <s-select label="Duration" value={String(filter.minSec)} onChange={(e) => go({ min: e.currentTarget.value })}>
            <s-option value="0">Any</s-option>
            <s-option value="10">10 s +</s-option>
            <s-option value="30">30 s +</s-option>
            <s-option value="60">1 min +</s-option>
            <s-option value="180">3 min +</s-option>
          </s-select>
          <s-text-field
            label="Visited page contains"
            placeholder="/products/travel-pillow"
            value={urlQ}
            onInput={(e) => setUrlQ(e.currentTarget.value)}
          />
          <s-checkbox
            label="Added to cart"
            checked={filter.atc || undefined}
            onChange={(e) => go({ atc: e.currentTarget.checked ? "1" : "" })}
          />
        </div>
        <s-box paddingBlockStart="base">
          <s-text color="subdued">
            {list.matched} of {list.total} visitors ({list.sessions} visits) · {list.withAtc} with add to cart · {fmtBytes(list.bytes)} stored
            {disk.total ? ` · server disk free ${fmtBytes(disk.free)} of ${fmtBytes(disk.total)}` : ""}
          </s-text>
        </s-box>
        <style>{`
          .wcr-t{width:100%;border-collapse:collapse;font-size:13px;table-layout:fixed}
          .wcr-t th{text-align:left;padding:7px 6px;font-weight:600;border-bottom:1px solid #e3e3e3;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
          .wcr-t td{padding:7px 6px;border-bottom:1px solid #f1f1f1;vertical-align:middle;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
          .wcr-t td.wrap{white-space:normal}
          .wcr-t .sub{color:#616161}
          .wcr-acts{display:inline-flex;gap:4px;align-items:center}
          .wcr-act{display:inline-flex;align-items:center;gap:2px;border-radius:10px;padding:1px 7px 1px 4px;font-size:12px;line-height:18px}
          .wcr-act.atc{background:#e4f5ea;color:#0c5132}
          .wcr-act.co{background:#e0f0ff;color:#00527c}
          .wcr-act.ord{background:#0c5132;color:#fff;padding:1px 7px}
          .wcr-act.ord a{color:#fff;text-decoration:none}
          .wcr-btns{display:inline-flex;gap:2px;align-items:center}
        `}</style>
        <div style={{ overflowX: "auto", marginTop: 12 }}>
          <table className="wcr-t">
            <colgroup>
              <col style={{ width: 104 }} />
              <col style={{ width: 46 }} />
              <col style={{ width: 64 }} />
              <col />
              <col style={{ width: 64 }} />
              <col style={{ width: 150 }} />
              <col style={{ width: 160 }} />
              <col style={{ width: 150 }} />
              <col style={{ width: 96 }} />
            </colgroup>
            <thead>
              <tr>
                <th>Last activity</th>
                <th title="Pages viewed">Pages</th>
                <th title="Time on site">Time</th>
                <th>First page → last page</th>
                <th>Device</th>
                <th>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 3 }}>
                    <s-icon type="globe" size="small" /> Location
                  </span>
                </th>
                <th>Source</th>
                <th title="Add to cart · Checkout · Order">Actions</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {list.items.map((r: RecVisitor) => {
                const ords = orders[r.vid] ?? [];
                const src = cleanSource(r.source) || "direct";
                return (
                  <tr key={r.vid}>
                    <td>
                      <a href={openUrl(r.vid)} target="_blank" rel="noreferrer">
                        {fmtTime(r.last)}
                      </a>
                    </td>
                    <td>{r.pages}</td>
                    <td>{fmtDuration(r.duration)}</td>
                    <td title={r.pages > 1 ? `${r.landing}\n→ ${r.lastUrl}` : r.landing}>
                      {pathOnly(r.landing)}
                      {r.pages > 1 ? <span className="sub"> → {pathOnly(r.lastUrl)}</span> : null}
                    </td>
                    <td title={`${r.os} · ${r.browser} · ${r.w}×${r.h}`}>{r.device}</td>
                    <td title={r.tz ? `Time zone: ${r.tz}` : undefined}>{locationLabel(r.country, r.tz)}</td>
                    <td title={src}>{src}</td>
                    <td>
                      <span className="wcr-acts">
                        {r.atc ? (
                          <span className="wcr-act atc" title="Added to cart">
                            <s-icon type="cart" size="small" tone="success" />
                            Cart
                          </span>
                        ) : null}
                        {r.checkout ? (
                          <span className="wcr-act co" title="Went to checkout">
                            <s-icon type="credit-card" size="small" tone="info" />
                            Checkout
                          </span>
                        ) : null}
                        {ords.map((o) => (
                          <span key={o.id} className="wcr-act ord" title={`Order ${o.name} · ${o.total} ${o.cur}`}>
                            <a href={`shopify://admin/orders/${o.id}`} target="_top">
                              ✓ {o.name}
                            </a>
                          </span>
                        ))}
                        {!r.atc && !r.checkout && !ords.length ? <span className="sub">—</span> : null}
                      </span>
                    </td>
                    <td>
                      <span className="wcr-btns">
                        <s-button variant="primary" href={openUrl(r.vid)} target="_blank">
                          Open
                        </s-button>
                        <s-button
                          variant="tertiary"
                          tone="critical"
                          icon={confirm === r.vid ? undefined : "delete"}
                          accessibilityLabel="Delete visitor"
                          onClick={() => {
                            if (confirm === r.vid) {
                              setConfirm("");
                              fetcher.submit({ intent: "delete", vid: r.vid }, { method: "post" });
                            } else setConfirm(r.vid);
                          }}
                        >
                          {confirm === r.vid ? "Sure?" : ""}
                        </s-button>
                      </span>
                    </td>
                  </tr>
                );
              })}
              {!list.items.length ? (
                <tr>
                  <td className="wrap sub" style={{ padding: 24 }} colSpan={9}>
                    {enabled
                      ? "No visitors for these filters yet. New visits appear here within a few seconds."
                      : "Recording is off. Turn it on to start collecting visits."}
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
        <s-box paddingBlockStart="small-200">
          <s-text color="subdued">
            Location: country from the visitor IP (
            <a href="https://db-ip.com" target="_blank" rel="noreferrer">
              IP Geolocation by DB-IP
            </a>
            ; the IP itself is not stored), city from the visitor’s time zone.
          </s-text>
        </s-box>
        {list.pages > 1 ? (
          <s-box paddingBlockStart="base">
            <s-stack direction="inline" gap="base" alignItems="center">
              <s-button disabled={filter.page <= 0 || undefined} onClick={() => go({ page: String(filter.page - 1) })}>
                ← Newer
              </s-button>
              <s-text>
                Page {filter.page + 1} of {list.pages}
              </s-text>
              <s-button
                disabled={filter.page + 1 >= list.pages || undefined}
                onClick={() => go({ page: String(filter.page + 1) })}
              >
                Older →
              </s-button>
            </s-stack>
          </s-box>
        ) : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
