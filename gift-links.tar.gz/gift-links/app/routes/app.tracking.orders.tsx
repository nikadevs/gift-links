import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { useLoaderData, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { handleTrkAction } from "../trk-actions.server";
import { loadOrders } from "../trk-orders.server";
import { TRK_ORDER_PAGE as PAGE, TRK_ORDER_TABS as TABS, TRK_STATUS_LABEL, type TrkStatus } from "../trk.shared";
import { StatusBadge, TrkNav, fmt, input, td, th, useTrkAction } from "../trk-ui";

/** Tracking → Orders (like Track123 Orders): status tabs, search, filters, export. */
export const loader = async ({ request }: LoaderFunctionArgs) => loadOrders(request);

export const action = async ({ request }: ActionFunctionArgs) => handleTrkAction(request);

type Row = ReturnType<typeof useLoaderData<typeof loader>>["rows"][number];

function toCsv(rows: Row[]) {
  const head = ["Order", "Tracking number", "Carrier", "Last-mile carrier", "Last-mile number", "Status", "Last event", "Last event time", "Order date", "Fulfillment date", "Delivery date", "Transit days", "Country"];
  const esc = (v: unknown) => `"${String(v ?? "").replace(/"/g, '""')}"`;
  return [
    head.join(","),
    ...rows.map((r) =>
      [r.order, r.number, r.carrier, r.lastMileCarrier, r.lastMileNumber, TRK_STATUS_LABEL[r.status as TrkStatus], r.lastEvent, r.lastEventAt, r.orderDate, r.shippedAt, r.deliveredAt, r.transitDays ?? "", r.country]
        .map(esc)
        .join(","),
    ),
  ].join("\n");
}

export default function TrackingOrders() {
  const d = useLoaderData<typeof loader>();
  const [params, setParams] = useSearchParams();
  const { post, busy } = useTrkAction();
  const [q, setQ] = useState(params.get("q") || "");
  const [exporting, setExporting] = useState(false);
  const go = (patch: Record<string, string>) => {
    const p = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) (v ? p.set(k, v) : p.delete(k));
    if (!("page" in patch)) p.delete("page");
    setParams(p);
  };
  const pages = Math.max(1, Math.ceil(d.total / PAGE));
  const status = params.get("status") || "";

  const doExport = async () => {
    setExporting(true);
    try {
      // resource route; App Bridge adds the session token to same-origin fetch
      const res = await fetch(`/app/tracking-export?${new URLSearchParams(params).toString()}`);
      if (!res.ok) throw new Error(`Export failed: HTTP ${res.status}`);
      const rows: Row[] = (await res.json()).rows;
      const blob = new Blob([toCsv(rows)], { type: "text/csv;charset=utf-8" });
      const a = document.createElement("a");
      a.href = URL.createObjectURL(blob);
      a.download = `tracking-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
      URL.revokeObjectURL(a.href);
    } finally {
      setExporting(false);
    }
  };

  const sel = (name: string, label: string, options: string[]) => (
    <select style={{ ...input, width: 170 }} value={params.get(name) || ""} onChange={(e) => go({ [name]: e.target.value })}>
      <option value="">{label}</option>
      {options.map((o) => (
        <option key={o} value={o}>
          {o}
        </option>
      ))}
    </select>
  );

  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      <s-section>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
          {TABS.map(([k, l]) => (
            <s-button key={k || "all"} variant={status === k ? "primary" : "secondary"} onClick={() => go({ status: k })}>
              {`${l} (${d.counts[k] ?? 0})`}
            </s-button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 12, alignItems: "center" }}>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              go({ q });
            }}
            style={{ display: "flex", gap: 6 }}
          >
            <input style={{ ...input, width: 240 }} placeholder="Order, tracking number or email" value={q} onChange={(e) => setQ(e.target.value)} />
            <s-button onClick={() => go({ q })}>Search</s-button>
          </form>
          <select style={{ ...input, width: 130 }} value={params.get("days") || "30"} onChange={(e) => go({ days: e.target.value })}>
            <option value="30">Last 30 days</option>
            <option value="60">Last 60 days</option>
            <option value="90">Last 90 days</option>
            <option value="9999">All</option>
          </select>
          {sel("carrier", "Carrier", d.carriers)}
          {sel("lastmile", "Last-mile carrier", d.lastMiles)}
          {sel("country", "Destination", d.countries)}
          <s-button variant="tertiary" loading={exporting || undefined} onClick={() => void doExport()}>
            Export CSV
          </s-button>
          <s-button variant="tertiary" loading={busy("import") || undefined} onClick={() => post({ intent: "import" })}>
            Sync orders
          </s-button>
        </div>
        {!d.rows.length ? (
          <s-paragraph>No shipments here. “Sync orders” reads shipped orders from Shopify (nothing is changed in the orders).</s-paragraph>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Order</th>
                  <th style={th}>Tracking number</th>
                  <th style={th}>Status</th>
                  <th style={th}>Last event</th>
                  <th style={th}>Order date</th>
                  <th style={th}>Fulfilled</th>
                  <th style={th}>Delivered</th>
                  <th style={th}>Transit days</th>
                  <th style={th}></th>
                </tr>
              </thead>
              <tbody>
                {d.rows.map((r) => (
                  <tr key={r.number}>
                    <td style={td}>
                      <a href={`shopify://admin/orders/${r.orderId}`} target="_top" style={{ color: "#005bd3" }}>
                        #{r.order}
                      </a>
                      <div style={{ color: "#616161", fontSize: 12 }}>
                        {r.country} {r.email}
                      </div>
                    </td>
                    <td style={td}>
                      <div>{r.number}</div>
                      <div style={{ color: "#616161", fontSize: 12 }}>
                        {r.carrier}
                        {r.lastMileNumber ? ` → ${r.lastMileCarrier} ${r.lastMileNumber}` : ""}
                      </div>
                    </td>
                    <td style={td}>
                      <StatusBadge status={r.status as TrkStatus} />
                      <div style={{ color: "#616161", fontSize: 12, marginTop: 4 }}>
                        {r.paypal === "ok" ? "PayPal ✓ " : r.paypal === "error" ? "PayPal ✗ " : ""}
                        {r.emails ? `${r.emails} email${r.emails > 1 ? "s" : ""}` : ""}
                      </div>
                    </td>
                    <td style={{ ...td, maxWidth: 300 }}>
                      <div>{r.lastEvent || (r.error ? "" : "—")}</div>
                      <div style={{ color: r.error ? "#b42318" : "#616161", fontSize: 12 }}>{r.error || fmt(r.lastEventAt)}</div>
                    </td>
                    <td style={td}>{fmt(r.orderDate, false)}</td>
                    <td style={td}>{fmt(r.shippedAt, false)}</td>
                    <td style={td}>{fmt(r.deliveredAt, false)}</td>
                    <td style={td}>{r.transitDays ?? ""}</td>
                    <td style={td}>
                      <s-button variant="tertiary" onClick={() => post({ intent: "refresh", number: r.number })}>
                        Update
                      </s-button>
                      {d.pageUrl ? (
                        <s-button variant="tertiary" href={`${d.pageUrl}?nums=${encodeURIComponent(r.number)}`} target="_blank">
                          Page
                        </s-button>
                      ) : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        {pages > 1 ? (
          <div style={{ display: "flex", gap: 8, alignItems: "center", marginTop: 12 }}>
            <s-button disabled={d.pg <= 1 || undefined} onClick={() => go({ page: String(d.pg - 1) })}>
              ← Previous
            </s-button>
            <span style={{ fontSize: 13 }}>
              Page {d.pg} of {pages} · {d.total} shipments
            </span>
            <s-button disabled={d.pg >= pages || undefined} onClick={() => go({ page: String(d.pg + 1) })}>
              Next →
            </s-button>
          </div>
        ) : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
