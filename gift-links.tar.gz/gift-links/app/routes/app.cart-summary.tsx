import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { CSSProperties } from "react";
import { useEffect, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { CS_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadCsConfig, saveCsConfig } from "../cs.server";
import { CS_DEFAULTS, CS_TEXT_FIELDS, normalizeCs, type CsConfig } from "../cs.shared";

/**
 * Cart Summary: on the /cart page the theme shows only "Subtotal" (which is
 * really the cart total after discount codes). This module shows Subtotal,
 * every discount code, Shipping (when the free-shipping bar is reached), Total
 * and "You save". No separate app embed: Turn on / Turn off writes
 * wc_cs.config.enabled; the Gift Links embed prints the code
 * (assets/wc-cart-summary.js, only on /cart).
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config }, domain] = await Promise.all([loadCsConfig(admin), loadShopDomain(admin)]);
  const live = config.enabled
    ? await checkEmbed(domain, CS_EMBED_MARKERS, url.searchParams.has("refresh"))
    : "off";
  return { config, live, domain };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadCsConfig(admin);
  const intent = String(form.get("intent") || "");
  let next: CsConfig = config;
  if (intent === "toggle") next = { ...config, enabled: form.get("enabled") === "1" };
  else if (intent === "save") {
    try {
      next = { ...normalizeCs(JSON.parse(String(form.get("config") || "{}"))), enabled: config.enabled };
    } catch {
      return { ok: false as const, error: "Bad form data", intent, enabled: config.enabled };
    }
  } else return { ok: false as const, error: "Unknown action", intent, enabled: config.enabled };
  next.updatedAt = new Date().toISOString();
  try {
    await saveCsConfig(admin, installationId, next);
    return { ok: true as const, error: "", intent, enabled: next.enabled };
  } catch (e) {
    return { ok: false as const, error: e instanceof Error ? e.message : String(e), intent, enabled: config.enabled };
  }
};

const lbl: CSSProperties = { display: "block", fontSize: 13, marginBottom: 4, color: "#303030" };
const help: CSSProperties = { display: "block", fontSize: 12, marginTop: 4, color: "#616161" };
const input: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  fontSize: 13,
  background: "#fdfdfd",
};

/* Same layout as extensions/gift-links-embed/assets/wc-cart-summary.js (keep in sync). */
function Preview({ c }: { c: CsConfig }) {
  const row: CSSProperties = { display: "flex", justifyContent: "space-between", gap: 12, fontSize: 15, lineHeight: "22px", padding: "4px 0" };
  return (
    <div style={{ background: "#f5f5f5", borderRadius: 8, padding: 20, maxWidth: 380, fontFamily: "inherit" }}>
      <div style={row}>
        <span>{c.subtotal}</span>
        <span>$82.40</span>
      </div>
      <div style={{ ...row, color: "#177983" }}>
        <span>{c.discount} (Bundle discount)</span>
        <span>−$15.98</span>
      </div>
      <div style={{ ...row, color: "#177983" }}>
        <span>{c.discount} (GIFTSCALE)</span>
        <span>−$6.64</span>
      </div>
      <div style={row}>
        <span>{c.shipping}</span>
        <span style={{ fontWeight: 600 }}>{c.free}</span>
      </div>
      <div style={{ ...row, borderTop: "1px solid #dcdcdc", marginTop: 8, paddingTop: 12, fontSize: 22, lineHeight: "30px", fontWeight: 700 }}>
        <span>{c.total}</span>
        <span>$59.78</span>
      </div>
      {c.note ? <div style={{ fontSize: 12, color: "#6b6b6b", marginTop: 6 }}>{c.note}</div> : null}
    </div>
  );
}

export default function CartSummary() {
  const { config } = useLoaderData<typeof loader>();
  // re-mount the form after every save so the inputs show the saved texts
  return <CartSummaryForm key={config.updatedAt || "new"} />;
}

function CartSummaryForm() {
  const { config, live, domain } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const busy = fetcher.state !== "idle";
  const [c, setC] = useState<CsConfig>(config);

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      shopify.toast.show(
        fetcher.data.intent === "save" ? "Saved" : fetcher.data.enabled ? "Cart Summary turned on" : "Cart Summary turned off",
      );
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const toggle = () => {
    const fd = new FormData();
    fd.set("intent", "toggle");
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };
  const save = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("config", JSON.stringify(c));
    fetcher.submit(fd, { method: "post" });
  };
  const dirty = CS_TEXT_FIELDS.some((f) => c[f.key] !== config[f.key]);

  return (
    <s-page inlineSize="large" heading="Cart Summary">
      <s-button slot="primary-action" variant="primary" disabled={!dirty || undefined} loading={(busy && fetcher.formData?.get("intent") === "save") || undefined} onClick={save}>
        Save
      </s-button>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? <s-badge tone="success">Active</s-badge> : <s-badge>Inactive</s-badge>}
          <s-button variant={config.enabled ? "secondary" : "primary"} loading={(busy && fetcher.formData?.get("intent") === "toggle") || undefined} onClick={toggle}>
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: code present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              <s-button variant="tertiary" href={`${domain || ""}/cart`} target="_blank">
                Open the cart
              </s-button>
            </>
          ) : null}
        </s-stack>
        {config.enabled && live === "off" ? (
          <s-banner tone="critical">
            The storefront doesn’t have the Cart Summary code yet. It is printed by the “Gift Links” app
            embed — it must stay on (Theme editor → App embeds). Changes can take a minute to appear.
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
      </s-section>

      <s-section heading="What it does">
        <s-paragraph>
          The theme’s cart shows a single “Subtotal” that already includes discount codes, so customers can’t
          see what they get off and what they will pay. On the cart page this module shows instead:
        </s-paragraph>
        <s-unordered-list>
          <s-list-item>Subtotal — all items at full price.</s-list-item>
          <s-list-item>One row per discount: bundle / volume discounts and codes, e.g. “Discount (GIFTSCALE) −$6.64”.</s-list-item>
          <s-list-item>Shipping: FREE — only when the theme’s free-shipping bar is reached.</s-list-item>
          <s-list-item>Total — Subtotal minus the discounts (Shopify’s cart total), charged at checkout before any tax.</s-list-item>
        </s-unordered-list>
        <s-paragraph>
          Numbers come from Shopify’s cart, in the visitor’s currency, and update when the cart changes. The
          cart and checkout are not changed. Some US orders get sales tax at checkout (the store doesn’t
          include tax in prices), so the note under Total says that taxes are calculated at checkout.
        </s-paragraph>
      </s-section>

      <s-section heading="Texts">
        <div style={{ display: "flex", gap: 32, flexWrap: "wrap", alignItems: "flex-start" }}>
          <div style={{ flex: "1 1 320px", maxWidth: 460 }}>
            {CS_TEXT_FIELDS.map((f) => (
              <div key={f.key} style={{ marginBottom: 14 }}>
                <span style={lbl}>{f.label}</span>
                <input
                  style={input}
                  value={c[f.key]}
                  placeholder={CS_DEFAULTS[f.key]}
                  onChange={(e) => {
                    const v = e.target.value;
                    setC((p) => ({ ...p, [f.key]: v }));
                  }}
                />
                {f.help ? <span style={help}>{f.help}</span> : null}
              </div>
            ))}
          </div>
          <div style={{ flex: "1 1 320px" }}>
            <span style={lbl}>Preview (example numbers)</span>
            <Preview c={normalizeCs(c)} />
          </div>
        </div>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
