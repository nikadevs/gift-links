import { useEffect, useState } from "react";
import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import {
  redirect,
  useActionData,
  useLoaderData,
  useNavigate,
  useNavigation,
  useSubmit,
} from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { blankOffer, type UpsellOffer } from "../upsells.shared";
import {
  loadUpsellConfig,
  offerFromForm,
  saveUpsellConfig,
} from "../upsells.server";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const { config } = await loadUpsellConfig(admin);
  const offer =
    params.id === "new"
      ? { ...blankOffer(), order: config.offers.length }
      : config.offers.find((o) => o.id === params.id);
  if (!offer) throw redirect("/app/upsells");
  return { offer };
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadUpsellConfig(admin);
  const id =
    params.id === "new"
      ? `u_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`
      : String(params.id);

  const { offer, errors } = offerFromForm(form, id);
  if (!offer) return { errors };

  const idx = config.offers.findIndex((o) => o.id === id);
  if (idx >= 0) config.offers[idx] = offer;
  else config.offers.push(offer);

  try {
    await saveUpsellConfig(admin, installationId, config);
  } catch (e) {
    return { errors: { form: (e as Error).message } };
  }
  return redirect(`/app/upsells/${id}?saved=1`);
};

type FieldEvent = Event & {
  currentTarget: { value?: string; checked?: boolean };
};
const val = (e: Event) => String((e as FieldEvent).currentTarget?.value ?? "");
const chk = (e: Event) => Boolean((e as FieldEvent).currentTarget?.checked);
const num = (gid: string) => gid.replace(/\D/g, "");

type PickedImage = { originalSrc?: string; url?: string };
type PickedProduct = {
  id: string;
  title: string;
  handle?: string;
  images?: PickedImage[];
  variants?: {
    id: string;
    title?: string;
    price?: string;
    image?: PickedImage;
  }[];
};
type PickedCollection = { id: string; title: string };

export default function UpsellRoute() {
  const data = useLoaderData<typeof loader>();
  return (
    <UpsellForm
      key={`${data.offer.id}:${data.offer.updatedAt}`}
      offer={data.offer}
    />
  );
}

function UpsellForm({ offer }: { offer: UpsellOffer }) {
  const actionData = useActionData<typeof action>();
  const errors: Record<string, string> = actionData?.errors ?? {};
  const [o, setO] = useState<UpsellOffer>(offer);
  const [price, setPrice] = useState("");
  const submit = useSubmit();
  const nav = useNavigation();
  const navigate = useNavigate();
  const shopify = useAppBridge();
  const isNew = offer.id === "new";
  const saving = nav.state === "submitting";

  useEffect(() => {
    if (new URLSearchParams(window.location.search).get("saved"))
      shopify.toast.show("Checkbox saved");
  }, [offer.updatedAt, shopify]);

  const set = <K extends keyof UpsellOffer>(k: K, v: UpsellOffer[K]) =>
    setO((prev) => ({ ...prev, [k]: v }));

  const pickUpsell = async () => {
    const selected = (await shopify.resourcePicker({
      type: "product",
      multiple: false,
      filter: { variants: true, draft: false, archived: false },
      ...(o.productId
        ? {
            selectionIds: [
              {
                id: `gid://shopify/Product/${o.productId}`,
                variants: o.variantId
                  ? [{ id: `gid://shopify/ProductVariant/${o.variantId}` }]
                  : undefined,
              },
            ],
          }
        : {}),
    })) as PickedProduct[] | undefined;
    const product = selected?.[0];
    const variant = product?.variants?.[0];
    if (!product || !variant) return;
    const img =
      variant.image?.originalSrc ??
      variant.image?.url ??
      product.images?.[0]?.originalSrc ??
      product.images?.[0]?.url ??
      "";
    const vTitle =
      variant.title && variant.title !== "Default Title" ? variant.title : "";
    setPrice(variant.price ?? "");
    setO((prev) => ({
      ...prev,
      productId: num(product.id),
      productHandle: product.handle ?? "",
      productTitle: product.title,
      variantId: num(variant.id),
      variantTitle: vTitle,
      image: img,
      name: prev.name || product.title,
      title: prev.title || product.title,
    }));
  };

  const pickProducts = async () => {
    const selected = (await shopify.resourcePicker({
      type: "product",
      multiple: true,
      filter: { variants: false, draft: false, archived: false },
      selectionIds: o.productIds.map((id) => ({
        id: `gid://shopify/Product/${id}`,
      })),
    })) as PickedProduct[] | undefined;
    if (!selected) return;
    setO((prev) => ({
      ...prev,
      productIds: selected.map((p) => num(p.id)),
      productTitles: selected.map((p) => p.title),
    }));
  };

  const pickCollections = async () => {
    const selected = (await shopify.resourcePicker({
      type: "collection",
      multiple: true,
      selectionIds: o.collectionIds.map((id) => ({
        id: `gid://shopify/Collection/${id}`,
      })),
    })) as PickedCollection[] | undefined;
    if (!selected) return;
    setO((prev) => ({
      ...prev,
      collectionIds: selected.map((c) => num(c.id)),
      collectionTitles: selected.map((c) => c.title),
    }));
  };

  const removeAt = (
    ids: "productIds" | "collectionIds",
    titles: "productTitles" | "collectionTitles",
    i: number,
  ) =>
    setO((prev) => ({
      ...prev,
      [ids]: prev[ids].filter((_, j) => j !== i),
      [titles]: prev[titles].filter((_, j) => j !== i),
    }));

  const save = () => {
    const fd = new FormData();
    fd.append("offer", JSON.stringify(o));
    submit(fd, { method: "POST" });
  };

  return (
    <s-page heading={isNew ? "New checkbox" : o.name || "Checkbox"}>
      <s-link slot="breadcrumb-actions" href="/app/upsells">
        Checkbox Upsell
      </s-link>
      <s-button
        slot="primary-action"
        variant="primary"
        onClick={save}
        {...(saving ? { loading: true } : {})}
      >
        Save
      </s-button>
      <s-button
        slot="secondary-actions"
        onClick={() => navigate("/app/upsells")}
      >
        Cancel
      </s-button>

      {errors.form ? (
        <s-banner tone="critical" heading="Could not save">
          {errors.form}
        </s-banner>
      ) : null}

      <s-section heading="Upsell product">
        <s-stack direction="block" gap="base">
          {o.variantId ? (
            <s-stack direction="inline" gap="base" alignItems="center">
              {o.image ? (
                <s-thumbnail src={o.image} alt="" size="small" />
              ) : null}
              <s-stack direction="block" gap="none">
                <s-text type="strong">
                  {o.productTitle}
                  {o.variantTitle ? ` — ${o.variantTitle}` : ""}
                </s-text>
                <s-text color="subdued">Variant ID {o.variantId}</s-text>
              </s-stack>
              <s-button onClick={pickUpsell}>Change</s-button>
            </s-stack>
          ) : (
            <s-button onClick={pickUpsell}>Select product</s-button>
          )}
          {errors.product ? (
            <s-text tone="critical">{errors.product}</s-text>
          ) : null}
          <s-paragraph>
            The storefront shows this product&apos;s live price. Set a
            compare-at price on it to show the strike-through, like $5.00 →
            $2.50.
          </s-paragraph>
        </s-stack>
      </s-section>

      <s-section heading="Checkbox">
        <s-stack direction="block" gap="base">
          <s-text-field
            label="Internal name"
            details="Only you see this."
            value={o.name}
            error={errors.name}
            onInput={(e: Event) => set("name", val(e))}
          />
          <s-text-field
            label="Text next to the checkbox"
            placeholder="Skip The Line"
            value={o.title}
            error={errors.title}
            onInput={(e: Event) => set("title", val(e))}
          />
          <s-text-field
            label="Subtitle (optional)"
            placeholder="Priority Processing"
            value={o.subtitle}
            onInput={(e: Event) => set("subtitle", val(e))}
          />
          <s-number-field
            label="Display order"
            details="Lower number = shown first."
            step={1}
            value={String(o.order)}
            onInput={(e: Event) => set("order", Number(val(e) || 0))}
          />
          <s-checkbox
            label="Pre-check the checkbox"
            details="The box is already ticked when the product page opens."
            checked={o.precheck}
            onChange={(e: Event) => set("precheck", chk(e))}
          />
          <s-switch
            label="Checkbox is enabled"
            checked={o.active}
            onChange={(e: Event) => set("active", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section heading="Show on">
        <s-stack direction="block" gap="base">
          <s-checkbox
            label="All products"
            details="Never shown on the upsell product itself or on Gift Links gift pages."
            checked={o.triggerAll}
            onChange={(e: Event) => set("triggerAll", chk(e))}
          />
          {!o.triggerAll ? (
            <>
              <s-stack direction="block" gap="small-200">
                <s-stack
                  direction="inline"
                  gap="base"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <s-text type="strong">Products</s-text>
                  <s-button variant="tertiary" onClick={pickProducts}>
                    Edit products
                  </s-button>
                </s-stack>
                {o.productIds.length === 0 ? (
                  <s-text color="subdued">No products selected</s-text>
                ) : (
                  o.productIds.map((id, i) => (
                    <s-stack
                      key={id}
                      direction="inline"
                      gap="base"
                      alignItems="center"
                      justifyContent="space-between"
                    >
                      <s-text>{o.productTitles[i] || `Product ${id}`}</s-text>
                      <s-button
                        variant="tertiary"
                        tone="critical"
                        onClick={() => removeAt("productIds", "productTitles", i)}
                      >
                        Remove
                      </s-button>
                    </s-stack>
                  ))
                )}
              </s-stack>
              <s-stack direction="block" gap="small-200">
                <s-stack
                  direction="inline"
                  gap="base"
                  alignItems="center"
                  justifyContent="space-between"
                >
                  <s-text type="strong">Collections</s-text>
                  <s-button variant="tertiary" onClick={pickCollections}>
                    Edit collections
                  </s-button>
                </s-stack>
                {o.collectionIds.length === 0 ? (
                  <s-text color="subdued">No collections selected</s-text>
                ) : (
                  o.collectionIds.map((id, i) => (
                    <s-stack
                      key={id}
                      direction="inline"
                      gap="base"
                      alignItems="center"
                      justifyContent="space-between"
                    >
                      <s-text>
                        {o.collectionTitles[i] || `Collection ${id}`}
                      </s-text>
                      <s-button
                        variant="tertiary"
                        tone="critical"
                        onClick={() =>
                          removeAt("collectionIds", "collectionTitles", i)
                        }
                      >
                        Remove
                      </s-button>
                    </s-stack>
                  ))
                )}
              </s-stack>
            </>
          ) : null}
          {errors.triggers ? (
            <s-text tone="critical">{errors.triggers}</s-text>
          ) : null}
        </s-stack>
      </s-section>

      <s-section heading="Cart behaviour">
        <s-stack direction="block" gap="base">
          <s-select
            label="Quantity added"
            value={o.quantityMode}
            onChange={(e: Event) =>
              set("quantityMode", val(e) === "match" ? "match" : "one")
            }
          >
            <s-option value="one">Always 1 (e.g. Skip The Line)</s-option>
            <s-option value="match">
              Same as the main product (e.g. a gift box for each item)
            </s-option>
          </s-select>
          <s-checkbox
            label="Add only once per cart"
            details="If it is already in the cart, ticking it again on another product doesn't add a second one."
            checked={o.oncePerCart}
            onChange={(e: Event) => set("oncePerCart", chk(e))}
          />
        </s-stack>
      </s-section>

      <s-section slot="aside" heading="Preview">
        <s-box padding="base" border="base" borderRadius="base">
          <s-stack direction="inline" gap="base" alignItems="center">
            <s-checkbox
              label=""
              accessibilityLabel="Preview checkbox"
              checked={o.precheck}
            />
            {o.image ? <s-thumbnail src={o.image} alt="" size="small" /> : null}
            <s-stack direction="block" gap="none">
              <s-text type="strong">
                {o.title || "Text next to the checkbox"}
                {price ? `  $${price}` : ""}
              </s-text>
              {o.subtitle ? <s-text>{o.subtitle}</s-text> : null}
            </s-stack>
          </s-stack>
        </s-box>
        <s-paragraph>
          Colours and position are set in the theme editor → App embeds →
          Checkbox Upsell.
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
