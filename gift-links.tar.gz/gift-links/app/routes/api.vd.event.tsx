import type { ActionFunctionArgs } from "react-router";
import prisma from "../db.server";
import { recordEvent } from "../vd-stats.server";

/**
 * Volume Discounts beacon from the storefront block (navigator.sendBeacon,
 * text/plain JSON): { shop: "x.myshopify.com", offer: "vd_…", t: "v" | "c" }
 *   v = block shown (impression), c = first tier click on the page.
 * Accepted only for installed shops; no personal data stored.
 */
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
};

const shopCache = new Map<string, { ok: boolean; at: number }>();
const ipHits = new Map<string, { n: number; at: number }>();

async function knownShop(shop: string) {
  const hit = shopCache.get(shop);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.ok;
  const n = await prisma.session.count({ where: { shop } });
  shopCache.set(shop, { ok: n > 0, at: Date.now() });
  return n > 0;
}

const done = () => new Response(null, { status: 204, headers: CORS });

export const loader = () => done();

export const action = async ({ request }: ActionFunctionArgs) => {
  if (request.method === "OPTIONS") return done();
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0].trim() ?? "local";
    const now = Date.now();
    const r = ipHits.get(ip);
    if (r && now - r.at < 60000) {
      if (++r.n > 60) return done();
    } else ipHits.set(ip, { n: 1, at: now });
    if (ipHits.size > 5000) ipHits.clear();

    const body = JSON.parse((await request.text()).slice(0, 500)) as {
      shop?: string;
      offer?: string;
      t?: string;
    };
    const shop = String(body.shop ?? "").toLowerCase();
    const offer = String(body.offer ?? "");
    if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)) return done();
    if (!/^vd_[a-z0-9]{4,20}$/.test(offer)) return done();
    if (body.t !== "v" && body.t !== "c") return done();
    if (!(await knownShop(shop))) return done();
    recordEvent(shop, offer, body.t);
  } catch {
    /* never fail a beacon */
  }
  return done();
};
