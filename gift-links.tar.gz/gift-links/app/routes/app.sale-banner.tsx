import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import type { CSSProperties } from "react";
import { useEffect, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { SB_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadActiveProducts, loadSbConfig, saveSbConfig } from "../sb.server";
import {
  SB_DEFAULTS,
  formatLeft,
  normalizeSb,
  type SbConfig,
} from "../sb.shared";

/**
 * Sale Banner: promo strip on product pages (badge, heading, text pill or a
 * personal 20–40 min countdown per visitor; at zero the banner hides for them). Settings in wc_sb.config; the theme app block "Sale Banner" renders it.
 * Per-product heading overrides for any active product.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const [{ config }, domain, products] = await Promise.all([
    loadSbConfig(admin),
    loadShopDomain(admin),
    loadActiveProducts(admin).catch(() => []),
  ]);
  // check the storefront on a product page (the block lives there)
  const probe =
    config.overrides
      .map((o) => products.find((p) => p.id === o.id))
      .find(Boolean) || products[0];
  const live =
    config.enabled && probe
      ? await checkEmbed(
          domain,
          SB_EMBED_MARKERS,
          url.searchParams.has("refresh"),
          `/products/${encodeURIComponent(probe.handle)}`,
        )
      : config.enabled
        ? ("unknown" as const)
        : ("off" as const);
  return { config, live, domain, products, probe: probe?.handle || "" };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const { installationId, config } = await loadSbConfig(admin);
  const intent = String(form.get("intent") || "");
  let next: SbConfig = config;
  if (intent === "toggle")
    next = { ...config, enabled: form.get("enabled") === "1" };
  else if (intent === "save") {
    try {
      next = {
        ...normalizeSb(JSON.parse(String(form.get("config") || "{}"))),
        enabled: config.enabled,
      };
    } catch {
      return {
        ok: false as const,
        error: "Bad form data",
        intent,
        enabled: config.enabled,
      };
    }
    // new timer range / countdown switched on / "Restart" button = new timers for everyone
    if (
      form.get("restart") === "1" ||
      next.timerMin !== config.timerMin ||
      next.timerMax !== config.timerMax ||
      (next.countdown && !config.countdown)
    )
      next.timerKey = Date.now().toString(36);
    else next.timerKey = config.timerKey;
  } else
    return {
      ok: false as const,
      error: "Unknown action",
      intent,
      enabled: config.enabled,
    };
  next.updatedAt = new Date().toISOString();
  try {
    await saveSbConfig(admin, installationId, next);
    return { ok: true as const, error: "", intent, enabled: next.enabled };
  } catch (e) {
    return {
      ok: false as const,
      error: e instanceof Error ? e.message : String(e),
      intent,
      enabled: config.enabled,
    };
  }
};

const lbl: CSSProperties = {
  display: "block",
  fontSize: 13,
  marginBottom: 4,
  color: "#303030",
};
const help: CSSProperties = {
  display: "block",
  fontSize: 12,
  marginTop: 4,
  color: "#616161",
};
const input: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  fontSize: 13,
  background: "#fdfdfd",
};

/* Same look as extensions/gift-links-embed/blocks/sale-banner.liquid (keep in sync). */
function Preview({
  badge,
  heading,
  pill,
}: {
  badge: string;
  heading: string;
  pill: string;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 12,
        minHeight: 76,
        padding: "10px 28px",
        border: "1px solid #efd283",
        borderRadius: 10,
        background:
          "linear-gradient(90deg,#fdeaa9 0%,#fde39b 55%,#fdd57b 100%)",
        color: "#111",
        boxSizing: "border-box",
      }}
    >
      {badge ? (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 10,
            height: 38,
            padding: "0 16px 0 14px",
            borderRadius: 999,
            background: "#111",
            color: "#fff",
            fontWeight: 600,
            fontSize: 18,
            textTransform: "uppercase",
            whiteSpace: "nowrap",
            letterSpacing: ".01em",
          }}
        >
          <span
            style={{
              width: 8,
              height: 8,
              borderRadius: "50%",
              background: "#22c55e",
            }}
          />
          {badge}
        </span>
      ) : null}
      <div
        style={{
          flex: "1 1 auto",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
        }}
      >
        {heading ? (
          <span
            style={{
              fontWeight: 600,
              fontSize: 26,
              lineHeight: 1.1,
              textTransform: "uppercase",
            }}
          >
            {heading}
          </span>
        ) : null}
      </div>
      {pill ? (
        <span
          style={{
            display: "inline-flex",
            alignItems: "center",
            height: 36,
            padding: "0 16px",
            borderRadius: 999,
            background: "#fff",
            color: "#6b6b6b",
            fontWeight: 500,
            fontSize: 17,
            whiteSpace: "nowrap",
            fontVariantNumeric: "tabular-nums",
            flex: "none",
          }}
        >
          {pill}
        </span>
      ) : null}
    </div>
  );
}

export default function SaleBanner() {
  const { config } = useLoaderData<typeof loader>();
  return <SaleBannerForm key={config.updatedAt || "new"} />;
}

function SaleBannerForm() {
  const { config, live, domain, products, probe } =
    useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const rv = useRevalidator();
  const shopify = useAppBridge();
  const busy = fetcher.state !== "idle";

  const [badge, setBadge] = useState(config.badge);
  const [heading, setHeading] = useState(config.heading);
  const [pillText, setPillText] = useState(config.pillText);
  const [countdown, setCountdown] = useState(config.countdown);
  const [tMin, setTMin] = useState(String(config.timerMin));
  const [tMax, setTMax] = useState(String(config.timerMax));
  const [demoEnd, setDemoEnd] = useState(
    () => Date.now() + config.timerMax * 60000,
  );
  const [over, setOver] = useState<Record<string, string>>(() =>
    Object.fromEntries(config.overrides.map((o) => [o.id, o.heading])),
  );
  const [q, setQ] = useState("");
  const [onlyCustom, setOnlyCustom] = useState(false);
  const [now, setNow] = useState(() => Date.now());
  const [previewId, setPreviewId] = useState("");

  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data?.ok) {
      shopify.toast.show(
        fetcher.data.intent === "save"
          ? "Saved"
          : fetcher.data.enabled
            ? "Sale Banner turned on"
            : "Sale Banner turned off",
      );
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const draft: SbConfig = normalizeSb({
    ...config,
    badge,
    heading,
    pillText,
    countdown,
    timerMin: tMin,
    timerMax: tMax,
    overrides: Object.entries(over).map(([id, h]) => ({ id, heading: h })),
  });
  const dirty =
    JSON.stringify({ ...draft, updatedAt: "" }) !==
    JSON.stringify({ ...config, updatedAt: "" });

  const toggle = () => {
    const fd = new FormData();
    fd.set("intent", "toggle");
    fd.set("enabled", config.enabled ? "0" : "1");
    fetcher.submit(fd, { method: "post" });
  };
  const save = (restart = false) => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("config", JSON.stringify(draft));
    if (restart) fd.set("restart", "1");
    fetcher.submit(fd, { method: "post" });
  };

  const demoLeft = demoEnd - now;
  const pillPreview = countdown
    ? formatLeft(Math.max(0, demoLeft))
    : draft.pillText;
  const previewHeading =
    (previewId && over[previewId]?.trim()) || draft.heading;
  const customCount = Object.values(over).filter((v) => v.trim()).length;
  const list = products.filter(
    (p) =>
      (!onlyCustom || (over[p.id] || "").trim()) &&
      (!q.trim() || p.title.toLowerCase().includes(q.trim().toLowerCase())),
  );
  const missing = config.overrides.filter(
    (o) => !products.some((p) => p.id === o.id),
  );

  return (
    <s-page inlineSize="large" heading="Sale Banner">
      <s-button
        slot="primary-action"
        variant="primary"
        disabled={!dirty || undefined}
        loading={
          (busy && fetcher.formData?.get("intent") === "save") || undefined
        }
        onClick={() => save()}
      >
        Save
      </s-button>

      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {config.enabled ? (
            <s-badge tone="success">Active</s-badge>
          ) : (
            <s-badge>Inactive</s-badge>
          )}
          <s-button
            variant={config.enabled ? "secondary" : "primary"}
            loading={
              (busy && fetcher.formData?.get("intent") === "toggle") ||
              undefined
            }
            onClick={toggle}
          >
            {config.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {config.enabled ? (
            <>
              {live === "on" ? (
                <s-badge tone="success">Storefront: banner present</s-badge>
              ) : live === "off" ? (
                <s-badge tone="critical">Storefront: block not found</s-badge>
              ) : (
                <s-badge tone="warning">Storefront: can’t check</s-badge>
              )}
              <s-button
                variant="tertiary"
                loading={rv.state === "loading" || undefined}
                onClick={() => {
                  window.history.replaceState(null, "", "?refresh=1");
                  rv.revalidate();
                }}
              >
                Refresh
              </s-button>
              {probe ? (
                <s-button
                  variant="tertiary"
                  href={`${domain || ""}/products/${probe}`}
                  target="_blank"
                >
                  Open a product
                </s-button>
              ) : null}
            </>
          ) : null}
        </s-stack>
        {config.enabled && live === "off" ? (
          <s-banner tone="warning">
            The banner isn’t on the product page yet. Add it once: Online Store
            → Themes → Customize → Products → Default product → in the product
            section “Add block” → Apps → “Sale Banner”, drag it under the
            photos, Save. Changes can take a minute to appear.
          </s-banner>
        ) : null}
        {fetcher.data && !fetcher.data.ok ? (
          <s-banner tone="critical">{fetcher.data.error}</s-banner>
        ) : null}
      </s-section>

      <s-section heading="Preview">
        {countdown && demoLeft <= 0 ? (
          <span style={help}>
            The timer ended: for this visitor the banner is now hidden on the
            store.
          </span>
        ) : (
          <Preview
            badge={draft.badge}
            heading={previewHeading}
            pill={pillPreview}
          />
        )}
        <span style={help}>
          Uses the theme’s own font on the store. Width adapts to the product
          column; on phones the texts get smaller and a long heading wraps to
          two lines.
        </span>
      </s-section>

      <s-section heading="Banner">
        <div style={{ maxWidth: 520 }}>
          <div style={{ marginBottom: 14 }}>
            <span style={lbl}>1. Sale badge</span>
            <input
              style={input}
              value={badge}
              maxLength={40}
              placeholder={SB_DEFAULTS.badge}
              onChange={(e) => setBadge(e.target.value)}
            />
            <span style={help}>
              Black badge on the left. Leave empty to hide it.
            </span>
          </div>
          <div style={{ marginBottom: 14 }}>
            <span style={lbl}>2. Default heading</span>
            <input
              style={input}
              value={heading}
              maxLength={80}
              placeholder={SB_DEFAULTS.heading}
              onChange={(e) => setHeading(e.target.value)}
            />
            <span style={help}>
              Shown on every product unless the product has its own heading
              below.
            </span>
          </div>
          <div style={{ marginBottom: 8 }}>
            <span style={lbl}>3. White badge</span>
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 13,
                margin: "4px 0",
              }}
            >
              <input
                type="radio"
                name="sb-mode"
                checked={!countdown}
                onChange={() => setCountdown(false)}
              />{" "}
              Text
            </label>
            <label
              style={{
                display: "flex",
                alignItems: "center",
                gap: 6,
                fontSize: 13,
                margin: "4px 0 10px",
              }}
            >
              <input
                type="radio"
                name="sb-mode"
                checked={countdown}
                onChange={() => setCountdown(true)}
              />{" "}
              Personal countdown HH:MM:SS (banner hides when it ends)
            </label>
          </div>
          {countdown ? (
            <div style={{ marginBottom: 14 }}>
              <span style={lbl}>Timer for each visitor, minutes</span>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span style={{ fontSize: 13 }}>from</span>
                <input
                  style={{ ...input, width: 80 }}
                  type="number"
                  min={1}
                  max={1440}
                  value={tMin}
                  onChange={(e) => setTMin(e.target.value)}
                />
                <span style={{ fontSize: 13 }}>to</span>
                <input
                  style={{ ...input, width: 80 }}
                  type="number"
                  min={1}
                  max={1440}
                  value={tMax}
                  onChange={(e) => setTMax(e.target.value)}
                />
              </div>
              <span style={help}>
                Every visitor gets a random timer in this range on their first
                visit (kept in their browser: the same on every page and after
                reloads). When it reaches 00:00:00 the banner is hidden for that
                visitor for good. Changing the range gives everyone a new timer.
              </span>
              <div
                style={{
                  display: "flex",
                  gap: 8,
                  alignItems: "center",
                  marginTop: 8,
                  flexWrap: "wrap",
                }}
              >
                <s-button
                  variant="secondary"
                  disabled={dirty || undefined}
                  loading={
                    (busy && fetcher.formData?.get("restart") === "1") ||
                    undefined
                  }
                  onClick={() => save(true)}
                >
                  Restart timers for all visitors
                </s-button>
                <s-button
                  variant="tertiary"
                  onClick={() =>
                    setDemoEnd(Date.now() + draft.timerMax * 60000)
                  }
                >
                  Restart preview
                </s-button>
              </div>
              <span style={help}>
                Restart: visitors whose banner already disappeared see it again
                with a new timer (e.g. for a new sale).
              </span>
            </div>
          ) : (
            <div style={{ marginBottom: 14 }}>
              <span style={lbl}>Text</span>
              <input
                style={input}
                value={pillText}
                maxLength={40}
                placeholder={SB_DEFAULTS.pillText}
                onChange={(e) => setPillText(e.target.value)}
              />
              <span style={help}>Leave empty to hide the white badge.</span>
            </div>
          )}
        </div>
      </s-section>

      <s-section heading={`Heading per product (${customCount} custom)`}>
        <s-paragraph>
          All active products. Type a heading to replace the default one on that
          product; empty = default.
        </s-paragraph>
        <div
          style={{
            display: "flex",
            gap: 12,
            alignItems: "center",
            flexWrap: "wrap",
            margin: "10px 0",
          }}
        >
          <input
            style={{ ...input, maxWidth: 300 }}
            placeholder="Search products"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <label
            style={{
              display: "flex",
              alignItems: "center",
              gap: 6,
              fontSize: 13,
            }}
          >
            <input
              type="checkbox"
              checked={onlyCustom}
              onChange={(e) => setOnlyCustom(e.target.checked)}
            />{" "}
            Only custom
          </label>
          <span style={{ fontSize: 12, color: "#616161" }}>
            {products.length} active products
          </span>
        </div>
        <div
          style={{
            border: "1px solid #e3e3e3",
            borderRadius: 8,
            overflow: "hidden",
          }}
        >
          {list.map((p, i) => (
            <div
              key={p.id}
              style={{
                display: "grid",
                gridTemplateColumns: "40px minmax(0,1fr) minmax(0,1.2fr)",
                gap: 12,
                alignItems: "center",
                padding: "8px 12px",
                borderTop: i ? "1px solid #ebebeb" : 0,
                background: previewId === p.id ? "#f6f9fc" : "#fff",
              }}
            >
              {p.image ? (
                <img
                  src={p.image}
                  alt=""
                  width={40}
                  height={40}
                  style={{
                    width: 40,
                    height: 40,
                    objectFit: "contain",
                    borderRadius: 4,
                    background: "#f4f4f4",
                  }}
                />
              ) : (
                <span
                  style={{
                    width: 40,
                    height: 40,
                    borderRadius: 4,
                    background: "#f1f1f1",
                  }}
                />
              )}
              <span
                style={{
                  fontSize: 13,
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                }}
                title={p.title}
              >
                {p.title}
              </span>
              <input
                style={input}
                value={over[p.id] || ""}
                maxLength={80}
                placeholder={draft.heading}
                onFocus={() => setPreviewId(p.id)}
                onChange={(e) => {
                  const v = e.target.value;
                  setOver((o) => {
                    const n = { ...o };
                    if (v) n[p.id] = v;
                    else delete n[p.id];
                    return n;
                  });
                }}
              />
            </div>
          ))}
          {!list.length ? (
            <div style={{ padding: 14, fontSize: 13, color: "#616161" }}>
              No products.
            </div>
          ) : null}
        </div>
        {missing.length ? (
          <span style={help}>
            {missing.length} custom heading(s) belong to products that are no
            longer active; they are kept and apply again if the product becomes
            active.
          </span>
        ) : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) =>
  boundary.headers(headersArgs);
