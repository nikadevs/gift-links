import type { ActionFunctionArgs, LoaderFunctionArgs } from "react-router";
import { authenticate } from "../shopify.server";
import { loadFeaturesProduct, saveFeatures, sliderFiles, uploadSliderPhoto, photoStatus, sanitizeIcon } from "../features.server";
export const loader = async ({request}: LoaderFunctionArgs) => {
  const {admin,cors} = await authenticate.admin(request);
  try {return cors(Response.json({ok:true, selection:await loadFeaturesProduct(admin,new URL(request.url).searchParams.get("product") || "")}));}
  catch(e){return cors(Response.json({ok:false,message:e instanceof Error?e.message:"Could not load slider."},{status:400}));}
};
export const action = async ({request}: ActionFunctionArgs) => {
  const {admin,cors} = await authenticate.admin(request), form=await request.formData();
  try {
    const intent=form.get("intent");
    if(intent==="files")return cors(Response.json({ok:true,files:(await sliderFiles(admin,String(form.get("after")||"")||null)).files}));
    if(intent==="icon")return cors(Response.json({ok:true,icon:sanitizeIcon(String(form.get("svg")||""))}));
    if(intent==="upload"){const file=form.get("photo");if(!(file instanceof File))throw new Error("Choose a photo.");return cors(Response.json({ok:true,upload:await uploadSliderPhoto(admin,file)}));}
    if(intent==="photo-status")return cors(Response.json({ok:true,upload:await photoStatus(admin,String(form.get("id")))}));
    if(intent!=="save")throw new Error("Unknown action.");
    const id=String(form.get("product")), loaded=await loadFeaturesProduct(admin,id);
    if(String(form.get("digest")||"")!==(loaded.product.config?.compareDigest||""))throw new Error("These settings were edited elsewhere. Reload before saving.");
    await saveFeatures(admin,id,JSON.parse(String(form.get("config"))),loaded.product.config?.compareDigest??null);
    return cors(Response.json({ok:true,selection:await loadFeaturesProduct(admin,id)}));
  }catch(e){return cors(Response.json({ok:false,message:e instanceof Error?e.message:"Could not save slider."},{status:400}));}
};
