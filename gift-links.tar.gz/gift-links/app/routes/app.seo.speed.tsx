import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useEffect, useState } from "react";
import { useFetcher, useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { jobStates, seoAuth, seoEmbedState } from "../seo/seo-context.server";
import { getLatestReport, getPsiRuns } from "../seo/seo-store.server";
import { startPsi } from "../seo/seo-psi.server";
import { cwvStatus, latestRuns } from "../seo/seo.shared";
import { loadEmbedConfig, saveEmbedConfig } from "../seo/seo-admin.server";
import { check, fmtBytes, fmtMs, type FieldMetric, type SeoEmbedConfig } from "../seo/seo.shared";
import { SevBadge, SeoTabs, ago, groupFindings, pathOf, scoreTone } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, shop, origin } = await seoAuth(request);
  const [runs, report, jobs, embedCfg, embed] = await Promise.all([
    getPsiRuns(shop),
    getLatestReport(shop),
    jobStates(shop),
    loadEmbedConfig(admin).then((r) => r.config).catch(() => null),
    seoEmbedState(shop, origin),
  ]);
  const latest = latestRuns(runs).sort(
    (a, b) => a.url.localeCompare(b.url) || a.strategy.localeCompare(b.strategy),
  );
  return {
    origin,
    latest,
    history: runs
      .filter((r) => !r.error)
      .slice(-40)
      .reverse()
      .map((r) => ({
        at: r.at,
        url: r.url,
        strategy: r.strategy,
        performance: r.scores.performance,
        lcp: r.lab.lcp,
        tbt: r.lab.tbt,
        cls: r.lab.cls,
      })),
    lastError: [...runs].reverse().find((r) => r.error)?.error ?? "",
    speedGroups: groupFindings(
      (report?.findings ?? []).filter((f) => check(f.check).category === "speed"),
    ).map((g) => ({
      id: g.def.id,
      title: g.def.title,
      severity: g.def.severity,
      fix: g.def.fix,
      count: g.count,
      sample: g.items.slice(0, 3).map((i) => `${pathOf(i.url)}${i.detail ? ` — ${i.detail}` : ""}`),
    })),
    scripts: (report?.scripts ?? []).slice(0, 80),
    pagesChecked: report?.checked ?? 0,
    jobs,
    embedCfg,
    embed,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, shop, origin } = await seoAuth(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  if (intent === "psi") {
    const raw = String(form.get("url") ?? "").trim();
    let url = `${origin}/`;
    try {
      if (raw) {
        const u = new URL(raw, origin);
        if (u.host !== new URL(origin).host) return { ok: false, error: "Only your own store URLs can be tested here." };
        url = u.href;
      }
    } catch {
      return { ok: false, error: "Not a valid URL" };
    }
    const ok = await startPsi(shop, [url]);
    return { ok, error: ok ? "" : "A test is already running" };
  }
  if (intent === "instant") {
    const mode = String(form.get("mode"));
    if (!["off", "prefetch", "prerender"].includes(mode)) return { ok: false, error: "bad mode" };
    const { installationId, config } = await loadEmbedConfig(admin);
    config.instantNav = mode as SeoEmbedConfig["instantNav"];
    await saveEmbedConfig(admin, installationId, config);
    return { ok: true, error: "" };
  }
  return { ok: false, error: "unknown action" };
};

function FieldCell({ m, unit, good, poor }: { m?: FieldMetric; unit: "ms" | ""; good: number; poor: number }) {
  if (!m) return <td className="num">—</td>;
  const cls = m.p75 <= good ? "ok" : m.p75 > poor ? "bad" : "warn";
  return <td className={`num ${cls}`}>{unit === "ms" ? fmtMs(m.p75) : m.p75.toFixed(2)}</td>;
}

export default function SeoSpeed() {
  const d = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const revalidator = useRevalidator();
  const [url, setUrl] = useState("");
  const [sel, setSel] = useState(0);
  const running = d.jobs.psi.status === "running";

  useEffect(() => {
    if (!running && !(fetcher.data?.ok && fetcher.state === "idle")) return;
    const t = setInterval(() => revalidator.state === "idle" && revalidator.revalidate(), 4000);
    const stop = setTimeout(() => clearInterval(t), running ? 20 * 60 * 1000 : 10000);
    return () => {
      clearInterval(t);
      clearTimeout(stop);
    };
  }, [running, fetcher.data, fetcher.state, revalidator]);

  const cur = d.latest[sel] ?? d.latest[0];
  const instant = d.embedCfg?.instantNav ?? "off";

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Speed">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <SeoTabs />

      {running ? (
        <s-banner tone="info" heading="PageSpeed test running…">
          {d.jobs.psi.progress} (each test takes up to a minute)
        </s-banner>
      ) : null}
      {fetcher.data?.error ? <s-banner tone="critical">{fetcher.data.error}</s-banner> : null}
      {d.lastError && !running ? (
        <s-banner tone="warning" heading="Last test error">
          {d.lastError}
        </s-banner>
      ) : null}

      <s-section heading="Test a page">
        <div className="wcs-filters">
          <input
            style={{ flex: 1, minWidth: 260 }}
            placeholder={`${d.origin}/products/…  (empty = home page)`}
            value={url}
            onChange={(e) => setUrl(e.target.value)}
          />
          <s-button
            variant="primary"
            onClick={() => fetcher.submit({ intent: "psi", url }, { method: "POST" })}
            {...(running || fetcher.state !== "idle" ? { disabled: true } : {})}
          >
            Test mobile + desktop
          </s-button>
        </div>
        <s-paragraph>
          <s-text color="subdued">
            Lab score = one simulated load (slow phone on 4G for mobile) and changes a few
            points between runs. Real-user numbers (Chrome UX Report, last 28 days) are what
            Google uses for Core Web Vitals: good is LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1.
          </s-text>
        </s-paragraph>
      </s-section>

      {d.latest.length ? (
        <s-section heading="Latest results">
          <div className="wcs-filters" style={{ marginBottom: 10 }}>
            {d.latest.map((r, i) => (
              <s-button
                key={`${r.url}|${r.strategy}`}
                variant={i === sel ? "primary" : "secondary"}
                onClick={() => setSel(i)}
              >
                {`${pathOf(r.url)} · ${r.strategy}`}
              </s-button>
            ))}
          </div>
          {cur ? (
            <div>
              <div className="wcs-kpis">
                {(
                  [
                    ["Performance", cur.scores.performance],
                    ["SEO (Lighthouse)", cur.scores.seo],
                    ["Accessibility", cur.scores.accessibility],
                    ["Best practices", cur.scores.bestPractices],
                  ] as const
                ).map(([k, v]) => (
                  <div className="wcs-kpi" key={k}>
                    <div className="k">{k}</div>
                    <div className={`v ${scoreTone(v)}`}>{v ?? "—"}</div>
                    <div className="s">{ago(cur.at)} · Lighthouse {cur.lighthouseVersion}</div>
                  </div>
                ))}
              </div>
              <table className="wcs-table" style={{ marginTop: 12 }}>
                <thead>
                  <tr>
                    <th />
                    <th className="num">LCP</th>
                    <th className="num">INP / TBT</th>
                    <th className="num">CLS</th>
                    <th className="num">FCP</th>
                    <th className="num">TTFB</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>Lab (this test)</td>
                    <td className="num">{fmtMs(cur.lab.lcp)}</td>
                    <td className="num">TBT {fmtMs(cur.lab.tbt)}</td>
                    <td className="num">{cur.lab.cls?.toFixed(3) ?? "—"}</td>
                    <td className="num">{fmtMs(cur.lab.fcp)}</td>
                    <td className="num">{fmtMs(cur.lab.ttfb)}</td>
                  </tr>
                  <tr>
                    <td>
                      Real users, 28 days ({cur.field?.scope === "origin" ? "whole site" : cur.field ? "this URL" : "no data"}){" "}
                      {cur.field ? (
                        <s-badge tone={cwvStatus(cur.field) === "pass" ? "success" : cwvStatus(cur.field) === "fail" ? "critical" : "neutral"}>
                          {cwvStatus(cur.field) === "pass" ? "CWV passed" : cwvStatus(cur.field) === "fail" ? "CWV failed" : "unknown"}
                        </s-badge>
                      ) : null}
                    </td>
                    <FieldCell m={cur.field?.lcp} unit="ms" good={2500} poor={4000} />
                    <FieldCell m={cur.field?.inp} unit="ms" good={200} poor={500} />
                    <FieldCell m={cur.field?.cls} unit="" good={0.1} poor={0.25} />
                    <FieldCell m={cur.field?.fcp} unit="ms" good={1800} poor={3000} />
                    <FieldCell m={cur.field?.ttfb} unit="ms" good={800} poor={1800} />
                  </tr>
                </tbody>
              </table>
              <s-paragraph>
                <s-text color="subdued">
                  {`Page weight: ${fmtBytes(cur.totalBytes)}.`}
                  {cur.lcpElement ? ` Largest element (LCP): ${cur.lcpElement}` : ""}
                </s-text>
              </s-paragraph>

              <s-heading>What slows this page down</s-heading>
              {cur.opportunities.length === 0 ? (
                <s-paragraph>Nothing flagged by Lighthouse.</s-paragraph>
              ) : (
                <table className="wcs-table">
                  <thead>
                    <tr>
                      <th>Lighthouse finding</th>
                      <th className="num">Est. saving</th>
                    </tr>
                  </thead>
                  <tbody>
                    {cur.opportunities.map((o) => (
                      <tr key={o.id}>
                        <td>
                          <div>{o.title}</div>
                          {o.displayValue ? <div className="sub">{o.displayValue}</div> : null}
                          {o.items?.length ? (
                            <ul style={{ margin: "4px 0", paddingLeft: 18 }}>
                              {o.items.map((it, i) => (
                                <li key={i} className="sub url">
                                  {it.label ?? ""} {it.url ? pathOrHost(it.url) : ""}
                                  {it.ms ? ` · ${fmtMs(it.ms)}` : ""}
                                  {it.bytes ? ` · ${fmtBytes(it.bytes)}` : ""}
                                </li>
                              ))}
                            </ul>
                          ) : null}
                        </td>
                        <td className="num">
                          {o.savingsMs ? fmtMs(o.savingsMs) : ""}
                          {o.savingsBytes ? ` ${fmtBytes(o.savingsBytes)}` : ""}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}

              {cur.thirdParties?.length ? (
                <>
                  <s-heading>Third-party code (apps, trackers)</s-heading>
                  <table className="wcs-table">
                    <thead>
                      <tr>
                        <th>Provider</th>
                        <th className="num">Main-thread time</th>
                        <th className="num">Blocking</th>
                        <th className="num">Transfer</th>
                      </tr>
                    </thead>
                    <tbody>
                      {cur.thirdParties.map((t) => (
                        <tr key={t.entity}>
                          <td>{t.entity}</td>
                          <td className="num">{fmtMs(t.mainThreadMs)}</td>
                          <td className="num">{fmtMs(t.blockingMs)}</td>
                          <td className="num">{fmtBytes(t.bytes)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </>
              ) : null}
            </div>
          ) : null}
        </s-section>
      ) : null}

      <s-section heading="Instant navigation (preload the next page)">
        <s-paragraph>
          When a shopper hovers or starts tapping a link, the browser starts loading that
          page, so it opens faster. Shopify already does this at the last moment
          (“conservative”); this makes it start earlier. Works in Chrome/Edge/Android;
          Safari and Firefox ignore it. Cart, checkout and account links are excluded.
          Nothing changes visually.
        </s-paragraph>
        <s-paragraph>
          <s-text color="subdued">
            Prerender is the fastest but runs the next page in the background — analytics
            pixels may count a page view early. Start with Prefetch.
          </s-text>
        </s-paragraph>
        <div className="wcs-filters">
          {(["off", "prefetch", "prerender"] as const).map((m) => (
            <s-button
              key={m}
              variant={instant === m ? "primary" : "secondary"}
              onClick={() => fetcher.submit({ intent: "instant", mode: m }, { method: "POST" })}
            >
              {m === "off" ? "Off" : m === "prefetch" ? "Prefetch on hover" : "Prerender on hover"}
            </s-button>
          ))}
          <s-badge tone={d.embed.state === "on" ? "success" : d.embed.state === "off" ? "critical" : "warning"}>
            {`App embed “SEO & Speed”: ${d.embed.state === "on" ? "On" : d.embed.state === "off" ? "Off" : "can’t check"}`}
          </s-badge>
          {d.embed.state !== "on" ? (
            <s-button variant="tertiary" href={d.embed.activateUrl} target="_blank">
              Turn on embed
            </s-button>
          ) : null}
        </div>
      </s-section>

      <s-section heading={`Speed problems found by the audit (${d.pagesChecked} pages)`}>
        {d.speedGroups.length === 0 ? (
          <s-paragraph>Run an audit on the Overview tab.</s-paragraph>
        ) : (
          <table className="wcs-table">
            <tbody>
              {d.speedGroups.map((g) => (
                <tr key={g.id}>
                  <td style={{ width: 90 }}>
                    <SevBadge severity={g.severity} />
                  </td>
                  <td>
                    <div>
                      <b>{g.title}</b> — {g.count} page(s)
                    </div>
                    <div className="sub">{g.fix}</div>
                    {g.sample.map((s, i) => (
                      <div key={i} className="sub url">
                        {s}
                      </div>
                    ))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </s-section>

      <s-section heading="Scripts loaded by your pages">
        {d.scripts.length === 0 ? (
          <s-paragraph>Run an audit to list scripts.</s-paragraph>
        ) : (
          <div className="wcs-scroll">
            <table className="wcs-table">
              <thead>
                <tr>
                  <th>Script</th>
                  <th>Source</th>
                  <th className="num">Pages</th>
                  <th className="num">Size*</th>
                  <th>Loading</th>
                </tr>
              </thead>
              <tbody>
                {d.scripts.map((s) => (
                  <tr key={s.src}>
                    <td className="url">{s.src.replace(/^https?:\/\//, "")}</td>
                    <td>{s.thirdParty ? s.host : "Shopify / theme"}</td>
                    <td className="num">{s.pages}</td>
                    <td className="num">{s.bytes ? fmtBytes(s.bytes) : "—"}</td>
                    <td>{s.blocking ? <span className="bad">blocking</span> : "async/defer"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
        <s-paragraph>
          <s-text color="subdued">
            * Uncompressed size of third-party files. Apps that inject scripts later with
            JavaScript may not be listed — PageSpeed’s “Third-party code” table above shows
            those too.
          </s-text>
        </s-paragraph>
      </s-section>

      {d.history.length ? (
        <s-section heading="Test history">
          <div className="wcs-scroll">
            <table className="wcs-table">
              <thead>
                <tr>
                  <th>When</th>
                  <th>Page</th>
                  <th>Device</th>
                  <th className="num">Score</th>
                  <th className="num">LCP</th>
                  <th className="num">TBT</th>
                  <th className="num">CLS</th>
                </tr>
              </thead>
              <tbody>
                {d.history.map((h, i) => (
                  <tr key={i}>
                    <td>{new Date(h.at).toLocaleString()}</td>
                    <td className="url">{pathOf(h.url)}</td>
                    <td>{h.strategy}</td>
                    <td className="num">{h.performance ?? "—"}</td>
                    <td className="num">{fmtMs(h.lcp)}</td>
                    <td className="num">{fmtMs(h.tbt)}</td>
                    <td className="num">{h.cls?.toFixed(3) ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </s-section>
      ) : null}
    </s-page>
  );
}

function pathOrHost(u: string) {
  try {
    const x = new URL(u);
    return x.host + (x.pathname.length > 50 ? `…${x.pathname.slice(-48)}` : x.pathname);
  } catch {
    return u;
  }
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
