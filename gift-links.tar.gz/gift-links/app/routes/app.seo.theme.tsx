import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useFetcher, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import { AccessError, scanTheme } from "../seo/seo-admin.server";
import type { ThemeScan } from "../seo/seo-admin.shared";
import { getThemeScan, saveThemeScan } from "../seo/seo-store.server";
import { fmtBytes } from "../seo/seo.shared";
import { SeoTabs, ago } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { shop } = await seoAuth(request);
  return { scan: await getThemeScan<ThemeScan>(shop) };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, shop } = await seoAuth(request);
  try {
    const scan = await scanTheme(admin);
    await saveThemeScan(shop, scan);
    return { ok: true, message: "" };
  } catch (e) {
    return {
      ok: false,
      message:
        e instanceof AccessError
          ? "The app needs “read themes” permission — approve the update in Shopify admin → Apps → WoodenCrew Apps."
          : (e as Error).message,
    };
  }
};

export default function SeoTheme() {
  const { scan } = useLoaderData<typeof loader>();
  const f = useFetcher<typeof action>();
  const busy = f.state !== "idle";

  const byApp = new Map<string, string[]>();
  for (const l of scan?.leftovers ?? []) byApp.set(l.match, [...(byApp.get(l.match) ?? []), l.file]);

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Theme code">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button slot="primary-action" variant="primary" onClick={() => f.submit({}, { method: "POST" })} {...(busy ? { disabled: true } : {})}>
        {busy ? "Scanning…" : scan ? "Scan again" : "Scan live theme"}
      </s-button>
      <SeoTabs />
      {f.data && !f.data.ok ? <s-banner tone="critical">{f.data.message}</s-banner> : null}
      <s-section>
        <s-paragraph>
          Read-only scan of the published theme: leftover code from apps, scripts that block
          the first paint, heavy files and snippets nobody uses. The app never edits theme
          code — use this as a to-do list (or ask Claude to prepare the change on a theme copy).
        </s-paragraph>
      </s-section>

      {!scan ? null : (
        <>
          <s-section>
            <div className="wcs-kpis">
              <div className="wcs-kpi">
                <div className="k">Theme</div>
                <div className="v" style={{ fontSize: 18 }}>{scan.themeName}</div>
                <div className="s">{`scanned ${ago(scan.scannedAt)}`}</div>
              </div>
              <div className="wcs-kpi">
                <div className="k">Files</div>
                <div className="v">{scan.files}</div>
                <div className="s">{fmtBytes(scan.totalBytes)} total</div>
              </div>
              <div className="wcs-kpi">
                <div className="k">Blocking scripts in layout</div>
                <div className={`v ${scan.blockingScripts.length ? "warning" : "success"}`}>{scan.blockingScripts.length}</div>
              </div>
              <div className="wcs-kpi">
                <div className="k">Unused snippets</div>
                <div className="v">{scan.unusedSnippets.length}</div>
              </div>
            </div>
          </s-section>

          <s-section heading="App code found in the theme">
            {byApp.size === 0 ? (
              <s-paragraph>No known app fingerprints.</s-paragraph>
            ) : (
              <table className="wcs-table">
                <thead>
                  <tr>
                    <th>App</th>
                    <th>Files</th>
                  </tr>
                </thead>
                <tbody>
                  {[...byApp.entries()].map(([app, files]) => (
                    <tr key={app}>
                      <td>{app}</td>
                      <td className="sub url">{files.join(", ")}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            <s-paragraph>
              <s-text color="subdued">
                Apps you still use (Judge.me, Vitals, Omnisend…) are expected here. For apps you
                removed (e.g. Tapita, AXE), this code can usually be deleted — on a theme copy
                first. Uninstalling an app does not remove code it added to the theme.
              </s-text>
            </s-paragraph>
          </s-section>

          <s-section heading="App embeds in the live theme">
            <table className="wcs-table">
              <tbody>
                {scan.appEmbeds.map((e) => (
                  <tr key={e.type}>
                    <td className="url">{e.type}</td>
                    <td>{e.disabled ? <s-badge tone="neutral">off</s-badge> : <s-badge tone="success">on</s-badge>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <s-paragraph>
              <s-text color="subdued">
                Each enabled embed can add scripts to every page. Embeds of uninstalled apps stay
                in settings but load nothing.
              </s-text>
            </s-paragraph>
          </s-section>

          <s-section heading="Scripts in theme code">
            {scan.blockingScripts.length ? (
              <>
                <s-heading>Render-blocking (no async/defer) in layout files</s-heading>
                <ul>
                  {scan.blockingScripts.map((s, i) => (
                    <li key={i} className="url">
                      {s.file}: {s.src}
                    </li>
                  ))}
                </ul>
              </>
            ) : null}
            <s-heading>External scripts</s-heading>
            {scan.externalScripts.length === 0 ? (
              <s-paragraph>None hard-coded.</s-paragraph>
            ) : (
              <ul>
                {scan.externalScripts.map((s, i) => (
                  <li key={i} className="url">
                    {s.file}: {s.src}
                  </li>
                ))}
              </ul>
            )}
          </s-section>

          <s-section heading="Largest asset files">
            <table className="wcs-table">
              <tbody>
                {scan.largestAssets.map((a) => (
                  <tr key={a.filename}>
                    <td className="url">{a.filename}</td>
                    <td className="num">{fmtBytes(a.size)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            <s-paragraph>
              <s-text color="subdued">
                Size on disk before gzip. Big JS/CSS that loads on every page matters most; big
                images here only matter if the theme uses them without resizing.
              </s-text>
            </s-paragraph>
          </s-section>

          <s-section heading={`Snippets not used by any template (${scan.unusedSnippets.length})`}>
            <s-paragraph>
              <s-text color="subdued">
                {scan.unusedSnippets.join(", ") || "None"}
              </s-text>
            </s-paragraph>
            <s-paragraph>
              <s-text color="subdued">
                Found by searching for render/include calls. A snippet used only by an app or
                with a dynamic name may show up here by mistake — check before deleting.
              </s-text>
            </s-paragraph>
          </s-section>
        </>
      )}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
