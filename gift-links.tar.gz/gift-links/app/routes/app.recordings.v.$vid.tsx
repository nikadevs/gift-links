import type { ActionFunctionArgs, HeadersFunction, LinksFunction, LoaderFunctionArgs } from "react-router";
import { useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ReactNode } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import playerCss from "rrweb-player/dist/style.css?url";
import { authenticate } from "../shopify.server";
import { deleteVisitor, filterQuery, getVisitor, parseFilter, visitorOrder } from "../rec.server";
import { recOrders, startRecOrderSync } from "../rec-orders.server";
import { cleanSource, countryName, fmtBytes, fmtDuration, tzCity } from "../rec.shared";

/**
 * Session Recordings — one visitor.
 * Layout: left sidebar (40 %) with the visitor info, visitor navigation, the
 * list of every page of every visit and the page controls; right (60 %) the
 * player at full window height. Each page is its own rrweb recording.
 * "Auto next" plays the next page, and after the last page the next (older)
 * visitor of the list. Speed and Auto next are remembered in this browser.
 */
export const links: LinksFunction = () => [{ rel: "stylesheet", href: playerCss }];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  startRecOrderSync();
  const { session } = await authenticate.admin(request);
  const visits = await getVisitor(session.shop, String(params.vid ?? ""));
  if (!visits.length) throw new Response("Visitor not found", { status: 404 });
  const vid = String(params.vid);
  // previous / next visitor in the same order and filters as the list
  const f = parseFilter(new URL(request.url).searchParams);
  const allOrders = await recOrders(session.shop);
  const order = await visitorOrder(session.shop, f, new Set(Object.keys(allOrders)));
  const i = order.indexOf(vid);
  const orders = (allOrders[vid] ?? []).map(({ id, name, total, cur }) => ({ id, name, total, cur }));
  return {
    vid,
    visits,
    orders,
    fq: filterQuery(f),
    pos: i,
    count: order.length,
    newer: i > 0 ? order[i - 1] : "",
    older: i >= 0 && i < order.length - 1 ? order[i + 1] : "",
  };
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { session, redirect } = await authenticate.admin(request);
  const form = await request.formData();
  if (String(form.get("intent")) === "delete") {
    await deleteVisitor(session.shop, String(params.vid ?? ""));
    return redirect("/app/recordings");
  }
  return { ok: false };
};

type Visit = Awaited<ReturnType<typeof loader>>["visits"][number];
type Item = {
  key: string;
  sid: string;
  p: number;
  url: string;
  title: string;
  t: number;
  visit: number;
  w: number;
  h: number;
};
type Ev = { type: number; timestamp: number; data?: { width?: number; height?: number } };
type Replayer = {
  on: (event: string, handler: (p: unknown) => void) => void;
  getCurrentTime: () => number;
  getMetaData: () => { totalTime: number };
  service?: { state?: { value?: string } };
};
type PlayerApi = {
  $destroy?: () => void;
  $set?: (props: Record<string, unknown>) => void;
  triggerResize?: () => void;
  getReplayer: () => Replayer;
  setSpeed?: (s: number) => void;
};

const TAGS = { "Add to cart": "#2e7d32", "Checkout click": "#1565c0" };
const CONTROLLER_H = 84; // rrweb-player's timeline + buttons
const SPEEDS = [1, 2, 4, 8];

function pathOf(u: string) {
  return u.split("?")[0] || "/";
}

function lsGet(k: string) {
  try {
    return window.localStorage.getItem(k);
  } catch {
    return null;
  }
}
function lsSet(k: string, v: string) {
  try {
    window.localStorage.setItem(k, v);
  } catch {
    /* private mode */
  }
}

/** frame that keeps the recorded viewport's aspect ratio inside the box */
function fit(bw: number, bh: number, rw: number, rh: number) {
  if (!rw || !rh) {
    rw = 1280;
    rh = 800;
  }
  const s = Math.min(bw / rw, bh / rh);
  return { w: Math.max(200, Math.floor(rw * s)), h: Math.max(160, Math.floor(rh * s)) };
}

export default function VisitorRecordingsRoute() {
  const { vid } = useLoaderData<typeof loader>();
  // new visitor → fresh state (selected page, player)
  return <VisitorRecordings key={vid} />;
}

function Row({ icon, children, title }: { icon: string; children: ReactNode; title?: string }) {
  return (
    <div className="wv-row" title={title}>
      <s-icon type={icon as "globe"} size="small" tone="neutral" />
      <span>{children}</span>
    </div>
  );
}

function VisitorRecordings() {
  const { visits, orders, fq, pos, count, newer, older } = useLoaderData<typeof loader>();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const del = useFetcher();
  const [confirmDel, setConfirmDel] = useState(false);

  const items: Item[] = useMemo(() => {
    const out: Item[] = [];
    visits.forEach((v: Visit, i: number) => {
      for (const p of v.pages) {
        out.push({ key: `${v.id}:${p.p}`, sid: v.id, p: p.p, url: p.url, title: p.title, t: p.t, visit: i, w: v.w, h: v.h });
      }
    });
    return out.sort((a, b) => a.t - b.t);
  }, [visits]);

  const [idx, setIdx] = useState(() => {
    const s = params.get("s");
    const i = s ? items.findIndex((x) => x.sid === s) : -1;
    return i >= 0 ? i : 0;
  });
  const [auto, setAuto] = useState(() => (typeof window === "undefined" ? true : lsGet("wcrec.auto") !== "0"));
  const [state, setState] = useState<"loading" | "ready" | "empty" | "error">("loading");
  const [msg, setMsg] = useState("");
  const stage = useRef<HTMLDivElement>(null);
  const box = useRef<HTMLDivElement>(null);
  const player = useRef<PlayerApi | null>(null);
  const recSize = useRef({ w: 0, h: 0 });
  const cache = useRef(new Map<string, Ev[]>());
  const autoRef = useRef(auto);
  const listRef = useRef<HTMLDivElement>(null);
  const [stageH, setStageH] = useState(0);
  const measured = stageH > 0;

  // remembered settings (this browser)
  useEffect(() => {
    autoRef.current = auto;
  }, [auto]);

  const fqs = fq ? `?${fq}` : "";
  const goVisitor = useCallback(
    (v: string, play = false) => {
      if (v) navigate(`/app/recordings/v/${v}${fqs}${play ? `${fqs ? "&" : "?"}autoplay=1` : ""}`);
    },
    [fqs, navigate],
  );

  const go = useCallback(
    (i: number) => {
      if (i >= 0 && i < items.length) setIdx(i);
    },
    [items.length],
  );

  // after the last page → next (older) visitor
  const advance = useCallback(() => {
    if (!autoRef.current) return;
    setIdx((i) => {
      if (i < items.length - 1) return i + 1;
      if (older) goVisitor(older, true);
      return i;
    });
  }, [items.length, older, goVisitor]);

  // keyboard ← →
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName ?? "";
      if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
      if (e.key === "ArrowRight") go(idx + 1);
      if (e.key === "ArrowLeft") go(idx - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, idx]);

  useEffect(() => {
    listRef.current?.querySelector(`[data-i="${idx}"]`)?.scrollIntoView({ block: "nearest" });
  }, [idx]);

  // the stage fills the window from its top edge down
  useEffect(() => {
    const measure = () => {
      if (!stage.current) return;
      const top = stage.current.getBoundingClientRect().top + window.scrollY;
      setStageH(Math.max(420, window.innerHeight - top - 16));
    };
    measure();
    window.addEventListener("resize", measure);
    const t = setTimeout(measure, 300);
    return () => {
      window.removeEventListener("resize", measure);
      clearTimeout(t);
    };
  }, []);

  // resize the running player with the stage
  useEffect(() => {
    const p = player.current;
    if (!p || !box.current || !stageH) return;
    const s = fit(box.current.clientWidth, stageH - CONTROLLER_H, recSize.current.w, recSize.current.h);
    p.$set?.({ width: s.w, height: s.h });
    p.triggerResize?.();
  }, [stageH]);

  // remember the speed the user clicks in the player controller
  useEffect(() => {
    const el = box.current;
    if (!el) return;
    const onClick = (e: MouseEvent) => {
      const b = (e.target as HTMLElement | null)?.closest("button");
      const m = b?.textContent?.trim().match(/^(\d+)x$/);
      if (m) lsSet("wcrec.speed", m[1]);
    };
    el.addEventListener("click", onClick, true);
    return () => el.removeEventListener("click", onClick, true);
  }, []);

  // load + play the selected page
  useEffect(() => {
    const it = items[idx];
    if (!it || !measured) return;
    let dead = false;
    let poll: ReturnType<typeof setInterval> | undefined;
    (async () => {
      try {
        await Promise.resolve();
        if (!dead) setState("loading");
        let events = cache.current.get(it.key);
        if (!events) {
          const res = await fetch(`/app/rec-events/${it.sid}?p=${it.p}`);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          events = ((await res.json()) as Ev[]).sort((a, b) => a.timestamp - b.timestamp);
          cache.current.set(it.key, events);
        }
        if (dead) return;
        player.current?.$destroy?.();
        player.current = null;
        if (!box.current) return;
        box.current.innerHTML = "";
        if (!events.some((e) => e.type === 2) || events.length < 2) {
          setState("empty");
          // nothing to watch here — move on after a moment
          if (autoRef.current) setTimeout(() => !dead && advance(), 1200);
          return;
        }
        const meta = events.find((e) => e.type === 4);
        recSize.current = { w: meta?.data?.width || it.w, h: meta?.data?.height || it.h };
        const s = fit(box.current.clientWidth, stageH - CONTROLLER_H, recSize.current.w, recSize.current.h);
        const saved = Number(lsGet("wcrec.speed"));
        const speed = SPEEDS.includes(saved) ? saved : 1;
        const { default: Player } = await import("rrweb-player");
        if (dead || !box.current) return;
        const p = new Player({
          target: box.current,
          props: {
            events: events as never,
            width: s.w,
            height: s.h,
            autoPlay: true,
            speed,
            skipInactive: true,
            speedOption: SPEEDS,
            tags: TAGS,
            mouseTail: { strokeStyle: "#E8660E", lineWidth: 2, duration: 600 },
          },
        }) as unknown as PlayerApi;
        player.current = p;
        // the "speed" prop is ignored at start in rrweb-player 2.1 — set it explicitly
        if (speed !== 1) p.setSpeed?.(speed);
        setState("ready");
        // end of the page → next page / next visitor
        let done = false;
        const finish = () => {
          if (done || dead) return;
          done = true;
          setTimeout(() => !dead && advance(), 700);
        };
        try {
          p.getReplayer().on("finish", finish);
        } catch {
          /* older player */
        }
        // fallback: the replayer stopped at the very end
        poll = setInterval(() => {
          try {
            const r = p.getReplayer();
            const total = r.getMetaData().totalTime;
            if (total > 0 && r.getCurrentTime() >= total - 300 && r.service?.state?.value === "paused") finish();
          } catch {
            /* ignore */
          }
        }, 1000);
      } catch (e) {
        if (!dead) {
          setMsg(e instanceof Error ? e.message : String(e));
          setState("error");
        }
      }
    })();
    return () => {
      dead = true;
      if (poll) clearInterval(poll);
    };
    // stageH changes are applied by the resize effect; only the first measure starts playback
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [idx, items, measured]);

  useEffect(
    () => () => {
      player.current?.$destroy?.();
      player.current = null;
    },
    [],
  );

  const cur = items[idx];
  const last = visits[visits.length - 1];
  const atc = visits.some((v: Visit) => v.atc);
  const co = visits.some((v: Visit) => v.checkout);
  const total = visits.reduce((n: number, v: Visit) => n + Math.max(0, v.end - v.start), 0);
  const source = cleanSource(visits.find((v: Visit) => v.utm)?.utm || "") || "direct";
  const country = [...visits].reverse().find((v: Visit) => v.country)?.country ?? "";
  const city = tzCity(last.tz);
  const first = visits[0].start;
  const sameDay = new Date(first).toDateString() === new Date(last.end).toDateString();
  const dt = (t: number) => new Date(t).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", hour12: false });
  const tm = (t: number) => new Date(t).toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit", hour12: false });

  return (
    <s-page inlineSize="large" heading={`Visitor · ${items.length} page${items.length === 1 ? "" : "s"}`}>
      <s-link slot="breadcrumb-actions" href={`/app/recordings${fqs}`}>
        Session Recordings
      </s-link>
      <style>{`
        .wv{display:grid;grid-template-columns:minmax(0,40fr) minmax(0,60fr);gap:14px;align-items:stretch}
        @media (max-width:900px){.wv{grid-template-columns:1fr}}
        .wv-side{display:flex;flex-direction:column;gap:10px;min-height:0;background:#fff;border:1px solid #e3e3e3;border-radius:12px;padding:12px;font-size:13px;color:#303030}
        .wv-info{display:grid;grid-template-columns:1fr 1fr;gap:6px 12px}
        .wv-row{display:flex;align-items:center;gap:6px;min-width:0}
        .wv-row>span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .wv-row.full{grid-column:1/-1}
        .wv-bar{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
        .wv-bar .grow{flex:1}
        .wv-tags{display:flex;gap:4px;flex-wrap:wrap}
        .wv-tag{display:inline-flex;align-items:center;gap:3px;border-radius:10px;padding:1px 8px;font-size:12px;line-height:18px}
        .wv-tag.atc{background:#e4f5ea;color:#0c5132}
        .wv-tag.co{background:#e0f0ff;color:#00527c}
        .wv-tag.ord{background:#0c5132;color:#fff}
        .wv-tag.ord a{color:#fff;text-decoration:none}
        .wv-list{flex:1;min-height:120px;overflow:auto;border:1px solid #e3e3e3;border-radius:8px}
        .wv-visit{position:sticky;top:0;background:#f6f6f7;padding:5px 10px;font-weight:600;border-bottom:1px solid #e3e3e3}
        .wv-item{display:block;width:100%;text-align:left;background:#fff;border:0;border-bottom:1px solid #f1f1f1;padding:6px 10px;cursor:pointer;font:inherit;color:#303030}
        .wv-item:hover{background:#f6f6f7}
        .wv-item[aria-current="true"]{background:#eaf4ff;box-shadow:inset 3px 0 #005bd3}
        .wv-item small{display:block;color:#616161;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .wv-cur{font-size:13px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .wv-stage{display:flex;flex-direction:column;align-items:center;justify-content:flex-start;background:#f6f6f7;border-radius:12px;overflow:hidden;position:relative}
        .wv-box{width:100%;display:flow-root}
        .wv-box .rr-player{float:none!important;margin:0 auto;box-shadow:none!important;background:transparent!important}
        .wv-box .rr-player__frame{background:#fff}
        .wv-msg{position:absolute;top:16px;left:16px;right:16px}
      `}</style>
      <div className="wv">
        <aside className="wv-side" style={stageH ? { height: stageH } : undefined}>
          <div className="wv-bar">
            <s-button disabled={!newer || undefined} onClick={() => goVisitor(newer)}>
              ← Newer
            </s-button>
            <s-text color="subdued">{pos >= 0 ? `${pos + 1} of ${count}` : ""}</s-text>
            <s-button disabled={!older || undefined} onClick={() => goVisitor(older)}>
              Older →
            </s-button>
            <span className="grow" />
            <s-button
              variant="tertiary"
              tone="critical"
              loading={del.state !== "idle" || undefined}
              onClick={() => {
                if (confirmDel) del.submit({ intent: "delete" }, { method: "post" });
                else setConfirmDel(true);
              }}
            >
              {confirmDel ? "Delete this visitor?" : "Delete"}
            </s-button>
          </div>
          <div className="wv-info">
            <Row icon="calendar">{sameDay ? `${dt(first)} – ${tm(last.end)}` : `${dt(first)} – ${dt(last.end)}`}</Row>
            <Row icon="clock">{fmtDuration(total)}</Row>
            <Row icon={last.device === "desktop" ? "desktop" : last.device === "tablet" ? "tablet" : "mobile"} title={`${last.w}×${last.h}`}>
              {last.device} · {last.os} · {last.browser}
            </Row>
            <Row icon="globe" title={last.tz ? `Time zone: ${last.tz}` : undefined}>
              {[countryName(country), city].filter(Boolean).join(" · ") || "—"}
            </Row>
            <Row icon="link" title={source}>
              {source}
            </Row>
            <Row icon="database">
              {fmtBytes(visits.reduce((n: number, v: Visit) => n + v.bytes, 0))}
              {last.lang ? ` · ${last.lang}` : ""}
            </Row>
            {atc || co || orders.length ? (
              <div className="wv-row full wv-tags">
                {atc ? <span className="wv-tag atc">🛒 Add to cart</span> : null}
                {co ? <span className="wv-tag co">💳 Checkout</span> : null}
                {orders.map((o) => (
                  <span key={o.id} className="wv-tag ord" title={`${o.total} ${o.cur}`}>
                    <a href={`shopify://admin/orders/${o.id}`} target="_top">
                      ✓ Order {o.name}
                    </a>
                  </span>
                ))}
              </div>
            ) : null}
          </div>
          <div className="wv-bar">
            <s-button disabled={idx <= 0 || undefined} onClick={() => go(idx - 1)}>
              ← Page
            </s-button>
            <s-button disabled={idx >= items.length - 1 || undefined} onClick={() => go(idx + 1)}>
              Page →
            </s-button>
            <span className="grow" />
            <s-checkbox
              label="Auto next"
              checked={auto || undefined}
              onChange={(e) => {
                const v = e.currentTarget.checked;
                setAuto(v);
                lsSet("wcrec.auto", v ? "1" : "0");
              }}
            />
          </div>
          <div className="wv-cur" title={cur?.url}>
            <b>
              Page {idx + 1} of {items.length}
            </b>{" "}
            · {cur ? pathOf(cur.url) : ""}
          </div>
          <div className="wv-list" ref={listRef}>
            {visits.map((v: Visit, vi: number) => (
              <div key={v.id}>
                <div className="wv-visit">
                  Visit {vi + 1} · {dt(v.start)} · {fmtDuration(v.end - v.start)}
                  {v.atc ? " · 🛒" : ""}
                </div>
                {items.map((it, i) =>
                  it.visit === vi ? (
                    <button
                      key={it.key}
                      type="button"
                      data-i={i}
                      className="wv-item"
                      aria-current={i === idx ? "true" : "false"}
                      onClick={() => go(i)}
                    >
                      {i + 1}. {tm(it.t)} — {pathOf(it.url)}
                      {it.title ? <small>{it.title}</small> : null}
                    </button>
                  ) : null,
                )}
              </div>
            ))}
          </div>
        </aside>
        <div className="wv-stage" ref={stage} style={stageH ? { height: stageH } : { minHeight: 420 }}>
          {state === "loading" ? (
            <div className="wv-msg">
              <s-spinner accessibilityLabel="Loading page recording" />
            </div>
          ) : null}
          {state === "empty" ? (
            <div className="wv-msg">
              <s-banner tone="warning">
                Nothing to replay on this page — the visitor left before the recorder started.
              </s-banner>
            </div>
          ) : null}
          {state === "error" ? (
            <div className="wv-msg">
              <s-banner tone="critical">Couldn’t load this page: {msg}</s-banner>
            </div>
          ) : null}
          <div className="wv-box" ref={box} />
        </div>
      </div>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
