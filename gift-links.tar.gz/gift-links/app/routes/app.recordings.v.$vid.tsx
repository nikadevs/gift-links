import type { ActionFunctionArgs, HeadersFunction, LinksFunction, LoaderFunctionArgs } from "react-router";
import { useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import playerCss from "rrweb-player/dist/style.css?url";
import { authenticate } from "../shopify.server";
import { deleteVisitor, getVisitor } from "../rec.server";
import { fmtBytes, fmtDuration } from "../rec.shared";

/**
 * Session Recordings — one visitor: every page of every visit in one list.
 * The player shows one page at a time (each page is its own rrweb recording
 * with its own full snapshot); ← / → buttons, the arrow keys or a click in the
 * list move between pages; "Auto next" continues with the next page.
 */
export const links: LinksFunction = () => [{ rel: "stylesheet", href: playerCss }];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const visits = await getVisitor(session.shop, String(params.vid ?? ""));
  if (!visits.length) throw new Response("Visitor not found", { status: 404 });
  return { vid: String(params.vid), visits };
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { session, redirect } = await authenticate.admin(request);
  const form = await request.formData();
  if (String(form.get("intent")) === "delete") {
    await deleteVisitor(session.shop, String(params.vid ?? ""));
    return redirect("/app/recordings");
  }
  return { ok: false };
};

type Visit = Awaited<ReturnType<typeof loader>>["visits"][number];
type Item = {
  key: string;
  sid: string;
  p: number;
  url: string;
  title: string;
  t: number;
  visit: number;
  w: number;
  h: number;
};
type Ev = { type: number; timestamp: number; data?: { width?: number; height?: number } };
type PlayerApi = {
  $destroy?: () => void;
  addEventListener: (event: string, handler: (p: unknown) => unknown) => void;
  play: () => void;
};

const TAGS = { "Add to cart": "#2e7d32", "Checkout click": "#1565c0" };
const MAX_H = 720;

function pathOf(u: string) {
  const s = u.split("?")[0] || "/";
  return s;
}

/** frame size that keeps the recorded viewport's aspect ratio and fits the column */
function frameSize(cw: number, rw: number, rh: number) {
  if (!rw || !rh) {
    rw = 1280;
    rh = 800;
  }
  let h = Math.round((cw * rh) / rw);
  let w = cw;
  if (h > MAX_H) {
    h = MAX_H;
    w = Math.round((h * rw) / rh);
  }
  return { w: Math.max(240, w), h: Math.max(200, h) };
}

export default function VisitorRecordings() {
  const { vid, visits } = useLoaderData<typeof loader>();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const del = useFetcher();
  const [confirmDel, setConfirmDel] = useState(false);

  const items: Item[] = useMemo(() => {
    const out: Item[] = [];
    visits.forEach((v: Visit, i: number) => {
      for (const p of v.pages) {
        out.push({ key: `${v.id}:${p.p}`, sid: v.id, p: p.p, url: p.url, title: p.title, t: p.t, visit: i, w: v.w, h: v.h });
      }
    });
    return out.sort((a, b) => a.t - b.t);
  }, [visits]);

  const startAt = useMemo(() => {
    const s = params.get("s");
    const i = s ? items.findIndex((x) => x.sid === s) : -1;
    return i >= 0 ? i : 0;
  }, [items, params]);

  const [idx, setIdx] = useState(startAt);
  const [auto, setAuto] = useState(true);
  const [state, setState] = useState<"loading" | "ready" | "empty" | "error">("loading");
  const [msg, setMsg] = useState("");
  const box = useRef<HTMLDivElement>(null);
  const player = useRef<PlayerApi | null>(null);
  const cache = useRef(new Map<string, Ev[]>());
  const autoRef = useRef(auto);
  useEffect(() => {
    autoRef.current = auto;
  }, [auto]);
  const listRef = useRef<HTMLDivElement>(null);

  const go = useCallback(
    (i: number) => {
      if (i >= 0 && i < items.length) setIdx(i);
    },
    [items.length],
  );

  // keyboard ← →
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName ?? "";
      if (/INPUT|TEXTAREA|SELECT/.test(tag)) return;
      if (e.key === "ArrowRight") go(idx + 1);
      if (e.key === "ArrowLeft") go(idx - 1);
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [go, idx]);

  // keep the active page visible in the list
  useEffect(() => {
    listRef.current?.querySelector(`[data-i="${idx}"]`)?.scrollIntoView({ block: "nearest" });
  }, [idx]);

  // load + play the selected page
  useEffect(() => {
    const it = items[idx];
    if (!it) return;
    let dead = false;
    (async () => {
      try {
        await Promise.resolve();
        if (!dead) setState("loading");
        let events = cache.current.get(it.key);
        if (!events) {
          const res = await fetch(`/app/rec-events/${it.sid}?p=${it.p}`);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          events = ((await res.json()) as Ev[]).sort((a, b) => a.timestamp - b.timestamp);
          cache.current.set(it.key, events);
        }
        if (dead) return;
        player.current?.$destroy?.();
        player.current = null;
        if (!box.current) return;
        box.current.innerHTML = "";
        if (!events.some((e) => e.type === 2) || events.length < 2) {
          setState("empty");
          return;
        }
        const meta = events.find((e) => e.type === 4);
        const size = frameSize(box.current.clientWidth, meta?.data?.width || it.w, meta?.data?.height || it.h);
        const { default: Player } = await import("rrweb-player");
        if (dead || !box.current) return;
        const p = new Player({
          target: box.current,
          props: {
            events: events as never,
            width: size.w,
            height: size.h,
            autoPlay: true,
            skipInactive: true,
            speedOption: [1, 2, 4, 8],
            tags: TAGS,
            mouseTail: { strokeStyle: "#E8660E", lineWidth: 2, duration: 600 },
          },
        }) as unknown as PlayerApi;
        p.addEventListener("finish", () => {
          if (autoRef.current && !dead) setTimeout(() => !dead && setIdx((i) => Math.min(i + 1, items.length - 1)), 800);
        });
        player.current = p;
        setState("ready");
      } catch (e) {
        if (!dead) {
          setMsg(e instanceof Error ? e.message : String(e));
          setState("error");
        }
      }
    })();
    return () => {
      dead = true;
    };
  }, [idx, items]);

  useEffect(
    () => () => {
      player.current?.$destroy?.();
      player.current = null;
    },
    [],
  );

  const cur = items[idx];
  const last = visits[visits.length - 1];
  const atc = visits.some((v: Visit) => v.atc);
  const co = visits.some((v: Visit) => v.checkout);
  const total = visits.reduce((n: number, v: Visit) => n + Math.max(0, v.end - v.start), 0);
  const source = visits.find((v: Visit) => v.utm)?.utm || "direct";

  return (
    <s-page inlineSize="large" heading={`Visitor · ${visits.length} visit${visits.length === 1 ? "" : "s"} · ${items.length} page${items.length === 1 ? "" : "s"}`}>
      <s-button slot="secondary-actions" onClick={() => navigate("/app/recordings")}>
        ← All visitors
      </s-button>
      <style>{`
        .wcrec-player{display:flow-root;min-height:200px}
        .wcrec-player .rr-player{float:none!important;margin:0 auto;box-shadow:none!important;border:1px solid #e3e3e3;border-radius:8px}
        .wcrec-player .rr-player__frame{background:#f6f6f7}
        .wcrec-layout{display:grid;grid-template-columns:300px minmax(0,1fr);gap:16px;align-items:start}
        @media (max-width:900px){.wcrec-layout{grid-template-columns:1fr}}
        .wcrec-list{max-height:760px;overflow:auto;border:1px solid #e3e3e3;border-radius:8px;font-size:13px}
        .wcrec-visit{position:sticky;top:0;background:#f6f6f7;padding:6px 10px;font-weight:600;border-bottom:1px solid #e3e3e3}
        .wcrec-item{display:block;width:100%;text-align:left;background:#fff;border:0;border-bottom:1px solid #f1f1f1;padding:7px 10px;cursor:pointer;font:inherit;color:#303030}
        .wcrec-item:hover{background:#f6f6f7}
        .wcrec-item[aria-current="true"]{background:#eaf4ff;box-shadow:inset 3px 0 #005bd3}
        .wcrec-item small{display:block;color:#616161;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .wcrec-nav{display:flex;align-items:center;gap:8px;margin-bottom:10px;flex-wrap:wrap}
        .wcrec-cur{flex:1;min-width:200px;font-size:13px;color:#303030;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
      `}</style>
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          <s-text>
            First seen {new Date(visits[0].start).toLocaleString()} · last {new Date(last.end).toLocaleString()} ·{" "}
            {fmtDuration(total)} on site · {last.device} · {last.os} · {last.browser} · {last.w}×{last.h}
          </s-text>
          {atc ? <s-badge tone="success">Add to cart</s-badge> : null}
          {co ? <s-badge tone="info">Checkout</s-badge> : null}
          <s-text color="subdued">
            {source} · {last.lang} {last.tz} · {fmtBytes(visits.reduce((n: number, v: Visit) => n + v.bytes, 0))}
          </s-text>
          <s-button
            variant="tertiary"
            tone="critical"
            loading={del.state !== "idle" || undefined}
            onClick={() => {
              if (confirmDel) del.submit({ intent: "delete" }, { method: "post" });
              else setConfirmDel(true);
            }}
          >
            {confirmDel ? "Delete all recordings of this visitor?" : "Delete"}
          </s-button>
        </s-stack>
      </s-section>
      <s-section>
        <div className="wcrec-layout">
          <div className="wcrec-list" ref={listRef}>
            {visits.map((v: Visit, vi: number) => (
              <div key={v.id}>
                <div className="wcrec-visit">
                  Visit {vi + 1} · {new Date(v.start).toLocaleString(undefined, { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })} ·{" "}
                  {fmtDuration(v.end - v.start)}
                  {v.atc ? " · 🛒" : ""}
                </div>
                {items.map((it, i) =>
                  it.visit === vi ? (
                    <button
                      key={it.key}
                      type="button"
                      data-i={i}
                      className="wcrec-item"
                      aria-current={i === idx ? "true" : "false"}
                      onClick={() => go(i)}
                    >
                      {i + 1}. {new Date(it.t).toLocaleTimeString()} — {pathOf(it.url)}
                      {it.title ? <small>{it.title}</small> : null}
                    </button>
                  ) : null,
                )}
              </div>
            ))}
          </div>
          <div>
            <div className="wcrec-nav">
              <s-button disabled={idx <= 0 || undefined} onClick={() => go(idx - 1)}>
                ← Previous page
              </s-button>
              <s-button disabled={idx >= items.length - 1 || undefined} onClick={() => go(idx + 1)}>
                Next page →
              </s-button>
              <div className="wcrec-cur" title={cur?.url}>
                <b>
                  Page {idx + 1} of {items.length}
                </b>{" "}
                · visit {cur ? cur.visit + 1 : 0} · {cur ? pathOf(cur.url) : ""}
              </div>
              <s-checkbox label="Auto next" checked={auto || undefined} onChange={(e) => setAuto(e.currentTarget.checked)} />
            </div>
            {state === "loading" ? <s-spinner accessibilityLabel="Loading page recording" /> : null}
            {state === "empty" ? (
              <s-banner tone="warning">
                Nothing to replay for this page — the visitor left before the recorder started (it waits until
                the page is loaded and idle).
              </s-banner>
            ) : null}
            {state === "error" ? <s-banner tone="critical">Couldn’t load this page: {msg}</s-banner> : null}
            <div className="wcrec-player" ref={box} data-vid={vid} />
          </div>
        </div>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
