import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useRevalidator, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import {
  SATC_EMBED_MARKERS,
  checkEmbed,
  embedActivateUrl,
} from "../embed-status.server";

/**
 * Sticky Add to Cart (replacement for the Vitals module).
 * Everything happens in the theme app embed "Sticky Add to Cart"
 * (blocks/sticky-add-to-cart.liquid). This page shows whether the embed is on
 * and links to its settings.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const domain = await loadShopDomain(admin);
  const state = await checkEmbed(domain, SATC_EMBED_MARKERS, url.searchParams.has("refresh"));
  return {
    state,
    // eslint-disable-next-line no-undef
    editorUrl: embedActivateUrl(session.shop, process.env.SHOPIFY_API_KEY || "", "sticky-add-to-cart"),
  };
};

export default function StickyAtc() {
  const { state, editorUrl } = useLoaderData<typeof loader>();
  const rv = useRevalidator();
  const badge =
    state === "on" ? (
      <s-badge tone="success">App embed: On</s-badge>
    ) : state === "off" ? (
      <s-badge tone="critical">App embed: Off</s-badge>
    ) : (
      <s-badge tone="warning">App embed: can’t check</s-badge>
    );
  return (
    <s-page inlineSize="large" heading="Sticky Add to Cart">
      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center">
          {badge}
          <s-button href={editorUrl} target="_blank">
            {state === "on" ? "Settings in theme editor" : "Turn on in theme editor"}
          </s-button>
          <s-button
            variant="tertiary"
            loading={rv.state === "loading" || undefined}
            onClick={() => {
              window.history.replaceState(null, "", "?refresh=1");
              rv.revalidate();
            }}
          >
            Refresh
          </s-button>
        </s-stack>
      </s-section>
      <s-section heading="What it does">
        <s-paragraph>
          On product pages, when the shopper scrolls past the Add to cart button, the same button
          appears fixed at the bottom of the screen. It hides again when the original button is back
          on screen and while a cart drawer is open.
        </s-paragraph>
        <s-paragraph>
          Clicking it presses the theme&apos;s own Add to cart button, so the selected variant,
          quantity, Volume Discounts tier and Checkbox Upsell checkboxes are added exactly as with the
          main button. If the variant is sold out, the button shows the theme&apos;s text and is
          disabled.
        </s-paragraph>
        <s-paragraph>
          Phones and tablets (below 992px): only the rounded button floats over the page. Desktop: a
          white bar with the product photo, title, price, a variant select (it switches the variant
          through the theme&apos;s own swatches) and the button — as in Vitals. Text, colors, corner
          radius and what is shown on desktop are set in the embed settings. Inline CSS + script, no
          extra downloads (the photo is the same small file the theme&apos;s swatches already load).
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
