import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { useLoaderData, useRevalidator } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { loadShopDomain } from "../campaigns.server";
import { TRK_EMBED_MARKERS, checkEmbed } from "../embed-status.server";
import { loadTrkPageConfig, pageTemplateState } from "../trk-admin.server";
import { TRK_TEMPLATE_SUFFIX, handleTrkAction } from "../trk-actions.server";
import { getLookups, getTrkSettings } from "../trk-store.server";
import { Check, Field, Grid, Kpi, TrkNav, card, input, useTrkAction } from "../trk-ui";

/**
 * Tracking → Tracking page. The customer page is /pages/<handle>. Best layout:
 * a page template "page.track-order" built in the theme editor with the app block
 * "Order tracking" + any theme sections (Products carousel = "You may also like").
 * Without the template the Gift Links embed still mounts the tracker on the page.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const s = await getTrkSettings(shop);
  const [{ config: page }, domain, tpl, lookups] = await Promise.all([
    loadTrkPageConfig(admin),
    loadShopDomain(admin),
    pageTemplateState(admin, s.pageHandle, TRK_TEMPLATE_SUFFIX),
    getLookups(shop),
  ]);
  const live = page.enabled ? await checkEmbed(domain, TRK_EMBED_MARKERS, url.searchParams.has("refresh")) : "off";
  const days = Object.entries(lookups).sort(([a], [b]) => (a < b ? 1 : -1));
  const sum = (n: number) => {
    const since = new Date(Date.now() - n * 86400000).toISOString().slice(0, 10);
    return days.filter(([d]) => d >= since).reduce((a, [, v]) => ({ l: a.l + v.lookups, f: a.f + v.found }), { l: 0, f: 0 });
  };
  const apiKey = process.env.SHOPIFY_API_KEY || "";
  const editorBase = `https://${shop}/admin/themes/${tpl.themeId || "current"}/editor`;
  return {
    settings: { pageHandle: s.pageHandle, hideOriginEvents: s.hideOriginEvents, hideChinese: s.hideChinese, lastMileOnly: s.lastMileOnly, updatedAt: s.updatedAt },
    page,
    live,
    domain,
    pageUrl: domain ? `${domain}/pages/${s.pageHandle}` : "",
    tpl,
    suffix: TRK_TEMPLATE_SUFFIX,
    editorTemplateUrl: `${editorBase}?template=page.${TRK_TEMPLATE_SUFFIX}&previewPath=${encodeURIComponent(`/pages/${s.pageHandle}`)}`,
    editorAddBlockUrl: apiKey
      ? `${editorBase}?template=page.${TRK_TEMPLATE_SUFFIX}&addAppBlockId=${encodeURIComponent(apiKey)}/tracking-page&target=newAppsSection`
      : "",
    look7: sum(7),
    look30: sum(30),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => handleTrkAction(request);

export default function TrackingPageAdmin() {
  const d = useLoaderData<typeof loader>();
  const rv = useRevalidator();
  const { post, busy } = useTrkAction();
  const [f, setF] = useState(d.settings);
  const dirty = JSON.stringify(f) !== JSON.stringify(d.settings);
  const usesTpl = d.tpl.page?.templateSuffix === d.suffix;
  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      <s-section heading="Tracking page">
        <s-stack direction="inline" gap="base" alignItems="center">
          {d.page.enabled ? <s-badge tone="success">On</s-badge> : <s-badge>Off</s-badge>}
          <s-button variant={d.page.enabled ? "secondary" : "primary"} loading={busy("page") || undefined} onClick={() => post({ intent: "page", on: d.page.enabled ? "0" : "1" })}>
            {d.page.enabled ? "Turn off" : "Turn on"}
          </s-button>
          {d.page.enabled ? (
            d.live === "on" ? (
              <s-badge tone="success">Storefront: code present</s-badge>
            ) : d.live === "off" ? (
              <s-badge tone="critical">Storefront: not found</s-badge>
            ) : (
              <s-badge tone="warning">Storefront: can’t check</s-badge>
            )
          ) : null}
          {d.pageUrl ? (
            <s-button variant="tertiary" href={d.pageUrl} target="_blank">
              View page
            </s-button>
          ) : null}
          <s-button
            variant="tertiary"
            loading={rv.state === "loading" || undefined}
            onClick={() => {
              window.history.replaceState(null, "", "?refresh=1");
              rv.revalidate();
            }}
          >
            Refresh
          </s-button>
        </s-stack>
        <div style={{ fontSize: 13, color: "#616161", marginTop: 8 }}>
          {d.pageUrl || `/pages/${d.settings.pageHandle}`} · Turn on creates the page if it doesn’t exist. The lookup needs the order number + email, or a
          tracking number (YunExpress or last-mile).
        </div>
      </s-section>

      <s-section heading="Page views (lookups)">
        <Grid>
          <Kpi label="Last 7 days" value={d.look7.l} hint={`${d.look7.f} found`} />
          <Kpi label="Last 30 days" value={d.look30.l} hint={`${d.look30.f} found`} />
        </Grid>
      </s-section>

      <s-section heading="Page template — add any blocks">
        <div style={{ ...card, fontSize: 13, display: "flex", flexDirection: "column", gap: 8 }}>
          <div>
            Template <b>page.{d.suffix}</b> in “{d.tpl.themeName || "published theme"}”:{" "}
            {d.tpl.templateExists ? <s-badge tone="success">exists</s-badge> : <s-badge tone="warning">not created yet</s-badge>}
            {"  "}Page uses it: {usesTpl ? <s-badge tone="success">yes</s-badge> : <s-badge>no</s-badge>}
          </div>
          <ol style={{ margin: 0, paddingLeft: 18, lineHeight: 1.6 }}>
            <li>
              Theme editor → top dropdown → <b>Pages</b> → <b>Create template</b> → name <b>{d.suffix}</b>, based on <i>Default page</i>.
            </li>
            <li>
              <b>Add section → Apps → Order tracking</b> (our block: texts, status names and color are edited right there).
            </li>
            <li>
              Add any theme sections around it — e.g. <b>Products carousel</b> with a collection = “You may also like”, Testimonial, Icon box, FAQ.
              Remove the “Page” content section if you don’t need it.
            </li>
            <li>Save, then press “Use template” below (or choose the template on the page in Online Store → Pages).</li>
          </ol>
          <s-stack direction="inline" gap="base">
            <s-button href={d.editorTemplateUrl} target="_blank">
              Open theme editor
            </s-button>
            {d.tpl.templateExists && d.editorAddBlockUrl ? (
              <s-button variant="secondary" href={d.editorAddBlockUrl} target="_blank">
                Add “Order tracking” block
              </s-button>
            ) : null}
            <s-button
              variant="secondary"
              disabled={!d.tpl.templateExists || usesTpl || undefined}
              loading={busy("useTemplate") || undefined}
              onClick={() => post({ intent: "useTemplate" })}
            >
              Use template
            </s-button>
          </s-stack>
        </div>
      </s-section>

      <s-section heading="Page settings">
        <Field label="Page handle" hint={`Address: /pages/${f.pageHandle}`}>
          <input style={{ ...input, maxWidth: 300 }} value={f.pageHandle} onChange={(e) => setF({ ...f, pageHandle: e.target.value })} />
        </Field>
        <div style={{ fontSize: 13, fontWeight: 600, margin: "8px 0" }}>Dropshipping mode</div>
        <Check
          label="Hide all Chinese characters from the tracking history"
          checked={f.hideChinese}
          onChange={(v) => setF({ ...f, hideChinese: v })}
        />
        <Check
          label="Hide China first-mile scans"
          hint="Customers see the scans from export / arrival onwards."
          checked={f.hideOriginEvents}
          onChange={(v) => setF({ ...f, hideOriginEvents: v })}
        />
        <Check
          label="Show only the last-mile carrier and number (once known)"
          hint="Hides “YunExpress YT…” — the customer sees e.g. Royal Mail QP…GB."
          checked={f.lastMileOnly}
          onChange={(v) => setF({ ...f, lastMileOnly: v })}
        />
        <s-button variant="primary" disabled={!dirty || undefined} loading={busy("save") || undefined} onClick={() => post({ intent: "save", settings: JSON.stringify(f) })}>
          Save
        </s-button>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
