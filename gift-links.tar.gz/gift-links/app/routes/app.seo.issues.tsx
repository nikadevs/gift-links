import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useMemo, useState } from "react";
import { useLoaderData, useNavigate, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import { getLatestReport, getPsiRuns } from "../seo/seo-store.server";
import { cwvStatus, latestRuns } from "../seo/seo.shared";
import {
  CATEGORY_LABEL,
  SEVERITY_ORDER,
  type Category,
  type Finding,
  type Severity,
} from "../seo/seo.shared";
import { FIX_LINK, SevBadge, SeoTabs, ago, groupFindings, pathOf } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { shop } = await seoAuth(request);
  const [report, runs] = await Promise.all([getLatestReport(shop), getPsiRuns(shop)]);
  const findings: Finding[] = [...(report?.findings ?? [])];
  for (const r of latestRuns(runs))
    if (r.strategy === "mobile" && cwvStatus(r.field) === "fail")
      findings.push({
        check: "cwv_fail",
        url: r.url,
        detail: `LCP ${r.field?.lcp?.p75 ?? "?"} ms · INP ${r.field?.inp?.p75 ?? "?"} ms · CLS ${r.field?.cls?.p75 ?? "?"} (${r.field?.scope === "origin" ? "whole site" : "this URL"})`,
      });
  return {
    findings,
    finishedAt: report?.finishedAt ?? "",
    checked: report?.checked ?? 0,
  };
};

export default function SeoIssues() {
  const { findings, finishedAt, checked } = useLoaderData<typeof loader>();
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const focus = params.get("check") ?? "";
  const [cat, setCat] = useState<Category | "">("");
  const [sev, setSev] = useState<Severity | "">("");
  const [q, setQ] = useState("");
  const [showInfo, setShowInfo] = useState(false);

  const groups = useMemo(() => {
    const ql = q.trim().toLowerCase();
    return groupFindings(findings).filter(
      (g) =>
        (!cat || g.def.category === cat) &&
        (!sev || g.def.severity === sev) &&
        (showInfo || sev === "info" || g.def.severity !== "info" || g.def.id === focus) &&
        (!ql ||
          g.def.title.toLowerCase().includes(ql) ||
          g.items.some((i) => i.url.toLowerCase().includes(ql))),
    );
  }, [findings, cat, sev, q, showInfo, focus]);

  const exportCsv = () => {
    const rows = [["severity", "category", "issue", "url", "detail"]];
    for (const g of groups)
      for (const i of g.items)
        rows.push([g.def.severity, g.def.category, g.def.title, i.url, i.detail ?? ""]);
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")).join("\n");
    const a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    a.download = `seo-issues-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
  };

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Issues">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button slot="secondary-actions" onClick={exportCsv}>
        Export CSV
      </s-button>
      <SeoTabs />
      <s-section>
        <div className="wcs-filters">
          <select value={cat} onChange={(e) => setCat(e.target.value as Category | "")}>
            <option value="">All categories</option>
            {Object.entries(CATEGORY_LABEL).map(([k, v]) => (
              <option key={k} value={k}>
                {v}
              </option>
            ))}
          </select>
          <select value={sev} onChange={(e) => setSev(e.target.value as Severity | "")}>
            <option value="">All severities</option>
            {SEVERITY_ORDER.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
          <input
            placeholder="Search issue or URL"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
          <label style={{ fontSize: 14 }}>
            <input
              type="checkbox"
              checked={showInfo}
              onChange={(e) => setShowInfo(e.target.checked)}
            />{" "}
            Show info notes
          </label>
          <span style={{ color: "#616161", fontSize: 13, marginLeft: "auto" }}>
            {finishedAt ? `${checked} pages · audited ${ago(finishedAt)}` : "No audit yet"}
          </span>
        </div>
      </s-section>

      {groups.length === 0 ? (
        <s-section>
          <s-paragraph>Nothing here{findings.length ? " with these filters" : " yet — run an audit on the Overview tab"}.</s-paragraph>
        </s-section>
      ) : (
        <div>
          {groups.map((g) => (
            <details key={g.def.id} id={g.def.id} className="wcs-issue" open={g.def.id === focus}>
              <summary>
                <SevBadge severity={g.def.severity} />
                <span className="t">{g.def.title}</span>
                <span className="wcs-chip">{CATEGORY_LABEL[g.def.category]}</span>
                <span className="n">{g.count}×</span>
              </summary>
              <div className="body">
                <p>
                  <b>Why it matters:</b> {g.def.why}
                </p>
                <p>
                  <b>How to fix:</b> {g.def.fix}{" "}
                  {g.def.docs ? (
                    <a href={g.def.docs} target="_blank" rel="noreferrer">
                      Official guide
                    </a>
                  ) : null}
                </p>
                {FIX_LINK[g.def.fixIn] ? (
                  <p>
                    <s-button onClick={() => navigate(FIX_LINK[g.def.fixIn]!.href)}>
                      {FIX_LINK[g.def.fixIn]!.label}
                    </s-button>
                  </p>
                ) : null}
                <ul>
                  {g.items.slice(0, 300).map((i, n) => (
                    <li key={n}>
                      <a href={i.url} target="_blank" rel="noreferrer">
                        {pathOf(i.url)}
                      </a>
                      {i.detail ? <span className="d"> — {i.detail}</span> : null}
                    </li>
                  ))}
                  {g.items.length > 300 ? <li>…and {g.items.length - 300} more (Export CSV)</li> : null}
                </ul>
              </div>
            </details>
          ))}
        </div>
      )}
      <s-section>
        <s-text color="subdued">
          The audit reads the HTML your server sends (like Google’s first pass) and does not
          run app scripts, so things added later by JavaScript are not seen. Lengths for
          titles/descriptions are guidelines, not Google rules.
        </s-text>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
