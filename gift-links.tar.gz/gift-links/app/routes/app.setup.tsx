import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const store = session.shop.replace(".myshopify.com", "");
  return {
    themeEditor: `https://admin.shopify.com/store/${store}/themes/current/editor?context=apps`,
  };
};

export default function Setup() {
  const { themeEditor } = useLoaderData<typeof loader>();
  return (
    <s-page heading="Setup guide">
      <s-section heading="1. Turn on the app embeds (once)">
        <s-paragraph>
          Online Store → Themes → Customize → App embeds → switch on{" "}
          <s-text type="strong">Gift Links</s-text> and{" "}
          <s-text type="strong">Checkbox Upsell</s-text> → Save. Each module
          has its own embed, so you can turn one off without the other.
        </s-paragraph>
        <s-button href={themeEditor} target="_blank">
          Open theme editor
        </s-button>
      </s-section>

      <s-section heading="2. Create the discount in Shopify">
        <s-unordered-list>
          <s-list-item>
            Discounts → Create → Buy X get Y → Discount code.
          </s-list-item>
          <s-list-item>
            Customer buys: collection with all products except the gift, minimum
            purchase amount (e.g. $10).
          </s-list-item>
          <s-list-item>
            Customer gets: the gift product, quantity 1, Free.
          </s-list-item>
          <s-list-item>Maximum uses per order: 1.</s-list-item>
          <s-list-item>
            Combinations: turn on product / order discounts if your store runs
            other sales or bundles at the same time.
          </s-list-item>
        </s-unordered-list>
      </s-section>

      <s-section heading="3. Create a gift campaign here">
        <s-paragraph>
          Pick the gift, pick the code, set the minimum subtotal to the same
          amount as the discount, save and copy the link into your email.
        </s-paragraph>
      </s-section>

      <s-section heading="4. Test before sending">
        <s-ordered-list>
          <s-list-item>Open the link in a private window.</s-list-item>
          <s-list-item>
            Add any product → the gift appears in the cart.
          </s-list-item>
          <s-list-item>
            Go to checkout → the gift is $0 and the code is applied.
          </s-list-item>
          <s-list-item>
            Remove the product → the gift is removed too.
          </s-list-item>
        </s-ordered-list>
      </s-section>

      <s-section heading="Checkbox Upsell">
        <s-ordered-list>
          <s-list-item>
            Checkbox Upsell → New checkbox → pick the product it adds (e.g.
            Skip The Line), the text, and where it shows (all products,
            products or collections).
          </s-list-item>
          <s-list-item>
            The live price of that product is shown. Set its compare-at price
            to get the strike-through ($5.00 → $2.50).
          </s-list-item>
          <s-list-item>
            Position and colours: theme editor → App embeds → Checkbox Upsell.
            By default it sits right before the Add to cart button.
          </s-list-item>
          <s-list-item>
            Test: tick the box → Add to cart → the drawer shows both lines; the
            upsell line has hidden properties _wc_upsell / _wc_upsell_for.
          </s-list-item>
        </s-ordered-list>
      </s-section>

      <s-section slot="aside" heading="Good to know">
        <s-paragraph>
          The campaign stays attached to the shopper&apos;s browser for 7 days
          after the click, so they can come back later.
        </s-paragraph>
        <s-paragraph>
          A code typed on Shopify&apos;s own checkout page can&apos;t add
          products (Shopify Plus only). Use the link, or a cart-page discount
          field.
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
