import type { ActionFunctionArgs } from "react-router";
import { isbot } from "isbot";
import prisma from "../db.server";
import { SID_RE, ingest } from "../rec.server";

/**
 * Session Recordings ingest: POST /api/rec?shop=&s=&v=&p=&q=&z=
 * Body = {"m"?:pageMeta,"f"?:flags,"e":[rrweb events]} as text/plain JSON,
 * gzip-compressed when z=1 (CompressionStream in the browser).
 * text/plain keeps the request "simple" → no CORS preflight.
 * Always answers 204 quickly; bad input is silently dropped.
 */
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Max-Age": "86400",
};
const MAX_BODY = 1024 * 1024;

const shopCache = new Map<string, { ok: boolean; at: number }>();
const ipHits = new Map<string, { n: number; at: number }>();

async function knownShop(shop: string) {
  const hit = shopCache.get(shop);
  if (hit && Date.now() - hit.at < 10 * 60 * 1000) return hit.ok;
  const n = await prisma.session.count({ where: { shop } });
  shopCache.set(shop, { ok: n > 0, at: Date.now() });
  return n > 0;
}

const done = () => new Response(null, { status: 204, headers: CORS });

export const loader = () => done();

export const action = async ({ request }: ActionFunctionArgs) => {
  if (request.method === "OPTIONS") return done();
  try {
    const ip = request.headers.get("x-forwarded-for")?.split(",")[0].trim() ?? "local";
    const now = Date.now();
    const r = ipHits.get(ip);
    if (r && now - r.at < 60000) {
      if (++r.n > 240) return done();
    } else ipHits.set(ip, { n: 1, at: now });
    if (ipHits.size > 20000) ipHits.clear();

    const ua = request.headers.get("user-agent") ?? "";
    if (!ua || isbot(ua)) return done();
    const len = Number(request.headers.get("content-length") || 0);
    if (len > MAX_BODY) return done();

    const q = new URL(request.url).searchParams;
    const shop = String(q.get("shop") ?? "").toLowerCase();
    const sid = String(q.get("s") ?? "");
    const vid = String(q.get("v") ?? "");
    const page = Number(q.get("p"));
    const seq = Number(q.get("q"));
    if (!/^[a-z0-9][a-z0-9-]*\.myshopify\.com$/.test(shop)) return done();
    if (!SID_RE.test(sid) || !/^[a-z0-9]{8,40}$/.test(vid)) return done();
    if (!Number.isInteger(page) || page < 0 || page > 9999) return done();
    if (!Number.isInteger(seq) || seq < 0 || seq > 99999) return done();
    if (!(await knownShop(shop))) return done();

    const body = Buffer.from(await request.arrayBuffer());
    if (!body.length || body.length > MAX_BODY) return done();
    await ingest({ shop, sid, vid, page, seq, zipped: q.get("z") === "1", body, ua, ip });
  } catch {
    /* never fail a beacon */
  }
  return done();
};
