import { readTrustpilot } from "../trustpilot.server";
export async function loader() {
  const data = await readTrustpilot();
  return Response.json(data || { error: "Reviews temporarily unavailable" }, { status: data ? 200 : 503, headers: { "Access-Control-Allow-Origin": "*", "Cache-Control": data ? "public, max-age=300" : "no-store" } });
}
