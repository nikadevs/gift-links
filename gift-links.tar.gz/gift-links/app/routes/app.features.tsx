import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { Link, useFetcher, useLoaderData, useNavigate, useRouteError } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { listFeaturesProducts, loadFeaturesProduct, saveFeatures, sliderFiles, uploadSliderPhoto, photoStatus, sanitizeIcon } from "../features.server";
import { emptyFeatures, type FeaturesConfig, type Feature, type FeaturePhoto } from "../features.shared";
import "../styles/features-editor.css";
export const loader = async ({request}: LoaderFunctionArgs) => {
  const {admin} = await authenticate.admin(request), id = new URL(request.url).searchParams.get("product");
  return id ? {selection: await loadFeaturesProduct(admin,id), products: []} : {selection: null, products: await listFeaturesProducts(admin)};
};
export const action = async ({request}: ActionFunctionArgs) => {
  const {admin} = await authenticate.admin(request), form = await request.formData(), intent = form.get("intent");
  try {
    if (intent === "files") return {ok: true, files: (await sliderFiles(admin, String(form.get("after") || "") || null)).files};
    if (intent === "upload") { const f = form.get("photo"); if (!(f instanceof File)) throw new Error("Choose a photo."); return {ok: true, upload: await uploadSliderPhoto(admin,f)}; }
    if (intent === "photo-status") return {ok:true, upload: await photoStatus(admin, String(form.get("id")))};
    if (intent === "icon") return {ok: true, icon: sanitizeIcon(String(form.get("svg") || ""))};
    if (intent !== "save") throw new Error("Unknown action.");
    const id = String(form.get("product")), loaded = await loadFeaturesProduct(admin,id);
    if (String(form.get("digest") || "") !== (loaded.product.config?.compareDigest || "")) throw new Error("These settings were edited elsewhere. Reload before saving.");
    await saveFeatures(admin,id,JSON.parse(String(form.get("config"))),loaded.product.config?.compareDigest ?? null);
    return {ok: true, message: "Features with Image Slider saved for this product.", selection: await loadFeaturesProduct(admin,id)};
  } catch (e) {return {ok:false, message:e instanceof Error ? e.message : "Could not save slider."};}
};
export default function FeaturesPage() {
  const {selection,products} = useLoaderData<typeof loader>(), shopify = useAppBridge(), navigate = useNavigate();
  async function pick() {const p = await shopify.resourcePicker({type:"product",action:"select",multiple:false}); if(p?.[0]) navigate(`/app/features?product=${encodeURIComponent(p[0].id)}`);}
  return <s-page heading="Features with Image Slider" inlineSize="large">
    <s-link slot="breadcrumb-actions" href="/app">WoodenCrew Apps</s-link>
    <s-button slot="primary-action" variant="primary" onClick={pick}>Choose product</s-button>
    {!selection ? <s-section heading="Configured products">{products.length ? products.map(p=><div className="wc-fe-row" key={p.id}><Link to={`/app/features?product=${encodeURIComponent(p.id)}`}>{p.title}</Link><span>{p.enabled?"Enabled":"Disabled"} · {p.count} features</span></div>) : <s-paragraph>Choose a product to configure its slider. Each product has its own content and enable switch.</s-paragraph>}</s-section> : <s-section heading={selection.product.title}><FeaturesEditor key={`${selection.product.id}:${selection.product.config?.compareDigest || 'new'}`} selection={selection}/></s-section>}
    <s-section heading="Place it once in your template"><s-paragraph>Add the Features Image Slider app block inside Product summary in the theme editor, and move it to the desired position. Every product uses its own saved settings. The block appears only when enabled and configured for that product. Your shared product template stays shared.</s-paragraph></s-section>
  </s-page>;
}
function FeaturesEditor({selection}: {selection: NonNullable<Awaited<ReturnType<typeof loader>>["selection"]>}) {
  const save = useFetcher<typeof action>();
  const [config,setConfig] = useState<FeaturesConfig>(selection.config || emptyFeatures());
  const digest=selection.product.config?.compareDigest || "";
  const [dirty,setDirty] = useState(false), [processing,setProcessing] = useState(false), [picker,setPicker] = useState<string|null>(null), [photos,setPhotos] = useState<FeaturePhoto[]>([]), [error,setError] = useState("");
  const [nextCursor,setNextCursor] = useState<string|null>(null);
  function update(patch: Partial<FeaturesConfig>) {setConfig(c=>({...c,...patch}));setDirty(true);}
  function feature(id: string, patch: Partial<Feature>) {setConfig(c=>({...c,features:c.features.map(f=>f.id===id?{...f,...patch}:f)}));setDirty(true);}
  async function api(values:Record<string,string|File>){const body=new FormData();for(const [key,value] of Object.entries(values))body.set(key,value);const response=await fetch('/api/features',{method:'POST',body});const data=await response.json() as {ok:boolean;message?:string;icon?:string;files?:Awaited<ReturnType<typeof sliderFiles>>['files'];upload?:Awaited<ReturnType<typeof uploadSliderPhoto>>};if(!data.ok)throw new Error(data.message || 'Request failed.');return data;}
  async function work(fn:()=>Promise<void>){setProcessing(true);setError('');try{await fn();}catch(e){setError(e instanceof Error?e.message:'Request failed.');}finally{setProcessing(false);}}
  const busy = save.state!=="idle" || processing;
  function reorder(index: number, direction: number) {const next=[...config.features]; [next[index],next[index+direction]]=[next[index+direction],next[index]];update({features:next});}
  async function svgFile(id: string, file?: File) {if(!file)return;await work(async()=>{if(file.size>16000)throw new Error('SVG must be smaller than 16 KB.');const data=await api({intent:'icon',svg:await file.text()});if(data.icon)feature(id,{iconSvg:data.icon});});}
  async function upload(id:string, file?:File){if(!file)return;await work(async()=>{let data=await api({intent:'upload',photo:file});for(let i=0;data.upload && !data.upload.photo && i<30;i++){await new Promise(r=>setTimeout(r,1000));data=await api({intent:'photo-status',id:data.upload.id});}if(!data.upload?.photo)throw new Error('Photo is still processing. Select it from Shopify Files shortly.');feature(id,{photo:data.upload.photo});});}
  async function files(id:string,after=''){setPicker(id);await work(async()=>{const data=await api({intent:'files',after});if(data.files){setPhotos(data.files.nodes.flatMap(n=>n.image?[n.image]:[]));setNextCursor(data.files.pageInfo.hasNextPage?data.files.pageInfo.endCursor:null);}});}
  const messages=[save.data].filter(d=>d && "message" in d);
  return <div className="wc-fe-editor">
    <div className="wc-fe-save"><button type="button" disabled={busy || !dirty} onClick={()=>save.submit({intent:"save",product:selection.product.id,digest,config:JSON.stringify(config)},{method:"post"})}>{busy?"Processing…":"Save slider"}</button><span>{dirty?"Unsaved changes — save before leaving":"Saved"}</span><s-link href={`shopify:admin/products/${selection.product.id.split('/').pop()}`}>Open product settings</s-link></div>
    {messages.map((d,i)=><s-banner key={i} tone={d?.ok?"success":"critical"}>{d && "message" in d ? d.message : ""}</s-banner>)}
    {error?<s-banner tone="critical">{error}</s-banner>:null}
    <fieldset className="wc-fe-form" disabled={busy}>
    <label className="wc-fe-toggle"><input type="checkbox" checked={config.enabled} onChange={e=>update({enabled:e.target.checked})}/> Enable this block for this product</label>
    <details open className="wc-fe-group"><summary>Slider settings</summary><div className="wc-fe-fields">
      <label>Main heading<textarea rows={2} maxLength={200} value={config.heading} onChange={e=>update({heading:e.target.value})}/></label>
      <label>Switch every (seconds)<input type="number" min={2} max={20} value={config.interval} onChange={e=>update({interval:Number(e.target.value)})}/></label>
      <p>Hover pauses autoplay. Clicking a feature selects its photo and stops autoplay until the page is reloaded.</p>
      <details><summary>Colors and spacing</summary><div className="wc-fe-colors">{([['accent','Accent'],['background','Background'],['textColor','Titles'],['mutedColor','Descriptions']] as const).map(([key,label])=><label key={key}>{label}<input type="color" value={config[key]} onChange={e=>update({[key]:e.target.value})}/></label>)}</div><div className="wc-fe-row">{([['paddingTop','Top spacing'],['paddingBottom','Bottom spacing']] as const).map(([key,label])=><label key={key}>{label} (px at 610 px width)<input type="number" min={0} max={120} value={config[key]} onChange={e=>update({[key]:Number(e.target.value)})}/></label>)}</div></details>
    </div></details>
    <div className="wc-fe-row"><strong>Features ({config.features.length}/10)</strong><button type="button" disabled={config.features.length>=10 || busy} onClick={()=>update({features:[...config.features,{id:crypto.randomUUID(),title:"",description:"",iconSvg:"",photo:null}]})}>Add feature</button></div>
    {config.features.map((f,i)=><details className="wc-fe-group" key={f.id}><summary>{i+1}. {f.title || "New feature"}</summary><div className="wc-fe-fields">
      <label>Title<input maxLength={100} value={f.title} onChange={e=>feature(f.id,{title:e.target.value})}/></label>
      <label>Description<textarea rows={3} maxLength={500} value={f.description} onChange={e=>feature(f.id,{description:e.target.value})}/></label>
      <div className="wc-fe-media"><div>{f.iconSvg?<img className="wc-fe-icon" src={`data:image/svg+xml,${encodeURIComponent(f.iconSvg)}`} alt="Feature icon"/>:null}<label>Upload SVG icon<input type="file" accept=".svg,image/svg+xml" disabled={busy} onChange={e=>void svgFile(f.id,e.target.files?.[0])}/></label><details><summary>Advanced: SVG code</summary><textarea rows={4} maxLength={16000} value={f.iconSvg} onChange={e=>feature(f.id,{iconSvg:e.target.value})}/><p>Simple SVG paths and shapes only. Icons are validated before saving.</p></details></div>
      <div>{f.photo?<img className="wc-fe-photo" src={f.photo.url} alt={f.photo.alt || "Feature photo"} width={96} height={128}/>:null}<label>Upload photo<input type="file" accept="image/jpeg,image/png,image/webp" disabled={busy} onChange={e=>void upload(f.id,e.target.files?.[0])}/></label><button type="button" disabled={busy} onClick={()=>{setPicker(f.id);setPhotos(selection.product.images.nodes);setNextCursor(null);}}>Choose product photo</button> <button type="button" disabled={busy} onClick={()=>void files(f.id)}>Choose from Shopify Files</button>{f.photo?<label>Photo alt text<input maxLength={200} value={f.photo.alt || ""} onChange={e=>feature(f.id,{photo:{...f.photo!,alt:e.target.value}})}/></label>:null}</div></div>
      <div className="wc-fe-row"><div><button type="button" disabled={i===0} onClick={()=>reorder(i,-1)}>Move up</button> <button type="button" disabled={i===config.features.length-1} onClick={()=>reorder(i,1)}>Move down</button></div><button type="button" onClick={()=>update({features:config.features.filter(item=>item.id!==f.id)})}>Remove feature</button></div>
    </div></details>)}
    {picker?<div className="wc-fe-picker" role="dialog" aria-label="Choose feature photo"><div className="wc-fe-row"><strong>Choose photo</strong><button type="button" onClick={()=>setPicker(null)}>Close</button></div><div className="wc-fe-grid">{photos.map(p=><button type="button" key={p.url} onClick={()=>{feature(picker,{photo:{...p,alt:p.alt || ""}});setPicker(null);}}><img src={p.url+ (p.url.includes('?')?'&':'?')+'width=160'} alt={p.alt||"Select photo"} width={100} height={100} loading="lazy"/></button>)}</div>{!photos.length?<p>{processing?"Loading photos…":"No photos found. Upload a photo above."}</p>:null}{nextCursor?<button type="button" disabled={busy} onClick={()=>void files(picker,nextCursor)}>Next page</button>:null}</div>:null}
    </fieldset>
  </div>;
}
export function ErrorBoundary(){return boundary.error(useRouteError());}
export const headers: HeadersFunction = args=>boundary.headers(args);
