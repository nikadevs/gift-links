import type { LoaderFunctionArgs } from "react-router";
import { loadOrders } from "../trk-orders.server";

/** CSV export data for Tracking → Orders (all rows of the current filter, JSON). */
export const loader = async ({ request }: LoaderFunctionArgs) => Response.json(await loadOrders(request, true));
