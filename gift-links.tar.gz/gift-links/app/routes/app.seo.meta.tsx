import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useMemo, useState } from "react";
import { useFetcher, useLoaderData, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth } from "../seo/seo-context.server";
import {
  AccessError,
  fillTemplate,
  listSeoRows,
  setHidden,
  updateSeo,
} from "../seo/seo-admin.server";
import type { SeoKind, SeoRow } from "../seo/seo-admin.shared";
import { SeoTabs } from "../seo/seo-ui";

const KINDS: Array<{ id: SeoKind; label: string }> = [
  { id: "products", label: "Products" },
  { id: "collections", label: "Collections" },
  { id: "pages", label: "Pages" },
  { id: "articles", label: "Blog posts" },
];

const asKind = (v: string | null): SeoKind =>
  (KINDS.find((k) => k.id === v)?.id ?? "products") as SeoKind;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, origin, name } = await seoAuth(request);
  const kind = asKind(new URL(request.url).searchParams.get("kind"));
  try {
    const rows = await listSeoRows(admin, kind);
    return { kind, rows, origin, shopName: name, accessError: "" };
  } catch (e) {
    return {
      kind,
      rows: [] as SeoRow[],
      origin,
      shopName: name,
      accessError:
        e instanceof AccessError
          ? "The app needs the new permissions (products / content). Open WoodenCrew Apps from Shopify admin → Apps and approve the update."
          : (e as Error).message,
    };
  }
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, name } = await seoAuth(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const kind = asKind(String(form.get("kind")));
  try {
    if (intent === "save") {
      await updateSeo(
        admin,
        kind,
        String(form.get("id")),
        String(form.get("title") ?? "").slice(0, 255),
        String(form.get("description") ?? "").slice(0, 320),
      );
      return { ok: true, intent, id: String(form.get("id")), message: "Saved" };
    }
    if (intent === "hide") {
      const hidden = form.get("hidden") === "1";
      await setHidden(admin, String(form.get("id")), hidden);
      return {
        ok: true,
        intent,
        id: String(form.get("id")),
        message: hidden ? "Hidden from search engines" : "Visible to search engines again",
      };
    }
    if (intent === "bulk") {
      const field = String(form.get("field")) === "description" ? "description" : "title";
      const tpl = String(form.get("template") ?? "").trim();
      if (!tpl) return { ok: false, intent, message: "Template is empty" };
      const rows = (await listSeoRows(admin, kind)).filter(
        (r) => r.status === "ACTIVE" && !(field === "title" ? r.seoTitle : r.seoDescription),
      );
      let done = 0;
      for (const r of rows.slice(0, 250)) {
        const value = fillTemplate(tpl, r, name).slice(0, field === "title" ? 255 : 320);
        if (!value) continue;
        await updateSeo(
          admin,
          kind,
          r.id,
          field === "title" ? value : r.seoTitle,
          field === "description" ? value : r.seoDescription,
        );
        done++;
      }
      return { ok: true, intent, message: `Filled ${done} empty ${field}s` };
    }
  } catch (e) {
    return {
      ok: false,
      intent,
      message:
        e instanceof AccessError
          ? "No permission to change this yet — approve the app’s new permissions in Shopify admin → Apps → WoodenCrew Apps."
          : (e as Error).message,
    };
  }
  return { ok: false, intent, message: "Unknown action" };
};

type Draft = { title: string; description: string };

function len(cls: number, min: number, max: number) {
  return cls > max ? "over" : cls && cls < min ? "over" : "";
}

function Row({
  row,
  kind,
  origin,
  dupTitle,
  dupDesc,
}: {
  row: SeoRow;
  kind: SeoKind;
  origin: string;
  dupTitle: boolean;
  dupDesc: boolean;
}) {
  const fetcher = useFetcher<typeof action>();
  const [d, setD] = useState<Draft>({ title: row.seoTitle, description: row.seoDescription });
  const [preview, setPreview] = useState(false);
  const dirty = d.title !== row.seoTitle || d.description !== row.seoDescription;
  const effTitle = d.title || row.name;
  const effDesc = d.description || row.fallbackDescription;
  const saving = fetcher.state !== "idle";
  const msg = fetcher.data && fetcher.state === "idle" ? fetcher.data : null;

  return (
    <tr>
      <td style={{ width: "22%" }}>
        <div style={{ display: "flex", gap: 8 }}>
          {row.image ? <img className="thumb" src={row.image} alt="" /> : null}
          <div>
            <a href={`${origin}${row.path}`} target="_blank" rel="noreferrer">
              {row.name}
            </a>
            <div className="sub">{row.path}</div>
            {row.status !== "ACTIVE" ? <s-badge tone="neutral">{row.status.toLowerCase()}</s-badge> : null}{" "}
            {row.hidden ? <s-badge tone="warning">noindex</s-badge> : null}
          </div>
        </div>
      </td>
      <td>
        <input
          className="wcs-input"
          value={d.title}
          placeholder={`(uses “${row.name}”)`}
          onChange={(e) => setD({ ...d, title: e.target.value })}
        />
        <div className={`wcs-count ${len(effTitle.length, 20, 60)}`}>
          {dupTitle ? "Duplicate · " : ""}
          {effTitle.length}/60
        </div>
        <textarea
          className="wcs-input"
          value={d.description}
          placeholder={row.fallbackDescription ? `(Google may use: “${row.fallbackDescription.slice(0, 120)}…”)` : "(empty)"}
          onChange={(e) => setD({ ...d, description: e.target.value })}
        />
        <div className={`wcs-count ${len(effDesc.length, 70, 160)}`}>
          {!d.description ? "No meta description · " : ""}
          {dupDesc ? "Duplicate · " : ""}
          {d.description.length}/160
        </div>
        {preview ? (
          <div style={{ border: "1px solid #e3e3e3", borderRadius: 8, padding: "8px 10px", margin: "4px 0", fontFamily: "arial,sans-serif" }}>
            <div style={{ fontSize: 12, color: "#202124" }}>{origin.replace(/^https?:\/\//, "")} › {row.path.split("/").filter(Boolean).join(" › ")}</div>
            <div style={{ fontSize: 18, color: "#1a0dab", lineHeight: "24px" }}>
              {effTitle.length > 60 ? `${effTitle.slice(0, 58)}…` : effTitle}
            </div>
            <div style={{ fontSize: 13, color: "#4d5156" }}>
              {effDesc.length > 158 ? `${effDesc.slice(0, 156)}…` : effDesc}
            </div>
          </div>
        ) : null}
      </td>
      <td style={{ width: 150 }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 6, alignItems: "flex-start" }}>
          <s-button
            variant="primary"
            onClick={() =>
              fetcher.submit({ intent: "save", kind, id: row.id, title: d.title, description: d.description }, { method: "POST" })
            }
            {...(!dirty || saving ? { disabled: true } : {})}
          >
            Save
          </s-button>
          <s-button variant="tertiary" onClick={() => setPreview(!preview)}>
            {preview ? "Hide preview" : "Google preview"}
          </s-button>
          <label style={{ fontSize: 13 }}>
            <input
              type="checkbox"
              checked={row.hidden}
              disabled={saving}
              onChange={(e) =>
                fetcher.submit({ intent: "hide", kind, id: row.id, hidden: e.target.checked ? "1" : "0" }, { method: "POST" })
              }
            />{" "}
            Hide from search
          </label>
          {msg ? (
            <span style={{ fontSize: 12, color: msg.ok ? "#0c6e3d" : "#b42318" }}>{msg.message}</span>
          ) : null}
        </div>
      </td>
    </tr>
  );
}

export default function SeoMeta() {
  const { kind, rows, origin, accessError, shopName } = useLoaderData<typeof loader>();
  const [, setParams] = useSearchParams();
  const bulk = useFetcher<typeof action>();
  const [q, setQ] = useState("");
  const [only, setOnly] = useState<"all" | "problems" | "hidden">("all");
  const [tplField, setTplField] = useState<"title" | "description">("title");
  const [tpl, setTpl] = useState("{title} | {shop}");

  const dup = useMemo(() => {
    const t = new Map<string, number>();
    const d = new Map<string, number>();
    for (const r of rows) {
      if (r.status !== "ACTIVE" || r.hidden) continue;
      const tt = (r.seoTitle || r.name).toLowerCase();
      t.set(tt, (t.get(tt) ?? 0) + 1);
      if (r.seoDescription) {
        const dd = r.seoDescription.toLowerCase();
        d.set(dd, (d.get(dd) ?? 0) + 1);
      }
    }
    return { t, d };
  }, [rows]);

  const filtered = rows.filter((r) => {
    const ql = q.trim().toLowerCase();
    if (ql && !`${r.name} ${r.path} ${r.seoTitle}`.toLowerCase().includes(ql)) return false;
    if (only === "hidden") return r.hidden;
    if (only === "problems") {
      const title = r.seoTitle || r.name;
      return (
        !r.seoDescription ||
        title.length > 60 ||
        title.length < 20 ||
        r.seoDescription.length > 160 ||
        (dup.t.get(title.toLowerCase()) ?? 0) > 1 ||
        (r.seoDescription && (dup.d.get(r.seoDescription.toLowerCase()) ?? 0) > 1)
      );
    }
    return true;
  });

  const emptyCount = rows.filter(
    (r) => r.status === "ACTIVE" && !(tplField === "title" ? r.seoTitle : r.seoDescription),
  ).length;
  const sample = rows.find((r) => r.status === "ACTIVE");

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Meta tags">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <SeoTabs />
      {accessError ? <s-banner tone="critical">{accessError}</s-banner> : null}
      <s-section>
        <div className="wcs-filters">
          {KINDS.map((k) => (
            <s-button key={k.id} variant={k.id === kind ? "primary" : "secondary"} onClick={() => setParams({ kind: k.id })}>
              {k.label}
            </s-button>
          ))}
          <select value={only} onChange={(e) => setOnly(e.target.value as typeof only)}>
            <option value="all">All</option>
            <option value="problems">Only with problems</option>
            <option value="hidden">Hidden from search</option>
          </select>
          <input placeholder="Search" value={q} onChange={(e) => setQ(e.target.value)} />
          <span style={{ color: "#616161", fontSize: 13, marginLeft: "auto" }}>
            {`${filtered.length} of ${rows.length}`}
          </span>
        </div>
      </s-section>

      <s-section heading="Fill empty fields from a template">
        <div className="wcs-filters">
          <select value={tplField} onChange={(e) => setTplField(e.target.value as "title" | "description")}>
            <option value="title">Meta title</option>
            <option value="description">Meta description</option>
          </select>
          <input style={{ flex: 1, minWidth: 260 }} value={tpl} onChange={(e) => setTpl(e.target.value)} />
          <s-button
            onClick={() => bulk.submit({ intent: "bulk", kind, field: tplField, template: tpl }, { method: "POST" })}
            {...(bulk.state !== "idle" || !emptyCount ? { disabled: true } : {})}
          >
            {`Fill ${emptyCount} empty`}
          </s-button>
        </div>
        <s-paragraph>
          <s-text color="subdued">
            {`Variables: {title} = ${kind === "products" ? "product" : "page"} name, {shop} = ${shopName}, {summary} = first sentences of the description. Only empty fields are filled; your own texts are never overwritten.`}
            {sample ? ` Example: “${tpl.replace(/\{title\}/g, sample.name).replace(/\{shop\}/g, shopName).replace(/\{summary\}/g, sample.fallbackDescription.slice(0, 60) + "…")}”` : ""}
          </s-text>
        </s-paragraph>
        {bulk.data && bulk.state === "idle" ? (
          <s-banner tone={bulk.data.ok ? "success" : "critical"}>{bulk.data.message}</s-banner>
        ) : null}
      </s-section>

      <s-section padding="none">
        <table className="wcs-table">
          <thead>
            <tr>
              <th>Item</th>
              <th>Meta title / Meta description</th>
              <th />
            </tr>
          </thead>
          <tbody>
            {filtered.map((r) => (
              <Row
                key={`${r.id}|${r.seoTitle}|${r.seoDescription}`}
                row={r}
                kind={kind}
                origin={origin}
                dupTitle={(dup.t.get((r.seoTitle || r.name).toLowerCase()) ?? 0) > 1}
                dupDesc={!!r.seoDescription && (dup.d.get(r.seoDescription.toLowerCase()) ?? 0) > 1}
              />
            ))}
          </tbody>
        </table>
      </s-section>
      <s-section>
        <s-text color="subdued">
          Titles around 50–60 characters and descriptions around 120–160 are usually shown in
          full by Google; these are guidelines, not limits. “Hide from search” sets Shopify’s
          seo.hidden field: the page gets noindex and leaves sitemap.xml. Gift copies ($0) can
          safely be hidden this way.
        </s-text>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
