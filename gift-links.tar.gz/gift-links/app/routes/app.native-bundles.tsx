import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useEffect, useMemo, useState } from "react";
import { useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import {
  convertProduct,
  loadBundles,
  loadNativeComponents,
  loadProductVariants,
  loadVariantInfo,
  revertProduct,
  saveVariant,
} from "../nb.server";
import { MAX_COMPONENTS, normalizeComps, parseSb, sbToComps, type Comp, type VariantInfo } from "../nb.shared";

/**
 * Bundles (replacement for the Simple Bundles app) — native Shopify fixed
 * bundles. See app/nb.shared.ts for why and how.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const url = new URL(request.url);
  const { products, info } = await loadBundles(admin);
  const byob = (p: (typeof products)[number]) => (p.variants.every((v) => v.state === "byob") ? 1 : 0);
  products.sort((a, b) => byob(a) - byob(b) || a.title.localeCompare(b.title));

  // "Add bundle" for a product that is not a bundle yet
  const extraId = url.searchParams.get("product");
  let extra: null | {
    id: string;
    title: string;
    variants: { id: string; title: string; price: number; native: Comp[]; sbComps: Comp[] }[];
  } = null;
  if (extraId && !products.some((p) => p.id === extraId)) {
    const p = await loadProductVariants(admin, extraId);
    if (p) {
      const nat = await loadNativeComponents(admin, p.variants.nodes.map((v) => v.id));
      extra = {
        id: p.id,
        title: p.title,
        variants: p.variants.nodes.map((v) => ({
          id: v.id,
          title: v.title,
          price: Number(v.price) || 0,
          native: nat[v.id] || [],
          sbComps: sbToComps(parseSb(v.sb?.value)),
        })),
      };
    }
  }
  return {
    products: products.map((p) => ({
      ...p,
      variants: p.variants.map(({ sb, ...v }) => ({ ...v, byobCount: sb && v.state === "byob" ? sb.length : 0 })),
    })),
    info,
    extra,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent") || "");
  try {
    if (intent === "save") {
      const comps = JSON.parse(String(form.get("components") || "[]")) as Comp[];
      await saveVariant(admin, String(form.get("productId")), String(form.get("variantId")), comps);
      return { ok: true as const, message: "Bundle saved" };
    }
    if (intent === "info") {
      const ids = JSON.parse(String(form.get("ids") || "[]")) as string[];
      return { ok: true as const, message: "", info: await loadVariantInfo(admin, ids.slice(0, 50)) };
    }
    const { products } = await loadBundles(admin);
    const ids = intent === "convertAll" ? products.map((p) => p.id) : [String(form.get("productId"))];
    let n = 0;
    for (const id of ids) {
      const p = products.find((x) => x.id === id);
      if (!p) continue;
      if (intent === "convert" || intent === "convertAll") n += (await convertProduct(admin, p)).variants;
      else if (intent === "revert") n += (await revertProduct(admin, p)).variants;
    }
    return {
      ok: true as const,
      message: intent === "revert" ? `Back to Simple Bundles: ${n} variant(s)` : `Native bundles: ${n} variant(s) updated`,
    };
  } catch (e) {
    return { ok: false as const, message: e instanceof Error ? e.message : String(e) };
  }
};

type LoaderData = ReturnType<typeof useLoaderData<typeof loader>>;
type Product = LoaderData["products"][number];
type Variant = Product["variants"][number];

const STATE: Record<string, { tone: "success" | "warning" | "critical" | "info" | undefined; label: string }> = {
  native: { tone: "success", label: "Native" },
  simple: { tone: "warning", label: "Simple Bundles" },
  differs: { tone: "critical", label: "Differs — check" },
  unflagged: { tone: "critical", label: "Not active — click Make native" },
  byob: { tone: "info", label: "Mix & match (Simple Bundles only)" },
  none: { tone: undefined, label: "Not a bundle" },
};

function money(n: number) {
  return `$${n.toFixed(2)}`;
}

function CompList({ comps, info }: { comps: Comp[]; info: Record<string, VariantInfo> }) {
  if (!comps.length) return <s-text color="subdued">—</s-text>;
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
      {comps.map((c) => {
        const v = info[c.variantId];
        const label = v ? `${v.productTitle}${v.title && v.title !== "Default Title" ? ` — ${v.title}` : ""}` : c.variantId;
        return (
          <span
            key={c.variantId}
            title={`${label} · ${v ? money(v.price) : "?"}`}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
              border: "1px solid #e3e3e3",
              borderRadius: 6,
              padding: "2px 6px 2px 2px",
              fontSize: 12,
              background: v && v.price > 0 ? "#f1f8f5" : "#fff",
            }}
          >
            {v?.image ? <img src={v.image} alt="" width={22} height={22} style={{ objectFit: "cover", borderRadius: 4 }} /> : null}
            <span style={{ maxWidth: 170, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {c.qty > 1 ? `${c.qty} × ` : ""}
              {label.replace(/^WoodenCrew™\s*\|?\s*/, "")}
            </span>
          </span>
        );
      })}
    </div>
  );
}

function Editor({
  productId,
  variant,
  initial,
  info: info0,
  onClose,
}: {
  productId: string;
  variant: { id: string; title: string; price: number };
  initial: Comp[];
  info: Record<string, VariantInfo>;
  onClose: () => void;
}) {
  const shopify = useAppBridge();
  const save = useFetcher<typeof action>();
  const lookup = useFetcher<typeof action>();
  const [rows, setRows] = useState<Comp[]>(initial);
  const info = useMemo(() => {
    const d = lookup.data;
    return d && "info" in d && d.info ? { ...info0, ...d.info } : info0;
  }, [info0, lookup.data]);
  useEffect(() => {
    if (save.state === "idle" && save.data?.ok) {
      shopify.toast.show(save.data.message);
      onClose();
    }
  }, [save.state, save.data, shopify, onClose]);

  const add = async () => {
    const picked = await shopify.resourcePicker({ type: "variant", action: "select", multiple: true });
    if (!picked?.length) return;
    const ids = (picked as { id: string }[]).map((p) => p.id);
    const next = normalizeComps([...rows, ...ids.map((id) => ({ variantId: id, qty: 1 }))]);
    setRows(next);
    // ask for every row the page didn't load (a new lookup replaces the previous one)
    const unknown = next.map((c) => c.variantId).filter((id) => !info0[id]);
    if (unknown.length) {
      const fd = new FormData();
      fd.set("intent", "info");
      fd.set("ids", JSON.stringify(unknown));
      lookup.submit(fd, { method: "post" });
    }
  };
  const sum = rows.reduce((s, c) => s + (info[c.variantId]?.price || 0) * c.qty, 0);
  const submit = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("productId", productId);
    fd.set("variantId", variant.id);
    fd.set("components", JSON.stringify(rows));
    save.submit(fd, { method: "post" });
  };

  return (
    <div style={{ border: "1px solid #c9cccf", borderRadius: 10, padding: 14, margin: "8px 0 14px", background: "#fafbfb" }}>
      <s-stack gap="base">
        <s-text type="strong">
          Components of “{variant.title}” (bundle price {money(variant.price)})
        </s-text>
        {rows.length ? (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left", color: "#616161" }}>
                <th style={{ padding: "4px 6px" }}>Component</th>
                <th style={{ padding: "4px 6px", width: 90 }}>Own price</th>
                <th style={{ padding: "4px 6px", width: 90 }}>Qty</th>
                <th style={{ width: 80 }} />
              </tr>
            </thead>
            <tbody>
              {rows.map((c, i) => {
                const v = info[c.variantId];
                return (
                  <tr key={c.variantId} style={{ borderTop: "1px solid #ebebeb" }}>
                    <td style={{ padding: "6px" }}>
                      <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
                        {v?.image ? <img src={v.image} alt="" width={28} height={28} style={{ objectFit: "cover", borderRadius: 4 }} /> : null}
                        <span>
                          {v ? v.productTitle : c.variantId}
                          {v && v.title !== "Default Title" ? <span style={{ color: "#616161" }}> — {v.title}</span> : null}
                          {v && v.status !== "ACTIVE" ? <span style={{ color: "#8a6116" }}> ({v.status.toLowerCase()})</span> : null}
                        </span>
                      </span>
                    </td>
                    <td style={{ padding: "6px" }}>{v ? money(v.price) : "…"}</td>
                    <td style={{ padding: "6px" }}>
                      <input
                        type="number"
                        min={1}
                        max={99}
                        value={c.qty}
                        onChange={(e) => {
                          const q = Math.max(1, Math.min(99, Number(e.currentTarget.value) || 1));
                          setRows((r) => r.map((x, j) => (j === i ? { ...x, qty: q } : x)));
                        }}
                        style={{ width: 60, padding: "4px 6px", border: "1px solid #c9cccf", borderRadius: 6 }}
                      />
                    </td>
                    <td style={{ padding: "6px", textAlign: "right" }}>
                      <s-button variant="tertiary" tone="critical" onClick={() => setRows((r) => r.filter((_, j) => j !== i))}>
                        Remove
                      </s-button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <s-text color="subdued">No components — saving makes this variant a normal (non-bundle) product.</s-text>
        )}
        <s-text color="subdued">
          Shopify splits the bundle price across components in proportion to their own prices (components
          sum {money(sum)}); $0 components stay $0 in the order — same as Simple Bundles.
        </s-text>
        {rows.length > MAX_COMPONENTS ? <s-banner tone="critical">Shopify allows up to {MAX_COMPONENTS} components.</s-banner> : null}
        {save.data && !save.data.ok ? <s-banner tone="critical">{save.data.message}</s-banner> : null}
        <s-stack direction="inline" gap="base">
          <s-button onClick={add}>Add components</s-button>
          <s-button variant="primary" loading={save.state !== "idle" || undefined} onClick={submit} disabled={rows.length > MAX_COMPONENTS || undefined}>
            Save
          </s-button>
          <s-button variant="tertiary" onClick={onClose}>
            Cancel
          </s-button>
        </s-stack>
      </s-stack>
    </div>
  );
}

export default function NativeBundles() {
  const { products, info, extra } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const shopify = useAppBridge();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [editing, setEditing] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const busy = fetcher.state !== "idle";

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      if (fetcher.data.ok) shopify.toast.show(fetcher.data.message);
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const counts = useMemo(() => {
    const c = { native: 0, simple: 0, differs: 0, unflagged: 0, byob: 0, none: 0 };
    for (const p of products) for (const v of p.variants) c[v.state] += 1;
    return c;
  }, [products]);

  const run = (intent: string, productId?: string) => {
    const key = `${intent}:${productId || ""}`;
    if ((intent === "revert" || intent === "convertAll") && confirm !== key) {
      setConfirm(key);
      return;
    }
    setConfirm(null);
    const fd = new FormData();
    fd.set("intent", intent);
    if (productId) fd.set("productId", productId);
    fetcher.submit(fd, { method: "post" });
  };

  const pickProduct = async () => {
    const picked = await shopify.resourcePicker({ type: "product", action: "select", multiple: false });
    if (picked?.[0]) navigate(`/app/native-bundles?product=${encodeURIComponent(picked[0].id)}`);
  };

  const shown = products.filter((p) => !q || p.title.toLowerCase().includes(q.toLowerCase()));

  const variantRow = (productId: string, v: Variant | (NonNullable<typeof extra>["variants"][number] & { state?: string })) => {
    const st = STATE[("state" in v && v.state) || (v.native.length ? "native" : "none")];
    const comps = v.native.length ? v.native : v.sbComps;
    const isOpen = editing === v.id;
    return (
      <div key={v.id} style={{ borderTop: "1px solid #ebebeb", padding: "8px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(140px, 1fr) 70px minmax(200px, 3fr) 190px 70px", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 13 }}>{v.title}</span>
          <span style={{ fontSize: 13 }}>{money(v.price)}</span>
          {"state" in v && v.state === "byob" ? (
            <s-text color="subdued">Customer picks from {comps.length} products (Simple Bundles mix &amp; match)</s-text>
          ) : (
            <CompList comps={comps} info={info} />
          )}
          <span>
            <s-badge tone={st.tone}>{st.label}</s-badge>
          </span>
          <span style={{ textAlign: "right" }}>
            {"state" in v && v.state === "byob" ? null : (
              <s-button variant="tertiary" onClick={() => setEditing(isOpen ? null : v.id)}>
                {isOpen ? "Close" : "Edit"}
              </s-button>
            )}
          </span>
        </div>
        {isOpen ? (
          <Editor
            productId={productId}
            variant={v}
            initial={v.native.length ? v.native : v.sbComps}
            info={info}
            onClose={() => setEditing(null)}
          />
        ) : null}
      </div>
    );
  };

  return (
    <s-page inlineSize="large" heading="Bundles">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-section>
        <s-stack gap="base">
          <s-stack direction="inline" gap="base" alignItems="center">
            <s-badge tone="success">Native: {counts.native}</s-badge>
            <s-badge tone="warning">Simple Bundles: {counts.simple}</s-badge>
            {counts.differs ? <s-badge tone="critical">Differs: {counts.differs}</s-badge> : null}
            {counts.unflagged ? <s-badge tone="critical">Not active: {counts.unflagged}</s-badge> : null}
            {counts.byob ? <s-badge tone="info">Mix &amp; match: {counts.byob}</s-badge> : null}
            <s-button onClick={pickProduct}>Add bundle</s-button>
            {counts.simple || counts.differs || counts.unflagged ? (
              <s-button variant="primary" loading={busy || undefined} onClick={() => run("convertAll")}>
                {confirm === "convertAll:" ? "Click again to confirm" : "Make all native"}
              </s-button>
            ) : null}
          </s-stack>
          <s-paragraph>
            Bundles are Shopify’s own (native) fixed bundles: when a bundle variant is added to the cart,
            Shopify itself shows its components in checkout and puts them in the order as one group (like
            Simple Bundles). The bundle’s price is split across priced components; $0 components stay $0.
            Stock = the lowest stock of its components. Works on all plans — no app script on the storefront.
          </s-paragraph>
          {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.message}</s-banner> : null}
          <s-banner tone="info">
            Switching from Simple Bundles: “Make native” per product (or all), check the product page, cart
            and checkout, then remove the Simple Bundles app. The Simple Bundles data (used by Bundle Contents)
            is kept and updated when you edit here. Mix &amp; match bundles (“Choose 2…5”) can’t be native
            fixed bundles and stay on Simple Bundles.
          </s-banner>
        </s-stack>
      </s-section>

      {extra ? (
        <s-section heading={`New bundle: ${extra.title}`}>
          <s-paragraph>Edit a variant and add its components. The variant’s own price becomes the bundle price.</s-paragraph>
          {extra.variants.map((v) => variantRow(extra.id, v))}
        </s-section>
      ) : params.get("product") ? (
        <s-section>
          <s-text color="subdued">That product is already in the list below.</s-text>
        </s-section>
      ) : null}

      <s-section>
        <div style={{ marginBottom: 10, maxWidth: 320 }}>
          <input
            placeholder="Search bundles"
            value={q}
            onChange={(e) => setQ(e.currentTarget.value)}
            style={{ width: "100%", padding: "6px 10px", border: "1px solid #c9cccf", borderRadius: 8 }}
          />
        </div>
        {shown.map((p) => {
          const canConvert = p.variants.some((v) => v.state === "simple" || v.state === "differs" || v.state === "unflagged");
          const canRevert = p.variants.some((v) => v.native.length || v.requiresComponents);
          return (
            <div key={p.id} style={{ border: "1px solid #e3e3e3", borderRadius: 12, padding: 14, marginBottom: 14, background: "#fff" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                {p.image ? <img src={p.image} alt="" width={36} height={36} style={{ objectFit: "cover", borderRadius: 6 }} /> : null}
                <s-link href={`shopify://admin/products/${p.id.split("/").pop()}`} target="_top">
                  {p.title}
                </s-link>
                {p.status !== "ACTIVE" ? <s-badge>{p.status.toLowerCase()}</s-badge> : null}
                <span style={{ flex: 1 }} />
                {canConvert ? (
                  <s-button variant="primary" loading={busy || undefined} onClick={() => run("convert", p.id)}>
                    Make native
                  </s-button>
                ) : null}
                {canRevert ? (
                  <s-button variant="tertiary" tone="critical" loading={busy || undefined} onClick={() => run("revert", p.id)}>
                    {confirm === `revert:${p.id}`
                      ? "Click again to confirm"
                      : p.variants.some((v) => v.sbComps.length)
                        ? "Back to Simple Bundles"
                        : "Remove bundle"}
                  </s-button>
                ) : null}
              </div>
              {p.variants.map((v) => variantRow(p.id, v))}
            </div>
          );
        })}
        {!shown.length ? <s-text color="subdued">No bundles found.</s-text> : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
