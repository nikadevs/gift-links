import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useEffect, useMemo, useState } from "react";
import { useFetcher, useLoaderData, useNavigate, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { useAppBridge } from "@shopify/app-bridge-react";
import { authenticate } from "../shopify.server";
import { duplicateBundleProduct } from "../nb-duplicate.server";
import { importAll, loadBundles, loadNativeComponents, loadProductVariants, loadVariantInfo } from "../nb.server";
import { activateBundle, deleteBundle, disableBundle, loadAll, migrateFromV2, saveBundleVariant, syncCartMap } from "../nb-gb.server";
import { ensureOrderWebhook, gbState } from "../gb.server";
import { MAX_COMPONENTS, normalizeComps, parseOwn, itemsToComps, sortForDisplay, type Comp, type VariantInfo } from "../nb.shared";

/**
 * Bundles — the product stays a normal product (Google / Facebook / TikTok);
 * right after an order is placed the app adds the bundle items to the order.
 * See app/nb-gb.server.ts.
 */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const migration = await migrateFromV2(admin).catch((e) => ({ done: false, variants: 0, problems: [(e as Error).message] }));
  {
    // Old Shopify bundles without our settings yet: copy their components into our settings (no visible change)
    const first = await loadBundles(admin);
    if (first.products.some((p) => p.variants.some((v) => v.state === "import"))) await importAll(admin, first.products);
  }
  const { products, info, gb } = await loadAll(admin);
  // cart "Included" block data (only written when it changed)
  const cartMap = await syncCartMap(admin, products).catch((e) => ({ changed: false, variants: 0, error: (e as Error).message }));
  const hook = await ensureOrderWebhook(session.shop, admin).catch(() => null);
  const st = await gbState(session.shop).catch(() => null);
  products.sort((a, b) => a.title.localeCompare(b.title));

  // "Add bundle" for a product that is not a bundle yet
  const extraId = url.searchParams.get("product");
  let extra: null | {
    id: string;
    title: string;
    variants: { id: string; title: string; price: number; native: Comp[]; ownComps: Comp[] }[];
  } = null;
  if (extraId && !products.some((p) => p.id === extraId)) {
    const p = await loadProductVariants(admin, extraId);
    if (p) {
      const nat = await loadNativeComponents(admin, p.variants.nodes.map((v) => v.id));
      extra = {
        id: p.id,
        title: p.title,
        variants: p.variants.nodes.map((v) => ({
          id: v.id,
          title: v.title,
          price: Number(v.price) || 0,
          native: nat[v.id] || [],
          ownComps: itemsToComps(parseOwn(v.own?.value)?.items ?? null),
        })),
      };
    }
  }
  return {
    products: products.map((p) => ({
      ...p,
      variants: p.variants.map(({ own, ...v }) => ({ ...v, ownAt: own?.updatedAt ?? "" })),
    })),
    info,
    extra,
    migrationProblems: migration.problems,
    cartMapError: "error" in cartMap ? cartMap.error : "",
    ready: !!gb.v1migrated,
    orders: {
      hook: hook ?? null,
      lastRunAt: st?.lastRunAt ?? "",
      lastError: st?.lastError ?? "",
      log: (st?.log ?? []).slice(-5).reverse(),
    },
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent") || "");
  try {
    if (intent !== "info") {
      const m = await migrateFromV2(admin);
      if (m.problems.length) throw new Error(`Settings move from Bundles v2 not finished: ${m.problems.join("; ")}`);
    }
    if (intent === "save") {
      const comps = JSON.parse(String(form.get("components") || "[]")) as Comp[];
      await saveBundleVariant(admin, String(form.get("productId")), String(form.get("variantId")), comps);
      return { ok: true as const, message: "Bundle saved" };
    }
    if (intent === "duplicate") {
      const r = await duplicateBundleProduct(admin, String(form.get("productId")));
      return {
        ok: true as const,
        message: `Copy created as Draft${r.bundled ? ` — bundle set for ${r.bundled} variant(s)` : ""}`,
        copyId: r.id,
      };
    }
    if (intent === "info") {
      const ids = JSON.parse(String(form.get("ids") || "[]")) as string[];
      return { ok: true as const, message: "", info: await loadVariantInfo(admin, ids.slice(0, 50)) };
    }
    const { products } = await loadAll(admin);
    const p = products.find((x) => x.id === String(form.get("productId")));
    if (!p) throw new Error("Bundle not found");
    if (intent === "activate") {
      const r = await activateBundle(admin, p);
      return { ok: true as const, message: `Active: ${r.variants} variant(s)` };
    }
    if (intent === "disable") {
      await disableBundle(admin, p);
      return { ok: true as const, message: "Bundle disabled" };
    }
    if (intent === "delete") {
      await deleteBundle(admin, p.id);
      return { ok: true as const, message: "Bundle product deleted" };
    }
    throw new Error("Unknown action");
  } catch (e) {
    return { ok: false as const, message: e instanceof Error ? e.message : String(e) };
  }
};

type LoaderData = ReturnType<typeof useLoaderData<typeof loader>>;
type Product = LoaderData["products"][number];
type Variant = Product["variants"][number];

const STATE: Record<string, { tone: "success" | "warning" | "critical" | "info" | undefined; label: string }> = {
  active: { tone: "success", label: "Active" },
  disabled: { tone: undefined, label: "Disabled" },
  differs: { tone: "critical", label: "Old Shopify bundle — click Activate" },
  import: { tone: "warning", label: "Not saved in app" },
  none: { tone: "warning", label: "No components" },
};

const sortName = (t?: string) => (t ?? "").replace(/^WoodenCrew™\s*\|?\s*/i, "");

function money(n: number) {
  return `$${n.toFixed(2)}`;
}

function CompList({ comps, info }: { comps: Comp[]; info: Record<string, VariantInfo> }) {
  if (!comps.length) return <s-text color="subdued">—</s-text>;
  // icons only (Roman 2026-11-18); name, price and role in the tooltip
  return (
    <div style={{ display: "flex", flexWrap: "wrap", gap: 4, alignItems: "center" }}>
      {sortForDisplay(comps, (c) => info[c.variantId]?.price ?? 0, (c) => sortName(info[c.variantId]?.productTitle)).map((c) => {
        const v = info[c.variantId];
        const label = v ? `${v.productTitle}${v.title && v.title !== "Default Title" ? ` — ${v.title}` : ""}` : c.variantId;
        const tip = `${c.qty > 1 ? `${c.qty} × ` : ""}${label} · ${v ? money(v.price) : "?"}${
          c.noOrder ? " · not added to orders" : ""
        }`;
        return (
          <span key={c.variantId} title={tip} style={{ position: "relative", display: "inline-flex", opacity: c.noOrder ? 0.35 : 1 }}>
            {v?.image ? (
              <img src={v.image} alt={label} width={30} height={30} style={{ objectFit: "cover", borderRadius: 4, display: "block" }} />
            ) : (
              <span style={{ width: 30, height: 30, borderRadius: 4, background: "#f1f1f1", display: "inline-block" }} />
            )}
            {c.qty > 1 ? (
              <span style={{ position: "absolute", right: -3, top: -5, fontSize: 9, fontWeight: 700, background: "#303030", color: "#fff", borderRadius: 8, padding: "0 4px" }}>
                {c.qty}
              </span>
            ) : null}
          </span>
        );
      })}
    </div>
  );
}

function Editor({
  productId,
  variant,
  initial,
  info: info0,
  onClose,
}: {
  productId: string;
  variant: { id: string; title: string; price: number };
  initial: Comp[];
  info: Record<string, VariantInfo>;
  onClose: () => void;
}) {
  const shopify = useAppBridge();
  const save = useFetcher<typeof action>();
  const lookup = useFetcher<typeof action>();
  const [rows, setRows] = useState<Comp[]>(() =>
    sortForDisplay(initial, (c) => info0[c.variantId]?.price ?? 0, (c) => sortName(info0[c.variantId]?.productTitle)),
  );
  const info = useMemo(() => {
    const d = lookup.data;
    return d && "info" in d && d.info ? { ...info0, ...d.info } : info0;
  }, [info0, lookup.data]);
  useEffect(() => {
    if (save.state === "idle" && save.data?.ok) {
      shopify.toast.show(save.data.message);
      onClose();
    }
  }, [save.state, save.data, shopify, onClose]);

  const add = async () => {
    // Product picker (shows product titles and photos; variants can be expanded and picked).
    // The variant picker showed blank rows for single-variant products ("Default Title", no variant photo).
    const picked = await shopify.resourcePicker({ type: "product", action: "select", multiple: true, filter: { variants: true } });
    if (!picked?.length) return;
    const ids = (picked as { id: string; variants?: { id?: string }[] }[])
      .flatMap((p) => (p.variants || []).map((v) => v.id))
      .filter((id): id is string => !!id);
    if (!ids.length) return;
    const next = normalizeComps([...rows, ...ids.map((id) => ({ variantId: id, qty: 1 }))]);
    setRows(next);
    // ask for every row the page didn't load (a new lookup replaces the previous one)
    const unknown = next.map((c) => c.variantId).filter((id) => !info0[id]);
    if (unknown.length) {
      const fd = new FormData();
      fd.set("intent", "info");
      fd.set("ids", JSON.stringify(unknown));
      lookup.submit(fd, { method: "post" });
    }
  };
  const submit = () => {
    const fd = new FormData();
    fd.set("intent", "save");
    fd.set("productId", productId);
    fd.set("variantId", variant.id);
    fd.set("components", JSON.stringify(rows));
    save.submit(fd, { method: "post" });
  };

  return (
    <div style={{ border: "1px solid #c9cccf", borderRadius: 10, padding: 14, margin: "8px 0 14px", background: "#fafbfb" }}>
      <s-stack gap="base">
        {rows.length ? (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ textAlign: "left", color: "#616161" }}>
                <th style={{ padding: "4px 6px" }}>Component</th>
                <th style={{ padding: "4px 6px", width: 90 }}>Own price</th>
                <th style={{ padding: "4px 6px", width: 90 }}>Qty</th>
                <th style={{ padding: "4px 6px", width: 100 }} title="Untick for items already inside the product: shown in the bundle, not added to the order">Add to Order</th>
                <th style={{ width: 80 }} />
              </tr>
            </thead>
            <tbody>
              {rows.map((c, i) => {
                const v = info[c.variantId];
                return (
                  <tr key={c.variantId} style={{ borderTop: "1px solid #ebebeb" }}>
                    <td style={{ padding: "6px" }}>
                      <span style={{ display: "inline-flex", gap: 8, alignItems: "center" }}>
                        {v?.image ? <img src={v.image} alt="" width={28} height={28} style={{ objectFit: "cover", borderRadius: 4 }} /> : null}
                        <span>
                          {v ? v.productTitle : c.variantId}
                          {v && v.title !== "Default Title" ? <span style={{ color: "#616161" }}> — {v.title}</span> : null}
                          {v && v.status !== "ACTIVE" ? <span style={{ color: "#8a6116" }}> ({v.status.toLowerCase()})</span> : null}
                        </span>
                      </span>
                    </td>
                    <td style={{ padding: "6px" }}>{v ? money(v.price) : "…"}</td>
                    <td style={{ padding: "6px" }}>
                      <input
                        type="number"
                        min={1}
                        max={99}
                        value={c.qty}
                        onChange={(e) => {
                          const q = Math.max(1, Math.min(99, Number(e.currentTarget.value) || 1));
                          setRows((r) => r.map((x, j) => (j === i ? { ...x, qty: q } : x)));
                        }}
                        style={{ width: 60, padding: "4px 6px", border: "1px solid #c9cccf", borderRadius: 6 }}
                      />
                    </td>

                    <td style={{ padding: "6px" }}>
                      <input
                        type="checkbox"
                        checked={!c.noOrder}
                        onChange={() => setRows((r) => r.map((x, j) => (j === i ? { ...x, noOrder: !x.noOrder } : x)))}
                      />
                    </td>
                    <td style={{ padding: "6px", textAlign: "right" }}>
                      <s-button variant="tertiary" tone="critical" onClick={() => setRows((r) => r.filter((_, j) => j !== i))}>
                        Remove
                      </s-button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        ) : (
          <s-text color="subdued">No components — nothing is added to this variant’s orders.</s-text>
        )}
        {rows.length > MAX_COMPONENTS ? <s-banner tone="critical">Shopify allows up to {MAX_COMPONENTS} components.</s-banner> : null}
        {save.data && !save.data.ok ? <s-banner tone="critical">{save.data.message}</s-banner> : null}
        <s-stack direction="inline" gap="base">
          <s-button onClick={add}>Add components</s-button>
          <s-button variant="primary" loading={save.state !== "idle" || undefined} onClick={submit} disabled={rows.length > MAX_COMPONENTS || undefined}>
            Save
          </s-button>
          <s-button variant="tertiary" onClick={onClose}>
            Cancel
          </s-button>
        </s-stack>
      </s-stack>
    </div>
  );
}

export default function NativeBundles() {
  const { products, info, extra, migrationProblems, orders, cartMapError } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const shopify = useAppBridge();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const [editing, setEditing] = useState<string | null>(null);
  const [confirm, setConfirm] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const busy = fetcher.state !== "idle";

  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      if (fetcher.data.ok) shopify.toast.show(fetcher.data.message);
    }
  }, [fetcher.state, fetcher.data, shopify]);

  const counts = useMemo(() => {
    const c = { active: 0, disabled: 0, differs: 0, import: 0, none: 0 };
    for (const p of products) for (const v of p.variants) c[v.state] += 1;
    return c;
  }, [products]);

  const run = (intent: string, productId?: string) => {
    const key = `${intent}:${productId || ""}`;
    if ((intent === "disable" || intent === "duplicate" || intent === "delete") && confirm !== key) {
      setConfirm(key);
      return;
    }
    setConfirm(null);
    const fd = new FormData();
    fd.set("intent", intent);
    if (productId) fd.set("productId", productId);
    fetcher.submit(fd, { method: "post" });
  };

  const pickProduct = async () => {
    const picked = await shopify.resourcePicker({ type: "product", action: "select", multiple: false });
    if (picked?.[0]) navigate(`/app/native-bundles?product=${encodeURIComponent(picked[0].id)}`);
  };

  const shown = products.filter((p) => !q || p.title.toLowerCase().includes(q.toLowerCase()));

  const variantRow = (productId: string, v: Variant | (NonNullable<typeof extra>["variants"][number] & { state?: string })) => {
    const state = "state" in v && v.state ? v.state : v.ownComps.length ? (v.native.length ? "differs" : "disabled") : "none";
    const st = STATE[state] ?? { tone: undefined, label: state };
    const comps = v.ownComps.length ? v.ownComps : v.native;
    const isOpen = editing === v.id;
    return (
      <div key={v.id} style={{ borderTop: "1px solid #ebebeb", padding: "8px 0" }}>
        <div style={{ display: "grid", gridTemplateColumns: "minmax(140px, 1fr) 70px minmax(200px, 3fr) 190px 70px", gap: 10, alignItems: "center" }}>
          <span style={{ fontSize: 13 }}>{v.title}</span>
          <span style={{ fontSize: 13 }}>{money(v.price)}</span>
          <CompList comps={comps} info={info} />
          <span>
            <s-stack direction="inline" gap="small-200">
              <s-badge tone={st.tone}>{st.label}</s-badge>
            </s-stack>
          </span>
          <span style={{ textAlign: "right" }}>
            <s-button variant="tertiary" onClick={() => setEditing(isOpen ? null : v.id)}>
              {isOpen ? "Close" : "Edit"}
            </s-button>
          </span>
        </div>
        {isOpen ? (
          <Editor
            productId={productId}
            variant={v}
            initial={comps}
            info={info}
            onClose={() => setEditing(null)}
          />
        ) : null}
      </div>
    );
  };

  return (
    <s-page inlineSize="large" heading="Bundles">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-section>
        <s-stack gap="base">
          <s-stack direction="inline" gap="base" alignItems="center">
            <s-badge tone="success">Active: {counts.active}</s-badge>
            <s-badge>Disabled: {counts.disabled}</s-badge>
            {counts.differs ? <s-badge tone="critical">Changed: {counts.differs}</s-badge> : null}
            {counts.import ? <s-badge tone="warning">Not saved in app: {counts.import}</s-badge> : null}
            <s-button onClick={pickProduct}>Add bundle</s-button>
          </s-stack>
          <s-paragraph>
            Active bundle: the product stays a normal product (it stays in Google, Facebook and TikTok); cart and
            checkout show only the product. Right after an order is placed the app adds every component with “Add to Order” ticked to the
            order (Order Editing, no email to the customer), each with its own name and SKU for the
            warehouse. Priced components get a 100% discount, so the order stays Paid. Disable stops adding items
            to new orders and keeps the settings.
          </s-paragraph>
          <s-text color="subdued">
            Orders: {orders.hook?.ok ? "webhook on (instant)" : "webhook not connected"} · last check{" "}
            {orders.lastRunAt ? new Date(orders.lastRunAt).toLocaleString() : "—"}
            {orders.lastError ? ` · error: ${orders.lastError}` : ""}
            {orders.log[0] ? ` · last: ${orders.log[0].order} ${orders.log[0].ok ? "✓" : "✗"} ${orders.log[0].text}` : ""}
          </s-text>
          {cartMapError ? <s-banner tone="warning">Cart “Included” block data not updated: {cartMapError}</s-banner> : null}
          {migrationProblems.length ? (
            <s-banner tone="critical">Settings from Bundles v2 were not moved (nothing changed): {migrationProblems.join("; ")}</s-banner>
          ) : null}
          {fetcher.data && !fetcher.data.ok ? <s-banner tone="critical">{fetcher.data.message}</s-banner> : null}
        </s-stack>
      </s-section>

      {extra ? (
        <s-section heading={`New bundle: ${extra.title}`}>
          <s-paragraph>
            Edit a variant, add its components, tick “Add to Order” for those the warehouse ships, Save, then Activate.
          </s-paragraph>
          {extra.variants.map((v) => variantRow(extra.id, v))}
        </s-section>
      ) : params.get("product") ? (
        <s-section>
          <s-text color="subdued">That product is already in the list below.</s-text>
        </s-section>
      ) : null}

      <s-section>
        <div style={{ marginBottom: 10, maxWidth: 320 }}>
          <input
            placeholder="Search bundles"
            value={q}
            onChange={(e) => setQ(e.currentTarget.value)}
            style={{ width: "100%", padding: "6px 10px", border: "1px solid #c9cccf", borderRadius: 8 }}
          />
        </div>
        {shown.map((p) => {
          const canActivate = p.variants.some((v) => v.ownComps.length && v.state !== "active");
          const canDisable = p.variants.some((v) => v.state === "active" || v.native.length || v.requiresComponents);
          return (
            <div key={p.id} style={{ border: "1px solid #e3e3e3", borderRadius: 12, padding: 14, marginBottom: 14, background: "#fff" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                {p.image ? <img src={p.image} alt="" width={36} height={36} style={{ objectFit: "cover", borderRadius: 6 }} /> : null}
                <s-link href={`shopify://admin/products/${p.id.split("/").pop()}`} target="_top">
                  {p.title}
                </s-link>
                {p.status !== "ACTIVE" ? <s-badge>{p.status.toLowerCase()}</s-badge> : null}
                <span style={{ flex: 1 }} />
                {canActivate ? (
                  <s-button variant="primary" loading={busy || undefined} onClick={() => run("activate", p.id)}>
                    Activate
                  </s-button>
                ) : null}
                <s-button variant="tertiary" loading={busy || undefined} onClick={() => run("duplicate", p.id)}>
                  {confirm === `duplicate:${p.id}` ? "Click again to duplicate" : "Duplicate"}
                </s-button>
                {canDisable ? (
                  <s-button variant="tertiary" tone="critical" loading={busy || undefined} onClick={() => run("disable", p.id)}>
                    {confirm === `disable:${p.id}` ? "Click again to confirm" : "Disable"}
                  </s-button>
                ) : null}
                <s-button
                  variant="tertiary"
                  tone="critical"
                  disabled={busy || undefined}
                  onClick={() => setConfirm(confirm === `delete:${p.id}` ? null : `delete:${p.id}`)}
                >
                  {confirm === `delete:${p.id}` ? "Cancel deletion" : "Delete bundle"}
                </s-button>
              </div>
              {confirm === `delete:${p.id}` ? (
                <s-banner tone="critical">
                  <s-paragraph>
                    Permanently delete {p.title} and all its variants from Shopify? Component products will stay in your catalog.
                  </s-paragraph>
                  <s-button tone="critical" disabled={busy || undefined} onClick={() => run("delete", p.id)}>
                    Permanently delete product
                  </s-button>
                </s-banner>
              ) : null}
              {p.variants.map((v) => variantRow(p.id, v))}
            </div>
          );
        })}
        {!shown.length ? <s-text color="subdued">No bundles found.</s-text> : null}
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
