import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useState } from "react";
import { useFetcher, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { seoAuth, seoEmbedState } from "../seo/seo-context.server";
import {
  AccessError,
  createRedirect,
  deleteRedirect,
  listLivePaths,
  listRedirects,
  loadEmbedConfig,
  saveEmbedConfig,
  suggestTarget,
} from "../seo/seo-admin.server";
import type { RedirectRow } from "../seo/seo-admin.shared";
import { get404, getLatestReport, save404 } from "../seo/seo-store.server";
import { SeoTabs, ago, pathOf } from "../seo/seo-ui";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, shop, origin } = await seoAuth(request);
  let redirects: RedirectRow[] = [];
  let error = "";
  let live: Array<{ path: string; name: string }> = [];
  try {
    [redirects, live] = await Promise.all([listRedirects(admin), listLivePaths(admin)]);
  } catch (e) {
    error =
      e instanceof AccessError
        ? "Approve the app’s new permissions (Shopify admin → Apps → WoodenCrew Apps) to manage redirects."
        : (e as Error).message;
  }
  const [report, log, embedCfg, embed] = await Promise.all([
    getLatestReport(shop),
    get404(shop),
    loadEmbedConfig(admin).then((r) => r.config).catch(() => null),
    seoEmbedState(shop, origin),
  ]);
  const redirected = new Set(redirects.map((r) => r.path.toLowerCase().replace(/\/$/, "")));

  // broken links: dead target → pages that link to it
  const broken = new Map<string, { target: string; status: string; from: string[] }>();
  for (const f of report?.findings ?? []) {
    if (f.check !== "broken_link" || !f.detail) continue;
    const m = f.detail.match(/^(\S+) → HTTP (.+)$/);
    if (!m) continue;
    const e = broken.get(m[1]) ?? { target: m[1], status: m[2], from: [] };
    if (!e.from.includes(f.url)) e.from.push(f.url);
    broken.set(m[1], e);
  }
  const brokenList = [...broken.values()].map((b) => {
    const path = new URL(b.target).pathname;
    return {
      ...b,
      path,
      redirected: redirected.has(path.toLowerCase().replace(/\/$/, "")),
      suggestion: suggestTarget(path, live),
    };
  });

  const notFound = Object.values(log)
    .filter((e) => !e.ignored)
    .sort((a, b) => b.hits - a.hits || b.last.localeCompare(a.last))
    .slice(0, 300)
    .map((e) => ({
      ...e,
      redirected: redirected.has(e.path.toLowerCase().replace(/\/$/, "")),
      suggestion: suggestTarget(e.path, live),
      refs: Object.entries(e.referrers)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 3)
        .map(([r, n]) => `${r} (${n})`),
    }));

  // redirect health: loops and chains
  const byPath = new Map(redirects.map((r) => [r.path.toLowerCase(), r]));
  const redirectIssues = redirects
    .map((r) => {
      const t = r.target.replace(origin, "").toLowerCase();
      if (t === r.path.toLowerCase()) return { ...r, problem: "Points to itself" };
      if (byPath.has(t)) return { ...r, problem: `Chain: target redirects again to ${byPath.get(t)!.target}` };
      return null;
    })
    .filter(Boolean) as Array<RedirectRow & { problem: string }>;

  return {
    origin,
    error,
    redirects,
    redirectIssues,
    broken: brokenList,
    notFound,
    finishedAt: report?.finishedAt ?? "",
    track404: embedCfg?.track404 ?? true,
    embed,
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, shop, origin } = await seoAuth(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  try {
    if (intent === "create") {
      let path = String(form.get("path") ?? "").trim();
      let target = String(form.get("target") ?? "").trim();
      if (path.startsWith("http")) path = new URL(path).pathname;
      if (target.startsWith(origin)) target = target.slice(origin.length) || "/";
      if (!path.startsWith("/")) return { ok: false, message: "“From” must start with /" };
      if (!target) return { ok: false, message: "“To” is empty" };
      if (path === target) return { ok: false, message: "From and To are the same" };
      await createRedirect(admin, path, target);
      return { ok: true, message: `Redirect ${path} → ${target} created` };
    }
    if (intent === "delete") {
      await deleteRedirect(admin, String(form.get("id")));
      return { ok: true, message: "Redirect deleted" };
    }
    if (intent === "ignore") {
      const log = await get404(shop);
      const p = String(form.get("path"));
      if (log[p]) log[p].ignored = true;
      await save404(shop, log);
      return { ok: true, message: "Ignored" };
    }
    if (intent === "clear404") {
      await save404(shop, {});
      return { ok: true, message: "404 log cleared" };
    }
    if (intent === "track404") {
      const { installationId, config } = await loadEmbedConfig(admin);
      config.track404 = form.get("on") === "1";
      await saveEmbedConfig(admin, installationId, config);
      return { ok: true, message: config.track404 ? "404 tracking on" : "404 tracking off" };
    }
  } catch (e) {
    return {
      ok: false,
      message:
        e instanceof AccessError
          ? "No permission yet — approve the app’s new permissions in Shopify admin → Apps → WoodenCrew Apps."
          : (e as Error).message,
    };
  }
  return { ok: false, message: "Unknown action" };
};

function RedirectForm({ from, suggestion }: { from: string; suggestion: string }) {
  const f = useFetcher<typeof action>();
  const [to, setTo] = useState(suggestion);
  if (f.data?.ok && f.state === "idle") return <span className="ok">{f.data.message}</span>;
  return (
    <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
      <input className="wcs-input" style={{ minWidth: 180 }} value={to} onChange={(e) => setTo(e.target.value)} />
      <s-button onClick={() => f.submit({ intent: "create", path: from, target: to }, { method: "POST" })} {...(f.state !== "idle" ? { disabled: true } : {})}>
        Redirect
      </s-button>
      {f.data && !f.data.ok ? <span className="bad" style={{ fontSize: 12 }}>{f.data.message}</span> : null}
    </div>
  );
}

export default function SeoLinks() {
  const d = useLoaderData<typeof loader>();
  const act = useFetcher<typeof action>();
  const add = useFetcher<typeof action>();
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [confirm, setConfirm] = useState("");
  const redirects = d.redirects.filter(
    (r) => !q || `${r.path} ${r.target}`.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <s-page inlineSize="large" heading="SEO & Speed — Links & 404">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <SeoTabs />
      {d.error ? <s-banner tone="critical">{d.error}</s-banner> : null}
      {act.data && act.state === "idle" ? (
        <s-banner tone={act.data.ok ? "success" : "critical"}>{act.data.message}</s-banner>
      ) : null}

      <s-section heading={`Broken internal links (${d.broken.length})`}>
        {d.broken.length === 0 ? (
          <s-paragraph>{d.finishedAt ? `None found in the last audit (${ago(d.finishedAt)}).` : "Run an audit first."}</s-paragraph>
        ) : (
          <table className="wcs-table">
            <thead>
              <tr>
                <th>Dead URL</th>
                <th>Linked from</th>
                <th>Fix</th>
              </tr>
            </thead>
            <tbody>
              {d.broken.map((b) => (
                <tr key={b.target}>
                  <td className="url">
                    {pathOf(b.target)} <span className="bad">({b.status})</span>
                  </td>
                  <td className="url sub">
                    {b.from.slice(0, 4).map((u) => (
                      <div key={u}>
                        <a href={u} target="_blank" rel="noreferrer">
                          {pathOf(u)}
                        </a>
                      </div>
                    ))}
                    {b.from.length > 4 ? `+${b.from.length - 4} more` : ""}
                  </td>
                  <td>
                    {b.redirected ? (
                      <span className="ok">Redirect exists</span>
                    ) : (
                      <RedirectForm from={b.path} suggestion={b.suggestion} />
                    )}
                    <div className="sub">Better: fix the link itself in the menu / section / description.</div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </s-section>

      <s-section heading={`404 log — real visits to missing pages (${d.notFound.length})`}>
        <div className="wcs-filters" style={{ marginBottom: 8 }}>
          <label style={{ fontSize: 14 }}>
            <input
              type="checkbox"
              checked={d.track404}
              onChange={(e) => act.submit({ intent: "track404", on: e.target.checked ? "1" : "0" }, { method: "POST" })}
            />{" "}
            Record 404 visits
          </label>
          <s-badge tone={d.embed.state === "on" ? "success" : d.embed.state === "off" ? "critical" : "warning"}>
            {`App embed: ${d.embed.state === "on" ? "On" : d.embed.state === "off" ? "Off" : "can’t check"}`}
          </s-badge>
          {d.embed.state !== "on" ? (
            <s-button variant="tertiary" href={d.embed.activateUrl} target="_blank">
              Turn on “SEO & Speed” embed
            </s-button>
          ) : null}
          {d.notFound.length ? (
            <s-button variant="tertiary" tone="critical" onClick={() => act.submit({ intent: "clear404" }, { method: "POST" })}>
              Clear log
            </s-button>
          ) : null}
        </div>
        {d.notFound.length === 0 ? (
          <s-paragraph>
            No 404 visits recorded yet. With the embed on, every visit to a missing page
            (old links, ads, typos) appears here with how often it happens and where it came from.
          </s-paragraph>
        ) : (
          <div className="wcs-scroll">
            <table className="wcs-table">
              <thead>
                <tr>
                  <th>Missing URL</th>
                  <th className="num">Visits</th>
                  <th>Last</th>
                  <th>Came from</th>
                  <th>Fix</th>
                </tr>
              </thead>
              <tbody>
                {d.notFound.map((e) => (
                  <tr key={e.path}>
                    <td className="url">{decodeSafe(e.path)}</td>
                    <td className="num">{e.hits}</td>
                    <td>{ago(e.last)}</td>
                    <td className="sub">{e.refs.join(", ") || "direct / unknown"}</td>
                    <td>
                      {e.redirected ? (
                        <span className="ok">Redirect exists</span>
                      ) : (
                        <RedirectForm from={e.path} suggestion={e.suggestion} />
                      )}
                      <s-button variant="tertiary" onClick={() => act.submit({ intent: "ignore", path: e.path }, { method: "POST" })}>
                        Ignore
                      </s-button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </s-section>

      <s-section heading={`URL redirects (${d.redirects.length})`}>
        {d.redirectIssues.length ? (
          <s-banner tone="warning" heading="Redirects to check">
            {d.redirectIssues.map((r) => `${r.path}: ${r.problem}`).join(" · ")}
          </s-banner>
        ) : null}
        <div className="wcs-filters" style={{ margin: "8px 0" }}>
          <input placeholder="/old-url" value={from} onChange={(e) => setFrom(e.target.value)} />
          <span>→</span>
          <input placeholder="/products/new-url" value={to} onChange={(e) => setTo(e.target.value)} />
          <s-button
            variant="primary"
            onClick={() => add.submit({ intent: "create", path: from, target: to }, { method: "POST" })}
            {...(!from || !to || add.state !== "idle" ? { disabled: true } : {})}
          >
            Add redirect
          </s-button>
          {add.data && add.state === "idle" ? (
            <span className={add.data.ok ? "ok" : "bad"} style={{ fontSize: 13 }}>
              {add.data.message}
            </span>
          ) : null}
          <input style={{ marginLeft: "auto" }} placeholder="Search redirects" value={q} onChange={(e) => setQ(e.target.value)} />
        </div>
        <div className="wcs-scroll">
          <table className="wcs-table">
            <thead>
              <tr>
                <th>From</th>
                <th>To</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {redirects.slice(0, 500).map((r) => (
                <tr key={r.id}>
                  <td className="url">{decodeSafe(r.path)}</td>
                  <td className="url">{decodeSafe(r.target)}</td>
                  <td className="num">
                    <s-button
                      variant="tertiary"
                      tone="critical"
                      onClick={() => {
                        if (confirm === r.id) {
                          setConfirm("");
                          act.submit({ intent: "delete", id: r.id }, { method: "POST" });
                        } else setConfirm(r.id);
                      }}
                    >
                      {confirm === r.id ? "Click again to delete" : "Delete"}
                    </s-button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <s-paragraph>
          <s-text color="subdued">
            Shopify redirects only work for URLs that no longer exist. Don’t send all old URLs
            to the home page — Google treats that like a 404; pick the closest page instead.
          </s-text>
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

function decodeSafe(s: string) {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
