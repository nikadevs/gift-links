import type { HeadersFunction, LinksFunction, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useNavigate, useSearchParams } from "react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { boundary } from "@shopify/shopify-app-react-router/server";
import replayCss from "@rrweb/replay/dist/style.css?url";
import { authenticate } from "../shopify.server";
import { heatOf, heatPages } from "../rec-heat.server";
import { pickSnapshot } from "../rec.server";

/**
 * Session Recordings — click map of one page.
 * Background = the page itself, rebuilt from a recent recording of this page on
 * the chosen device (rrweb snapshot, nothing loaded from the store except its
 * images/CSS). Clicks are placed on the element that was clicked (CSS path),
 * or at the stored page position when that element isn't on the snapshot.
 */
export const links: LinksFunction = () => [{ rel: "stylesheet", href: replayCss }];

const DEVICES = ["mobile", "desktop", "tablet"] as const;

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const sp = new URL(request.url).searchParams;
  const days = [1, 7, 14, 30].includes(Number(sp.get("days"))) ? Number(sp.get("days")) : 7;
  const device = (DEVICES as readonly string[]).includes(sp.get("device") ?? "") ? String(sp.get("device")) : "mobile";
  const pages = (await heatPages(session.shop, days, device)).slice(0, 80);
  const key = sp.get("page") && pages.some((p) => p.key === sp.get("page")) ? String(sp.get("page")) : pages[0]?.key ?? "";
  const heat = key ? await heatOf(session.shop, key, days, device) : null;
  const snap = key ? await pickSnapshot(session.shop, key, device) : null;
  return { days, device, pages, key, heat, snap };
};

type Ev = { type: number; timestamp: number; data?: { width?: number; height?: number } };
type Spot = { x: number; y: number };
type ReplayerT = {
  iframe: HTMLIFrameElement;
  wrapper: HTMLDivElement;
  pause: (t?: number) => void;
  destroy: () => void;
};

const fmtPct = (a: number, b: number) => (b ? `${Math.round((a / b) * 1000) / 10}%` : "—");

/** classic heat palette for alpha 0..255 */
function palette() {
  const c = document.createElement("canvas");
  c.width = 256;
  c.height = 1;
  const g = c.getContext("2d")!;
  const grad = g.createLinearGradient(0, 0, 256, 0);
  grad.addColorStop(0.05, "rgba(0,0,255,0)");
  grad.addColorStop(0.25, "#0040ff");
  grad.addColorStop(0.45, "#00d4ff");
  grad.addColorStop(0.6, "#30ff30");
  grad.addColorStop(0.8, "#ffee00");
  grad.addColorStop(1, "#ff2000");
  g.fillStyle = grad;
  g.fillRect(0, 0, 256, 1);
  return g.getImageData(0, 0, 256, 1).data;
}

function drawHeat(canvas: HTMLCanvasElement, spots: Spot[], radius: number) {
  const ctx = canvas.getContext("2d")!;
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  if (!spots.length) return;
  // stronger single dots when there are few clicks, softer when there are many
  const a = Math.min(0.6, Math.max(0.06, 6 / Math.sqrt(spots.length)));
  for (const s of spots) {
    const g = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, radius);
    g.addColorStop(0, `rgba(0,0,0,${a})`);
    g.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = g;
    ctx.fillRect(s.x - radius, s.y - radius, radius * 2, radius * 2);
  }
  const img = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const pal = palette();
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const al = d[i + 3];
    if (!al) continue;
    const o = Math.min(255, al) * 4;
    d[i] = pal[o];
    d[i + 1] = pal[o + 1];
    d[i + 2] = pal[o + 2];
    d[i + 3] = Math.min(220, 60 + al);
  }
  ctx.putImageData(img, 0, 0);
}

export default function Heatmap() {
  const { days, device, pages, key, heat, snap } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const [params] = useSearchParams();
  const host = useRef<HTMLDivElement>(null);
  const stage = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLCanvasElement>(null);
  const replayer = useRef<ReplayerT | null>(null);
  const [state, setState] = useState<"idle" | "loading" | "ready" | "nosnap" | "error">("idle");
  const [msg, setMsg] = useState("");
  const [geom, setGeom] = useState({ w: 0, h: 0, scale: 1 });
  const [rects, setRects] = useState<Record<string, { x: number; y: number; w: number; h: number } | null>>({});
  const [hover, setHover] = useState("");

  const go = (patch: Record<string, string>) => {
    const next = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) {
      if (v) next.set(k, v);
      else next.delete(k);
    }
    navigate(`?${next.toString()}`);
  };

  // 1) rebuild the page from a recording
  useEffect(() => {
    let dead = false;
    replayer.current?.destroy();
    replayer.current = null;
    if (host.current) host.current.innerHTML = "";
    if (!snap) {
      Promise.resolve().then(() => !dead && setState(key ? "nosnap" : "idle"));
      return;
    }
    (async () => {
      try {
        await Promise.resolve();
        if (dead) return;
        setState("loading");
        const res = await fetch(`/app/rec-events/${snap.sid}?p=${snap.p}`);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const events = ((await res.json()) as Ev[]).sort((a, b) => a.timestamp - b.timestamp);
        const full = events.findIndex((e) => e.type === 2);
        if (full < 0) throw new Error("this recording has no page snapshot");
        const { Replayer } = await import("@rrweb/replay");
        if (dead || !host.current) return;
        const meta = events.find((e) => e.type === 4);
        const w = meta?.data?.width || snap.w || 390;
        const h0 = meta?.data?.height || snap.h || 800;
        const r = new Replayer(events as never, {
          root: host.current,
          skipInactive: true,
          showWarning: false,
          mouseTail: false,
          triggerFocus: false,
        }) as unknown as ReplayerT;
        replayer.current = r;
        // the page as it looked ~1 s after the snapshot (lazy blocks settled)
        r.pause(events[full].timestamp - events[0].timestamp + 1000);
        const doc = r.iframe.contentDocument;
        if (!doc) throw new Error("snapshot could not be rebuilt");
        // full page height at the recorded width
        r.iframe.style.width = `${w}px`;
        r.iframe.setAttribute("width", String(w));
        r.iframe.style.height = `${h0}px`;
        await new Promise((ok) => setTimeout(ok, 400));
        const fullH = Math.min(30000, Math.max(h0, doc.documentElement.scrollHeight, doc.body?.scrollHeight ?? 0));
        r.iframe.style.height = `${fullH}px`;
        r.iframe.setAttribute("height", String(fullH));
        r.wrapper.style.width = `${w}px`;
        r.wrapper.style.height = `${fullH}px`;
        r.iframe.style.pointerEvents = "none";
        await new Promise((ok) => setTimeout(ok, 300));
        if (dead) return;
        const colW = stage.current?.clientWidth ?? w;
        const scale = Math.min(1, colW / w);
        setGeom({ w, h: fullH, scale });
        setState("ready");
      } catch (e) {
        if (!dead) {
          setMsg(e instanceof Error ? e.message : String(e));
          setState("error");
        }
      }
    })();
    return () => {
      dead = true;
    };
  }, [snap, key]);

  // 2) find every clicked element on the rebuilt page and draw the heat
  useEffect(() => {
    if (state !== "ready" || !heat || !canvas.current) return;
    const doc = replayer.current?.iframe.contentDocument;
    if (!doc) return;
    const found: Record<string, { x: number; y: number; w: number; h: number } | null> = {};
    const spots: Spot[] = [];
    const s = geom.scale;
    for (const e of heat.sel) {
      let el: Element | null = null;
      try {
        el = doc.querySelector(e.s);
      } catch {
        el = null;
      }
      const r = el?.getBoundingClientRect();
      if (r && r.width > 1 && r.height > 1) {
        found[e.s] = { x: r.left, y: r.top, w: r.width, h: r.height };
        for (const [rx, ry] of e.p) spots.push({ x: (r.left + rx * r.width) * s, y: (r.top + ry * r.height) * s });
        // more clicks than kept points: spread the rest over the same points
        for (let i = e.p.length; i < e.n && e.p.length; i++) {
          const [rx, ry] = e.p[i % e.p.length];
          spots.push({ x: (r.left + rx * r.width) * s, y: (r.top + ry * r.height) * s });
        }
      } else found[e.s] = null;
    }
    // clicks on elements missing from the snapshot (closed menus, drawers, other variants) → page position
    const placed = new Set(Object.entries(found).filter(([, v]) => v).map(([k]) => k));
    const missingShare = heat.n ? heat.sel.filter((e) => !placed.has(e.s)).reduce((n, e) => n + e.n, 0) / heat.n : 0;
    if (missingShare > 0) {
      const take = Math.round(heat.raw.length * missingShare);
      for (const [x, y, w] of heat.raw.slice(0, take)) {
        const yy = y * (geom.w / w); // same layout scales with width
        if (yy < geom.h) spots.push({ x: x * geom.w * s, y: yy * s });
      }
    }
    const c = canvas.current;
    c.width = Math.round(geom.w * s);
    c.height = Math.round(geom.h * s);
    drawHeat(c, spots.slice(0, 20000), device === "desktop" ? 22 : 16);
    Promise.resolve().then(() => setRects(found));
  }, [state, heat, geom, device]);

  const total = heat?.n ?? 0;
  const top = useMemo(() => (heat?.sel ?? []).slice(0, 40), [heat]);
  const box = hover ? rects[hover] : null;

  return (
    <s-page inlineSize="large" heading="Click map">
      <s-link slot="breadcrumb-actions" href="/app/recordings">
        Session Recordings
      </s-link>
      <style>{`
        .hm{display:grid;grid-template-columns:minmax(0,36fr) minmax(0,64fr);gap:14px;align-items:start}
        @media (max-width:900px){.hm{grid-template-columns:1fr}}
        .hm-side{background:#fff;border:1px solid #e3e3e3;border-radius:12px;padding:12px;display:flex;flex-direction:column;gap:10px;font-size:13px;position:sticky;top:8px}
        .hm-f{display:grid;grid-template-columns:1fr 1fr;gap:8px}
        .hm-list{max-height:62vh;overflow:auto;border:1px solid #e3e3e3;border-radius:8px}
        .hm-row{display:grid;grid-template-columns:22px minmax(0,1fr) 46px 52px;gap:6px;align-items:center;padding:6px 8px;border-bottom:1px solid #f1f1f1;cursor:default}
        .hm-row:hover{background:#f6f6f7}
        .hm-row .l{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
        .hm-row .t{color:#8a8a8a;font-size:11px}
        .hm-row .miss{color:#b0b0b0}
        .hm-bar{height:4px;background:#ff6a00;border-radius:2px;margin-top:3px}
        .hm-stage{background:#f6f6f7;border-radius:12px;overflow:hidden;min-height:420px;position:relative}
        .hm-frame{position:relative;transform-origin:0 0}
        .hm-frame .replayer-wrapper{position:relative!important}
        .hm-frame .replayer-mouse,.hm-frame .replayer-mouse-tail{display:none!important}
        .hm-canvas{position:absolute;left:0;top:0;pointer-events:none}
        .hm-box{position:absolute;border:2px solid #005bd3;border-radius:4px;box-shadow:0 0 0 2000px rgba(0,0,0,.18);pointer-events:none}
        .hm-msg{padding:24px}
      `}</style>
      <div className="hm">
        <aside className="hm-side">
          <s-select label="Page" value={key} onChange={(e) => go({ page: e.currentTarget.value })}>
            {pages.length ? (
              pages.map((p) => (
                <s-option key={p.key} value={p.key}>
                  {p.key} · {p.n} clicks
                </s-option>
              ))
            ) : (
              <s-option value="">No clicks yet</s-option>
            )}
          </s-select>
          <div className="hm-f">
            <s-select label="Device" value={device} onChange={(e) => go({ device: e.currentTarget.value, page: key })}>
              <s-option value="mobile">Mobile</s-option>
              <s-option value="desktop">Desktop</s-option>
              <s-option value="tablet">Tablet</s-option>
            </s-select>
            <s-select label="Period" value={String(days)} onChange={(e) => go({ days: e.currentTarget.value, page: key })}>
              <s-option value="1">Today</s-option>
              <s-option value="7">7 days</s-option>
              <s-option value="14">14 days</s-option>
              <s-option value="30">30 days</s-option>
            </s-select>
          </div>
          <s-text color="subdued">
            {total} clicks on {key || "—"} ({device}). Hover a row to see the element on the page.
          </s-text>
          <div className="hm-list">
            {top.map((e, i) => (
              <div
                key={e.s}
                className="hm-row"
                onMouseEnter={() => setHover(e.s)}
                onMouseLeave={() => setHover("")}
                title={e.s}
              >
                <b>{i + 1}</b>
                <div style={{ minWidth: 0 }}>
                  <div className={`l${rects[e.s] === null ? " miss" : ""}`}>{e.l || `<${e.t}>`}</div>
                  <div className="t">
                    {e.t}
                    {rects[e.s] === null ? " · not on this snapshot" : ""}
                  </div>
                  <div className="hm-bar" style={{ width: `${Math.max(3, (e.n / (top[0]?.n || 1)) * 100)}%` }} />
                </div>
                <span>{e.n}</span>
                <span className="t">{fmtPct(e.n, total)}</span>
              </div>
            ))}
            {!top.length ? <div className="hm-msg">No clicks recorded for this page and device yet.</div> : null}
          </div>
        </aside>
        <div className="hm-stage" ref={stage}>
          {state === "loading" ? (
            <div className="hm-msg">
              <s-spinner accessibilityLabel="Building the page" />
            </div>
          ) : null}
          {state === "nosnap" ? (
            <div className="hm-msg">
              <s-banner tone="warning">
                No recent recording of this page on {device} to draw the page from. The list on the left still shows
                where people click.
              </s-banner>
            </div>
          ) : null}
          {state === "error" ? (
            <div className="hm-msg">
              <s-banner tone="critical">Couldn’t build the page: {msg}</s-banner>
            </div>
          ) : null}
          <div style={{ width: geom.w * geom.scale, height: geom.h * geom.scale, position: "relative", margin: "0 auto" }}>
            <div className="hm-frame" style={{ width: geom.w, height: geom.h, transform: `scale(${geom.scale})` }}>
              <div ref={host} />
            </div>
            <canvas className="hm-canvas" ref={canvas} style={{ width: geom.w * geom.scale, height: geom.h * geom.scale }} />
            {box ? (
              <div
                className="hm-box"
                style={{
                  left: box.x * geom.scale - 3,
                  top: box.y * geom.scale - 3,
                  width: box.w * geom.scale + 6,
                  height: box.h * geom.scale + 6,
                }}
              />
            ) : null}
          </div>
        </div>
      </div>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
