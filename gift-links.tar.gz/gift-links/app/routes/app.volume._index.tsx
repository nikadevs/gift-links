import type {
  ActionFunctionArgs,
  HeadersFunction,
  LoaderFunctionArgs,
} from "react-router";
import { useEffect, useMemo, useState } from "react";
import {
  Link,
  useFetcher,
  useLoaderData,
  useNavigate,
  useRevalidator,
  useSearchParams,
} from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import {
  loadVdConfig,
  newOfferId,
  removeOfferDiscounts,
  saveVdConfig,
  syncOfferDiscounts,
} from "../vd.server";
import { maxPercent, offerStatus } from "../vd.shared";
import { getEvents, getVdStats, summarizeOffers } from "../vd-stats.server";
import { loadShopDomain } from "../campaigns.server";
import {
  VD_EMBED_MARKERS,
  checkEmbed,
  embedActivateUrl,
} from "../embed-status.server";

const PERIODS = [7, 30, 60];

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const url = new URL(request.url);
  const d = Number(url.searchParams.get("days"));
  const days = PERIODS.includes(d) ? d : 30;

  const [{ config }, stats, events, domain] = await Promise.all([
    loadVdConfig(admin),
    getVdStats(admin),
    getEvents(session.shop),
    loadShopDomain(admin),
  ]);
  const embed = await checkEmbed(domain, VD_EMBED_MARKERS);
  const rows = summarizeOffers(stats, events, config.offers, days);
  const total = Object.values(rows).reduce((s, r) => s + r.revenue, 0);
  return {
    days,
    embed: {
      state: embed,
      // eslint-disable-next-line no-undef
      activateUrl: embedActivateUrl(session.shop, process.env.SHOPIFY_API_KEY || "", "volume-discounts"),
    },
    stats: {
      status: stats.status,
      error: stats.error ?? "",
      computedAt: stats.computedAt ?? "",
      currency: stats.currency ?? "USD",
    },
    total: Math.round(total * 100) / 100,
    offers: config.offers.map((o) => ({
      id: o.id,
      name: o.name,
      status: offerStatus(o),
      upTo: maxPercent(o),
      gifts: o.tiers.reduce((n, t) => n + t.gifts.length, 0),
      images: o.productImages,
      titles: o.productTitles,
      discounts: o.discountIds.length,
      discountError: o.discountError,
      ...rows[o.id],
    })),
  };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const form = await request.formData();
  const intent = String(form.get("intent"));
  const id = String(form.get("id"));

  if (intent === "refresh-stats") {
    const domain = await loadShopDomain(admin);
    await Promise.all([
      getVdStats(admin, true),
      getEvents(session.shop),
      checkEmbed(domain, VD_EMBED_MARKERS, true),
    ]);
    return { ok: true, intent, error: "" };
  }

  const { installationId, config } = await loadVdConfig(admin);
  const offer = config.offers.find((o) => o.id === id);
  if (!offer) return { ok: false, intent, error: "Offer not found" };
  let error = "";

  if (intent === "delete") {
    const left = await removeOfferDiscounts(admin, offer);
    if (left.length) error = "Some Shopify discounts could not be deleted — check Shopify → Discounts";
    config.offers = config.offers.filter((o) => o.id !== id);
  } else if (intent === "toggle") {
    const turnOn = !offer.active;
    if (turnOn) {
      const clash = config.offers.find(
        (x) => x.id !== id && x.active && offerStatus(x) !== "Ended" && x.productIds.some((p) => offer.productIds.includes(p)),
      );
      if (clash)
        return { ok: false, intent, error: `A product is already in the active offer “${clash.name}”` };
    }
    const synced = await syncOfferDiscounts(
      admin,
      { ...offer, active: turnOn, updatedAt: new Date().toISOString() },
      offer.discountIds,
    );
    error = synced.discountError;
    config.offers = config.offers.map((o) => (o.id === id ? synced : o));
  } else if (intent === "duplicate") {
    config.offers.push({
      ...offer,
      id: newOfferId(),
      name: `${offer.name} (copy)`,
      active: false,
      discountIds: [],
      discountError: "",
      updatedAt: new Date().toISOString(),
    });
  }
  await saveVdConfig(admin, installationId, config);
  return { ok: !error, intent, error };
};

function ago(iso: string) {
  if (!iso) return "never";
  const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
}

const TABS = ["All", "Active", "Inactive", "Scheduled"] as const;

const CSS = `
.vd-card{background:#fff;border-radius:12px;box-shadow:0 1px 0 rgba(26,26,26,.07),0 0 0 1px rgba(26,26,26,.08);overflow:hidden}
.vd-top{display:flex;gap:12px;align-items:center;padding:12px}
.vd-search{flex:1;display:flex;align-items:center;gap:8px;border:1px solid #8a8a8a;border-radius:8px;padding:0 10px;height:36px}
.vd-search input{border:0;outline:0;flex:1;font-size:14px;background:transparent}
.vd-tabs{display:flex;gap:4px;padding:6px 12px;border-top:1px solid #ebebeb;border-bottom:1px solid #ebebeb;background:#fafafa}
.vd-tab{border:0;background:transparent;padding:6px 12px;border-radius:8px;font-size:14px;color:#303030;cursor:pointer}
.vd-tab.on{background:#e3e3e3;font-weight:550}
.vd-table{width:100%;border-collapse:collapse;font-size:14px;line-height:20px;color:#303030}
.vd-table th{font-weight:550;text-align:left;color:#616161;background:#f7f7f7;padding:10px 12px;border-bottom:1px solid #e3e3e3;white-space:nowrap}
.vd-table td{padding:14px 12px;border-bottom:1px solid #ebebeb;vertical-align:middle}
.vd-table tr:last-child td{border-bottom:0}
.vd-table tbody tr:hover td{background:#fafafa}
.vd-table .num{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.vd-table a.name{color:#303030;text-decoration:none;font-weight:650}
.vd-table a.name:hover{text-decoration:underline}
.vd-thumbs{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;max-width:300px}
.vd-thumbs img{width:44px;height:44px;object-fit:contain;border:1px solid #e3e3e3;border-radius:8px;background:#fff}
.vd-more{font-size:13px;color:#616161;margin-top:6px}
.vd-chip{display:inline-block;margin-top:4px;background:#f1f1f1;border-radius:8px;padding:2px 8px;font-size:13px;color:#616161}
.vd-acts{display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap}
.vd-err{color:#8e1f0b;font-size:13px;margin-top:4px}
.vd-empty{padding:40px 16px;text-align:center;color:#616161}
`;

export default function VolumeDiscounts() {
  const { offers, stats, days, embed, total } = useLoaderData<typeof loader>();
  const fetcher = useFetcher<typeof action>();
  const navigate = useNavigate();
  const revalidator = useRevalidator();
  const [, setParams] = useSearchParams();
  const [confirmId, setConfirmId] = useState("");
  const [q, setQ] = useState("");
  const [tab, setTab] = useState<(typeof TABS)[number]>("All");

  const money = (n: number) => {
    try {
      return new Intl.NumberFormat("en-US", {
        style: "currency",
        currency: stats.currency || "USD",
      }).format(n);
    } catch {
      return `$${n.toFixed(2)}`;
    }
  };

  const running = stats.status === "running";
  useEffect(() => {
    if (!running) return;
    const t = setInterval(() => {
      if (revalidator.state === "idle") revalidator.revalidate();
    }, 4000);
    return () => clearInterval(t);
  }, [running, revalidator]);

  const submit = (intent: string, id = "") =>
    fetcher.submit({ intent, id }, { method: "POST" });

  const list = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return offers.filter((o) => {
      if (tab === "Active" && o.status !== "Active") return false;
      if (tab === "Inactive" && !["Inactive", "Ended"].includes(o.status)) return false;
      if (tab === "Scheduled" && o.status !== "Scheduled") return false;
      if (!needle) return true;
      return (
        o.name.toLowerCase().includes(needle) ||
        o.id.toLowerCase().includes(needle) ||
        o.titles.some((t) => t.toLowerCase().includes(needle))
      );
    });
  }, [offers, q, tab]);

  const statusLine =
    stats.status === "running"
      ? "Collecting orders…"
      : stats.status === "no_access"
        ? "No access to orders yet"
        : stats.status === "error"
          ? `Could not update: ${stats.error}`
          : `Orders updated ${ago(stats.computedAt)}`;

  return (
    <s-page inlineSize="large" heading="Volume Discounts">
      <s-link slot="breadcrumb-actions" href="/app">
        WoodenCrew Apps
      </s-link>
      <s-button slot="primary-action" variant="primary" onClick={() => navigate("/app/volume/new")}>
        Create Volume Discount
      </s-button>

      {fetcher.data?.error ? (
        <s-banner tone="critical" heading="Not done">
          {fetcher.data.error}
        </s-banner>
      ) : null}

      {embed.state === "off" ? (
        <s-banner tone="warning" heading="The Volume Discounts block is switched off in your theme">
          Active offers still give their Shopify discounts in the cart, but shoppers don’t see the
          block and free gifts are not added. Turn on the app embed “Volume Discounts” in the theme
          editor and press Save.{" "}
          <s-link href={embed.activateUrl} target="_blank">
            Turn on
          </s-link>
        </s-banner>
      ) : null}

      <s-section>
        <s-stack direction="inline" gap="base" alignItems="center" justifyContent="space-between">
          <s-stack direction="inline" gap="small-200" alignItems="center">
            {PERIODS.map((p) => (
              <s-button
                key={p}
                variant={p === days ? "primary" : "secondary"}
                onClick={() => setParams({ days: String(p) })}
              >
                {`Last ${p} days`}
              </s-button>
            ))}
            <s-badge tone="success">{`${money(total)} added revenue`}</s-badge>
          </s-stack>
          <s-stack direction="inline" gap="small-200" alignItems="center">
            {embed.state === "on" ? (
              <s-badge tone="success">App embed: On</s-badge>
            ) : embed.state === "off" ? (
              <s-badge tone="critical">App embed: Off</s-badge>
            ) : (
              <s-badge tone="warning">App embed: can’t check</s-badge>
            )}
            <s-text color="subdued">{statusLine}</s-text>
            <s-button
              variant="tertiary"
              onClick={() => submit("refresh-stats")}
              {...(running || fetcher.state !== "idle" ? { disabled: true } : {})}
            >
              Refresh
            </s-button>
          </s-stack>
        </s-stack>
      </s-section>

      <style>{CSS}</style>
      <div className="vd-card">
        <div className="vd-top">
          <div className="vd-search">
            <svg width="16" height="16" viewBox="0 0 20 20" aria-hidden="true">
              <path
                fill="#616161"
                d="M8.5 3a5.5 5.5 0 0 1 4.38 8.83l3.4 3.4a.75.75 0 1 1-1.06 1.06l-3.4-3.4A5.5 5.5 0 1 1 8.5 3Zm0 1.5a4 4 0 1 0 0 8 4 4 0 0 0 0-8Z"
              />
            </svg>
            <input
              placeholder="Search by name, product or ID"
              aria-label="Search offers"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </div>
        </div>
        <div className="vd-tabs">
          {TABS.map((t) => (
            <button key={t} type="button" className={`vd-tab${tab === t ? " on" : ""}`} onClick={() => setTab(t)}>
              {t}
            </button>
          ))}
        </div>
        {list.length === 0 ? (
          <div className="vd-empty">
            {offers.length === 0 ? (
              <>
                <p>No volume discounts yet. Create “Buy 2 with 20% off, Buy 3 with 30% off” blocks with free gifts.</p>
                <s-button variant="primary" onClick={() => navigate("/app/volume/new")}>
                  Create Volume Discount
                </s-button>
              </>
            ) : (
              <p>No offers match.</p>
            )}
          </div>
        ) : (
          <table className="vd-table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Status</th>
                <th>Type</th>
                <th className="num">Impressions</th>
                <th className="num">Clicks</th>
                <th className="num">Click Rate</th>
                <th className="num">Orders</th>
                <th className="num">Revenue</th>
                <th className="num">Actions</th>
              </tr>
            </thead>
            <tbody>
              {list.map((o) => (
                <tr key={o.id}>
                  <td>
                    <Link className="name" to={`/app/volume/${o.id}`}>
                      {o.name}
                    </Link>
                    <div className="vd-thumbs">
                      {o.images.slice(0, 10).map((src, i) =>
                        src ? <img key={i} src={src} alt={o.titles[i] ?? ""} title={o.titles[i] ?? ""} /> : null,
                      )}
                    </div>
                    {o.images.length > 10 ? <div className="vd-more">{`+ ${o.images.length - 10} items`}</div> : null}
                    {o.discountError ? <div className="vd-err">{o.discountError}</div> : null}
                  </td>
                  <td>
                    <s-badge
                      tone={o.status === "Active" ? "success" : o.status === "Scheduled" ? "info" : "neutral"}
                    >
                      {o.status}
                    </s-badge>
                  </td>
                  <td>
                    <div>Volume Discount</div>
                    <span className="vd-chip">
                      {o.upTo > 0 ? `Up to ${o.upTo}% off` : "No discount"}
                      {o.gifts ? " + gifts" : ""}
                    </span>
                  </td>
                  <td className="num">{(o.impressions ?? 0).toLocaleString("en-US")}</td>
                  <td className="num">{(o.clicks ?? 0).toLocaleString("en-US")}</td>
                  <td className="num">
                    {o.impressions ? `${Math.round((o.clicks / o.impressions) * 10000) / 100}%` : "—"}
                  </td>
                  <td className="num">{(o.orders ?? 0).toLocaleString("en-US")}</td>
                  <td className="num">{money(o.revenue ?? 0)}</td>
                  <td>
                    <div className="vd-acts">
                      <s-button onClick={() => submit("toggle", o.id)}>
                        {o.status === "Inactive" ? "Activate" : "Deactivate"}
                      </s-button>
                      <s-button variant="tertiary" onClick={() => submit("duplicate", o.id)}>
                        Duplicate
                      </s-button>
                      <s-button
                        tone="critical"
                        variant="tertiary"
                        onClick={() => {
                          if (confirmId === o.id) {
                            setConfirmId("");
                            submit("delete", o.id);
                          } else setConfirmId(o.id);
                        }}
                      >
                        {confirmId === o.id ? "Click again to delete" : "Delete"}
                      </s-button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
      <s-box padding="base">
        <s-text color="subdued">
          Impressions and clicks are counted by the storefront block. Orders and revenue = order
          lines that got this offer’s Shopify discount (last 60 days of orders).
        </s-text>
      </s-box>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
