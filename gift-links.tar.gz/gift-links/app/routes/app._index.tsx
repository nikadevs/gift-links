import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useNavigate } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { campaignStatus, loadConfig } from "../campaigns.server";
import { loadUpsellConfig } from "../upsells.server";

/** WoodenCrew Apps — home: one card per module. */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const [{ config: gifts }, { config: upsells }] = await Promise.all([
    loadConfig(admin),
    loadUpsellConfig(admin),
  ]);
  return {
    gifts: {
      total: gifts.campaigns.length,
      live: gifts.campaigns.filter((c) => campaignStatus(c) === "Live").length,
    },
    upsells: {
      total: upsells.offers.length,
      live: upsells.offers.filter((o) => o.active).length,
    },
  };
};

type ModuleCard = {
  title: string;
  text: string;
  href: string;
  embed: string;
  live: number;
  total: number;
  unit: string;
};

export default function Home() {
  const { gifts, upsells } = useLoaderData<typeof loader>();
  const navigate = useNavigate();

  const modules: ModuleCard[] = [
    {
      title: "Gift Links",
      text: "A free gift lands in the cart from an email link or a discount code.",
      href: "/app/gifts",
      embed: "Gift Links",
      live: gifts.live,
      total: gifts.total,
      unit: "campaign",
    },
    {
      title: "Checkbox Upsell",
      text: "Checkboxes above Add to cart (Skip The Line, gift box…). Ticked items go into the cart with the product.",
      href: "/app/upsells",
      embed: "Checkbox Upsell",
      live: upsells.live,
      total: upsells.total,
      unit: "checkbox",
    },
  ];

  return (
    <s-page heading="WoodenCrew Apps">
      <s-section heading="Modules">
        <s-stack direction="block" gap="base">
          {modules.map((m) => (
            <s-box
              key={m.href}
              padding="base"
              border="base"
              borderRadius="base"
            >
              <s-stack direction="block" gap="base">
                <s-stack direction="block" gap="small-200">
                  <s-stack direction="inline" gap="small-200" alignItems="center">
                    <s-heading>{m.title}</s-heading>
                    <s-badge tone={m.live ? "success" : "neutral"}>
                      {`${m.live} live / ${m.total} ${m.unit}${m.total === 1 ? "" : "s"}`}
                    </s-badge>
                  </s-stack>
                  <s-text color="subdued">{m.text}</s-text>
                  <s-text color="subdued">
                    {`Theme app embed: “${m.embed}”`}
                  </s-text>
                </s-stack>
                <s-stack direction="inline" gap="base">
                  <s-button variant="primary" onClick={() => navigate(m.href)}>
                    Open
                  </s-button>
                </s-stack>
              </s-stack>
            </s-box>
          ))}
        </s-stack>
      </s-section>

      <s-section slot="aside" heading="One app, many tools">
        <s-paragraph>
          Each module keeps its own settings and its own app embed in the theme
          editor, so you can switch one off without touching the others.
        </s-paragraph>
        <s-paragraph>
          <s-link href="/app/setup">Setup guide</s-link>
        </s-paragraph>
      </s-section>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
