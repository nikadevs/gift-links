import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { ReactNode } from "react";
import { Link, useLoaderData } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { campaignStatus, loadConfig } from "../campaigns.server";
import { loadUpsellConfig } from "../upsells.server";
import { loadVdConfig } from "../vd.server";
import { offerStatus } from "../vd.shared";
import { getLatestReport } from "../seo/seo-store.server";

/** WoodenCrew Apps — home: list of modules (same look as Vitals → Apps). */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin, session } = await authenticate.admin(request);
  const [{ config: gifts }, { config: upsells }, { config: vd }, seo] = await Promise.all([
    loadConfig(admin),
    loadUpsellConfig(admin),
    loadVdConfig(admin).catch(() => ({ config: { version: 1 as const, offers: [] } })),
    getLatestReport(session.shop),
  ]);
  return {
    gifts: gifts.campaigns.filter((c) => campaignStatus(c) === "Live").length,
    upsells: upsells.offers.filter((o) => o.active).length,
    volume: vd.offers.filter((o) => offerStatus(o) === "Active").length,
    seo: Boolean(seo),
  };
};

const STROKE = {
  fill: "none",
  stroke: "#F05A1A",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

const icons: Record<string, ReactNode> = {
  gift: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="9" y="19" width="30" height="21" rx="1.5" />
      <rect x="7" y="13" width="34" height="7" rx="1.5" />
      <path d="M24 13v27M24 13c-2-5-9-7-10-3s5 4 10 3c2-5 9-7 10-3s-5 4-10 3" />
    </svg>
  ),
  checkbox: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="8" y="10" width="11" height="11" rx="2" />
      <path d="m10.5 15.5 2.5 2.5 4.5-5" />
      <path d="M24 13h16M24 18h10" />
      <rect x="8" y="27" width="11" height="11" rx="2" />
      <path d="M24 30h16M24 35h10" />
    </svg>
  ),
  volume: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M6 18.5V14h30l3 4.5" />
      <path d="M6 18.5a4 4 0 0 1 0 8V35h36v-8.5a4 4 0 0 1 0-8V18.5Z" />
      <path d="m19 31 10-9" />
      <circle cx="19.5" cy="22.5" r="2" />
      <circle cx="28.5" cy="30.5" r="2" />
    </svg>
  ),
  seo: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M8 32a16 16 0 1 1 32 0" />
      <path d="m24 32 7-9" />
      <circle cx="24" cy="32" r="2.2" />
      <path d="M12 26.5l2 .8M16.5 19.5l1.4 1.6M24 16.5v2.2M34 22l-1.6 1.2" />
      <path d="M10 38h28" />
    </svg>
  ),
};

type Mod = { href: string; icon: string; title: string; text: string; active: boolean };

const CSS = `
.wcm{background:#fff;border-radius:12px;box-shadow:0 1px 0 rgba(26,26,26,.07),0 0 0 1px rgba(26,26,26,.08);overflow:hidden}
.wcm a{display:flex;align-items:center;gap:20px;padding:18px 20px;border-top:1px solid #ebebeb;text-decoration:none;color:#303030}
.wcm a:first-child{border-top:0}
.wcm a:hover{background:#fafafa}
.wcm .ic{flex:none;width:64px;height:64px;border-radius:14px;background:#FEF3EC;border:1px solid #FBE3D5;display:grid;place-items:center}
.wcm .ic svg{width:40px;height:40px}
.wcm .tx{flex:1;min-width:0}
.wcm .tt{display:block;font-size:17px;font-weight:550;line-height:24px;color:#1a1a1a}
.wcm .ds{font-size:14px;line-height:20px;color:#4a4a4a;margin-top:4px}
.wcm .on{flex:none;background:#B4FED2;color:#0C5132;font-weight:550;font-size:14px;border-radius:10px;padding:4px 12px}
@media (max-width:600px){.wcm a{gap:12px;padding:14px}.wcm .ic{width:48px;height:48px}.wcm .ic svg{width:30px;height:30px}}
`;

export default function Home() {
  const d = useLoaderData<typeof loader>();

  const modules: Mod[] = [
    {
      href: "/app/volume",
      icon: "volume",
      title: "Volume Discounts",
      text: "Increase your store’s average order value with “Buy 2, save 20%” tiers and free gifts, with variant swatches for every item.",
      active: d.volume > 0,
    },
    {
      href: "/app/upsells",
      icon: "checkbox",
      title: "Checkbox Upsell",
      text: "Checkboxes above Add to cart (Skip The Line, gift box…). Ticked items go into the cart together with the product.",
      active: d.upsells > 0,
    },
    {
      href: "/app/gifts",
      icon: "gift",
      title: "Gift Links",
      text: "A free gift lands in the cart automatically from an email link or a discount code.",
      active: d.gifts > 0,
    },
    {
      href: "/app/seo",
      icon: "seo",
      title: "SEO & Speed",
      text: "Find and fix SEO and speed problems: site audit, PageSpeed and Core Web Vitals, meta tags, image ALT, broken links and redirects.",
      active: d.seo,
    },
  ];

  return (
    <s-page inlineSize="large" heading="WoodenCrew Apps">
      <style>{CSS}</style>
      <div className="wcm">
        {modules.map((m) => (
          <Link key={m.href} to={m.href}>
            <span className="ic">{icons[m.icon]}</span>
            <span className="tx">
              <span className="tt">{m.title}</span>
              <span className="ds" style={{ display: "block" }}>
                {m.text}
              </span>
            </span>
            {m.active ? <span className="on">Active</span> : null}
          </Link>
        ))}
      </div>
      <s-box padding="base">
        <s-text color="subdued">
          Each module has its own app embed in the theme editor, so you can switch one off without touching the others.{" "}
          <s-link href="/app/setup">Setup guide</s-link>
        </s-text>
      </s-box>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
