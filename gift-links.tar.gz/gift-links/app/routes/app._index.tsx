import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import type { ReactNode } from "react";
import { useMemo, useState } from "react";
import { Link, useFetcher, useLoaderData, useNavigate } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
/**
 * WoodenCrew Apps — module directory. Module settings live in their own routes.
 */

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];
type Row = { key: string; icon: string; title: string; sub: string; editUrl: string };
const MODULES: Row[] = [
  { key: "m:features", icon: "bestsellers", title: "Features with Image Slider", sub: "Product-specific icons, text and photo slider", editUrl: "/app/features" },
  { key: "m:trustpilot", icon: "seo", title: "Trustpilot Reviews", sub: "Daily rating cache and customer photo collage", editUrl: "/app/trustpilot" },
  { key: "m:volume", icon: "volume", title: "Volume Discounts", sub: "Quantity discounts", editUrl: "/app/volume" },
  { key: "m:upsells", icon: "checkbox", title: "Checkbox Upsell", sub: "Optional additions to the cart", editUrl: "/app/upsells" },
  { key: "m:gifts", icon: "gift", title: "Gift Links", sub: "Gift campaigns and links", editUrl: "/app/gifts" },
  { key: "m:tracking", icon: "links", title: "Tracking", sub: "Order tracking, last-mile numbers, Omnisend & PayPal — replaces Track123", editUrl: "/app/tracking" },
  { key: "m:native-bundles", icon: "gift", title: "Bundles", sub: "Product bundles (Shopify native)", editUrl: "/app/native-bundles" },
  { key: "m:bundles", icon: "gift", title: "Bundle Contents", sub: "What's included in a product bundle", editUrl: "/app/bundles" },
  { key: "m:sticky-atc", icon: "sticky", title: "Sticky Add to Cart", sub: "Add to cart button that stays at the bottom of product pages", editUrl: "/app/sticky-atc" },
  { key: "m:content-protection", icon: "shield", title: "Content Protection", sub: "Block copying, right click and image dragging", editUrl: "/app/content-protection" },
  { key: "m:best-sellers", icon: "bestsellers", title: "Best Sellers Protection", sub: "Hide the \"Best selling\" sort option from competitors", editUrl: "/app/best-sellers" },
  { key: "m:sale-banner", icon: "volume", title: "Sale Banner", sub: "Sale badge, heading and countdown on product pages", editUrl: "/app/sale-banner" },
  { key: "m:cart-summary", icon: "checkout", title: "Cart Summary", sub: "Subtotal, discount codes, shipping and Total on the cart page", editUrl: "/app/cart-summary" },
  { key: "m:favicon-cart", icon: "favicon", title: "Favicon Cart Count", sub: "Number of cart items on the browser tab icon", editUrl: "/app/favicon-cart" },
  { key: "m:quick-links", icon: "links", title: "Quick Links", sub: "Admin links on the storefront, only for you", editUrl: "/app/quick-links" },
  { key: "m:currency-converter", icon: "currency", title: "Currency Converter", sub: "Currency switcher in the header (Shopify Markets prices)", editUrl: "/app/currency-converter" },
  { key: "m:checkout-buttons", icon: "checkout", title: "Hide Dynamic Checkout Buttons", sub: "Hide express-pay buttons on product pages and cart", editUrl: "/app/checkout-buttons" },
  { key: "m:recordings", icon: "recordings", title: "Session Recordings", sub: "Replay how visitors use the store", editUrl: "/app/recordings" },
  { key: "m:seo", icon: "seo", title: "SEO & Speed", sub: "Search visibility and storefront performance", editUrl: "/app/seo" },
];

const PINS_NS = "wc_home";
const PINS_KEY = "pins";

async function loadPins(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query HomePins { currentAppInstallation { id metafield(namespace: "${PINS_NS}", key: "${PINS_KEY}") { value } } }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let pins: string[] = [];
  try {
    const v = JSON.parse(inst?.metafield?.value || "[]");
    if (Array.isArray(v)) pins = v.map(String);
  } catch {
    pins = [];
  }
  return { ownerId: inst?.id ?? "", pins };
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const { pins } = await loadPins(admin);
  return { rows: MODULES, pins };
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const { admin } = await authenticate.admin(request);
  const form = await request.formData();
  if (String(form.get("intent")) !== "pin") return { ok: false };
  const key = String(form.get("key") || "");
  const { ownerId, pins } = await loadPins(admin);
  if (!ownerId || !key) return { ok: false };
  const next = pins.includes(key) ? pins.filter((p) => p !== key) : [...pins, key];
  const res = await admin.graphql(
    `#graphql
    mutation HomePinsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { message } }
    }`,
    {
      variables: {
        metafields: [{ ownerId, namespace: PINS_NS, key: PINS_KEY, type: "json", value: JSON.stringify(next) }],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  return { ok: !(json.data?.metafieldsSet?.userErrors ?? []).length };
};

/* ---------- icons (Vitals-style orange line icons) ---------- */

const STROKE = {
  fill: "none",
  stroke: "#E8660E",
  strokeWidth: 1.7,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

const icons: Record<string, ReactNode> = {
  gift: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="9" y="19" width="30" height="21" rx="1.5" />
      <rect x="7" y="13" width="34" height="7" rx="1.5" />
      <path d="M24 13v27M24 13c-2-5-9-7-10-3s5 4 10 3c2-5 9-7 10-3s-5 4-10 3" />
    </svg>
  ),
  checkbox: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="8" y="10" width="11" height="11" rx="2" />
      <path d="m10.5 15.5 2.5 2.5 4.5-5" />
      <path d="M24 13h16M24 18h10" />
      <rect x="8" y="27" width="11" height="11" rx="2" />
      <path d="M24 30h16M24 35h10" />
    </svg>
  ),
  volume: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M8 17.5 34 11l2 6.5" />
      <path d="M5 19.5h38v6a3.5 3.5 0 0 0 0 7v6H5v-6a3.5 3.5 0 0 0 0-7Z" />
      <path d="m20 34 8-10" />
      <circle cx="20" cy="25.5" r="1.8" />
      <circle cx="28" cy="32.5" r="1.8" />
    </svg>
  ),
  shield: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M24 5 9 11v11c0 9.5 6.4 17.6 15 21 8.6-3.4 15-11.5 15-21V11Z" />
      <rect x="18" y="22" width="12" height="9" rx="1.5" />
      <path d="M20.5 22v-3a3.5 3.5 0 0 1 7 0v3" />
    </svg>
  ),
  favicon: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="5" y="9" width="38" height="30" rx="3" />
      <path d="M5 17h38" />
      <rect x="10" y="22" width="12" height="12" rx="2" />
      <circle cx="12" cy="32" r="5" fill="currentColor" stroke="none" />
      <path d="M26 26h12M26 31h8" />
    </svg>
  ),
  bestsellers: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M8 12h18M8 20h12M8 28h8" />
      <path d="M34 9v26M28 29l6 6 6-6" />
      <path d="M6 40 42 6" />
    </svg>
  ),
  links: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="5" y="9" width="38" height="30" rx="3" />
      <path d="M5 17h38" />
      <path d="M10 13h3M16 13h3M22 13h3" />
      <path d="M21 31.5l-1.8 1.8a3.5 3.5 0 0 1-5-5l3.6-3.6a3.5 3.5 0 0 1 5 0" />
      <path d="M27 24.5l1.8-1.8a3.5 3.5 0 0 1 5 5l-3.6 3.6a3.5 3.5 0 0 1-5 0" />
    </svg>
  ),
  currency: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <circle cx="18" cy="20" r="11" />
      <circle cx="30" cy="28" r="11" />
      <path d="M18 14v12M15 16.5h4.5a2 2 0 0 1 0 4h-3a2 2 0 0 0 0 4H21" />
    </svg>
  ),
  sticky: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="11" y="5" width="26" height="38" rx="4" />
      <rect x="15" y="31" width="18" height="7" rx="3.5" />
      <path d="M17 13h14M17 19h10" />
    </svg>
  ),
  checkout: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="7" y="15" width="34" height="18" rx="3" />
      <path d="M18 24h12" />
      <path d="M9 41 39 7" />
    </svg>
  ),
  recordings: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <rect x="6" y="10" width="36" height="24" rx="3" />
      <path d="m21 17 8 5-8 5Z" />
      <path d="M6 40h36" />
      <circle cx="17" cy="40" r="2" />
    </svg>
  ),
  seo: (
    <svg viewBox="0 0 48 48" {...STROKE}>
      <path d="M8 32a16 16 0 1 1 32 0" />
      <path d="m24 32 7-9" />
      <circle cx="24" cy="32" r="2.2" />
      <path d="M12 26.5l2 .8M16.5 19.5l1.4 1.6M24 16.5v2.2M34 22l-1.6 1.2" />
      <path d="M10 38h28" />
    </svg>
  ),
};

const ICO = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.4,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};
const PencilIcon = () => (
  <svg width="15" height="15" viewBox="0 0 16 16" {...ICO}>
    <path d="M10.9 2.6a1.6 1.6 0 0 1 2.3 0l.2.2a1.6 1.6 0 0 1 0 2.3L5.7 12.8 2.5 13.5l.7-3.2Z" />
    <path d="m9.6 3.9 2.5 2.5" />
  </svg>
);
const PinIcon = ({ on }: { on: boolean }) => (
  <svg width="16" height="16" viewBox="0 0 16 16" {...ICO}>
    <path d="M5.5 2h5M6.3 2v3.6L4.2 8.3v1.2h7.6V8.3L9.7 5.6V2M8 9.5V14" />
    {on ? null : <path d="M2.8 2.8l10.4 10.4" />}
  </svg>
);
const CSS = `
html,body{background:#f1f1f1}
.wch{max-width:964px;margin:0 auto 24px}
.wch-card{background:#fff;border-radius:12px;box-shadow:0 0 0 1px #ebebeb;overflow:hidden;color:#1a1a1a}
.wch-hd{display:flex;align-items:flex-start;gap:8px;padding:16.5px 18px 11.5px;border-bottom:1px solid #ededed}
.wch-hd-t{flex:1;min-width:0}
.wch-h{margin:0;font-size:15.2px;font-weight:600;line-height:20px;color:#1a1a1a}
.wch-hs{margin-top:6px;font-size:11.4px;line-height:16px;color:#4a4a4a}
.wch-sel{position:relative;flex:none;width:125px}
.wch-sel select{appearance:none;-webkit-appearance:none;width:100%;height:32px;margin:0;padding:0 26px 0 13px;border:1px solid #e3e3e3;border-radius:8px;background:#fff;color:#303030;font:inherit;font-size:11.4px;font-weight:600;cursor:pointer}
.wch-sel svg{position:absolute;right:9px;top:11px;pointer-events:none;color:#303030}
.wch-q{flex:none;width:200px;height:32px;margin:0;padding:0 13px;border:1px solid #e3e3e3;border-radius:8px;background:#fff;color:#303030;font:inherit;font-size:11.8px;outline:none}
.wch-q::placeholder{color:#6b6b6b}
.wch-sel select:focus,.wch-q:focus{border-color:#1a1a1a;box-shadow:0 0 0 1px #1a1a1a}
.wch-list{max-height:520px;overflow-y:auto}
.wch-row{position:relative;display:flex;align-items:center;height:65px;padding:0 18px;border-top:1px solid #ededed;cursor:pointer}
.wch-row:first-child{border-top:0;height:64px}
.wch-row:hover{background:#f7f7f7}
.wch-row.pin::before{content:"";position:absolute;left:0;top:0;bottom:0;width:3px;background:#0d56b2}
.wch-ic{flex:none;width:42px;height:42px;border-radius:8px;background:#f9f1e9;box-shadow:inset 0 0 0 1px #f4e3d6;display:grid;place-items:center}
.wch-ic svg{width:28px;height:28px}
.wch-tx{flex:1;min-width:0;margin-left:12px}
.wch-t{display:block;font-size:12.6px;font-weight:600;line-height:17px;color:#1a1a1a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wch-s{display:block;margin-top:3.5px;font-size:11px;line-height:14px;color:#4a4a4a;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.wch-b{flex:none;margin-left:12px;padding:0 8.5px;border-radius:7px;font-size:11.4px;font-weight:600;line-height:19px;white-space:nowrap}
.wch-b.on{background:#affebf;color:#0c5132}
.wch-b.off{background:#e8e8e8;color:#616161}
.wch-e{flex:none;width:150px;margin-left:12px;text-align:right}
.wch-ev{display:block;font-size:12.35px;font-weight:700;line-height:20px;color:#0b4429}
.wch-es{display:block;margin-top:3.7px;font-size:10.45px;line-height:16px;color:#595959}
.wch-a{flex:none;display:flex;gap:2px;margin-left:12px;visibility:hidden}
.wch-list:hover .wch-a,.wch-row:focus-within .wch-a{visibility:visible}
.wch-btn{display:grid;place-items:center;width:26px;height:26px;padding:0;border:0;border-radius:6px;background:transparent;color:#787878;cursor:pointer;text-decoration:none}
.wch-btn:hover{background:#ebebeb}
.wch-btn.on{color:#303030}
.wch-btn.ask{width:auto;padding:0 8px;background:#fee9e8;color:#8e1f0b;font:inherit;font-size:11.4px;font-weight:600}
.wch-empty{padding:24px 18px;font-size:12.35px;color:#4a4a4a}
.wch-ft{display:flex;align-items:center;justify-content:space-between;height:45px;padding:0 18px;border-top:1px solid #ededed;background:#f7f7f7;font-size:12.35px;line-height:17px;color:#4a4a4a}
.wch-ft a{color:#005bd3;text-decoration:none}
.wch-ft a:hover{text-decoration:underline}
@media (max-width:700px){.wch-hd{flex-wrap:wrap}.wch-q{flex:1;width:auto}.wch-e{width:auto}.wch-es{display:none}.wch-a{visibility:visible}}
`;

export default function Home() {
  const { rows, pins: savedPins } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const pinFetcher = useFetcher();
  const [q, setQ] = useState("");

  // optimistic pin toggle
  let pins = savedPins;
  if (pinFetcher.formData?.get("intent") === "pin") {
    const k = String(pinFetcher.formData.get("key"));
    pins = pins.includes(k) ? pins.filter((p) => p !== k) : [...pins, k];
  }

  const list = useMemo(() => {
    const term = q.trim().toLowerCase();
    const out = rows.filter((r) => !term || `${r.title} ${r.sub}`.toLowerCase().includes(term));
    const pinned = (r: Row) => (pins.includes(r.key) ? 0 : 1);
    out.sort((a, b) => pinned(a) - pinned(b));
    return out;
  }, [rows, pins, q]);

  return (
    <s-page inlineSize="large">
      <style>{CSS}</style>
      <div className="wch">
        <div className="wch-card">
          <div className="wch-hd">
            <div className="wch-hd-t">
              <h2 className="wch-h">Modules</h2>
              <div className="wch-hs">
                {rows.length} modules
              </div>
            </div>
            <input
              className="wch-q"
              type="search"
              placeholder="Search..."
              value={q}
              onChange={(e) => setQ(e.currentTarget.value)}
              aria-label="Search"
            />
          </div>

          <div className="wch-list">
            {list.length === 0 ? <div className="wch-empty">Nothing found.</div> : null}
            {list.map((r) => {
              const pinned = pins.includes(r.key);
              return (
                // eslint-disable-next-line jsx-a11y/click-events-have-key-events, jsx-a11y/no-static-element-interactions
                <div
                  key={r.key}
                  className={`wch-row${pinned ? " pin" : ""}`}
                  onClick={(e) => {
                    if ((e.target as HTMLElement).closest("a,button")) return;
                    navigate(r.editUrl);
                  }}
                >
                  <span className="wch-ic">{icons[r.icon]}</span>
                  <span className="wch-tx">
                    <span className="wch-t">{r.title}</span>
                    {r.sub ? <span className="wch-s">{r.sub}</span> : null}
                  </span>
                  <span className="wch-a">
                    <Link className="wch-btn" to={r.editUrl} title="Edit" aria-label="Edit">
                      <PencilIcon />
                    </Link>
                    <button
                      type="button"
                      className={`wch-btn${pinned ? " on" : ""}`}
                      title={pinned ? "Unpin" : "Pin to top"}
                      aria-label={pinned ? "Unpin" : "Pin to top"}
                      onClick={() => pinFetcher.submit({ intent: "pin", key: r.key }, { method: "POST" })}
                    >
                      <PinIcon on={pinned} />
                    </button>
                  </span>
                </div>
              );
            })}
          </div>

          <div className="wch-ft">
            <span>
              {rows.length} modules
            </span>
            <Link to="/app/setup">Setup guide →</Link>
          </div>
        </div>
      </div>
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => {
  return boundary.headers(headersArgs);
};
