import type { HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useLoaderData, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { getLookups, loadShipments } from "../trk-store.server";
import { computeStats } from "../trk.server";
import { TRK_OMNISEND_EVENT, TRK_STATUS_LABEL, TRK_STATUS_ORDER, type TrkStatus } from "../trk.shared";
import { Grid, HBars, Kpi, STATUS_COLOR, ShareBar, StackedDays, StatusBadge, TrkNav, fmt, input, td, th } from "../trk-ui";

/** Tracking → Analytics (Track123 tabs: Shipments, delivery times, tracking page, exceptions, notifications). */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const days = Number(url.searchParams.get("days")) || 30;
  const carrier = url.searchParams.get("carrier") || "";
  const country = url.searchParams.get("country") || "";
  const all = [...(await loadShipments(shop)).values()];
  const stats = computeStats(all, { days, carrier, country });
  const lookups = await getLookups(shop);
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  const lookupSeries = Object.entries(lookups)
    .filter(([d]) => d >= since)
    .sort(([a], [b]) => (a < b ? -1 : 1))
    .map(([day, v]) => ({ day, ...v }));
  const sinceMs = Date.now() - days * 86400000;
  const notif: Record<string, number> = {};
  for (const r of all) {
    for (const [k, v] of Object.entries(r.notified)) {
      if (v.startsWith("skipped") || Date.parse(v) < sinceMs) continue;
      notif[k] = (notif[k] ?? 0) + 1;
    }
  }
  const uniq = (a: string[]) => [...new Set(a.filter(Boolean))].sort();
  return {
    stats,
    lookupSeries,
    notif,
    carriers: uniq(all.flatMap((r) => [r.carrier, r.lastMileCarrier])),
    countries: uniq(all.map((r) => r.country)),
  };
};

const TABS: [string, string][] = [
  ["shipments", "Shipments"],
  ["time", "Order-to-delivery time"],
  ["page", "Tracking page"],
  ["exceptions", "Exceptions"],
  ["notification", "Notification"],
];

export default function TrackingAnalytics() {
  const d = useLoaderData<typeof loader>();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "shipments";
  const go = (patch: Record<string, string>) => {
    const p = new URLSearchParams(params);
    for (const [k, v] of Object.entries(patch)) (v ? p.set(k, v) : p.delete(k));
    setParams(p);
  };
  const st = d.stats;
  const shown: TrkStatus[] = TRK_STATUS_ORDER.filter((k) => st.byStatus[k]);

  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      <s-section>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 12 }}>
          {TABS.map(([k, l]) => (
            <s-button key={k} variant={tab === k ? "primary" : "secondary"} onClick={() => go({ tab: k })}>
              {l}
            </s-button>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <select style={{ ...input, width: 140 }} value={params.get("days") || "30"} onChange={(e) => go({ days: e.target.value })}>
            <option value="7">Last 7 days</option>
            <option value="30">Last 30 days</option>
            <option value="60">Last 60 days</option>
            <option value="90">Last 90 days</option>
            <option value="180">Last 180 days</option>
          </select>
          <select style={{ ...input, width: 170 }} value={params.get("carrier") || ""} onChange={(e) => go({ carrier: e.target.value })}>
            <option value="">All carriers</option>
            {d.carriers.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
          <select style={{ ...input, width: 150 }} value={params.get("country") || ""} onChange={(e) => go({ country: e.target.value })}>
            <option value="">All destinations</option>
            {d.countries.map((c) => (
              <option key={c} value={c}>
                {c}
              </option>
            ))}
          </select>
        </div>
      </s-section>

      {tab === "shipments" ? (
        <>
          <s-section>
            <Grid>
              <Kpi label="Total shipments" value={st.total} />
              <Kpi label="Pending rate" value={`${st.pendingRate}%`} />
              <Kpi label="Delivery rate" value={`${st.deliveryRate}%`} />
              <Kpi label="Avg. transit time" value={st.transit.avg != null ? `${st.transit.avg} d` : "—"} />
            </Grid>
          </s-section>
          <s-section heading="Status trend by fulfillment day (count)">
            <StackedDays series={st.series} statuses={shown} />
          </s-section>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 420px" }}>
              <s-section heading="Shipments by status">
                <ShareBar parts={TRK_STATUS_ORDER.map((k) => ({ key: k, value: st.byStatus[k], color: STATUS_COLOR[k], label: TRK_STATUS_LABEL[k] }))} />
              </s-section>
            </div>
            <div style={{ flex: "1 1 360px" }}>
              <s-section heading="Top carriers">
                <HBars rows={st.carriers.map((c) => ({ label: c.name, value: c.count }))} />
              </s-section>
            </div>
          </div>
        </>
      ) : null}

      {tab === "time" ? (
        <>
          <s-section>
            <Grid>
              <Kpi label="Processing time (order → shipped)" value={st.processing.avg != null ? `${st.processing.avg} d` : "—"} />
              <Kpi label="Transit time (shipped → delivered)" value={st.transit.avg != null ? `${st.transit.avg} d` : "—"} />
              <Kpi label="Order-to-delivery time" value={st.orderToDelivery.avg != null ? `${st.orderToDelivery.avg} d` : "—"} />
            </Grid>
          </s-section>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            {(
              [
                ["Processing time distribution", st.processing.buckets],
                ["Transit time distribution", st.transit.buckets],
                ["Order-to-delivery distribution", st.orderToDelivery.buckets],
              ] as const
            ).map(([title, b]) => (
              <div key={title} style={{ flex: "1 1 300px" }}>
                <s-section heading={title}>
                  <HBars rows={b.map((x) => ({ label: x.label, value: x.count }))} />
                </s-section>
              </div>
            ))}
          </div>
          <div style={{ display: "flex", gap: 16, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 420px" }}>
              <s-section heading="Transit time by destination">
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th style={th}>Destination</th>
                      <th style={th}>Shipments</th>
                      <th style={th}>Avg. days</th>
                      <th style={th}>On the way</th>
                    </tr>
                  </thead>
                  <tbody>
                    {st.countries.map((c) => (
                      <tr key={c.name}>
                        <td style={td}>{c.name}</td>
                        <td style={td}>{c.count}</td>
                        <td style={td}>{c.avg ?? "—"}</td>
                        <td style={td}>{c.active}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </s-section>
            </div>
            <div style={{ flex: "1 1 360px" }}>
              <s-section heading="Transit time by last-mile carrier">
                <HBars rows={st.lastMile.map((c) => ({ label: c.name, value: c.avg ?? 0, note: `(${c.count})` }))} unit=" d" />
              </s-section>
            </div>
          </div>
        </>
      ) : null}

      {tab === "page" ? (
        <s-section heading="Tracking page lookups per day">
          {d.lookupSeries.length ? (
            <HBars rows={d.lookupSeries.slice(-31).map((x) => ({ label: x.day, value: x.lookups, note: `(${x.found} found)` }))} />
          ) : (
            <s-paragraph>No lookups yet — they are counted once the tracking page is on.</s-paragraph>
          )}
        </s-section>
      ) : null}

      {tab === "exceptions" ? (
        <s-section heading={`Exceptions, failed attempts and returns (${st.exceptions.length})`}>
          {!st.exceptions.length ? (
            <s-paragraph>None in this period.</s-paragraph>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Order</th>
                  <th style={th}>Tracking</th>
                  <th style={th}>Status</th>
                  <th style={th}>Last event</th>
                  <th style={th}>When</th>
                </tr>
              </thead>
              <tbody>
                {st.exceptions.map((x) => (
                  <tr key={x.number}>
                    <td style={td}>
                      #{x.order.replace("#", "")} <span style={{ color: "#616161" }}>{x.country}</span>
                    </td>
                    <td style={td}>{x.number}</td>
                    <td style={td}>
                      <StatusBadge status={x.status} />
                    </td>
                    <td style={td}>{x.lastEvent}</td>
                    <td style={td}>{fmt(x.at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </s-section>
      ) : null}

      {tab === "notification" ? (
        <s-section heading="Omnisend events sent">
          <HBars
            rows={[
              ...TRK_STATUS_ORDER.filter((k) => TRK_OMNISEND_EVENT[k]).map((k) => ({
                label: TRK_STATUS_LABEL[k],
                value: d.notif[TRK_OMNISEND_EVENT[k]] ?? 0,
                color: STATUS_COLOR[k],
              })),
              {
                label: "To yourself",
                value: Object.entries(d.notif)
                  .filter(([k]) => k.startsWith("admin:"))
                  .reduce((a, [, v]) => a + v, 0),
              },
            ]}
          />
          <div style={{ fontSize: 12, color: "#616161", marginTop: 8 }}>Opens and clicks of these emails are in Omnisend → Reports.</div>
        </s-section>
      ) : null}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
