import type { ActionFunctionArgs, HeadersFunction, LoaderFunctionArgs } from "react-router";
import { useState } from "react";
import { useLoaderData, useSearchParams } from "react-router";
import { boundary } from "@shopify/shopify-app-react-router/server";
import { authenticate } from "../shopify.server";
import { handleTrkAction } from "../trk-actions.server";
import { getLog, getTrkSettings } from "../trk-store.server";
import { yunConfigured } from "../trk-yun.server";
import { TRK_STATUS_LABEL, publicSettings, type TrkSettingsPublic, type TrkStatus } from "../trk.shared";
import { Check, Field, TrkNav, card, fmt, input, td, th, useTrkAction } from "../trk-ui";

/** Tracking → Settings: General (like Track123) + Integration (YunExpress, PayPal, Omnisend) + Activity log. */
export const loader = async ({ request }: LoaderFunctionArgs) => {
  const { session } = await authenticate.admin(request);
  const s = await getTrkSettings(session.shop);
  const log = await getLog(session.shop);
  return { settings: publicSettings(s), yunReady: yunConfigured(s), log: log.slice(0, 150) };
};

export const action = async ({ request }: ActionFunctionArgs) => handleTrkAction(request);

type Form = TrkSettingsPublic & { yunAppSecret: string; yunSourceKey: string; omnisendKey: string; paypalSecret: string };

export default function TrackingSettings() {
  const d = useLoaderData<typeof loader>();
  const [params, setParams] = useSearchParams();
  const tab = params.get("tab") || "general";
  const { post, busy, fetcher } = useTrkAction();
  const [f, setF] = useState<Form>({ ...d.settings, yunAppSecret: "", yunSourceKey: "", omnisendKey: "", paypalSecret: "" });
  const [num, setNum] = useState("");
  const set = <K extends keyof Form>(k: K, v: Form[K]) => setF((p) => ({ ...p, [k]: v }));
  const save = () => {
    const { hasYunSecret, hasYunSourceKey, hasOmnisendKey, hasPaypalSecret, ...rest } = f;
    void hasYunSecret;
    void hasYunSourceKey;
    void hasOmnisendKey;
    void hasPaypalSecret;
    post({ intent: "save", settings: JSON.stringify(rest) });
  };
  const secret = (k: "yunAppSecret" | "yunSourceKey" | "omnisendKey" | "paypalSecret", has: boolean, label: string) => (
    <Field label={label} hint={has ? "Saved. Leave empty to keep it." : undefined}>
      <input style={input} type="password" autoComplete="off" value={f[k]} placeholder={has ? "••••••••" : ""} onChange={(e) => set(k, e.target.value)} />
    </Field>
  );
  const test = fetcher.data?.intent === "test" ? (fetcher.data.test as Record<string, unknown> | undefined) : undefined;
  const saveBtn = (
    <s-section>
      <s-button variant="primary" loading={busy("save") || undefined} onClick={save}>
        Save settings
      </s-button>
    </s-section>
  );

  return (
    <s-page inlineSize="large" heading="Tracking">
      <TrkNav />
      <s-section>
        <div style={{ display: "flex", gap: 6 }}>
          {(
            [
              ["general", "General"],
              ["integration", "Integration"],
              ["log", "Activity log"],
            ] as const
          ).map(([k, l]) => (
            <s-button key={k} variant={tab === k ? "primary" : "secondary"} onClick={() => setParams({ tab: k })}>
              {l}
            </s-button>
          ))}
        </div>
      </s-section>

      {tab === "general" ? (
        <>
          <s-banner tone="warning">While Track123 is still installed keep the two Shopify options off — otherwise both apps write statuses and links.</s-banner>
          <s-section heading="Tracking link">
            <Check
              label="Update Shopify's tracking links to our tracking page"
              hint="On every fulfillment with the number (the warehouse makes 2–3 per order). Same number and carrier, only the link changes. No email is sent."
              checked={f.shopifyUrl}
              onChange={(v) => set("shopifyUrl", v)}
            />
          </s-section>
          <s-section heading="Fulfillment events">
            <Check
              label="Send shipping tracking events to Shopify (In transit, Out for delivery, Delivered…)"
              hint="Order timeline + Shopify's own “Out for delivery / Delivered” emails, if those are on in Shopify Settings → Notifications."
              checked={f.shopifyEvents}
              onChange={(v) => set("shopifyEvents", v)}
            />
          </s-section>
          <s-section heading="Dropshipping mode (tracking page)">
            <Check label="Hide all Chinese characters from the tracking history" checked={f.hideChinese} onChange={(v) => set("hideChinese", v)} />
            <Check label="Hide China first-mile scans" checked={f.hideOriginEvents} onChange={(v) => set("hideOriginEvents", v)} />
            <Check
              label="Hide the original carrier and show only the last-mile carrier"
              checked={f.lastMileOnly}
              onChange={(v) => set("lastMileOnly", v)}
            />
          </s-section>
          <s-section heading="Sync">
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
              <Field label="Check each parcel every (hours)">
                <input style={input} type="number" min={2} max={48} value={f.pollHours} onChange={(e) => set("pollHours", Number(e.target.value))} />
              </Field>
              <Field label="Import orders of the last (days)">
                <input style={input} type="number" min={1} max={90} value={f.importDays} onChange={(e) => set("importDays", Number(e.target.value))} />
              </Field>
              <Field label="Stop tracking after (days)">
                <input style={input} type="number" min={20} max={180} value={f.maxDays} onChange={(e) => set("maxDays", Number(e.target.value))} />
              </Field>
            </div>
          </s-section>
          {saveBtn}
        </>
      ) : null}

      {tab === "integration" ? (
        <>
          <s-section heading="YunExpress Open API — carrier data (free)">
            <s-paragraph>
              Keys from the YunExpress account that ships the parcels (open.yunexpress.cn → user center → API: App ID, App secret, Source key). Usually the
              warehouse has this account.
            </s-paragraph>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
              <Field label="App ID">
                <input style={input} value={f.yunAppId} onChange={(e) => set("yunAppId", e.target.value)} />
              </Field>
              {secret("yunAppSecret", f.hasYunSecret, "App secret")}
              {secret("yunSourceKey", f.hasYunSourceKey, "Source key")}
            </div>
            <Check label="Sandbox (test environment)" checked={f.yunSandbox} onChange={(v) => set("yunSandbox", v)} />
            <div style={{ display: "flex", gap: 6, alignItems: "center", flexWrap: "wrap" }}>
              <input style={{ ...input, width: 260 }} placeholder="YT… number to test the keys" value={num} onChange={(e) => setNum(e.target.value)} />
              <s-button disabled={!d.yunReady || !num || undefined} loading={busy("test") || undefined} onClick={() => post({ intent: "test", number: num })}>
                Test number
              </s-button>
              {!d.yunReady ? <span style={{ fontSize: 12, color: "#616161" }}>Save the keys first</span> : null}
            </div>
            {test ? (
              <div style={{ marginTop: 12, fontSize: 13 }}>
                <div>
                  Last mile: <b>{String(test.lastMileCarrier || "—")}</b> {String(test.lastMileNumber || "")} · scans: {Array.isArray(test.events) ? test.events.length : 0}
                </div>
                <ul style={{ margin: "8px 0", paddingLeft: 18 }}>
                  {(Array.isArray(test.events) ? (test.events as { at: string; text: string; place: string; status: TrkStatus }[]) : []).slice(0, 8).map((e, i) => (
                    <li key={i}>
                      {fmt(e.at)} — {e.text} {e.place ? `(${e.place})` : ""} → <i>{TRK_STATUS_LABEL[e.status]}</i>
                    </li>
                  ))}
                </ul>
                <details>
                  <summary style={{ cursor: "pointer" }}>Raw response</summary>
                  <pre style={{ whiteSpace: "pre-wrap", fontSize: 11, maxHeight: 300, overflow: "auto", background: "#f6f6f6", padding: 8 }}>{String(test.raw ?? "")}</pre>
                </details>
              </div>
            ) : null}
          </s-section>

          <s-section heading="PayPal — tracking numbers on PayPal payments">
            <div style={{ ...card, fontSize: 13, marginBottom: 12 }}>
              Track123 is currently connected to PayPal and already uploads tracking numbers. Turn this on only after removing Track123 (duplicates are
              ignored by PayPal, but there is no need for two uploads).
            </div>
            <Check
              label="Send tracking numbers to PayPal"
              hint="Works without YunExpress keys: every shipped PayPal order gets its YunExpress number. Old orders of the import period are sent too."
              checked={f.paypalEnabled}
              onChange={(v) => set("paypalEnabled", v)}
            />
            <s-paragraph>
              developer.paypal.com → Apps &amp; Credentials → <b>Live</b> → Create app, logged in as the PayPal account that receives the money (the same one
              that is connected to Shopify).
            </s-paragraph>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 12 }}>
              <Field label="Client ID">
                <input style={input} value={f.paypalClientId} onChange={(e) => set("paypalClientId", e.target.value)} />
              </Field>
              {secret("paypalSecret", f.hasPaypalSecret, "Secret")}
            </div>
            <s-button disabled={!f.paypalClientId || !f.hasPaypalSecret || undefined} loading={busy("paypalTest") || undefined} onClick={() => post({ intent: "paypalTest" })}>
              Test PayPal keys
            </s-button>
            <span style={{ fontSize: 12, color: "#616161", marginLeft: 8 }}>Checks the keys and finds the latest PayPal payment; sends nothing.</span>
          </s-section>

          <s-section heading="Omnisend — customer emails">
            {secret("omnisendKey", f.hasOmnisendKey, "Omnisend API key (Omnisend → Store settings → API keys)")}
            <s-paragraph>Which statuses are emailed and the test events are on the Notification page.</s-paragraph>
          </s-section>
          {saveBtn}
        </>
      ) : null}

      {tab === "log" ? (
        <s-section>
          {!d.log.length ? (
            <s-paragraph>Nothing yet.</s-paragraph>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Time</th>
                  <th style={th}>Type</th>
                  <th style={th}>Order</th>
                  <th style={th}>Number</th>
                  <th style={th}>Result</th>
                </tr>
              </thead>
              <tbody>
                {d.log.map((l, i) => (
                  <tr key={i}>
                    <td style={td}>{fmt(l.at)}</td>
                    <td style={td}>{l.kind}</td>
                    <td style={td}>{l.order ?? ""}</td>
                    <td style={td}>{l.number ?? ""}</td>
                    <td style={{ ...td, color: l.ok ? undefined : "#b42318" }}>{l.text}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </s-section>
      ) : null}
    </s-page>
  );
}

export const headers: HeadersFunction = (headersArgs) => boundary.headers(headersArgs);
