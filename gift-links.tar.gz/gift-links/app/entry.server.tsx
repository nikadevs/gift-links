import { PassThrough } from "stream";
import { renderToPipeableStream } from "react-dom/server";
import { ServerRouter } from "react-router";
import { createReadableStreamFromReadable } from "@react-router/node";
import { type EntryContext } from "react-router";
import { isbot } from "isbot";
import { addDocumentResponseHeaders, unauthenticated } from "./shopify.server";
import { startSeoScheduler } from "./seo/seo-scheduler.server";
import { startTrustpilotScheduler } from "./trustpilot.server";
import { startTrkScheduler } from "./trk.server";
import { startBundleCurrencyScheduler } from "./bundles-currency.server";
import prisma from "./db.server";

// SEO & Speed: daily audits / PageSpeed tests run inside this process
startSeoScheduler();
startTrustpilotScheduler();
startTrkScheduler();
// Bundle Contents: component values in every storefront currency, refreshed every 6 h
startBundleCurrencyScheduler(
  async () => [...new Set<string>((await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } })).map((r: { shop: string }) => r.shop))],
  async (shop) => (await unauthenticated.admin(shop)).admin,
);

export const streamTimeout = 5000;

export default async function handleRequest(
  request: Request,
  responseStatusCode: number,
  responseHeaders: Headers,
  reactRouterContext: EntryContext,
) {
  addDocumentResponseHeaders(request, responseHeaders);
  const userAgent = request.headers.get("user-agent");
  const callbackName = isbot(userAgent ?? "") ? "onAllReady" : "onShellReady";

  return new Promise((resolve, reject) => {
    const { pipe, abort } = renderToPipeableStream(
      <ServerRouter context={reactRouterContext} url={request.url} />,
      {
        [callbackName]: () => {
          const body = new PassThrough();
          const stream = createReadableStreamFromReadable(body);

          responseHeaders.set("Content-Type", "text/html");
          resolve(
            new Response(stream, {
              headers: responseHeaders,
              status: responseStatusCode,
            }),
          );
          pipe(body);
        },
        onShellError(error) {
          reject(error);
        },
        onError(error) {
          responseStatusCode = 500;
          console.error(error);
        },
      },
    );

    // Automatically timeout the React renderer after 6 seconds, which ensures
    // React has enough time to flush down the rejected boundary contents
    setTimeout(abort, streamTimeout + 1000);
  });
}
