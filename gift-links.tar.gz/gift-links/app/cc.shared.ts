/** Currency Converter — types, defaults and validation shared by server and admin UI. */
export const CC_POSITIONS = ["menu", "top_left", "top_right", "bottom_left", "bottom_right"] as const;
export type CcPos = (typeof CC_POSITIONS)[number];

export type CcConfig = {
  version: 1;
  enabled: boolean;
  /** ISO codes in display order */
  currencies: string[];
  showDesktop: boolean;
  desktopPos: CcPos;
  showMobile: boolean;
  mobilePos: CcPos;
  /** "$10 USD" instead of "$10" */
  showCode: boolean;
  /** tooltip with the price in the store currency */
  hoverOriginal: boolean;
  flags: boolean;
  tooltipSize: number;
  bg: string;
  activeBg: string;
  border: string;
  text: string;
  /** switch to the visitor's local currency on the first visit */
  autoConvert: boolean;
  /** …only if that currency is in the list */
  onlyListed: boolean;
  cartNotice: boolean;
  cartNoticeText: string;
  cartNoticeBg: string;
  customCss: string;
  updatedAt: string;
};

/** Values taken from the Vitals module settings of woodencrew.store (2026-10-15). */
export const CC_DEFAULTS: CcConfig = {
  version: 1,
  enabled: false,
  currencies: ["USD", "NZD", "GBP", "EUR", "CAD", "CHF", "AUD"],
  showDesktop: true,
  desktopPos: "menu",
  showMobile: true,
  mobilePos: "menu",
  showCode: false,
  hoverOriginal: false,
  flags: false,
  tooltipSize: 12,
  bg: "ffffff",
  activeBg: "f6f6f6",
  border: "f4f4f4",
  text: "111111",
  autoConvert: true,
  onlyListed: true,
  cartNotice: false,
  cartNoticeText:
    "Prices are displayed in {{ visible_currency }}. Checkout is processed in {{ default_currency }}.",
  cartNoticeBg: "ffffff",
  // The mobile placement rules that were in Vitals' custom CSS for this store
  customCss:
    "@media (max-width: 769px) {\n  .wc-cc.wc-cc--menu {\n    position: sticky !important;\n    top: 40px !important;\n    left: 42px !important;\n    bottom: auto !important;\n    margin-top: -25px !important;\n  }\n}",
  updatedAt: "",
};

const HEX = /^[0-9a-f]{6}$/i;
const CODE = /^[A-Z]{3}$/;

function hex(v: unknown, d: string) {
  const s = String(v ?? "").replace(/^#/, "").trim();
  return HEX.test(s) ? s.toLowerCase() : d;
}
function pos(v: unknown, d: CcPos): CcPos {
  return (CC_POSITIONS as readonly string[]).includes(String(v)) ? (v as CcPos) : d;
}
function bool(v: unknown, d: boolean) {
  return typeof v === "boolean" ? v : d;
}

/** Normalise anything (stored JSON or form input) into a valid config. */
export function normalizeCc(p: Partial<Record<keyof CcConfig, unknown>> | null | undefined): CcConfig {
  const d = CC_DEFAULTS;
  const x = p || {};
  const list = Array.isArray(x.currencies)
    ? [...new Set(x.currencies.map((c) => String(c).toUpperCase().trim()).filter((c) => CODE.test(c)))].slice(0, 60)
    : d.currencies;
  const size = Math.round(Number(x.tooltipSize));
  return {
    version: 1,
    enabled: bool(x.enabled, d.enabled),
    currencies: list,
    showDesktop: bool(x.showDesktop, d.showDesktop),
    desktopPos: pos(x.desktopPos, d.desktopPos),
    showMobile: bool(x.showMobile, d.showMobile),
    mobilePos: pos(x.mobilePos, d.mobilePos),
    showCode: bool(x.showCode, d.showCode),
    hoverOriginal: bool(x.hoverOriginal, d.hoverOriginal),
    flags: bool(x.flags, d.flags),
    tooltipSize: size >= 8 && size <= 30 ? size : d.tooltipSize,
    bg: hex(x.bg, d.bg),
    activeBg: hex(x.activeBg, d.activeBg),
    border: hex(x.border, d.border),
    text: hex(x.text, d.text),
    autoConvert: bool(x.autoConvert, d.autoConvert),
    onlyListed: bool(x.onlyListed, d.onlyListed),
    cartNotice: bool(x.cartNotice, d.cartNotice),
    cartNoticeText: typeof x.cartNoticeText === "string" ? x.cartNoticeText.slice(0, 400) : d.cartNoticeText,
    cartNoticeBg: hex(x.cartNoticeBg, d.cartNoticeBg),
    // </style> would close the style tag on the storefront
    customCss: typeof x.customCss === "string" ? x.customCss.replace(/<\/?style/gi, "").slice(0, 5000) : d.customCss,
    updatedAt: typeof x.updatedAt === "string" ? x.updatedAt : "",
  };
}

