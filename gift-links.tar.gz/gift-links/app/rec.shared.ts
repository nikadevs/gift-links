/** Session Recordings — types shared by the server and the admin UI. */

export const REC_NAMESPACE = "wc_rec";
export const REC_KEY = "config";
export const REC_RETENTION_DAYS = 30;

/** Saved in the app-owned metafield wc_rec.config (the theme reads it). */
export type RecConfig = {
  version: 1;
  enabled: boolean;
  /** absolute URL of POST /api/rec on our server */
  endpoint: string;
  updatedAt: string;
};

export type RecPage = {
  p: number;
  url: string;
  title: string;
  t: number;
};

/** One recording = one visitor session (several pages), meta.json on disk. */
export type RecSession = {
  id: string;
  vid: string;
  day: string;
  start: number;
  end: number;
  pages: RecPage[];
  device: "mobile" | "tablet" | "desktop";
  w: number;
  h: number;
  ua: string;
  browser: string;
  os: string;
  ref: string;
  utm: string;
  lang: string;
  tz: string;
  atc: boolean;
  checkout: boolean;
  clicks: number;
  /** ISO country code from the visitor IP (DB-IP lite); the IP itself is not stored */
  country?: string;
  chunks: number;
  bytes: number;
};

export type RecListItem = Omit<RecSession, "ua"> & { duration: number };

export function fmtDuration(ms: number) {
  const s = Math.max(0, Math.round(ms / 1000));
  const m = Math.floor(s / 60);
  const h = Math.floor(m / 60);
  if (h) return `${h}h ${m % 60}m`;
  if (m) return `${m}m ${String(s % 60).padStart(2, "0")}s`;
  return `${s}s`;
}

export function fmtBytes(n: number) {
  if (n >= 1024 ** 3) return `${(n / 1024 ** 3).toFixed(1)} GB`;
  if (n >= 1024 ** 2) return `${(n / 1024 ** 2).toFixed(1)} MB`;
  if (n >= 1024) return `${Math.round(n / 1024)} KB`;
  return `${n} B`;
}

export function deviceOf(ua: string, w: number, touch: boolean): RecSession["device"] {
  if (/iPad|Tablet/i.test(ua) || (touch && w >= 768 && w < 1100 && !/Mobi/i.test(ua))) return "tablet";
  if (/Mobi|iPhone|Android/i.test(ua) || (touch && w < 768)) return "mobile";
  return "desktop";
}

export function browserOf(ua: string) {
  if (/Edg\//.test(ua)) return "Edge";
  if (/OPR\/|Opera/.test(ua)) return "Opera";
  if (/SamsungBrowser/.test(ua)) return "Samsung";
  if (/FBAN|FBAV|FB_IAB/.test(ua)) return "Facebook app";
  if (/Instagram/.test(ua)) return "Instagram app";
  if (/TikTok|BytedanceWebview/i.test(ua)) return "TikTok app";
  if (/CriOS|Chrome\//.test(ua)) return "Chrome";
  if (/FxiOS|Firefox\//.test(ua)) return "Firefox";
  if (/Safari\//.test(ua)) return "Safari";
  return "Other";
}

export function osOf(ua: string) {
  if (/iPhone|iPad|iPod/.test(ua)) return "iOS";
  if (/Android/.test(ua)) return "Android";
  if (/Windows/.test(ua)) return "Windows";
  if (/Mac OS X|Macintosh/.test(ua)) return "macOS";
  if (/Linux/.test(ua)) return "Linux";
  return "Other";
}

/** "omnisend / campaign: Sale (6acf469db7f7dabccf476ed3)" → without the long id */
export function cleanSource(src: string) {
  return src.replace(/\s*\([0-9a-f]{12,}\)\s*$/i, "").trim();
}

const regionNames = (() => {
  try {
    return new Intl.DisplayNames(["en"], { type: "region" });
  } catch {
    return null;
  }
})();

export function countryName(code?: string) {
  if (!code) return "";
  try {
    return regionNames?.of(code.toUpperCase()) || code;
  } catch {
    return code;
  }
}

/** "Europe/London" → "London" (the visitor's time-zone city, approximate) */
export function tzCity(tz?: string) {
  if (!tz || !tz.includes("/")) return "";
  return tz.split("/").pop()!.replace(/_/g, " ");
}

export function locationLabel(country?: string, tz?: string) {
  const c = countryName(country);
  const city = tzCity(tz);
  if (c && city) return `${c} · ${city}`;
  return c || city || "—";
}
