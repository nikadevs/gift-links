export type FeaturePhoto = { url: string; width: number; height: number; alt: string };
export type Feature = { id: string; title: string; description: string; iconSvg: string; iconTile?: boolean; photo: FeaturePhoto | null };
export type FeaturesConfig = { version: 1; enabled: boolean; heading: string; interval: number; accent: string; background: string; textColor: string; mutedColor: string; paddingTop: number; paddingBottom: number; features: Feature[]; updatedAt: string };
export const emptyFeatures = (): FeaturesConfig => ({ version: 1, enabled: false, heading: "", interval: 5, accent: "#087f8c", background: "#ffffff", textColor: "#080b0d", mutedColor: "#666666", paddingTop: 28, paddingBottom: 70, features: [], updatedAt: "" });
export function readFeatures(value?: string | null): FeaturesConfig | null {
  try { const v = JSON.parse(value || "null"); return v?.version === 1 && Array.isArray(v.features) ? v : null; } catch { return null; }
}
