/**
 * Volume Discounts — storage, validation, Shopify discounts and gift copies.
 *
 * Config: ONE app-owned JSON metafield on the AppInstallation
 * (namespace "wc_vd", key "config"), read by the theme app embed in Liquid
 * as `app.metafields.wc_vd.config.value` (same pattern as the other modules).
 */
import {
  AUTOMATIC_DISCOUNT_LIMIT,
  GIFT_TAG,
  MAX_TIERS,
  VD_GIFT_TAG,
  VD_KEY,
  MAX_FREE,
  VD_NAMESPACE,
  bogoSteps,
  cleanTitle,
  discountCount,
  discountSteps,
  isBogo,
  invisibleSuffix,
  offerStatus,
  type VdConfig,
  type VdGift,
  type VdOffer,
  type VdTier,
} from "./vd.shared";

export type { VdConfig, VdOffer } from "./vd.shared";

type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

async function gql<T>(
  admin: AdminGraphql,
  query: string,
  variables?: Record<string, unknown>,
): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: unknown };
  if (json.errors) throw new Error(JSON.stringify(json.errors).slice(0, 400));
  return json.data as T;
}

const errs = (list?: { message: string }[] | null) =>
  (list ?? []).map((e) => e.message).join("; ");

export const emptyVdConfig = (): VdConfig => ({ version: 1, offers: [] });

export async function loadVdConfig(admin: AdminGraphql) {
  const data = await gql<{
    currentAppInstallation?: {
      id: string;
      metafield?: { value?: string | null } | null;
    };
  }>(
    admin,
    `#graphql
    query WcVdConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_vd", key: "config") { value }
      }
    }`,
  );
  const inst = data.currentAppInstallation;
  let config = emptyVdConfig();
  if (inst?.metafield?.value) {
    try {
      const p = JSON.parse(inst.metafield.value);
      if (p && Array.isArray(p.offers)) config = p;
    } catch {
      // corrupted value — start fresh rather than crash the admin
    }
  }
  return { installationId: inst?.id ?? "", config };
}

export async function saveVdConfig(
  admin: AdminGraphql,
  installationId: string,
  config: VdConfig,
) {
  // eslint-disable-next-line no-undef
  const appUrl = (process.env.SHOPIFY_APP_URL || "").replace(/\/+$/, "");
  if (appUrl) config.beaconUrl = `${appUrl}/api/vd/event`;
  const data = await gql<{
    metafieldsSet?: { userErrors: { message: string }[] };
  }>(
    admin,
    `#graphql
    mutation WcVdSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      metafields: [
        {
          ownerId: installationId,
          namespace: VD_NAMESPACE,
          key: VD_KEY,
          type: "json",
          value: JSON.stringify(config),
        },
      ],
    },
  );
  const e = errs(data.metafieldsSet?.userErrors);
  if (e) throw new Error(e);
}

// ---------------------------------------------------------------------------
// products & gifts

const digits = (s: unknown) => String(s ?? "").replace(/\D/g, "");
const PRODUCT_GID = (id: string) => `gid://shopify/Product/${digits(id)}`;

type ProductNode = {
  id: string;
  title: string;
  handle: string;
  status: string;
  tags: string[];
  featuredMedia?: { preview?: { image?: { url: string } | null } | null } | null;
  variants: {
    nodes: {
      id: string;
      title: string;
      price: string;
      compareAtPrice?: string | null;
      media?: { nodes: { preview?: { image?: { url: string } | null } | null }[] };
    }[];
  };
};

const PRODUCT_FIELDS = `
  id title handle status tags
  featuredMedia { preview { image { url } } }
  variants(first: 100) {
    nodes {
      id title price compareAtPrice
      media(first: 1) { nodes { preview { image { url } } } }
    }
  }`;

async function fetchProducts(admin: AdminGraphql, ids: string[]) {
  if (!ids.length) return new Map<string, ProductNode>();
  const data = await gql<{ nodes: (ProductNode | null)[] }>(
    admin,
    `#graphql
    query WcVdProducts($ids: [ID!]!) {
      nodes(ids: $ids) { ... on Product { ${PRODUCT_FIELDS} } }
    }`,
    { ids: ids.map(PRODUCT_GID) },
  );
  const map = new Map<string, ProductNode>();
  for (const n of data.nodes ?? []) if (n?.id) map.set(digits(n.id), n);
  return map;
}

const img = (p: ProductNode) => p.featuredMedia?.preview?.image?.url ?? "";

export type GiftCheck = {
  gift: VdGift;
  /** all variants cost $0 → safe to add as a free gift */
  isFree: boolean;
  /** highest variant price, used when making a copy */
  price: string;
  active: boolean;
};

function giftFromProduct(p: ProductNode): GiftCheck {
  const vs = p.variants.nodes;
  const isFree = vs.length > 0 && vs.every((v) => Number(v.price) === 0);
  const value =
    vs.map((v) => Number(v.compareAtPrice ?? 0)).find((n) => n > 0) ??
    Math.max(0, ...vs.map((v) => Number(v.price)));
  const title = p.title.replace(/\s*[—-]\s*Gift\s*$/i, "");
  const name = title.replace(/^WoodenCrew™?\s*\|?\s*/i, "").trim() || title;
  return {
    isFree,
    // UNLISTED = sellable, but hidden from collections, search and recommendations
    active: p.status === "ACTIVE" || p.status === "UNLISTED",
    price: Math.max(0, ...vs.map((v) => Number(v.price))).toFixed(2),
    gift: {
      productId: digits(p.id),
      handle: p.handle,
      title,
      name,
      image: img(p),
      value: value ? Number(value).toFixed(2) : "",
      guard: p.tags.includes(GIFT_TAG) || p.tags.includes(VD_GIFT_TAG),
      variants: vs.map((v) => ({
        id: digits(v.id),
        title: v.title === "Default Title" ? "" : v.title,
        image: v.media?.nodes?.[0]?.preview?.image?.url ?? "",
      })),
    },
  };
}

export async function giftInfo(admin: AdminGraphql, productId: string) {
  const p = (await fetchProducts(admin, [productId])).get(digits(productId));
  if (!p) throw new Error("Product not found");
  return giftFromProduct(p);
}

/**
 * Makes a $0 copy of a product to use as a free gift.
 *
 * Created as a NEW product with productSet (not productDuplicate: a duplicate
 * inherits every sales channel of the original — Google, Facebook, TikTok,
 * Shop — and a $0 gift must never land in a feed). The copy:
 *  - status UNLISTED: can go into the cart, never shows in collections,
 *    search or recommendations;
 *  - same options/variants/SKUs/images (existing media files are reused),
 *    every variant $0 with compare-at = the original price (shown struck
 *    through in the block), not inventory-tracked;
 *  - tags gift-links-gift (its page redirects home) + wc-vd-gift + hidden-gift,
 *    seo.hidden = 1;
 *  - published to the Online Store only.
 */
export async function makeGiftCopy(admin: AdminGraphql, productId: string) {
  type Src = {
    id: string;
    title: string;
    vendor: string;
    productType: string;
    options: { name: string; optionValues: { name: string }[] }[];
    media: { nodes: { id?: string }[] };
    variants: {
      nodes: {
        title: string;
        price: string;
        compareAtPrice?: string | null;
        sku?: string | null;
        selectedOptions: { name: string; value: string }[];
        media: { nodes: { id?: string }[] };
      }[];
    };
  };
  const data = await gql<{ product: Src | null }>(
    admin,
    `#graphql
    query WcVdGiftSource($id: ID!) {
      product(id: $id) {
        id title vendor productType
        options { name optionValues { name } }
        media(first: 50) { nodes { ... on MediaImage { id } } }
        variants(first: 100) {
          nodes {
            title price compareAtPrice sku
            selectedOptions { name value }
            media(first: 1) { nodes { ... on MediaImage { id } } }
          }
        }
      }
    }`,
    { id: PRODUCT_GID(productId) },
  );
  const src = data.product;
  if (!src) throw new Error("Product not found");
  const mediaIds = src.media.nodes.map((m) => m.id).filter((x): x is string => Boolean(x));
  const hasOptions = !(src.variants.nodes.length === 1 && src.variants.nodes[0].title === "Default Title");

  const input: Record<string, unknown> = {
    title: `${src.title} — Gift`,
    status: "UNLISTED",
    vendor: src.vendor,
    productType: src.productType,
    tags: [GIFT_TAG, VD_GIFT_TAG, "hidden-gift"],
    metafields: [{ namespace: "seo", key: "hidden", type: "number_integer", value: "1" }],
    files: mediaIds.map((id) => ({ id })),
    productOptions: hasOptions
      ? src.options.map((o, i) => ({ name: o.name, position: i + 1, values: o.optionValues.map((v) => ({ name: v.name })) }))
      : [{ name: "Title", values: [{ name: "Default Title" }] }],
    variants: src.variants.nodes.map((v, i) => {
      const was = Math.max(Number(v.compareAtPrice ?? 0), Number(v.price ?? 0));
      const img = v.media.nodes[0]?.id;
      return {
        position: i + 1,
        optionValues: hasOptions
          ? v.selectedOptions.map((o) => ({ optionName: o.name, name: o.value }))
          : [{ optionName: "Title", name: "Default Title" }],
        price: "0.00",
        compareAtPrice: was > 0 ? was.toFixed(2) : null,
        inventoryPolicy: "CONTINUE",
        inventoryItem: { tracked: false, ...(v.sku ? { sku: v.sku } : {}) },
        ...(img ? { file: { id: img } } : {}),
      };
    }),
  };

  const created = await gql<{
    productSet?: { product?: { id: string } | null; userErrors: { message: string }[] };
  }>(
    admin,
    `#graphql
    mutation WcVdGiftCreate($input: ProductSetInput!) {
      productSet(synchronous: true, input: $input) {
        product { id handle }
        userErrors { field message code }
      }
    }`,
    { input },
  );
  const np = created.productSet?.product;
  if (!np) throw new Error(errs(created.productSet?.userErrors) || "Could not create the gift copy");
  const notes: string[] = [];

  // publish to the Online Store only (an unpublished product can't go into the cart)
  try {
    // on this store `catalog` is null for the channel publications → match by name
    const pubs = await gql<{
      publications: { nodes: { id: string; name?: string | null; catalog?: { title: string } | null }[] };
    }>(
      admin,
      `#graphql
      query WcVdPubs { publications(first: 30) { nodes { id name catalog { title } } } }`,
    );
    const online = pubs.publications.nodes.find((p) => /online store/i.test(`${p.name ?? ""} ${p.catalog?.title ?? ""}`));
    if (!online) notes.push("Online Store channel not found — publish the copy manually");
    else {
      const pub = await gql<{ publishablePublish?: { userErrors: { message: string }[] } }>(
        admin,
        `#graphql
        mutation WcVdPublish($id: ID!, $input: [PublicationInput!]!) {
          publishablePublish(id: $id, input: $input) { userErrors { field message } }
        }`,
        { id: np.id, input: [{ publicationId: online.id }] },
      );
      const e4 = errs(pub.publishablePublish?.userErrors);
      if (e4) notes.push(`publish: ${e4}`);
    }
  } catch (e) {
    notes.push(`publish to Online Store: ${(e as Error).message} — publish the copy manually`);
  }

  const info = await giftInfo(admin, np.id);
  return { ...info, notes };
}

// ---------------------------------------------------------------------------
// Shopify automatic discounts

async function deleteDiscounts(admin: AdminGraphql, ids: string[]) {
  const failed: string[] = [];
  for (const id of ids) {
    try {
      const d = await gql<{
        discountAutomaticDelete?: { deletedAutomaticDiscountId?: string | null; userErrors: { message: string }[] };
      }>(
        admin,
        `#graphql
        mutation WcVdDiscDelete($id: ID!) {
          discountAutomaticDelete(id: $id) { deletedAutomaticDiscountId userErrors { field message } }
        }`,
        { id },
      );
      const e = errs(d.discountAutomaticDelete?.userErrors);
      // already deleted by hand in Shopify admin → fine
      if (e && !/not exist|not found|invalid id/i.test(e)) failed.push(id);
    } catch {
      failed.push(id);
    }
  }
  return failed;
}

const dayStart = (d: string) => (d ? `${d}T00:00:00Z` : new Date().toISOString());
const dayEnd = (d: string) => (d ? `${d}T23:59:59Z` : null);

/**
 * Makes Shopify match the offer: removes the offer's old automatic discounts
 * and, when the offer is switched on, creates the chain again.
 * Returns the offer with discountIds / discountError filled in.
 */
export async function syncOfferDiscounts(
  admin: AdminGraphql,
  offer: VdOffer,
  oldIds: string[],
): Promise<VdOffer> {
  const leftovers = await deleteDiscounts(admin, oldIds);
  const next: VdOffer = { ...offer, discountIds: [...leftovers], discountError: "" };
  if (leftovers.length)
    next.discountError = `Could not delete ${leftovers.length} old discount(s) — remove them in Shopify → Discounts`;
  if (!offer.active || offerStatus(offer) === "Ended") return next;

  let createFailed = false;
  const steps = discountSteps(offer.tiers);
  for (const [k, step] of steps.entries()) {
    try {
      const d = await gql<{
        discountAutomaticBasicCreate?: {
          automaticDiscountNode?: { id: string } | null;
          userErrors: { message: string }[];
        };
      }>(
        admin,
        `#graphql
        mutation WcVdDiscCreate($d: DiscountAutomaticBasicInput!) {
          discountAutomaticBasicCreate(automaticBasicDiscount: $d) {
            automaticDiscountNode { id }
            userErrors { field message }
          }
        }`,
        {
          d: {
            title: (cleanTitle(offer.discountTitle) || "Bundle discount") + invisibleSuffix(`${offer.id}:${k}:${Date.now()}`),
            startsAt: dayStart(offer.startsAt),
            endsAt: dayEnd(offer.endsAt),
            combinesWith: { productDiscounts: true, orderDiscounts: true, shippingDiscounts: true },
            minimumRequirement: { quantity: { greaterThanOrEqualToQuantity: String(step.qty) } },
            customerGets: {
              value: { percentage: step.pct },
              items: { products: { productsToAdd: offer.productIds.map(PRODUCT_GID) } },
            },
          },
        },
      );
      const id = d.discountAutomaticBasicCreate?.automaticDiscountNode?.id;
      if (!id) throw new Error(errs(d.discountAutomaticBasicCreate?.userErrors) || "not created");
      next.discountIds.push(id);
    } catch (e) {
      const msg = (e as Error).message;
      createFailed = true;
      next.discountError = /access|scope|denied|write_discounts/i.test(msg)
        ? "The app has no permission to create discounts yet — open the app once and approve the new permissions (write_discounts)."
        : `Shopify discount for "Buy ${step.qty}" was not created: ${msg}`;
      break;
    }
  }
  // "Buy N Get N FREE": Shopify Buy X Get Y — N bought → N more (the cheapest) free, repeats.
  // Doesn't combine with other product discounts, so Shopify gives the cart the better of
  // this and a "% off" tier instead of stacking them (checked live 2026-10-10).
  if (!createFailed) {
    for (const n of bogoSteps(offer.tiers)) {
      try {
        const items = { products: { productsToAdd: offer.productIds.map(PRODUCT_GID) } };
        const d = await gql<{
          discountAutomaticBxgyCreate?: {
            automaticDiscountNode?: { id: string } | null;
            userErrors: { message: string }[];
          };
        }>(
          admin,
          `#graphql
          mutation WcVdBxgyCreate($d: DiscountAutomaticBxgyInput!) {
            discountAutomaticBxgyCreate(automaticBxgyDiscount: $d) {
              automaticDiscountNode { id }
              userErrors { field message }
            }
          }`,
          {
            d: {
              title: (cleanTitle(offer.discountTitle) || "Bundle discount") + invisibleSuffix(`${offer.id}:b${n}:${Date.now()}`),
              startsAt: dayStart(offer.startsAt),
              endsAt: dayEnd(offer.endsAt),
              combinesWith: { productDiscounts: false, orderDiscounts: true, shippingDiscounts: true },
              customerBuys: { value: { quantity: String(n) }, items },
              customerGets: { value: { discountOnQuantity: { quantity: String(n), effect: { percentage: 1 } } }, items },
            },
          },
        );
        const id = d.discountAutomaticBxgyCreate?.automaticDiscountNode?.id;
        if (!id) throw new Error(errs(d.discountAutomaticBxgyCreate?.userErrors) || "not created");
        next.discountIds.push(id);
      } catch (e) {
        const msg = (e as Error).message;
        createFailed = true;
        next.discountError = /access|scope|denied|write_discounts/i.test(msg)
          ? "The app has no permission to create discounts yet — open the app once and approve the new permissions (write_discounts)."
          : `Shopify discount for "Buy ${n} Get ${n} FREE" was not created: ${msg}`;
        break;
      }
    }
  }
  if (createFailed && next.discountIds.length > leftovers.length) {
    // half-created chain would give wrong prices → roll back and switch off
    const created = next.discountIds.slice(leftovers.length);
    const stuck = await deleteDiscounts(admin, created);
    next.discountIds = [...leftovers, ...stuck];
  }
  if (createFailed) next.active = false;
  return next;
}

export async function removeOfferDiscounts(admin: AdminGraphql, offer: VdOffer) {
  return deleteDiscounts(admin, offer.discountIds);
}

// ---------------------------------------------------------------------------
// form → offer

const str = (v: unknown, max = 200) => String(v ?? "").trim().slice(0, max);
const isDate = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s);

/** Validates the submitted offer (JSON field "offer"). Gifts are re-checked live. */
export async function offerFromForm(
  admin: AdminGraphql,
  form: FormData,
  id: string,
  others: VdOffer[],
): Promise<{ offer?: VdOffer; errors: Record<string, string> }> {
  const errors: Record<string, string> = {};
  let o: Partial<VdOffer> = {};
  try {
    o = JSON.parse(String(form.get("offer") ?? "{}"));
  } catch {
    return { errors: { form: "Could not read the form — reload the page" } };
  }

  const name = str(o.name, 120);
  if (!name) errors.name = "Give the offer a name";

  const productIds = (Array.isArray(o.productIds) ? o.productIds : []).map(digits).filter(Boolean);
  const uniq = [...new Set(productIds)];
  if (!uniq.length) errors.products = "Select the products this offer applies to";
  const titles = Array.isArray(o.productTitles) ? o.productTitles.map((t) => str(t, 255)) : [];
  const images = Array.isArray(o.productImages) ? o.productImages.map((t) => str(t, 1000)) : [];

  const startsAt = str(o.startsAt, 10);
  const endsAt = str(o.endsAt, 10);
  if (startsAt && !isDate(startsAt)) errors.dates = "Start date must be YYYY-MM-DD";
  if (endsAt && !isDate(endsAt)) errors.dates = "End date must be YYYY-MM-DD";
  if (startsAt && endsAt && endsAt < startsAt) errors.dates = "End date is before the start date";

  // tiers
  const rawTiers = (Array.isArray(o.tiers) ? o.tiers : []).slice(0, MAX_TIERS);
  const tiers: VdTier[] = rawTiers.map((t) => {
    const free = Math.min(Math.max(Math.round(Number(t?.free ?? 0)) || 0, 0), MAX_FREE);
    return {
      qty: free ? free * 2 : Math.round(Number(t?.qty ?? 0)),
      percent: free ? 0 : Math.round(Number(t?.percent ?? 0) * 100) / 100,
      ...(free ? { free } : {}),
      label: str(t?.label, 40),
      gifts: Array.isArray(t?.gifts) ? t.gifts.slice(0, 4) : [],
    };
  });
  if (!tiers.length) errors.tiers = "Add at least one tier";
  tiers.forEach((t, i) => {
    if (!(t.qty >= 1 && t.qty <= 99)) errors.tiers = `Tier #${i + 1}: quantity must be 1–99`;
    else if (i > 0 && t.qty <= tiers[i - 1].qty)
      errors.tiers = `Tier #${i + 1}: quantity must be bigger than tier #${i}`;
    else if (!(t.percent >= 0 && t.percent <= 90)) errors.tiers = `Tier #${i + 1}: discount must be 0–90%`;
    else if (!isBogo(t)) {
      // "% off" tiers only grow; "Buy N Get N FREE" tiers don't take part in this rule
      const prev = tiers.slice(0, i).filter((x) => !isBogo(x)).pop();
      if (prev && t.percent < prev.percent) errors.tiers = `Tier #${i + 1}: discount can't be lower than an earlier "% off" tier`;
    }
  });

  // gifts: must be $0 products (otherwise the shopper would pay for them)
  const giftIds = [...new Set(tiers.flatMap((t) => t.gifts.map((g) => digits(g?.productId))).filter(Boolean))];
  let live = new Map<string, ProductNode>();
  try {
    live = await fetchProducts(admin, giftIds);
  } catch (e) {
    errors.gifts = `Could not check the gift products: ${(e as Error).message}`;
  }
  for (const t of tiers) {
    const names = new Map(t.gifts.map((g) => [digits(g?.productId), str(g?.name, 60)]));
    t.gifts = t.gifts
      .map((g) => live.get(digits(g?.productId)))
      .filter((p): p is ProductNode => Boolean(p))
      .map((p) => {
        const c = giftFromProduct(p);
        const custom = names.get(digits(p.id));
        if (custom) c.gift.name = custom;
        if (!c.isFree) errors.gifts = `“${p.title}” is not $0 — use “Make $0 gift copy”`;
        else if (!c.active) errors.gifts = `“${p.title}” is a draft or archived — set it to Unlisted in Products`;
        return c.gift;
      });
  }
  if (!errors.gifts && giftIds.length && live.size < giftIds.length)
    errors.gifts = "A gift product was deleted — pick it again";

  const active = Boolean(o.active);
  if (active) {
    const clash = others.find(
      (x) => x.id !== id && x.active && offerStatus(x) !== "Ended" && x.productIds.some((p) => uniq.includes(p)),
    );
    if (clash)
      errors.products = `A product is already in the active offer “${clash.name}” — one product can be in one active offer only`;
    const used = others
      .filter((x) => x.id !== id && x.active && offerStatus(x) !== "Ended")
      .reduce((n, x) => n + discountCount(x.tiers), 0);
    if (used + discountCount(tiers) > AUTOMATIC_DISCOUNT_LIMIT)
      errors.tiers = `Shopify allows ${AUTOMATIC_DISCOUNT_LIMIT} active automatic discounts; active offers already use ${used}`;
  }

  if (Object.keys(errors).length) return { errors };

  const defaultTier = Math.min(Math.max(Math.round(Number(o.defaultTier ?? 0)), 0), tiers.length - 1);
  const visibleTiers = Math.min(Math.max(Math.round(Number(o.visibleTiers ?? 3)), 1), MAX_TIERS);

  return {
    errors,
    offer: {
      id,
      name,
      active,
      startsAt,
      endsAt,
      productIds: uniq,
      productTitles: uniq.map((pid) => titles[productIds.indexOf(pid)] ?? ""),
      productImages: uniq.map((pid) => images[productIds.indexOf(pid)] ?? ""),
      header: str(o.header, 80),
      discountTitle: cleanTitle(str(o.discountTitle, 60)) || "Bundle discount",
      defaultTier,
      visibleTiers,
      tiers,
      discountIds: [],
      discountError: "",
      updatedAt: new Date().toISOString(),
    },
  };
}

export const newOfferId = () =>
  `vd_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
