/**
 * Duplicate a bundle product.
 *
 * Shopify's own "Duplicate" refuses products whose variants are bundles
 * ("Cannot duplicate a bundle product"). This makes the copy with productSet:
 * same title (+ " (Copy)"), description, SEO, template, category, type, vendor, tags,
 * options and variants (prices, SKUs, inventory settings, variant photos),
 * the same media files, product metafields and variant metafields (including our
 * bundle settings wc_bundles.config), manual collections and sales channels.
 * The copy is created as Draft. Its bundle components are then set by this app
 * from the copied settings, so this app owns them and can edit them later.
 */
import { activateBundle, loadAll } from "./nb-gb.server";

import type { authenticate } from "./shopify.server";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  if (!json.data) throw new Error("Empty response from Shopify");
  return json.data;
}

type Mf = { namespace: string; key: string; type: string; value: string };

// Not copied: the Bundle Contents snapshot (keyed by the source's variant ids — rebuilt with
// Save & sync) and app-reserved namespaces (only their owning app may write them).
const SKIP = (m: Mf) => (m.namespace === "custom" && m.key === "wc_bundle_contents") || m.namespace.startsWith("app--") || m.namespace.startsWith("$app");

async function productMetafields(admin: AdminGraphql, id: string): Promise<Mf[]> {
  const out: Mf[] = [];
  let after: string | null = null;
  for (;;) {
    const d: { product: { metafields: { nodes: Mf[]; pageInfo: { hasNextPage: boolean; endCursor: string } } } } = await gql(
      admin,
      `#graphql
      query WcDupMf($id: ID!, $after: String) {
        product(id: $id) { metafields(first: 100, after: $after) { nodes { namespace key type value } pageInfo { hasNextPage endCursor } } }
      }`,
      { id, after },
    );
    out.push(...d.product.metafields.nodes);
    if (!d.product.metafields.pageInfo.hasNextPage) return out;
    after = d.product.metafields.pageInfo.endCursor;
  }
}

type Src = {
  title: string;
  descriptionHtml: string;
  vendor: string;
  productType: string;
  tags: string[];
  templateSuffix: string | null;
  seo: { title: string | null; description: string | null };
  category: { id: string } | null;
  options: { name: string; position: number; optionValues: { name: string }[] }[];
  media: { nodes: { id: string; alt: string | null }[] };
  collections: { nodes: { id: string; ruleSet: { appliedDisjunctively: boolean } | null }[] };
  resourcePublications: { nodes: { publication: { id: string } }[] };
  variants: {
    nodes: {
      price: string;
      compareAtPrice: string | null;
      sku: string | null;
      taxable: boolean;
      inventoryPolicy: string;
      selectedOptions: { name: string; value: string }[];
      inventoryItem: {
        tracked: boolean;
        requiresShipping: boolean;
        countryCodeOfOrigin: string | null;
        harmonizedSystemCode: string | null;
        measurement: { weight: { value: number; unit: string } | null };
      };
      media: { nodes: { id: string }[] };
      metafields: { nodes: Mf[] };
    }[];
  };
};

export async function duplicateBundleProduct(admin: AdminGraphql, productId: string) {
  const d: { product: Src | null } = await gql(
    admin,
    `#graphql
    query WcDupSrc($id: ID!) {
      product(id: $id) {
        title descriptionHtml vendor productType tags templateSuffix
        seo { title description } category { id }
        options { name position optionValues { name } }
        media(first: 250) { nodes { id alt } }
        collections(first: 50) { nodes { id ruleSet { appliedDisjunctively } } }
        resourcePublications(first: 50) { nodes { publication { id } } }
        variants(first: 100) {
          nodes {
            price compareAtPrice sku taxable inventoryPolicy
            selectedOptions { name value }
            inventoryItem { tracked requiresShipping countryCodeOfOrigin harmonizedSystemCode measurement { weight { value unit } } }
            media(first: 1) { nodes { id } }
            metafields(first: 50) { nodes { namespace key type value } }
          }
        }
      }
    }`,
    { id: productId },
  );
  const p = d.product;
  if (!p) throw new Error("Product not found");
  const metafields = (await productMetafields(admin, productId)).filter((m) => !SKIP(m));

  const input = {
    title: `${p.title} (Copy)`,
    descriptionHtml: p.descriptionHtml,
    vendor: p.vendor,
    productType: p.productType,
    tags: p.tags,
    templateSuffix: p.templateSuffix,
    seo: p.seo,
    ...(p.category ? { category: p.category.id } : {}),
    status: "DRAFT",
    productOptions: p.options.map((o) => ({ name: o.name, position: o.position, values: o.optionValues.map((v) => ({ name: v.name })) })),
    files: p.media.nodes.map((m) => ({ id: m.id, alt: m.alt ?? "" })),
    collections: p.collections.nodes.filter((c) => !c.ruleSet).map((c) => c.id),
    metafields,
    variants: p.variants.nodes.map((v, i) => {
      const ii = v.inventoryItem;
      return {
        position: i + 1,
        optionValues: v.selectedOptions.map((o) => ({ optionName: o.name, name: o.value })),
        price: v.price,
        compareAtPrice: v.compareAtPrice,
        sku: v.sku,
        taxable: v.taxable,
        inventoryPolicy: v.inventoryPolicy,
        inventoryItem: {
          tracked: ii.tracked,
          requiresShipping: ii.requiresShipping,
          ...(ii.measurement?.weight ? { measurement: { weight: ii.measurement.weight } } : {}),
          ...(ii.countryCodeOfOrigin ? { countryCodeOfOrigin: ii.countryCodeOfOrigin } : {}),
          ...(ii.harmonizedSystemCode ? { harmonizedSystemCode: ii.harmonizedSystemCode } : {}),
        },
        ...(v.media.nodes[0] ? { file: { id: v.media.nodes[0].id } } : {}),
        metafields: v.metafields.nodes.filter((m) => !SKIP(m)),
      };
    }),
  };

  const r: { productSet: { product: { id: string; handle: string } | null; userErrors: { field: string[] | null; message: string }[] } } = await gql(
    admin,
    `#graphql
    mutation WcDupSet($input: ProductSetInput!) {
      productSet(input: $input, synchronous: true) { product { id handle } userErrors { field message } }
    }`,
    { input },
  );
  if (r.productSet.userErrors.length || !r.productSet.product) {
    throw new Error(r.productSet.userErrors.map((e) => `${(e.field || []).join(".")}: ${e.message}`).join("; ") || "Copy failed");
  }
  const copy = r.productSet.product;

  // Same sales channels as the original (the copy is Draft, so customers don't see it yet)
  const pubs = p.resourcePublications.nodes.map((n) => ({ publicationId: n.publication.id }));
  if (pubs.length) {
    const pr: { publishablePublish: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcDupPub($id: ID!, $input: [PublicationInput!]!) { publishablePublish(id: $id, input: $input) { userErrors { message } } }`,
      { id: copy.id, input: pubs },
    );
    if (pr.publishablePublish.userErrors.length) console.warn("[wc-bundles] copy publish:", pr.publishablePublish.userErrors.map((e) => e.message).join("; "));
  }

  // Bundle components from the copied settings — owned by this app
  let bundled = 0;
  const { products } = await loadAll(admin);
  const bp = products.find((x) => x.id === copy.id);
  if (bp && bp.variants.some((v) => v.ownComps.length)) bundled = (await activateBundle(admin, bp)).variants;
  return { id: copy.id, handle: copy.handle, bundled };
}
