/**
 * Bundle Contents — component values in every storefront currency.
 *
 * Shopify Markets converts and ROUNDS prices per currency (e.g. GBP to whole
 * pounds, EUR to .95), so the storefront cannot reproduce them from the base
 * value and Shopify.currency.rate. Components are often Draft products, so
 * Liquid cannot read them either. We therefore ask the Admin API for each
 * component's contextual compare-at price in one country per currency and
 * store the result in the snapshot (item.values[CUR] in cents, config.currencies).
 *
 * A daily refresh keeps the values in step with Shopify's exchange rates.
 */
import { readBundle, type BundleConfig } from "./bundles.shared";

type Admin = { graphql: (query: string, options?: { variables?: Record<string, unknown> }) => Promise<Response> };

/** Countries probed to discover which currencies the storefront can show (one per currency is kept). */
const PROBE = [
  "US", "GB", "DE", "CA", "AU", "NZ", "CH", "DK", "SE", "NO", "PL", "CZ", "HU", "RO", "IS", "JP", "CN", "HK",
  "TW", "KR", "SG", "MY", "TH", "ID", "PH", "VN", "IN", "PK", "AE", "SA", "QA", "IL", "TR", "ZA", "EG", "MA",
  "NG", "KE", "BR", "MX", "AR", "CL", "CO", "PE", "DO", "DM", "MV", "UA", "KZ", "FJ", "XK", "BA", "AL",
];

async function gql<T>(admin: Admin, query: string, variables: Record<string, unknown> = {}): Promise<T> {
  const res = await admin.graphql(query, { variables });
  const json = await res.json();
  if (!res.ok || json.errors?.length) throw new Error(json.errors?.map((e: { message: string }) => e.message).join("; ") || "Shopify request failed");
  return json.data as T;
}

function cents(amount: string | null | undefined): number | null {
  if (amount === null || amount === undefined || amount === "") return null;
  const n = Number(amount);
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : null;
}

/** currency -> representative country, discovered through one variant's contextual pricing. */
export async function currencyCountries(admin: Admin, sampleVariantId: string): Promise<Map<string, string>> {
  const fields = PROBE.map(c => `${c}: contextualPricing(context: {country: ${c}}) { price { currencyCode } }`).join("\n");
  const data = await gql<{ node: Record<string, { price: { currencyCode: string } } | null> | null }>(admin,
    `#graphql
    query WcbProbe($id: ID!) { node(id: $id) { ... on ProductVariant { ${fields} } } }`, { id: sampleVariantId });
  const map = new Map<string, string>();
  for (const c of PROBE) {
    const cur = data.node?.[c]?.price?.currencyCode;
    if (cur && !map.has(cur)) map.set(cur, c);
  }
  return map;
}

/** variantId -> { CUR: compare-at cents | null } */
export async function contextualValues(admin: Admin, variantIds: string[], countries: Map<string, string>) {
  const out = new Map<string, Record<string, number | null>>();
  const titles = new Map<string, string>();
  const entries = [...countries.entries()];
  const fields = entries.map(([cur, c]) => `${cur}: contextualPricing(context: {country: ${c}}) { compareAtPrice { amount currencyCode } }`).join("\n");
  for (let i = 0; i < variantIds.length; i += 5) {
    const data = await gql<{ nodes: ({ id: string } & Record<string, { compareAtPrice: { amount: string; currencyCode: string } | null } | null>)[] }>(admin,
      `#graphql
      query WcbValues($ids: [ID!]!) { nodes(ids: $ids) { ... on ProductVariant { id product { title shortTitle: metafield(namespace: "custom", key: "short_title") { value } } ${fields} } } }`, { ids: variantIds.slice(i, i + 5) });
    for (const node of data.nodes) {
      if (!node?.id) continue;
      const values: Record<string, number | null> = {};
      for (const [cur] of entries) {
        const p = (node as Record<string, { compareAtPrice: { amount: string; currencyCode: string } | null } | null>)[cur];
        values[cur] = p?.compareAtPrice && p.compareAtPrice.currencyCode === cur ? cents(p.compareAtPrice.amount) : null;
      }
      out.set(node.id, values);
      const product = (node as unknown as { product?: { title: string; shortTitle: { value: string } | null } }).product;
      if (product) titles.set(node.id, product.shortTitle?.value?.trim() || product.title);
    }
  }
  return { values: out, titles };
}

/** Fills item.values / config.currencies (and refreshes item.title from Short Title) in place. Never throws: on failure the base currency stays labelled. */
export async function addCurrencyValues(admin: Admin, config: BundleConfig): Promise<{ ok: boolean; error?: string }> {
  const ids = [...new Set(config.panels.flatMap(p => p.items.map(i => i.variantId)))];
  if (!ids.length) return { ok: true };
  try {
    const countries = await currencyCountries(admin, ids[0]);
    if (!countries.size) return { ok: false, error: "No storefront currencies found." };
    const { values, titles } = await contextualValues(admin, ids, countries);
    config.currencies = [...countries.keys()].sort();
    for (const panel of config.panels) for (const item of panel.items) {
      const v = values.get(item.variantId);
      item.values = v ? v : undefined;
      // keep the snapshot title in step with the component's current Short Title
      const t = titles.get(item.variantId);
      if (t) item.title = t;
    }
    config.currenciesAt = new Date().toISOString();
    return { ok: true };
  } catch (e) {
    console.warn("[wc-bundles] currency values:", (e as Error).message);
    return { ok: false, error: (e as Error).message };
  }
}

const SAVE = `#graphql
  mutation WcbCurrencySave($metafields: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $metafields) { userErrors { message } } }`;

/** Refresh currency values of every saved snapshot (CAS — a concurrent admin save wins). */
export async function refreshAllCurrencyValues(admin: Admin) {
  let after: string | null = null;
  let updated = 0;
  do {
    const data: { products: { nodes: { id: string; config: { value: string; compareDigest: string } | null }[]; pageInfo: { hasNextPage: boolean; endCursor: string } } } = await gql(admin, `#graphql
      query WcbAll($after: String) {
        products(first: 50, after: $after, query: "metafields.custom.wc_bundle_contents:*") {
          nodes { id config: metafield(namespace: "custom", key: "wc_bundle_contents") { value compareDigest } }
          pageInfo { hasNextPage endCursor }
        }
      }`, { after });
    for (const p of data.products.nodes) {
      const config = readBundle(p.config?.value);
      if (!config || !p.config) continue;
      const before = JSON.stringify(config);
      const r = await addCurrencyValues(admin, config);
      if (!r.ok) continue;
      const old = JSON.parse(before) as BundleConfig;
      const beforeValues = JSON.stringify({ c: old.currencies, v: old.panels.map(x => x.items.map(i => [i.values, i.title])) });
      const afterValues = JSON.stringify({ c: config.currencies, v: config.panels.map(x => x.items.map(i => [i.values, i.title])) });
      if (beforeValues === afterValues) continue;
      const value = JSON.stringify(config);
      if (new TextEncoder().encode(value).length > 60000) { console.warn(`[wc-bundles] ${p.id}: snapshot too large with currencies`); continue; }
      const res = await gql<{ metafieldsSet: { userErrors: { message: string }[] } }>(admin, SAVE,
        { metafields: [{ ownerId: p.id, namespace: "custom", key: "wc_bundle_contents", type: "json", value, compareDigest: p.config.compareDigest }] });
      if (res.metafieldsSet.userErrors.length) console.warn(`[wc-bundles] ${p.id}:`, res.metafieldsSet.userErrors.map(e => e.message).join("; "));
      else updated++;
    }
    after = data.products.pageInfo.hasNextPage ? data.products.pageInfo.endCursor : null;
  } while (after);
  return updated;
}

declare global {
  // eslint-disable-next-line no-var
  var wcBundleCurrencyTimer: NodeJS.Timeout | undefined;
}

export function startBundleCurrencyScheduler(getShops: () => Promise<string[]>, getAdmin: (shop: string) => Promise<Admin>) {
  if (globalThis.wcBundleCurrencyTimer) return;
  const tick = async () => {
    let shops: string[] = [];
    try { shops = await getShops(); } catch { return; }
    for (const shop of shops) {
      try {
        const n = await refreshAllCurrencyValues(await getAdmin(shop));
        console.log(`[wc-bundles] currency refresh ${shop}: ${n} snapshot(s) updated`);
      } catch (e) {
        console.warn(`[wc-bundles] currency refresh ${shop}:`, (e as Error).message);
      }
    }
  };
  setTimeout(() => void tick(), 2 * 60 * 1000).unref?.();
  globalThis.wcBundleCurrencyTimer = setInterval(() => void tick(), 6 * 60 * 60 * 1000);
  globalThis.wcBundleCurrencyTimer.unref?.();
}
