/**
 * Volume Discounts — statistics for the offers table (like Vitals):
 * Impressions, Clicks, Click rate, Orders, Revenue.
 *
 *  - Impressions / clicks: the storefront block sends a beacon
 *    (POST /api/vd/event, once per page view and on the first tier click).
 *    Counted per day per offer in $WC_DATA_DIR/vd/<shop>/events.json.
 *  - Orders / revenue: one Bulk Operation over the last 60 days of orders.
 *    A line counts when it got one of OUR automatic discounts (allocation of
 *    an AutomaticDiscountApplication whose title is the offer's discount
 *    title) and its product is in the offer. Revenue = the line's discounted
 *    total. Cached in the app-owned metafield wc_vd.stats (6 h, or Refresh).
 */
import fs from "node:fs/promises";
import path from "node:path";
import { cleanTitle } from "./vd.shared";

type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

// ---------------------------------------------------------------------------
// beacon events (file storage)

const dataRoot = () =>
  path.resolve(process.env.WC_DATA_DIR || path.join(process.cwd(), "data"), "vd");
const safe = (shop: string) => shop.replace(/[^a-z0-9.-]/gi, "_");
const eventsFile = (shop: string) => path.join(dataRoot(), safe(shop), "events.json");

/** day → offerId → [impressions, clicks] */
type Events = Record<string, Record<string, [number, number]>>;

const pending = new Map<string, Events>();
let flushTimer: NodeJS.Timeout | null = null;

async function readEvents(shop: string): Promise<Events> {
  try {
    return JSON.parse(await fs.readFile(eventsFile(shop), "utf8")) as Events;
  } catch {
    return {};
  }
}

async function flush() {
  flushTimer = null;
  const batch = [...pending.entries()];
  pending.clear();
  for (const [shop, add] of batch) {
    const cur = await readEvents(shop);
    for (const [d, offers] of Object.entries(add)) {
      const day = (cur[d] ??= {});
      for (const [id, [v, c]] of Object.entries(offers)) {
        const x = (day[id] ??= [0, 0]);
        x[0] += v;
        x[1] += c;
      }
    }
    // keep ~100 days
    const keep = Object.keys(cur).sort().slice(-100);
    const trimmed: Events = {};
    for (const d of keep) trimmed[d] = cur[d];
    const file = eventsFile(shop);
    await fs.mkdir(path.dirname(file), { recursive: true });
    const tmp = `${file}.${process.pid}.tmp`;
    await fs.writeFile(tmp, JSON.stringify(trimmed));
    await fs.rename(tmp, file);
  }
}

export function recordEvent(shop: string, offerId: string, kind: "v" | "c") {
  const d = new Date().toISOString().slice(0, 10);
  const ev = pending.get(shop) ?? {};
  const day = (ev[d] ??= {});
  const x = (day[offerId] ??= [0, 0]);
  if (kind === "v") x[0] += 1;
  else x[1] += 1;
  pending.set(shop, ev);
  if (!flushTimer) flushTimer = setTimeout(() => void flush().catch(() => {}), 5000);
}

export async function getEvents(shop: string) {
  await flush().catch(() => {});
  return readEvents(shop);
}

// ---------------------------------------------------------------------------
// orders (bulk operation, cached in a metafield)

export const VD_STATS_WINDOW_DAYS = 60;
const STALE_MS = 6 * 60 * 60 * 1000;
const RUNNING_TIMEOUT_MS = 20 * 60 * 1000;

/** per day: "<discount title>|<productId>" → [lines, revenue] */
export type VdStatsDay = { d: string; k: Record<string, [number, number]> };

export type VdStats = {
  version: 1;
  status: "idle" | "running" | "error" | "no_access";
  opId?: string;
  startedAt?: string;
  computedAt?: string;
  error?: string;
  currency?: string;
  days: VdStatsDay[];
};

const empty = (): VdStats => ({ version: 1, status: "idle", days: [] });

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>) {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: unknown };
  if (json.errors) throw new Error(JSON.stringify(json.errors).slice(0, 300));
  return json.data as T;
}

async function load(admin: AdminGraphql) {
  const data = await gql<{
    currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null };
  }>(
    admin,
    `#graphql
    query WcVdStatsCfg {
      currentAppInstallation { id metafield(namespace: "wc_vd", key: "stats") { value } }
    }`,
  );
  const inst = data.currentAppInstallation;
  let stats = empty();
  if (inst?.metafield?.value) {
    try {
      const p = JSON.parse(inst.metafield.value);
      if (p && Array.isArray(p.days)) stats = p;
    } catch {
      // rebuild
    }
  }
  return { ownerId: inst?.id ?? "", stats };
}

async function save(admin: AdminGraphql, ownerId: string, stats: VdStats) {
  const data = await gql<{ metafieldsSet?: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcVdStatsSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    { metafields: [{ ownerId, namespace: "wc_vd", key: "stats", type: "json", value: JSON.stringify(stats) }] },
  );
  const e = (data.metafieldsSet?.userErrors ?? []).map((x) => x.message).join("; ");
  if (e) throw new Error(e);
}

const isAccessError = (m: string) => /access denied|read_orders|not approved|access scope|ACCESS_DENIED/i.test(m);

async function start(admin: AdminGraphql, ownerId: string, prev: VdStats) {
  const since = new Date(Date.now() - VD_STATS_WINDOW_DAYS * 86400000).toISOString().slice(0, 10);
  const query = `{
    orders(query: "created_at:>=${since} AND -status:cancelled") {
      edges { node {
        id createdAt test
        lineItems { edges { node {
          quantity
          product { id }
          discountedTotalSet { shopMoney { amount currencyCode } }
          discountAllocations { discountApplication { __typename ... on AutomaticDiscountApplication { title } } }
        } } }
      } }
    }
  }`;
  let next: VdStats;
  try {
    const data = await gql<{
      bulkOperationRunQuery?: { bulkOperation?: { id: string } | null; userErrors: { message: string }[] };
    }>(
      admin,
      `#graphql
      mutation WcVdStatsRun($query: String!) {
        bulkOperationRunQuery(query: $query) { bulkOperation { id status } userErrors { field message } }
      }`,
      { query },
    );
    const r = data.bulkOperationRunQuery;
    const err = (r?.userErrors ?? []).map((e) => e.message).join("; ");
    next =
      err || !r?.bulkOperation?.id
        ? { ...prev, status: isAccessError(err) ? "no_access" : "error", error: err || "Bulk operation was not created" }
        : { ...prev, status: "running", opId: r.bulkOperation.id, startedAt: new Date().toISOString(), error: undefined };
  } catch (e) {
    const msg = (e as Error).message;
    next = { ...prev, status: isAccessError(msg) ? "no_access" : "error", error: msg };
  }
  await save(admin, ownerId, next);
  return next;
}

/** Bulk JSONL → per-day aggregates. Exported for tests. */
export function aggregate(jsonl: string) {
  const orders = new Map<string, { d: string; test: boolean }>();
  const byDay = new Map<string, VdStatsDay>();
  let currency: string | undefined;
  const rows: Record<string, unknown>[] = [];
  for (const raw of jsonl.split("\n")) {
    if (!raw.trim()) continue;
    try {
      rows.push(JSON.parse(raw));
    } catch {
      // skip
    }
  }
  for (const row of rows)
    if (!row.__parentId)
      orders.set(String(row.id), { d: String(row.createdAt ?? "").slice(0, 10), test: Boolean(row.test) });
  for (const row of rows) {
    const parent = row.__parentId as string | undefined;
    if (!parent) continue;
    const o = orders.get(parent);
    if (!o || o.test || !o.d) continue;
    const pid = String((row.product as { id?: string } | null)?.id ?? "").replace(/\D/g, "");
    if (!pid) continue;
    const allocs = (row.discountAllocations as { discountApplication?: { __typename?: string; title?: string } }[]) ?? [];
    const titles = [
      ...new Set(
        allocs
          .map((a) => a.discountApplication)
          .filter((a) => a?.__typename === "AutomaticDiscountApplication" && a.title)
          .map((a) => cleanTitle(String(a!.title))),
      ),
    ];
    if (!titles.length) continue;
    const money = (row.discountedTotalSet as { shopMoney?: { amount?: string; currencyCode?: string } })?.shopMoney;
    currency = currency || money?.currencyCode;
    const rev = Number(money?.amount ?? 0);
    const day = byDay.get(o.d) ?? { d: o.d, k: {} };
    for (const t of titles) {
      const key = `${t}|${pid}`;
      const cur = day.k[key] ?? [0, 0];
      day.k[key] = [cur[0] + 1, Math.round((cur[1] + rev) * 100) / 100];
    }
    byDay.set(o.d, day);
  }
  return { days: [...byDay.values()].sort((a, b) => a.d.localeCompare(b.d)), currency };
}

async function finish(admin: AdminGraphql, ownerId: string, prev: VdStats) {
  const data = await gql<{ bulkOperation?: { status: string; errorCode?: string | null; url?: string | null } | null }>(
    admin,
    `#graphql
    query WcVdStatsOp($id: ID!) { bulkOperation(id: $id) { id status errorCode url } }`,
    { id: prev.opId },
  );
  const op = data.bulkOperation;
  const started = prev.startedAt ? Date.parse(prev.startedAt) : 0;
  if (!op || ["CREATED", "RUNNING"].includes(op.status)) {
    if (Date.now() - started > RUNNING_TIMEOUT_MS) {
      const next: VdStats = { ...prev, status: "error", error: "Timed out collecting orders" };
      await save(admin, ownerId, next);
      return next;
    }
    return prev;
  }
  if (op.status !== "COMPLETED") {
    const next: VdStats = { ...prev, status: "error", error: `Bulk operation ${op.status}${op.errorCode ? ` (${op.errorCode})` : ""}` };
    await save(admin, ownerId, next);
    return next;
  }
  let text = "";
  if (op.url) {
    const res = await fetch(op.url);
    if (!res.ok) throw new Error(`Download failed: ${res.status}`);
    text = await res.text();
  }
  const { days, currency } = aggregate(text);
  const next: VdStats = { version: 1, status: "idle", computedAt: new Date().toISOString(), currency: currency ?? prev.currency, days };
  await save(admin, ownerId, next);
  return next;
}

export async function getVdStats(admin: AdminGraphql, force = false) {
  const { ownerId, stats } = await load(admin);
  try {
    if (stats.status === "running" && stats.opId) return await finish(admin, ownerId, stats);
    const age = stats.computedAt ? Date.now() - Date.parse(stats.computedAt) : Infinity;
    if (force || age > STALE_MS) return await start(admin, ownerId, stats);
  } catch (e) {
    return { ...stats, status: "error" as const, error: (e as Error).message };
  }
  return stats;
}

export type OfferRow = { impressions: number; clicks: number; orders: number; revenue: number };

/** Per-offer totals for the last `days` days. */
export function summarizeOffers(
  stats: VdStats,
  events: Events,
  offers: { id: string; discountTitle: string; productIds: string[] }[],
  days: number,
) {
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  const out: Record<string, OfferRow> = {};
  for (const o of offers) {
    const row: OfferRow = { impressions: 0, clicks: 0, orders: 0, revenue: 0 };
    for (const [d, per] of Object.entries(events)) {
      if (d < since || !per[o.id]) continue;
      row.impressions += per[o.id][0];
      row.clicks += per[o.id][1];
    }
    const keys = new Set(o.productIds.map((p) => `${cleanTitle(o.discountTitle)}|${p}`));
    for (const day of stats.days) {
      if (day.d < since) continue;
      for (const [k, [n, rev]] of Object.entries(day.k)) {
        if (!keys.has(k)) continue;
        row.orders += n;
        row.revenue += rev;
      }
    }
    row.revenue = Math.round(row.revenue * 100) / 100;
    out[o.id] = row;
  }
  return out;
}
