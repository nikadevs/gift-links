/**
 * SEO & Speed — small shared UI pieces (module tabs, badges, table CSS).
 */
import { useLocation, useNavigate } from "react-router";
import {
  check,
  SEVERITY_ORDER,
  SEVERITY_WEIGHT,
  type CheckDef,
  type Finding,
  type Severity,
} from "./seo.shared";

export const TABS = [
  { href: "/app/seo", label: "Overview" },
  { href: "/app/seo/issues", label: "Issues" },
  { href: "/app/seo/pages", label: "Pages" },
  { href: "/app/seo/speed", label: "Speed" },
  { href: "/app/seo/meta", label: "Meta tags" },
  { href: "/app/seo/images", label: "Image ALT" },
  { href: "/app/seo/links", label: "Links & 404" },
  { href: "/app/seo/theme", label: "Theme code" },
  { href: "/app/seo/settings", label: "Settings" },
];

export function SeoTabs() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const active =
    TABS.slice()
      .reverse()
      .find((t) => pathname === t.href || pathname.startsWith(`${t.href}/`))?.href ??
    "/app/seo";
  return (
    <div className="wcs-tabs">
      <style>{SEO_CSS}</style>
      {TABS.map((t) => (
        <button
          key={t.href}
          type="button"
          className={t.href === active ? "on" : ""}
          onClick={() => navigate(t.href)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}

const SEV_TONE: Record<Severity, "critical" | "warning" | "caution" | "info" | "neutral"> = {
  critical: "critical",
  high: "warning",
  medium: "caution",
  low: "info",
  info: "neutral",
};

export function SevBadge({ severity }: { severity: Severity }) {
  return <s-badge tone={SEV_TONE[severity]}>{severity}</s-badge>;
}

export function ago(iso?: string) {
  if (!iso) return "never";
  const m = Math.round((Date.now() - Date.parse(iso)) / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  return h < 48 ? `${h} h ago` : `${Math.round(h / 24)} days ago`;
}

export type FindingGroup = {
  def: CheckDef;
  count: number;
  items: Finding[];
};

export function groupFindings(findings: Finding[]): FindingGroup[] {
  const map = new Map<string, FindingGroup>();
  for (const f of findings) {
    const g = map.get(f.check) ?? { def: check(f.check), count: 0, items: [] };
    g.count++;
    g.items.push(f);
    map.set(f.check, g);
  }
  return [...map.values()].sort(
    (a, b) =>
      SEVERITY_ORDER.indexOf(a.def.severity) - SEVERITY_ORDER.indexOf(b.def.severity) ||
      b.count * SEVERITY_WEIGHT[b.def.severity] - a.count * SEVERITY_WEIGHT[a.def.severity] ||
      a.def.title.localeCompare(b.def.title),
  );
}

export const FIX_LINK: Record<string, { href: string; label: string } | undefined> = {
  meta: { href: "/app/seo/meta", label: "Fix in Meta tags" },
  images: { href: "/app/seo/images", label: "Fix in Image ALT" },
  links: { href: "/app/seo/links", label: "Fix in Links & 404" },
  speed: { href: "/app/seo/speed", label: "Open Speed" },
  theme: { href: "/app/seo/theme", label: "See Theme code" },
};

export function pathOf(url: string) {
  try {
    const u = new URL(url);
    return decodeURIComponent(u.pathname) + u.search;
  } catch {
    return url;
  }
}

export function scoreTone(n?: number) {
  if (n == null) return "neutral";
  return n >= 90 ? "success" : n >= 50 ? "warning" : "critical";
}

export const SEO_CSS = `
.wcs-tabs{display:flex;flex-wrap:wrap;gap:4px;margin:0 0 4px}
.wcs-tabs button{font:inherit;font-size:13px;font-weight:550;border:1px solid #d4d4d4;background:#fff;color:#303030;border-radius:8px;padding:6px 12px;cursor:pointer}
.wcs-tabs button:hover{background:#f3f3f3}
.wcs-tabs button.on{background:#303030;color:#fff;border-color:#303030}
.wcs-table{width:100%;border-collapse:collapse;font-size:14px;line-height:20px;color:#303030}
.wcs-table th{font-weight:550;text-align:left;color:#616161;background:#f7f7f7;padding:9px 12px;border-bottom:1px solid #e3e3e3;white-space:nowrap;position:sticky;top:0}
.wcs-table td{padding:9px 12px;border-bottom:1px solid #ebebeb;vertical-align:top}
.wcs-table tr:last-child td{border-bottom:0}
.wcs-table tbody tr:hover td{background:#fafafa}
.wcs-table .num{text-align:right;white-space:nowrap;font-variant-numeric:tabular-nums}
.wcs-table .sub{color:#616161;font-size:13px}
.wcs-table .url{word-break:break-all}
.wcs-table .bad{color:#b42318;font-weight:550}
.wcs-table .warn{color:#8a6100}
.wcs-table .ok{color:#0c6e3d}
.wcs-table img.thumb{width:40px;height:40px;object-fit:cover;border:1px solid #e3e3e3;border-radius:6px;background:#fff}
.wcs-scroll{max-height:640px;overflow:auto}
.wcs-input{width:100%;box-sizing:border-box;font:inherit;font-size:14px;padding:6px 8px;border:1px solid #c9c9c9;border-radius:8px;background:#fff}
.wcs-input:focus{outline:2px solid #005bd3;outline-offset:-1px;border-color:#005bd3}
textarea.wcs-input{min-height:56px;resize:vertical}
.wcs-count{font-size:12px;color:#616161;text-align:right}
.wcs-count.over{color:#b42318}
.wcs-kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px}
.wcs-kpi{border:1px solid #e3e3e3;border-radius:12px;padding:12px 14px;background:#fff}
.wcs-kpi .k{font-size:13px;color:#616161}
.wcs-kpi .v{font-size:26px;font-weight:650;line-height:34px}
.wcs-kpi .s{font-size:12px;color:#616161}
.wcs-kpi .v.success{color:#0c6e3d}.wcs-kpi .v.warning{color:#8a6100}.wcs-kpi .v.critical{color:#b42318}
.wcs-issue{border:1px solid #e3e3e3;border-radius:12px;margin:0 0 10px;background:#fff}
.wcs-issue summary{display:flex;gap:10px;align-items:center;padding:10px 14px;cursor:pointer;list-style:none}
.wcs-issue summary::-webkit-details-marker{display:none}
.wcs-issue summary .t{font-weight:600;flex:1}
.wcs-issue summary .n{color:#616161;white-space:nowrap}
.wcs-issue .body{padding:0 14px 12px;font-size:14px}
.wcs-issue .body p{margin:6px 0}
.wcs-issue .body ul{margin:6px 0;padding-left:18px;max-height:260px;overflow:auto}
.wcs-issue .body li{margin:2px 0;word-break:break-all}
.wcs-issue .body .d{color:#616161}
.wcs-bar{height:8px;border-radius:4px;background:#ebebeb;overflow:hidden}
.wcs-bar>i{display:block;height:100%}
.wcs-chip{display:inline-block;font-size:12px;border-radius:6px;padding:1px 6px;background:#f1f1f1;color:#303030;margin:1px 2px 1px 0}
.wcs-filters{display:flex;flex-wrap:wrap;gap:6px;align-items:center}
.wcs-filters select,.wcs-filters input{font:inherit;font-size:14px;padding:5px 8px;border:1px solid #c9c9c9;border-radius:8px;background:#fff}
.wcs-spark{display:block}
`;
