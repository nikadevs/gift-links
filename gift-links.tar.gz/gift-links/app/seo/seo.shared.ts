/**
 * SEO & Speed — shared types and the catalogue of checks.
 *
 * Every finding the crawler can produce has an entry in CHECKS: what it
 * means, why it matters, how to fix it and an official source. The UI shows
 * this text, so it must stay factual (no promised ranking gains).
 */

export type Severity = "critical" | "high" | "medium" | "low" | "info";
export type Category = "seo" | "schema" | "links" | "images" | "speed" | "tech";

export const SEVERITY_ORDER: Severity[] = [
  "critical",
  "high",
  "medium",
  "low",
  "info",
];

export const SEVERITY_WEIGHT: Record<Severity, number> = {
  critical: 10,
  high: 5,
  medium: 2,
  low: 1,
  info: 0,
};

export const CATEGORY_LABEL: Record<Category, string> = {
  seo: "Search basics",
  schema: "Structured data",
  links: "Links & redirects",
  images: "Images",
  speed: "Speed",
  tech: "Technical",
};

/** Where in the app the fix can be made (relative app path). */
export type FixTarget =
  | "meta"
  | "images"
  | "links"
  | "speed"
  | "theme"
  | "admin"
  | "none";

export type CheckDef = {
  id: string;
  title: string;
  category: Category;
  severity: Severity;
  why: string;
  fix: string;
  fixIn: FixTarget;
  docs?: string;
};

const G = "https://developers.google.com/search/docs";
const WEB = "https://web.dev";

export const CHECKS: Record<string, CheckDef> = {
  // ---- HTTP / technical ----------------------------------------------------
  http_error: {
    id: "http_error",
    title: "Page returns an error status",
    category: "tech",
    severity: "critical",
    why: "Google can’t index a page that answers 4xx/5xx, and shoppers land on an error.",
    fix: "Restore the page, or add a 301 redirect to the closest live page.",
    fixIn: "links",
    docs: `${G}/crawling-indexing/http-network-errors`,
  },
  fetch_failed: {
    id: "fetch_failed",
    title: "Page could not be loaded",
    category: "tech",
    severity: "high",
    why: "The audit could not download the page (timeout or network error). It may be slow or temporarily down.",
    fix: "Open the page yourself; re-run the audit. Repeated failures point to a server or app problem.",
    fixIn: "none",
  },
  rate_limited: {
    id: "rate_limited",
    title: "Audit limited by the server (HTTP 429)",
    category: "tech",
    severity: "medium",
    why: "The server asked this crawler to slow down. This does not prove the URL is missing or its canonical is broken; the audit is incomplete.",
    fix: "Wait and re-run a smaller audit. Do not create redirects or change canonical URLs based on HTTP 429.",
    fixIn: "none",
    docs: `${G}/crawling-indexing/http-network-errors`,
  },
  redirected: {
    id: "redirected",
    title: "URL in sitemap / links redirects",
    category: "links",
    severity: "low",
    why: "Each redirect costs a round trip for shoppers and crawl budget for Google.",
    fix: "Link to the final URL directly.",
    fixIn: "links",
    docs: `${G}/crawling-indexing/301-redirects`,
  },
  liquid_error: {
    id: "liquid_error",
    title: "Liquid error printed on the page",
    category: "tech",
    severity: "critical",
    why: "A theme template is broken; visible text like “Liquid error” hurts trust and can hide content.",
    fix: "Find the section/snippet named in the error in the theme code and fix it (or roll back the theme change).",
    fixIn: "theme",
  },
  no_lang: {
    id: "no_lang",
    title: "<html> has no lang attribute",
    category: "tech",
    severity: "low",
    why: "Helps browsers, screen readers and translation tools. Google itself mostly detects language from content.",
    fix: "Add lang=\"{{ request.locale.iso_code }}\" to the <html> tag in layout/theme.liquid.",
    fixIn: "theme",
  },
  no_viewport: {
    id: "no_viewport",
    title: "No mobile viewport tag",
    category: "tech",
    severity: "high",
    why: "Without it the page renders as a zoomed-out desktop page on phones. Google indexes the mobile version.",
    fix: "Add <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"> to the <head>.",
    fixIn: "theme",
    docs: `${G}/crawling-indexing/mobile/mobile-sites-mobile-first-indexing`,
  },
  mixed_content: {
    id: "mixed_content",
    title: "Insecure http:// resources on an https page",
    category: "tech",
    severity: "medium",
    why: "Browsers block or warn about http resources on https pages (broken images/scripts, “not secure”).",
    fix: "Change the resource URLs to https:// (often in a theme setting, a custom HTML block or product description).",
    fixIn: "theme",
    docs: `${WEB}/articles/what-is-mixed-content`,
  },

  // ---- Indexing ------------------------------------------------------------
  noindex: {
    id: "noindex",
    title: "Page is set to noindex",
    category: "seo",
    severity: "high",
    why: "Google will drop this page from search results. Fine for intentional pages (cart, thank-you, gifts), a disaster for products.",
    fix: "If the page should rank: remove “Hide from search engines” in Meta tags (seo.hidden) or remove the robots tag in the theme.",
    fixIn: "meta",
    docs: `${G}/crawling-indexing/block-indexing`,
  },
  noindex_in_sitemap: {
    id: "noindex_in_sitemap",
    title: "Sitemap lists a noindex page",
    category: "seo",
    severity: "medium",
    why: "Sitemaps should only list pages you want indexed; mixed signals waste crawl budget.",
    fix: "Either make the page indexable or hide it with seo.hidden (Shopify then also removes it from the sitemap).",
    fixIn: "meta",
    docs: `${G}/crawling-indexing/sitemaps/build-sitemap`,
  },
  canonical_missing: {
    id: "canonical_missing",
    title: "No canonical URL",
    category: "seo",
    severity: "medium",
    why: "The canonical tells Google which URL is the main version (Shopify has many duplicate URL paths for the same product).",
    fix: "Make sure layout/theme.liquid prints <link rel=\"canonical\" href=\"{{ canonical_url }}\">.",
    fixIn: "theme",
    docs: `${G}/crawling-indexing/consolidate-duplicate-urls`,
  },
  canonical_other: {
    id: "canonical_other",
    title: "Canonical points to another URL",
    category: "seo",
    severity: "info",
    why: "Normal for duplicates (e.g. /collections/x/products/y → /products/y). A problem only if a main page points elsewhere by mistake.",
    fix: "Check that the target is the version you want in Google.",
    fixIn: "none",
    docs: `${G}/crawling-indexing/consolidate-duplicate-urls`,
  },
  canonical_broken: {
    id: "canonical_broken",
    title: "Canonical points to a broken or redirecting URL",
    category: "seo",
    severity: "high",
    why: "Google may ignore the canonical or index the wrong page.",
    fix: "Point the canonical at a live 200 URL.",
    fixIn: "theme",
  },
  robots_root_disallow: {
    id: "robots_root_disallow",
    title: "robots.txt blocks the whole site",
    category: "seo",
    severity: "critical",
    why: "A “Disallow: /” for all crawlers stops Google from crawling the store.",
    fix: "Edit templates/robots.txt.liquid (Online Store → Themes → Edit code) and remove the rule.",
    fixIn: "theme",
    docs: `${G}/crawling-indexing/robots/intro`,
  },
  robots_no_sitemap: {
    id: "robots_no_sitemap",
    title: "robots.txt doesn’t link the sitemap",
    category: "seo",
    severity: "low",
    why: "The Sitemap: line helps all search engines find your sitemap.",
    fix: "Shopify adds it by default; if you customised robots.txt.liquid, keep the default rules.",
    fixIn: "theme",
  },
  sitemap_missing: {
    id: "sitemap_missing",
    title: "sitemap.xml not reachable",
    category: "seo",
    severity: "high",
    why: "The sitemap is how Google discovers products and articles quickly.",
    fix: "Shopify generates /sitemap.xml automatically; check the store password and domain settings.",
    fixIn: "admin",
  },

  // ---- Titles & descriptions ------------------------------------------------
  title_missing: {
    id: "title_missing",
    title: "Missing page title",
    category: "seo",
    severity: "high",
    why: "The <title> is the main source of the blue link in Google results.",
    fix: "Set a meta title in Meta tags.",
    fixIn: "meta",
    docs: `${G}/appearance/title-link`,
  },
  title_long: {
    id: "title_long",
    title: "Title is long (over 60 characters)",
    category: "seo",
    severity: "low",
    why: "Google has no hard limit, but long titles are usually cut off in results (around 50–60 characters / 600px).",
    fix: "Put the important words first; keep it near 60 characters.",
    fixIn: "meta",
    docs: `${G}/appearance/title-link`,
  },
  title_short: {
    id: "title_short",
    title: "Title is very short (under 20 characters)",
    category: "seo",
    severity: "low",
    why: "A short title often misses the words people search for.",
    fix: "Describe the page: product type + key benefit + brand.",
    fixIn: "meta",
    docs: `${G}/appearance/title-link`,
  },
  title_duplicate: {
    id: "title_duplicate",
    title: "Same title on several pages",
    category: "seo",
    severity: "medium",
    why: "Google may rewrite duplicate titles and it’s harder to tell the pages apart.",
    fix: "Make each title unique.",
    fixIn: "meta",
    docs: `${G}/appearance/title-link`,
  },
  desc_missing: {
    id: "desc_missing",
    title: "Missing meta description",
    category: "seo",
    severity: "medium",
    why: "Google often uses the description as the snippet under the title; without it a random piece of text is shown.",
    fix: "Write a 120–160 character description in Meta tags.",
    fixIn: "meta",
    docs: `${G}/appearance/snippet`,
  },
  desc_long: {
    id: "desc_long",
    title: "Meta description is long (over 160 characters)",
    category: "seo",
    severity: "info",
    why: "Longer descriptions are usually cut in results. Not an error.",
    fix: "Keep the key message in the first 150 characters.",
    fixIn: "meta",
    docs: `${G}/appearance/snippet`,
  },
  desc_short: {
    id: "desc_short",
    title: "Meta description is short (under 70 characters)",
    category: "seo",
    severity: "low",
    why: "A short description gives searchers little reason to click.",
    fix: "Add the main benefit, offer (free shipping, returns) and a call to action.",
    fixIn: "meta",
    docs: `${G}/appearance/snippet`,
  },
  desc_duplicate: {
    id: "desc_duplicate",
    title: "Same meta description on several pages",
    category: "seo",
    severity: "low",
    why: "Duplicate snippets look generic in results.",
    fix: "Write a specific description for each page.",
    fixIn: "meta",
    docs: `${G}/appearance/snippet`,
  },

  // ---- Content structure ---------------------------------------------------
  h1_missing: {
    id: "h1_missing",
    title: "No H1 heading",
    category: "seo",
    severity: "medium",
    why: "The main heading tells shoppers and search engines what the page is about.",
    fix: "Make the product/collection/article title the page’s H1 in the theme section.",
    fixIn: "theme",
  },
  h1_empty: {
    id: "h1_empty",
    title: "Empty H1 heading",
    category: "seo",
    severity: "medium",
    why: "An H1 without text (often a logo wrapper) gives no information.",
    fix: "Give the H1 real text, or use a different tag for the logo.",
    fixIn: "theme",
  },
  h1_multiple: {
    id: "h1_multiple",
    title: "Several H1 headings",
    category: "seo",
    severity: "info",
    why: "Allowed by Google, but one clear H1 per page is easier to read and to audit.",
    fix: "Keep one H1 for the page title; use H2/H3 for sections.",
    fixIn: "theme",
  },
  thin_content: {
    id: "thin_content",
    title: "Little text content",
    category: "seo",
    severity: "low",
    why: "Product and article pages with very little unique text have less chance to match searches.",
    fix: "Add useful details: materials, size, use cases, FAQ.",
    fixIn: "admin",
    docs: `${G}/fundamentals/creating-helpful-content`,
  },
  og_missing: {
    id: "og_missing",
    title: "Social share tags missing (og:title / og:image)",
    category: "seo",
    severity: "low",
    why: "Facebook, WhatsApp, Pinterest, Telegram use Open Graph tags for link previews.",
    fix: "Dawn-based themes print them from snippets/meta-tags.liquid; set a social sharing image in theme settings.",
    fixIn: "theme",
  },
  hreflang_issue: {
    id: "hreflang_issue",
    title: "hreflang problem",
    category: "seo",
    severity: "medium",
    why: "With several markets/languages, hreflang tells Google which URL to show to which country.",
    fix: "Shopify Markets prints hreflang automatically — check that the theme still outputs {{ content_for_header }} and that market domains/subfolders are live.",
    fixIn: "admin",
    docs: `${G}/specialty/international/localized-versions`,
  },
  url_non_ascii: {
    id: "url_non_ascii",
    title: "URL handle has special characters",
    category: "seo",
    severity: "info",
    why: "Characters like ™ or spaces are percent-encoded (%E2%84%A2) — ugly to share, easy to break when copied.",
    fix: "Use a plain handle (letters, numbers, dashes). Changing a handle needs a redirect from the old URL — Shopify offers it when you edit the handle.",
    fixIn: "admin",
    docs: `${G}/crawling-indexing/url-structure`,
  },

  // ---- Structured data -----------------------------------------------------
  jsonld_invalid: {
    id: "jsonld_invalid",
    title: "Broken JSON-LD (structured data)",
    category: "schema",
    severity: "high",
    why: "Google ignores structured data it can’t parse — no price/rating rich results.",
    fix: "Fix the JSON in the snippet that prints it (often an unescaped quote in a product field).",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/intro-structured-data`,
  },
  product_schema_missing: {
    id: "product_schema_missing",
    title: "Product page has no Product structured data",
    category: "schema",
    severity: "high",
    why: "Product markup is how Google shows price, stock and rating in results and merchant listings.",
    fix: "Add Product/ProductGroup JSON-LD to the product template.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/merchant-listing`,
  },
  product_offer_invalid: {
    id: "product_offer_invalid",
    title: "Product offer without valid price / currency / availability",
    category: "schema",
    severity: "high",
    why: "Merchant listings require offers.price and priceCurrency; availability is strongly recommended.",
    fix: "Print price, priceCurrency and availability for every variant offer.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/merchant-listing`,
  },
  product_no_image: {
    id: "product_no_image",
    title: "Product markup without image",
    category: "schema",
    severity: "high",
    why: "image is required for merchant listings.",
    fix: "Add the product image URL to the Product JSON-LD.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/merchant-listing`,
  },
  product_no_identifier: {
    id: "product_no_identifier",
    title: "Product markup without brand / SKU / GTIN",
    category: "schema",
    severity: "low",
    why: "Recommended identifiers help Google match your product with searches and shopping data.",
    fix: "Add brand (WoodenCrew) and sku; gtin if you have barcodes.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/merchant-listing`,
  },
  product_no_return_policy: {
    id: "product_no_return_policy",
    title: "No return policy in product markup",
    category: "schema",
    severity: "low",
    why: "Return info can be shown next to the price. It can come from product markup, Organization markup or Search Console settings.",
    fix: "Add hasMerchantReturnPolicy (or set returns in Search Console → Shopping → Shipping and returns).",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/return-policy`,
  },
  product_no_shipping: {
    id: "product_no_shipping",
    title: "No shipping details in markup",
    category: "schema",
    severity: "info",
    why: "Optional. Shipping cost/speed can be given per product (shippingDetails), for the whole store (Organization → hasShippingService) or in Search Console, which wins over markup.",
    fix: "Only add it with real, confirmed rates and delivery times — never invented ones.",
    fixIn: "none",
    docs: `${G}/appearance/structured-data/shipping-policy`,
  },
  rating_invalid: {
    id: "rating_invalid",
    title: "Rating markup looks wrong",
    category: "schema",
    severity: "high",
    why: "ratingValue must be inside the scale and reviewCount/ratingCount > 0, matching what the page shows.",
    fix: "Take rating and count from the same source as the visible reviews widget (Judge.me).",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/review-snippet`,
  },
  schema_duplicate: {
    id: "schema_duplicate",
    title: "Same structured data type printed twice",
    category: "schema",
    severity: "medium",
    why: "Two different Product or Organization blocks with conflicting values confuse Google (often an app + the theme both print it).",
    fix: "Keep one source; switch off the duplicate in the theme or the app.",
    fixIn: "theme",
  },
  org_schema_missing: {
    id: "org_schema_missing",
    title: "Home page has no Organization / WebSite markup",
    category: "schema",
    severity: "low",
    why: "Organization (logo, name, sameAs) and WebSite (site name) help Google show your brand correctly.",
    fix: "Add Organization + WebSite JSON-LD on the home page.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/organization`,
  },
  breadcrumb_missing: {
    id: "breadcrumb_missing",
    title: "No BreadcrumbList markup",
    category: "schema",
    severity: "info",
    why: "Breadcrumbs replace the raw URL in results with a readable path.",
    fix: "Add BreadcrumbList JSON-LD to product, collection and article templates.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/breadcrumb`,
  },
  article_schema_missing: {
    id: "article_schema_missing",
    title: "Article without Article markup",
    category: "schema",
    severity: "low",
    why: "Article markup gives Google the headline, image, author and dates.",
    fix: "Add Article/BlogPosting JSON-LD to the article template.",
    fixIn: "theme",
    docs: `${G}/appearance/structured-data/article`,
  },

  // ---- Links ---------------------------------------------------------------
  broken_link: {
    id: "broken_link",
    title: "Broken internal link",
    category: "links",
    severity: "high",
    why: "Shoppers hit a 404 and Google wastes crawl budget on dead URLs.",
    fix: "Change the link in the menu/section/description, or redirect the dead URL to the right page.",
    fixIn: "links",
  },
  link_to_redirect: {
    id: "link_to_redirect",
    title: "Internal link points to a redirect",
    category: "links",
    severity: "low",
    why: "Works, but adds an extra hop on every click.",
    fix: "Update the link to the final URL.",
    fixIn: "links",
  },
  not_found_hits: {
    id: "not_found_hits",
    title: "Visitors are landing on 404 pages",
    category: "links",
    severity: "medium",
    why: "Real visits (ads, old links, Google) end on “Page not found”.",
    fix: "Create redirects for the most visited dead URLs (Links → 404 log).",
    fixIn: "links",
  },

  // ---- Images --------------------------------------------------------------
  img_no_alt: {
    id: "img_no_alt",
    title: "Images without alt text",
    category: "images",
    severity: "low",
    why: "Alt text is how Google Images and screen readers understand an image.",
    fix: "Add descriptive alt text (Images tool fills product images in bulk).",
    fixIn: "images",
    docs: `${G}/appearance/google-images`,
  },
  img_no_dimensions: {
    id: "img_no_dimensions",
    title: "Images without width/height",
    category: "speed",
    severity: "low",
    why: "Without size attributes the page jumps while images load (layout shift / CLS).",
    fix: "Use {{ image | image_url: width: … | image_tag }} which prints width/height, or add aspect-ratio CSS.",
    fixIn: "theme",
    docs: `${WEB}/articles/optimize-cls`,
  },
  img_oversized: {
    id: "img_oversized",
    title: "Full-size images loaded without resizing",
    category: "speed",
    severity: "medium",
    why: "Shopify CDN can resize and convert to WebP/AVIF, but only if the URL asks for a width. Original files can be several MB.",
    fix: "Use image_url with a width and srcset (image_tag does this).",
    fixIn: "theme",
    docs: "https://shopify.dev/docs/storefronts/themes/best-practices/performance/images",
  },
  img_no_srcset: {
    id: "img_no_srcset",
    title: "Images without responsive srcset",
    category: "speed",
    severity: "info",
    why: "Phones download desktop-size images when there is no srcset.",
    fix: "Use image_tag with widths: … so the browser picks the right size.",
    fixIn: "theme",
    docs: "https://shopify.dev/docs/storefronts/themes/best-practices/performance/images",
  },
  lcp_image_lazy: {
    id: "lcp_image_lazy",
    title: "First large image is lazy-loaded",
    category: "speed",
    severity: "medium",
    why: "The top image is usually the LCP element; lazy-loading it delays the main paint.",
    fix: "Load the first visible image eagerly with fetchpriority=\"high\".",
    fixIn: "theme",
    docs: `${WEB}/articles/lcp-lazy-loading`,
  },

  // ---- Speed (static HTML) -------------------------------------------------
  html_heavy: {
    id: "html_heavy",
    title: "Very large HTML",
    category: "speed",
    severity: "low",
    why: "Big HTML (inline JSON, mega menus, many hidden sections) slows the first paint on phones.",
    fix: "Remove hidden/unused sections, trim mega-menu levels, avoid printing all variants/products as inline JSON.",
    fixIn: "theme",
    docs: `${WEB}/articles/dom-size-and-interactivity`,
  },
  dom_large: {
    id: "dom_large",
    title: "Too many HTML elements (DOM size)",
    category: "speed",
    severity: "medium",
    why: "Large DOMs make every click/tap slower (INP) and use more memory. Lighthouse warns above ~1,400 elements.",
    fix: "Same as large HTML: fewer hidden sections, lighter menus, paginate long lists.",
    fixIn: "theme",
    docs: `${WEB}/articles/dom-size-and-interactivity`,
  },
  render_blocking_js: {
    id: "render_blocking_js",
    title: "Render-blocking scripts in <head>",
    category: "speed",
    severity: "medium",
    why: "A script without async/defer stops the browser from drawing anything until it is downloaded and run.",
    fix: "Add defer (or async) to the script tag, or load it from an app embed. Test that the feature still works.",
    fixIn: "theme",
    docs: "https://developer.chrome.com/docs/lighthouse/performance/render-blocking-resources",
  },
  render_blocking_css: {
    id: "render_blocking_css",
    title: "Many render-blocking stylesheets",
    category: "speed",
    severity: "low",
    why: "Every stylesheet in <head> must load before first paint.",
    fix: "Combine small CSS files, load non-critical CSS (popups, reviews) later with media=\"print\" onload trick.",
    fixIn: "theme",
    docs: "https://developer.chrome.com/docs/lighthouse/performance/render-blocking-resources",
  },
  third_party_heavy: {
    id: "third_party_heavy",
    title: "Many third-party script domains",
    category: "speed",
    severity: "medium",
    why: "Each app/tracker adds downloads and main-thread work — the most common reason Shopify stores are slow on phones.",
    fix: "Review the list in Speed → Scripts; remove apps you don’t use and their leftover code.",
    fixIn: "speed",
    docs: `${WEB}/articles/optimizing-content-efficiency-loading-third-party-javascript`,
  },
  duplicate_script: {
    id: "duplicate_script",
    title: "Same script loaded twice",
    category: "speed",
    severity: "medium",
    why: "Double downloads and the code runs twice (can also double-track analytics).",
    fix: "Remove the second include (theme + app embed often both add it).",
    fixIn: "theme",
  },
  jquery_multiple: {
    id: "jquery_multiple",
    title: "Several copies of jQuery",
    category: "speed",
    severity: "medium",
    why: "Different apps each load their own jQuery (~30 KB gzip each).",
    fix: "Keep one copy; ask app vendors for a jQuery-free version.",
    fixIn: "theme",
  },
  font_no_swap: {
    id: "font_no_swap",
    title: "Web fonts without font-display",
    category: "speed",
    severity: "low",
    why: "Text stays invisible until the font downloads.",
    fix: "Add font-display: swap to @font-face rules (Shopify font_face filter: font_display: 'swap').",
    fixIn: "theme",
    docs: `${WEB}/articles/font-best-practices`,
  },
  iframe_not_lazy: {
    id: "iframe_not_lazy",
    title: "Embedded iframes load immediately",
    category: "speed",
    severity: "low",
    why: "YouTube/maps iframes download hundreds of KB even when not on screen.",
    fix: "Add loading=\"lazy\" to iframes below the first screen.",
    fixIn: "theme",
    docs: `${WEB}/articles/iframe-lazy-loading`,
  },
  video_heavy: {
    id: "video_heavy",
    title: "Large video on the page",
    category: "speed",
    severity: "info",
    why: "Autoplay videos are often the biggest download on mobile (several MB).",
    fix: "Keep the current behaviour if it sells; otherwise compress the file, add a poster image or preload=\"metadata\". (Your rule: video UX changes need approval.)",
    fixIn: "none",
    docs: `${WEB}/articles/lazy-loading-video`,
  },

  // ---- Lab/field (PageSpeed) -----------------------------------------------
  cwv_fail: {
    id: "cwv_fail",
    title: "Core Web Vitals not passed (real users)",
    category: "speed",
    severity: "high",
    why: "Google uses real-user Core Web Vitals (LCP ≤ 2.5 s, INP ≤ 200 ms, CLS ≤ 0.1 at the 75th percentile) as a page-experience signal.",
    fix: "See Speed → PageSpeed for the failing metric and its biggest causes.",
    fixIn: "speed",
    docs: `${WEB}/articles/vitals`,
  },
};

export function check(id: string): CheckDef {
  return (
    CHECKS[id] ?? {
      id,
      title: id,
      category: "tech",
      severity: "info",
      why: "",
      fix: "",
      fixIn: "none",
    }
  );
}

/** One finding on one URL. `detail` is short evidence (e.g. "73 chars"). */
export type Finding = { check: string; url: string; detail?: string };

export type ScriptInfo = {
  src: string;
  host: string;
  thirdParty: boolean;
  inHead: boolean;
  blocking: boolean;
  bytes?: number;
};

export type PageFacts = {
  url: string;
  finalUrl: string;
  status: number;
  kind: PageKind;
  ms: number;
  title: string;
  description: string;
  canonical: string;
  robots: string;
  h1: string[];
  words: number;
  htmlBytes: number;
  domNodes: number;
  images: number;
  imagesNoAlt: number;
  scripts: number;
  thirdPartyHosts: string[];
  schemaTypes: string[];
  internalLinks: number;
  error?: string;
};

export type PageKind =
  | "home"
  | "product"
  | "collection"
  | "article"
  | "blog"
  | "page"
  | "policy"
  | "search"
  | "other";

export function pageKind(path: string): PageKind {
  const p = path.replace(/^\/[a-z]{2}(-[a-z]{2})?(?=\/|$)/i, "") || "/";
  if (p === "/" || p === "") return "home";
  if (/\/products\/[^/]+\/?$/.test(p)) return "product";
  if (/^\/collections\/[^/]+\/?$/.test(p) || p === "/collections") return "collection";
  if (/^\/blogs\/[^/]+\/[^/]+/.test(p)) return "article";
  if (/^\/blogs\/[^/]+\/?$/.test(p)) return "blog";
  if (/^\/pages\//.test(p)) return "page";
  if (/^\/policies\//.test(p)) return "policy";
  if (/^\/search/.test(p)) return "search";
  return "other";
}

export type CrawlReport = {
  version: 1;
  id: string;
  mode: "quick" | "full";
  origin: string;
  startedAt: string;
  finishedAt: string;
  discovered: number;
  checked: number;
  linksChecked: number;
  pages: PageFacts[];
  findings: Finding[];
  scripts: Array<ScriptInfo & { pages: number }>;
  robots: { status: number; sitemapLine: boolean };
  sitemap: { status: number; urls: number };
  score: number;
  notes: string[];
};

export type JobState = {
  kind: "crawl" | "psi";
  status: "idle" | "running" | "done" | "error";
  startedAt?: string;
  finishedAt?: string;
  progress?: string;
  done?: number;
  total?: number;
  error?: string;
};

/** Health score 0–100 from findings, de-duplicated per check+url. */
export function scoreFindings(findings: Finding[], pages: number): number {
  if (!pages) return 0;
  const perCheck = new Map<string, number>();
  for (const f of findings) {
    const def = check(f.check);
    const w = SEVERITY_WEIGHT[def.severity];
    if (!w) continue;
    perCheck.set(f.check, (perCheck.get(f.check) ?? 0) + w);
  }
  // each check's penalty grows with the share of pages it affects, capped
  let penalty = 0;
  for (const [id, total] of perCheck) {
    const w = SEVERITY_WEIGHT[check(id).severity];
    const affected = total / w;
    const share = Math.min(1, affected / pages);
    penalty += w * (0.4 + 0.6 * share);
  }
  return Math.max(0, Math.round(100 - penalty));
}

// ---- PageSpeed -------------------------------------------------------------

export type Strategy = "mobile" | "desktop";

export type FieldMetric = {
  p75: number;
  category: "FAST" | "AVERAGE" | "SLOW" | string;
};

export type PsiOpportunity = {
  id: string;
  title: string;
  savingsMs?: number;
  savingsBytes?: number;
  score?: number | null;
  displayValue?: string;
  items?: Array<{ url?: string; label?: string; ms?: number; bytes?: number }>;
};

export type PsiRun = {
  url: string;
  strategy: Strategy;
  at: string;
  lighthouseVersion?: string;
  scores: { performance?: number; seo?: number; accessibility?: number; bestPractices?: number };
  lab: { fcp?: number; lcp?: number; tbt?: number; cls?: number; si?: number; ttfb?: number };
  field?: {
    scope: "url" | "origin";
    overall?: string;
    lcp?: FieldMetric;
    inp?: FieldMetric;
    cls?: FieldMetric;
    fcp?: FieldMetric;
    ttfb?: FieldMetric;
  };
  lcpElement?: string;
  totalBytes?: number;
  opportunities: PsiOpportunity[];
  thirdParties?: Array<{ entity: string; blockingMs: number; bytes: number; mainThreadMs: number }>;
  error?: string;
};

export type SeoSettings = {
  version: 1;
  psiKey: string;
  keyPaths: string[];
  autoDaily: boolean;
  autoPsi: boolean;
  fullCrawlMax: number;
};

export const DEFAULT_SETTINGS: SeoSettings = {
  version: 1,
  psiKey: "",
  keyPaths: [],
  autoDaily: true,
  autoPsi: true,
  fullCrawlMax: 300,
};

/** Storefront config (app-owned metafield wc_seo.config, read by the embed). */
export type SeoEmbedConfig = {
  version: 1;
  instantNav: "off" | "prefetch" | "prerender";
  track404: boolean;
  beaconUrl: string;
};

export const DEFAULT_EMBED: SeoEmbedConfig = {
  version: 1,
  instantNav: "off",
  track404: true,
  beaconUrl: "",
};

export function fmtMs(ms?: number) {
  if (ms == null || Number.isNaN(ms)) return "—";
  return ms >= 1000 ? `${(ms / 1000).toFixed(1)} s` : `${Math.round(ms)} ms`;
}

export function fmtBytes(b?: number) {
  if (b == null) return "—";
  if (b >= 1024 * 1024) return `${(b / 1024 / 1024).toFixed(1)} MB`;
  if (b >= 1024) return `${Math.round(b / 1024)} KB`;
  return `${b} B`;
}

/** Latest successful run per url+strategy. */
/** Errors remain actionable only until a newer successful run of that URL/device. */
export function latestPsiError(runs: PsiRun[]): string {
  const latest = new Map<string, PsiRun>();
  for (const run of runs) {
    const key = `${run.url}|${run.strategy}`;
    const previous = latest.get(key);
    if (!previous || previous.at <= run.at) latest.set(key, run);
  }
  return [...latest.values()].filter((run) => run.error)
    .sort((a, b) => b.at.localeCompare(a.at))[0]?.error ?? "";
}

export function latestRuns(runs: PsiRun[]) {
  const map = new Map<string, PsiRun>();
  for (const r of runs) {
    if (r.error) continue;
    const k = `${r.url}|${r.strategy}`;
    const prev = map.get(k);
    if (!prev || prev.at < r.at) map.set(k, r);
  }
  return [...map.values()];
}

/** Core Web Vitals pass/fail from field data (p75 thresholds). */
export function cwvStatus(f: PsiRun["field"] | null | undefined): "pass" | "fail" | "unknown" {
  if (!f?.lcp || !f.cls) return "unknown";
  const lcpOk = f.lcp.p75 <= 2500;
  const clsOk = f.cls.p75 <= 0.1;
  const inpOk = f.inp ? f.inp.p75 <= 200 : true;
  return lcpOk && clsOk && inpOk ? "pass" : "fail";
}
