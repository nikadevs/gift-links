/**
 * SEO & Speed — Shopify Admin API helpers (read + fix).
 *
 *  - meta titles / descriptions for products, collections, pages, articles
 *    (products/collections: `seo` field; pages/articles: global.title_tag /
 *    global.description_tag metafields — the same fields Shopify admin edits)
 *  - "Hide from search engines": metafield seo.hidden = 1 (Shopify adds
 *    noindex,nofollow and removes the page from sitemap.xml)
 *  - product image ALT text (fileUpdate on the MediaImage)
 *  - URL redirects
 *  - theme code scan (read only)
 *  - storefront embed config: app-owned metafield wc_seo.config
 */
import {
  DEFAULT_EMBED,
  type SeoEmbedConfig,
} from "./seo.shared";
import type {
  ImageRow,
  RedirectRow,
  SeoKind,
  SeoRow,
  ThemeScan,
} from "./seo-admin.shared";

export type { ImageRow, RedirectRow, SeoKind, SeoRow, ThemeScan } from "./seo-admin.shared";
export { altTemplate, fillTemplate } from "./seo-admin.shared";

export type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

export class AccessError extends Error {}

async function gql<T>(
  admin: AdminGraphql,
  query: string,
  variables?: Record<string, unknown>,
): Promise<T> {
  let res: Response;
  try {
    res = await admin.graphql(query, variables ? { variables } : undefined);
  } catch (e) {
    // the library throws on GraphQL errors; surface access problems clearly
    const msg = String((e as Error).message ?? e);
    if (/access|scope|denied|unauthori[sz]ed/i.test(msg)) throw new AccessError(msg);
    throw e;
  }
  const json = (await res.json()) as { data?: T; errors?: Array<{ message: string }> };
  if (json.errors?.length) {
    const msg = json.errors.map((e) => e.message).join("; ");
    if (/access|scope|denied/i.test(msg)) throw new AccessError(msg);
    throw new Error(msg.slice(0, 300));
  }
  return json.data as T;
}

type UserError = { field?: string[] | null; message: string };
function assertNoErrors(errors: UserError[] | undefined) {
  if (errors?.length) throw new Error(errors.map((e) => e.message).join("; "));
}

// ---- meta tags ---------------------------------------------------------------


const META = `
  hidden: metafield(namespace: "seo", key: "hidden") { value }
`;

export async function listSeoRows(admin: AdminGraphql, kind: SeoKind): Promise<SeoRow[]> {
  const rows: SeoRow[] = [];
  let after: string | null = null;
  for (let page = 0; page < 20; page++) {
    if (kind === "products") {
      const d: {
        products: {
          nodes: Array<{
            id: string;
            title: string;
            handle: string;
            status: string;
            description: string;
            seo: { title: string | null; description: string | null };
            featuredMedia: { preview?: { image?: { url: string } | null } | null } | null;
            hidden: { value: string } | null;
          }>;
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      } = await gql(
        admin,
        `#graphql
        query WcSeoProducts($after: String) {
          products(first: 100, after: $after, sortKey: TITLE) {
            nodes {
              id title handle status
              description(truncateAt: 200)
              seo { title description }
              featuredMedia { preview { image { url(transform: { maxWidth: 64 }) } } }
              ${META}
            }
            pageInfo { hasNextPage endCursor }
          }
        }`,
        { after },
      );
      for (const n of d.products.nodes)
        rows.push({
          id: n.id,
          kind,
          name: n.title,
          handle: n.handle,
          path: `/products/${n.handle}`,
          status: n.status,
          seoTitle: n.seo.title ?? "",
          seoDescription: n.seo.description ?? "",
          fallbackDescription: n.description ?? "",
          hidden: n.hidden?.value === "1",
          image: n.featuredMedia?.preview?.image?.url,
        });
      after = d.products.pageInfo.hasNextPage ? d.products.pageInfo.endCursor : null;
    } else if (kind === "collections") {
      const d: {
        collections: {
          nodes: Array<{
            id: string;
            title: string;
            handle: string;
            description: string;
            seo: { title: string | null; description: string | null };
            hidden: { value: string } | null;
          }>;
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      } = await gql(
        admin,
        `#graphql
        query WcSeoCollections($after: String) {
          collections(first: 100, after: $after, sortKey: TITLE) {
            nodes {
              id title handle
              description(truncateAt: 200)
              seo { title description }
              ${META}
            }
            pageInfo { hasNextPage endCursor }
          }
        }`,
        { after },
      );
      for (const n of d.collections.nodes)
        rows.push({
          id: n.id,
          kind,
          name: n.title,
          handle: n.handle,
          path: `/collections/${n.handle}`,
          status: "ACTIVE",
          seoTitle: n.seo.title ?? "",
          seoDescription: n.seo.description ?? "",
          fallbackDescription: n.description ?? "",
          hidden: n.hidden?.value === "1",
        });
      after = d.collections.pageInfo.hasNextPage ? d.collections.pageInfo.endCursor : null;
    } else if (kind === "pages") {
      const d: {
        pages: {
          nodes: Array<{
            id: string;
            title: string;
            handle: string;
            isPublished: boolean;
            bodySummary: string;
            titleTag: { value: string } | null;
            descTag: { value: string } | null;
            hidden: { value: string } | null;
          }>;
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      } = await gql(
        admin,
        `#graphql
        query WcSeoPages($after: String) {
          pages(first: 100, after: $after, sortKey: TITLE) {
            nodes {
              id title handle isPublished bodySummary
              titleTag: metafield(namespace: "global", key: "title_tag") { value }
              descTag: metafield(namespace: "global", key: "description_tag") { value }
              ${META}
            }
            pageInfo { hasNextPage endCursor }
          }
        }`,
        { after },
      );
      for (const n of d.pages.nodes)
        rows.push({
          id: n.id,
          kind,
          name: n.title,
          handle: n.handle,
          path: `/pages/${n.handle}`,
          status: n.isPublished ? "ACTIVE" : "HIDDEN",
          seoTitle: n.titleTag?.value ?? "",
          seoDescription: n.descTag?.value ?? "",
          fallbackDescription: n.bodySummary ?? "",
          hidden: n.hidden?.value === "1",
        });
      after = d.pages.pageInfo.hasNextPage ? d.pages.pageInfo.endCursor : null;
    } else {
      const d: {
        articles: {
          nodes: Array<{
            id: string;
            title: string;
            handle: string;
            isPublished: boolean;
            summary: string | null;
            blog: { handle: string };
            image: { url: string } | null;
            titleTag: { value: string } | null;
            descTag: { value: string } | null;
            hidden: { value: string } | null;
          }>;
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      } = await gql(
        admin,
        `#graphql
        query WcSeoArticles($after: String) {
          articles(first: 100, after: $after, sortKey: TITLE) {
            nodes {
              id title handle isPublished summary
              blog { handle }
              image { url(transform: { maxWidth: 64 }) }
              titleTag: metafield(namespace: "global", key: "title_tag") { value }
              descTag: metafield(namespace: "global", key: "description_tag") { value }
              ${META}
            }
            pageInfo { hasNextPage endCursor }
          }
        }`,
        { after },
      );
      for (const n of d.articles.nodes)
        rows.push({
          id: n.id,
          kind,
          name: n.title,
          handle: n.handle,
          path: `/blogs/${n.blog.handle}/${n.handle}`,
          status: n.isPublished ? "ACTIVE" : "HIDDEN",
          seoTitle: n.titleTag?.value ?? "",
          seoDescription: n.descTag?.value ?? "",
          fallbackDescription: stripHtml(n.summary ?? "").slice(0, 200),
          hidden: n.hidden?.value === "1",
          image: n.image?.url,
        });
      after = d.articles.pageInfo.hasNextPage ? d.articles.pageInfo.endCursor : null;
    }
    if (!after) break;
  }
  return rows;
}

export function stripHtml(s: string) {
  return s.replace(/<[^>]*>/g, " ").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim();
}

export async function updateSeo(
  admin: AdminGraphql,
  kind: SeoKind,
  id: string,
  title: string,
  description: string,
) {
  title = title.trim();
  description = description.trim();
  if (kind === "products") {
    const d: { productUpdate: { userErrors: UserError[] } } = await gql(
      admin,
      `#graphql
      mutation WcSeoProductUpdate($product: ProductUpdateInput!) {
        productUpdate(product: $product) { userErrors { field message } }
      }`,
      { product: { id, seo: { title, description } } },
    );
    assertNoErrors(d.productUpdate.userErrors);
    return;
  }
  if (kind === "collections") {
    const d: { collectionUpdate: { userErrors: UserError[] } } = await gql(
      admin,
      `#graphql
      mutation WcSeoCollectionUpdate($input: CollectionInput!) {
        collectionUpdate(input: $input) { userErrors { field message } }
      }`,
      { input: { id, seo: { title, description } } },
    );
    assertNoErrors(d.collectionUpdate.userErrors);
    return;
  }
  // pages / articles → global.title_tag / global.description_tag
  const set: Array<Record<string, string>> = [];
  const del: Array<Record<string, string>> = [];
  for (const [key, value] of [
    ["title_tag", title],
    ["description_tag", description],
  ] as const) {
    if (value)
      set.push({ ownerId: id, namespace: "global", key, type: "single_line_text_field", value });
    else del.push({ ownerId: id, namespace: "global", key });
  }
  if (set.length) await metafieldsSet(admin, set);
  if (del.length) await metafieldsDelete(admin, del);
}

async function metafieldsSet(admin: AdminGraphql, metafields: Array<Record<string, string>>) {
  const d: { metafieldsSet: { userErrors: UserError[] } } = await gql(
    admin,
    `#graphql
    mutation WcSeoMetafieldsSet($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    { metafields },
  );
  assertNoErrors(d.metafieldsSet.userErrors);
}

async function metafieldsDelete(admin: AdminGraphql, metafields: Array<Record<string, string>>) {
  const d: { metafieldsDelete: { userErrors: UserError[] } } = await gql(
    admin,
    `#graphql
    mutation WcSeoMetafieldsDelete($metafields: [MetafieldIdentifierInput!]!) {
      metafieldsDelete(metafields: $metafields) { userErrors { field message } }
    }`,
    { metafields },
  );
  assertNoErrors(d.metafieldsDelete.userErrors);
}

export async function setHidden(admin: AdminGraphql, ownerId: string, hidden: boolean) {
  if (hidden)
    await metafieldsSet(admin, [
      { ownerId, namespace: "seo", key: "hidden", type: "number_integer", value: "1" },
    ]);
  else await metafieldsDelete(admin, [{ ownerId, namespace: "seo", key: "hidden" }]);
}


// ---- image ALT -------------------------------------------------------------


export async function listProductImages(admin: AdminGraphql): Promise<ImageRow[]> {
  const out: ImageRow[] = [];
  let after: string | null = null;
  for (let page = 0; page < 20; page++) {
    const d: {
      products: {
        nodes: Array<{
          id: string;
          title: string;
          handle: string;
          status: string;
          media: {
            nodes: Array<{
              id: string;
              alt: string | null;
              mediaContentType: string;
              image?: { url: string; width: number; height: number } | null;
              originalSource?: { fileSize: number | null } | null;
            }>;
          };
        }>;
        pageInfo: { hasNextPage: boolean; endCursor: string | null };
      };
    } = await gql(
      admin,
      `#graphql
      query WcSeoProductImages($after: String) {
        products(first: 50, after: $after, sortKey: TITLE, query: "status:active") {
          nodes {
            id title handle status
            media(first: 40) {
              nodes {
                id alt mediaContentType
                ... on MediaImage {
                  image { url(transform: { maxWidth: 120 }) width height }
                  originalSource { fileSize }
                }
              }
            }
          }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { after },
    );
    for (const p of d.products.nodes) {
      p.media.nodes
        .filter((m) => m.mediaContentType === "IMAGE")
        .forEach((m, i) =>
          out.push({
            id: m.id,
            productId: p.id,
            productTitle: p.title,
            productHandle: p.handle,
            position: i + 1,
            alt: m.alt ?? "",
            url: m.image?.url ?? "",
            width: m.image?.width,
            height: m.image?.height,
            fileSize: m.originalSource?.fileSize ?? undefined,
          }),
        );
    }
    after = d.products.pageInfo.hasNextPage ? d.products.pageInfo.endCursor : null;
    if (!after) break;
  }
  return out;
}

export async function updateAlts(admin: AdminGraphql, items: Array<{ id: string; alt: string }>) {
  for (let i = 0; i < items.length; i += 25) {
    const d: { fileUpdate: { userErrors: UserError[] } } = await gql(
      admin,
      `#graphql
      mutation WcSeoAlt($files: [FileUpdateInput!]!) {
        fileUpdate(files: $files) { userErrors { field message } }
      }`,
      { files: items.slice(i, i + 25).map((x) => ({ id: x.id, alt: x.alt.slice(0, 512) })) },
    );
    assertNoErrors(d.fileUpdate.userErrors);
  }
}


// ---- redirects -------------------------------------------------------------


export async function listRedirects(admin: AdminGraphql, query = ""): Promise<RedirectRow[]> {
  const out: RedirectRow[] = [];
  let after: string | null = null;
  for (let page = 0; page < 10; page++) {
    const d: {
      urlRedirects: {
        nodes: RedirectRow[];
        pageInfo: { hasNextPage: boolean; endCursor: string | null };
      };
    } = await gql(
      admin,
      `#graphql
      query WcSeoRedirects($after: String, $query: String) {
        urlRedirects(first: 250, after: $after, query: $query) {
          nodes { id path target }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { after, query: query || null },
    );
    out.push(...d.urlRedirects.nodes);
    after = d.urlRedirects.pageInfo.hasNextPage ? d.urlRedirects.pageInfo.endCursor : null;
    if (!after) break;
  }
  return out;
}

export async function createRedirect(admin: AdminGraphql, path: string, target: string) {
  const d: { urlRedirectCreate: { userErrors: UserError[] } } = await gql(
    admin,
    `#graphql
    mutation WcSeoRedirectCreate($urlRedirect: UrlRedirectInput!) {
      urlRedirectCreate(urlRedirect: $urlRedirect) { userErrors { field message } }
    }`,
    { urlRedirect: { path, target } },
  );
  assertNoErrors(d.urlRedirectCreate.userErrors);
}

export async function deleteRedirect(admin: AdminGraphql, id: string) {
  const d: { urlRedirectDelete: { userErrors: UserError[] } } = await gql(
    admin,
    `#graphql
    mutation WcSeoRedirectDelete($id: ID!) {
      urlRedirectDelete(id: $id) { userErrors { field message } }
    }`,
    { id },
  );
  assertNoErrors(d.urlRedirectDelete.userErrors);
}

/** All live URL paths, used to suggest a redirect target for a dead URL. */
export async function listLivePaths(admin: AdminGraphql) {
  const [products, collections, pages, articles] = await Promise.all(
    (["products", "collections", "pages", "articles"] as SeoKind[]).map((k) =>
      listSeoRows(admin, k).catch(() => [] as SeoRow[]),
    ),
  );
  return [...products, ...collections, ...pages, ...articles]
    .filter((r) => r.status === "ACTIVE")
    .map((r) => ({ path: r.path, name: r.name, kind: r.kind }));
}

/** Best-guess target for a dead path: same last segment, then word overlap. */
export function suggestTarget(
  deadPath: string,
  live: Array<{ path: string; name: string }>,
): string {
  const clean = decodeSafe(deadPath).toLowerCase().replace(/[?#].*$/, "").replace(/\/$/, "");
  const seg = clean.split("/").pop() ?? "";
  const words = new Set(seg.split(/[^a-z0-9]+/).filter((w) => w.length > 2));
  const type = clean.match(/^\/(?:[a-z]{2}(?:-[a-z]{2})?\/)?(products|collections|pages|blogs)\//)?.[1];
  let best = { path: "", score: 0 };
  for (const l of live) {
    const lseg = l.path.split("/").pop() ?? "";
    if (lseg === seg) return l.path;
    const lw = new Set(
      `${lseg} ${l.name}`.toLowerCase().split(/[^a-z0-9]+/).filter((w) => w.length > 2),
    );
    let score = 0;
    for (const w of words) if (lw.has(w)) score++;
    if (type && l.path.startsWith(`/${type}/`)) score += 0.5;
    if (score > best.score) best = { path: l.path, score };
  }
  if (best.score >= 1.5) return best.path;
  if (type === "products" || type === "collections") return "/collections/all";
  if (type === "blogs") {
    const b = clean.match(/\/blogs\/([^/]+)/)?.[1];
    return b ? `/blogs/${b}` : "/";
  }
  return "/";
}

function decodeSafe(s: string) {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

// ---- theme scan ------------------------------------------------------------


type ThemeFile = {
  filename: string;
  size: number | string;
  body: { content?: string };
};

/** Known removed-app fingerprints worth flagging if still in theme code. */
const LEFTOVER_PATTERNS: Array<[RegExp, string]> = [
  [/tapita/i, "Tapita"],
  [/axe-?checkbox|__UpsellCheckbox/i, "AXE Checkbox Upsell"],
  [/booster(theme|apps)/i, "Booster"],
  [/pagefly/i, "PageFly"],
  [/gempages|gem-?page/i, "GemPages"],
  [/shogun/i, "Shogun"],
  [/loox\.io/i, "Loox"],
  [/stamped\.io/i, "Stamped"],
  [/yotpo/i, "Yotpo"],
  [/privy/i, "Privy"],
  [/klaviyo/i, "Klaviyo"],
  [/hextom/i, "Hextom"],
  [/omnisend/i, "Omnisend"],
  [/judge\.me|judgeme/i, "Judge.me"],
  [/vitals\.(app|co)/i, "Vitals"],
];

export async function scanTheme(admin: AdminGraphql): Promise<ThemeScan> {
  const t: {
    themes: { nodes: Array<{ id: string; name: string }> };
  } = await gql(
    admin,
    `#graphql
    query WcSeoMainTheme {
      themes(first: 1, roles: [MAIN]) { nodes { id name } }
    }`,
  );
  const theme = t.themes.nodes[0];
  if (!theme) throw new Error("No published theme found");

  // 1) list every file with size (no bodies)
  const all: Array<{ filename: string; size: number }> = [];
  let after: string | null = null;
  for (let i = 0; i < 10; i++) {
    const d: {
      theme: {
        files: {
          nodes: Array<{ filename: string; size: number | string }>;
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      };
    } = await gql(
      admin,
      `#graphql
      query WcSeoThemeFiles($id: ID!, $after: String) {
        theme(id: $id) {
          files(first: 2500, after: $after) {
            nodes { filename size }
            pageInfo { hasNextPage endCursor }
          }
        }
      }`,
      { id: theme.id, after },
    );
    all.push(...d.theme.files.nodes.map((f) => ({ filename: f.filename, size: Number(f.size) })));
    after = d.theme.files.pageInfo.hasNextPage ? d.theme.files.pageInfo.endCursor : null;
    if (!after) break;
  }

  // 2) bodies of liquid files (layout, sections, snippets, templates json)
  const bodies = new Map<string, string>();
  for (const pattern of [
    ["layout/*"],
    ["snippets/*"],
    ["sections/*"],
    ["blocks/*"],
    ["templates/*"],
    ["config/settings_data.json"],
  ]) {
    let cursor: string | null = null;
    for (let i = 0; i < 20; i++) {
      const d: {
        theme: {
          files: {
            nodes: ThemeFile[];
            pageInfo: { hasNextPage: boolean; endCursor: string | null };
          };
        };
      } = await gql(
        admin,
        `#graphql
        query WcSeoThemeBodies($id: ID!, $names: [String!], $after: String) {
          theme(id: $id) {
            files(first: 100, filenames: $names, after: $after) {
              nodes {
                filename size
                body { ... on OnlineStoreThemeFileBodyText { content } }
              }
              pageInfo { hasNextPage endCursor }
            }
          }
        }`,
        { id: theme.id, names: pattern, after: cursor },
      );
      for (const f of d.theme.files.nodes)
        if (typeof f.body?.content === "string") bodies.set(f.filename, f.body.content);
      cursor = d.theme.files.pageInfo.hasNextPage ? d.theme.files.pageInfo.endCursor : null;
      if (!cursor) break;
    }
  }

  const liquid = [...bodies.entries()].filter(([f]) => !f.startsWith("config/"));
  const allCode = liquid.map(([, c]) => c).join("\n");

  // unused snippets: never rendered/included anywhere
  const snippets = all
    .filter((f) => f.filename.startsWith("snippets/") && f.filename.endsWith(".liquid"))
    .map((f) => f.filename.replace(/^snippets\/|\.liquid$/g, ""));
  const unusedSnippets = snippets.filter((name) => {
    const esc = name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    return !new RegExp(`(render|include)\\s*\\(?\\s*['"]${esc}['"]`).test(allCode);
  });

  // external <script src> and blocking ones in layout files
  const externalScripts: ThemeScan["externalScripts"] = [];
  const blockingScripts: ThemeScan["blockingScripts"] = [];
  for (const [file, code] of liquid) {
    for (const m of code.matchAll(/<script\b([^>]*)\bsrc\s*=\s*["']([^"']+)["']([^>]*)>/gi)) {
      const attrs = `${m[1]} ${m[3]}`;
      const src = m[2];
      if (/^https?:|^\/\//.test(src)) externalScripts.push({ file, src });
      if (file.startsWith("layout/") && !/\b(defer|async)\b/i.test(attrs) && !/type\s*=\s*["']module/i.test(attrs))
        blockingScripts.push({ file, src });
    }
  }

  // app embeds in settings_data.json
  const appEmbeds: ThemeScan["appEmbeds"] = [];
  const settings = bodies.get("config/settings_data.json");
  if (settings) {
    try {
      const json = JSON.parse(settings.replace(/^\s*\/\*[\s\S]*?\*\/\s*/, ""));
      const blocks = json?.current?.blocks ?? {};
      for (const b of Object.values(blocks) as Array<{ type?: string; disabled?: boolean }>)
        if (b?.type?.startsWith("shopify://apps/"))
          appEmbeds.push({ type: b.type.replace("shopify://apps/", ""), disabled: !!b.disabled });
    } catch {
      /* ignore */
    }
  }

  // leftovers from apps (by fingerprint) — only report, never delete
  const leftovers: ThemeScan["leftovers"] = [];
  for (const [file, code] of liquid) {
    for (const [re, app] of LEFTOVER_PATTERNS) {
      if (re.test(file) || re.test(code)) {
        leftovers.push({ file, match: app });
      }
    }
  }

  const assets = all
    .filter((f) => f.filename.startsWith("assets/"))
    .sort((a, b) => b.size - a.size);

  return {
    themeId: theme.id,
    themeName: theme.name,
    files: all.length,
    totalBytes: all.reduce((s, f) => s + f.size, 0),
    largestAssets: assets.slice(0, 15),
    unusedSnippets,
    externalScripts,
    blockingScripts,
    appEmbeds,
    leftovers,
    scannedAt: new Date().toISOString(),
  };
}

// ---- storefront embed config (metafield read by the theme app embed) -------

export async function loadEmbedConfig(admin: AdminGraphql) {
  const d: {
    currentAppInstallation: { id: string; metafield: { value: string } | null };
  } = await gql(
    admin,
    `#graphql
    query WcSeoEmbedConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_seo", key: "config") { value }
      }
    }`,
  );
  let config: SeoEmbedConfig = { ...DEFAULT_EMBED };
  try {
    const raw = d.currentAppInstallation.metafield?.value;
    if (raw) config = { ...config, ...JSON.parse(raw) };
  } catch {
    /* keep default */
  }
  return { installationId: d.currentAppInstallation.id, config };
}

export async function saveEmbedConfig(
  admin: AdminGraphql,
  installationId: string,
  config: SeoEmbedConfig,
) {
  await metafieldsSet(admin, [
    {
      ownerId: installationId,
      namespace: "wc_seo",
      key: "config",
      type: "json",
      value: JSON.stringify(config),
    },
  ]);
}

export async function loadShopBasics(admin: AdminGraphql) {
  const d: { shop: { name: string; myshopifyDomain: string; primaryDomain: { url: string } } } =
    await gql(
      admin,
      `#graphql
      query WcSeoShop { shop { name myshopifyDomain primaryDomain { url } } }`,
    );
  return {
    name: d.shop.name,
    myshopify: d.shop.myshopifyDomain,
    origin: d.shop.primaryDomain.url.replace(/\/$/, ""),
  };
}
