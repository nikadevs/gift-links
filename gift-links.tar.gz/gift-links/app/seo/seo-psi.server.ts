/**
 * SEO & Speed — Google PageSpeed Insights (Lighthouse lab test + Chrome UX
 * Report field data of real visitors).
 *
 * API: https://developers.google.com/speed/docs/insights/v5/get-started
 * Works without a key, but Google recommends a key for regular automated
 * use (Settings → PageSpeed API key). Each test takes 10–60 s.
 *
 * Lighthouse 12+/13 replaced many "opportunities" with "insights", so the
 * parser is generic: every performance audit that is not passing is listed,
 * sorted by its estimated metric savings.
 */
import type { FieldMetric, PsiOpportunity, PsiRun, Strategy } from "./seo.shared";
import { addPsiRuns, getSettings, setJob } from "./seo-store.server";

export { cwvStatus, latestRuns } from "./seo.shared";

const API = "https://www.googleapis.com/pagespeedonline/v5/runPagespeed";
const running = new Set<string>();

export function isPsiRunning(shop: string) {
  return running.has(shop);
}

type LhAudit = {
  id: string;
  title: string;
  score: number | null;
  scoreDisplayMode?: string;
  displayValue?: string;
  numericValue?: number;
  metricSavings?: Record<string, number>;
  details?: {
    type?: string;
    overallSavingsMs?: number;
    overallSavingsBytes?: number;
    items?: Array<Record<string, unknown>>;
  };
};

type PsiJson = {
  error?: { message?: string; code?: number };
  id?: string;
  loadingExperience?: CruxBlock;
  originLoadingExperience?: CruxBlock;
  lighthouseResult?: {
    lighthouseVersion?: string;
    finalDisplayedUrl?: string;
    categories?: Record<string, { score: number | null; auditRefs?: Array<{ id: string; group?: string }> }>;
    audits?: Record<string, LhAudit>;
  };
};

type CruxBlock = {
  id?: string;
  origin_fallback?: boolean;
  overall_category?: string;
  metrics?: Record<string, { percentile: number; category: string }>;
};

export async function runPsi(url: string, strategy: Strategy, key: string): Promise<PsiRun> {
  const at = new Date().toISOString();
  const q = new URLSearchParams({ url, strategy });
  for (const c of ["performance", "seo", "accessibility", "best-practices"])
    q.append("category", c);
  if (key) q.set("key", key);
  try {
    const r = await fetch(`${API}?${q}`, { signal: AbortSignal.timeout(120000) });
    const json = (await r.json()) as PsiJson;
    if (!r.ok || json.error) {
      const msg = json.error?.message ?? `HTTP ${r.status}`;
      return {
        url,
        strategy,
        at,
        scores: {},
        lab: {},
        opportunities: [],
        error:
          r.status === 429
            ? `Google quota exceeded${key ? "" : " — add a free PageSpeed API key in Settings"}: ${msg}`
            : msg,
      };
    }
    return parsePsi(url, strategy, at, json);
  } catch (e) {
    return { url, strategy, at, scores: {}, lab: {}, opportunities: [], error: (e as Error).message };
  }
}

const score = (v: number | null | undefined) =>
  v == null ? undefined : Math.round(v * 100);

export function parsePsi(url: string, strategy: Strategy, at: string, json: PsiJson): PsiRun {
  const lh = json.lighthouseResult ?? {};
  const audits = lh.audits ?? {};
  const num = (id: string) => audits[id]?.numericValue;
  const cats = lh.categories ?? {};

  // field data: page-level if Google has enough visits, otherwise origin
  const page = json.loadingExperience;
  const origin = json.originLoadingExperience;
  const useOrigin = !page?.metrics || page.origin_fallback;
  const crux = useOrigin ? origin : page;
  const m = crux?.metrics ?? {};
  const fm = (k: string, div = 1): FieldMetric | undefined =>
    m[k] ? { p75: m[k].percentile / div, category: m[k].category } : undefined;
  const field = crux?.metrics
    ? {
        scope: (useOrigin ? "origin" : "url") as "url" | "origin",
        overall: crux.overall_category,
        lcp: fm("LARGEST_CONTENTFUL_PAINT_MS"),
        inp: fm("INTERACTION_TO_NEXT_PAINT"),
        cls: fm("CUMULATIVE_LAYOUT_SHIFT_SCORE", 100),
        fcp: fm("FIRST_CONTENTFUL_PAINT_MS"),
        ttfb: fm("EXPERIMENTAL_TIME_TO_FIRST_BYTE"),
      }
    : undefined;

  // opportunities / insights / diagnostics that are not passing
  const perfRefs = cats.performance?.auditRefs ?? [];
  const metricIds = new Set([
    "first-contentful-paint",
    "largest-contentful-paint",
    "total-blocking-time",
    "cumulative-layout-shift",
    "speed-index",
    "interactive",
    "max-potential-fid",
  ]);
  const opportunities: PsiOpportunity[] = [];
  for (const ref of perfRefs) {
    const a = audits[ref.id];
    if (!a || metricIds.has(a.id)) continue;
    if (["notApplicable", "manual", "error"].includes(a.scoreDisplayMode ?? "")) continue;
    const failing =
      (a.score != null && a.score < 0.9) ||
      (a.scoreDisplayMode === "informative" && hasSavings(a));
    if (!failing) continue;
    const savingsMs =
      a.details?.overallSavingsMs ??
      (a.metricSavings ? Math.max(a.metricSavings.LCP ?? 0, a.metricSavings.FCP ?? 0, a.metricSavings.TBT ?? 0) : undefined);
    opportunities.push({
      id: a.id,
      title: a.title,
      score: a.score,
      displayValue: a.displayValue,
      savingsMs: savingsMs || undefined,
      savingsBytes: a.details?.overallSavingsBytes || undefined,
      items: flatItems(a.details).slice(0, 6).map(itemSummary).filter((x) => x.url || x.label),
    });
  }
  opportunities.sort(
    (x, y) =>
      (y.savingsMs ?? 0) - (x.savingsMs ?? 0) ||
      (y.savingsBytes ?? 0) - (x.savingsBytes ?? 0) ||
      (x.score ?? 1) - (y.score ?? 1),
  );

  // third parties
  const tp = flatItems(
    audits["third-parties-insight"]?.details ?? audits["third-party-summary"]?.details,
  );
  const thirdParties = tp
    .map((i) => ({
      entity: typeof i.entity === "string" ? i.entity : String((i.entity as { text?: string })?.text ?? ""),
      blockingMs: Number(i.blockingTime ?? 0),
      bytes: Number(i.transferSize ?? 0),
      mainThreadMs: Number(i.mainThreadTime ?? 0),
    }))
    .filter((t) => t.entity)
    .sort((a, b) => b.mainThreadMs - a.mainThreadMs || b.bytes - a.bytes)
    .slice(0, 15);

  return {
    url,
    strategy,
    at,
    lighthouseVersion: lh.lighthouseVersion,
    scores: {
      performance: score(cats.performance?.score),
      seo: score(cats.seo?.score),
      accessibility: score(cats.accessibility?.score),
      bestPractices: score(cats["best-practices"]?.score),
    },
    lab: {
      fcp: num("first-contentful-paint"),
      lcp: num("largest-contentful-paint"),
      tbt: num("total-blocking-time"),
      cls: num("cumulative-layout-shift"),
      si: num("speed-index"),
      ttfb: num("server-response-time"),
    },
    field,
    lcpElement: findLcpElement(audits),
    totalBytes: num("total-byte-weight"),
    opportunities: opportunities.slice(0, 15),
    thirdParties,
  };
}

/** Table rows of an audit; Lighthouse 12+ nests tables inside "list" details. */
function flatItems(details: unknown): Array<Record<string, unknown>> {
  const d = details as { type?: string; items?: unknown } | undefined;
  if (!d || !Array.isArray(d.items)) return [];
  const out: Array<Record<string, unknown>> = [];
  for (const it of d.items as Array<Record<string, unknown>>) {
    if (!it || typeof it !== "object") continue;
    if ((it.type === "table" || it.type === "opportunity") && Array.isArray(it.items))
      out.push(...(it.items as Array<Record<string, unknown>>));
    else if (it.type === "list" || it.type === "checklist" || it.type === "network-tree") continue;
    else out.push(it);
  }
  return out;
}

function hasSavings(a: LhAudit) {
  const s = a.metricSavings ?? {};
  return Object.values(s).some((v) => v > 0) || (a.details?.overallSavingsMs ?? 0) > 0;
}

function itemSummary(i: Record<string, unknown>) {
  const node = i.node as { nodeLabel?: string; snippet?: string } | undefined;
  const url = typeof i.url === "string" ? i.url : undefined;
  const ms = Number(i.wastedMs ?? i.blockingTime ?? i.mainThreadTime ?? i.duration ?? NaN);
  const bytes = Number(i.wastedBytes ?? i.transferSize ?? i.totalBytes ?? NaN);
  const label =
    (typeof i.entity === "string" && i.entity) ||
    (i.entity as { text?: string } | undefined)?.text ||
    node?.nodeLabel ||
    node?.snippet ||
    (typeof i.label === "string" ? i.label : undefined) ||
    (typeof i.groupLabel === "string" ? i.groupLabel : undefined);
  return {
    url,
    label: label ? String(label).slice(0, 160) : undefined,
    ms: Number.isFinite(ms) ? Math.round(ms) : undefined,
    bytes: Number.isFinite(bytes) ? Math.round(bytes) : undefined,
  };
}

function findLcpElement(audits: Record<string, LhAudit>): string | undefined {
  for (const id of ["largest-contentful-paint-element", "lcp-breakdown-insight", "lcp-discovery-insight"]) {
    const found = findNode(audits[id]?.details);
    if (found) return found;
  }
  return undefined;
}

function findNode(v: unknown, depth = 0): string | undefined {
  if (!v || depth > 6) return undefined;
  if (Array.isArray(v)) {
    for (const x of v) {
      const f = findNode(x, depth + 1);
      if (f) return f;
    }
    return undefined;
  }
  if (typeof v === "object") {
    const o = v as Record<string, unknown>;
    if (o.type === "node" && (o.snippet || o.nodeLabel))
      return `${o.nodeLabel ?? ""}${o.snippet ? ` — ${String(o.snippet).slice(0, 200)}` : ""}`.trim();
    for (const x of Object.values(o)) {
      const f = findNode(x, depth + 1);
      if (f) return f;
    }
  }
  return undefined;
}

/** Test several URLs (mobile + desktop) in the background. */
export async function startPsi(shop: string, urls: string[]) {
  if (running.has(shop) || !urls.length) return false;
  running.add(shop);
  const startedAt = new Date().toISOString();
  void (async () => {
    try {
      const { psiKey } = await getSettings(shop);
      const runs: PsiRun[] = [];
      const plan = urls.flatMap((u) => (["mobile", "desktop"] as Strategy[]).map((s) => [u, s] as const));
      let done = 0;
      for (const [u, s] of plan) {
        await setJob(shop, {
          kind: "psi",
          status: "running",
          startedAt,
          progress: `Testing ${s}: ${u}`,
          done,
          total: plan.length,
        });
        runs.push(await runPsi(u, s, psiKey || process.env.PSI_API_KEY || ""));
        done++;
      }
      await addPsiRuns(shop, runs);
      const errors = runs.filter((r) => r.error);
      await setJob(shop, {
        kind: "psi",
        status: errors.length === runs.length ? "error" : "done",
        startedAt,
        finishedAt: new Date().toISOString(),
        progress: `${runs.length - errors.length}/${runs.length} tests done`,
        ...(errors.length ? { error: errors[0].error } : {}),
      });
    } catch (e) {
      await setJob(shop, {
        kind: "psi",
        status: "error",
        startedAt,
        finishedAt: new Date().toISOString(),
        error: (e as Error).message,
      });
    } finally {
      running.delete(shop);
    }
  })();
  return true;
}


