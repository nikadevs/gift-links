/**
 * SEO & Speed — analysis of ONE storefront HTML page.
 *
 * Pure function (no network): takes the HTML that the server downloaded and
 * returns facts, findings, internal links, scripts and media to check.
 * Scripts on the page are NOT executed, so markup injected later by app
 * JavaScript is not seen here — the UI says so.
 */
import { parse, type HTMLElement } from "node-html-parser";
import {
  pageKind,
  type Finding,
  type PageFacts,
  type ScriptInfo,
} from "./seo.shared";

export type PageAnalysis = {
  facts: PageFacts;
  findings: Finding[];
  /** absolute internal URLs (no hash, no query) linked from this page */
  links: string[];
  scripts: ScriptInfo[];
  videos: string[];
  hreflang: Array<{ lang: string; href: string }>;
};

/** Hosts that belong to Shopify itself (not counted as third-party apps). */
const SHOPIFY_HOSTS =
  /(^|\.)((cdn\.)?shopify\.com|shopifycdn\.(com|net)|shopifysvc\.com|shopify-assets\.com|shop\.app|myshopify\.com|shopifycloud\.com)$/i;

const NON_PAGE =
  /^\/(cart|checkout|checkouts|account|orders|tools|apps|services|admin|password|challenge|cdn|wpm@|web-pixels|\.well-known)(\/|$)|^\/[^?]*\.(js|css|json|xml|png|jpe?g|gif|webp|avif|svg|pdf|mp4|webm|ico|txt|woff2?)$/i;

export function isShopifyHost(host: string) {
  return SHOPIFY_HOSTS.test(host);
}

export function normalizeUrl(href: string, base: string): URL | null {
  try {
    const u = new URL(href, base);
    if (!/^https?:$/.test(u.protocol)) return null;
    u.hash = "";
    return u;
  } catch {
    return null;
  }
}

function attr(el: HTMLElement, name: string) {
  const v = el.getAttribute(name);
  return v == null ? undefined : v;
}

function text(el: HTMLElement | null | undefined) {
  return (el?.text ?? "").replace(/\s+/g, " ").trim();
}

type Node = Record<string, unknown>;

function typesOf(n: Node): string[] {
  const t = n["@type"];
  return (Array.isArray(t) ? t : [t]).filter(Boolean).map(String);
}

function flattenLd(data: unknown): Node[] {
  const out: Node[] = [];
  const walk = (v: unknown) => {
    if (Array.isArray(v)) return v.forEach(walk);
    if (v && typeof v === "object") {
      const n = v as Node;
      if (Array.isArray(n["@graph"])) (n["@graph"] as unknown[]).forEach(walk);
      if (n["@type"]) out.push(n);
    }
  };
  walk(data);
  return out;
}

const asArray = <T,>(v: T | T[] | undefined | null): T[] =>
  v == null ? [] : Array.isArray(v) ? v : [v];

const ORG_TYPES = new Set([
  "Organization",
  "OnlineStore",
  "OnlineBusiness",
  "Corporation",
  "Store",
  "LocalBusiness",
]);
const ARTICLE_TYPES = new Set(["Article", "BlogPosting", "NewsArticle"]);

export function analyzePage(input: {
  url: string;
  finalUrl: string;
  status: number;
  html: string;
  ms: number;
  origin: string;
  xRobotsTag?: string;
}): PageAnalysis {
  const { url, finalUrl, status, html, ms, origin } = input;
  const findings: Finding[] = [];
  const add = (check: string, detail?: string) =>
    findings.push({ check, url, ...(detail ? { detail } : {}) });

  const root = parse(html, {
    comment: false,
    blockTextElements: { script: true, style: true, noscript: true, pre: true },
  });
  const head = root.querySelector("head");
  const body = root.querySelector("body") ?? root;
  const path = new URL(finalUrl || url).pathname;
  const kind = pageKind(path);
  const originHost = new URL(origin).host;

  // ---- head basics ---------------------------------------------------------
  const metas = root.querySelectorAll("meta");
  const metaBy = (key: string) =>
    metas.find(
      (m) =>
        (attr(m, "name") ?? attr(m, "property") ?? "").toLowerCase() === key,
    );
  const title = text(head?.querySelector("title") ?? root.querySelector("title"));
  const description = (attr(metaBy("description") ?? root, "content") ?? "").trim();
  const robots = [
    attr(metaBy("robots") ?? root, "content") ?? "",
    attr(metaBy("googlebot") ?? root, "content") ?? "",
    input.xRobotsTag ?? "",
  ]
    .filter(Boolean)
    .join(", ");
  const links = root.querySelectorAll("link");
  const canonical =
    attr(
      links.find((l) => (attr(l, "rel") ?? "").toLowerCase() === "canonical") ??
        root,
      "href",
    ) ?? "";

  if (/Liquid (syntax )?error/i.test(html)) add("liquid_error");
  if (!attr(root.querySelector("html") ?? root, "lang")) add("no_lang");
  if (!metaBy("viewport")) add("no_viewport");

  if (!title) add("title_missing");
  else if (title.length > 60) add("title_long", `${title.length} chars`);
  else if (title.length < 20) add("title_short", `${title.length} chars`);

  if (!description) add("desc_missing");
  else if (description.length > 160) add("desc_long", `${description.length} chars`);
  else if (description.length < 70) add("desc_short", `${description.length} chars`);

  if (/noindex/i.test(robots)) add("noindex", robots);

  if (!canonical) add("canonical_missing");
  else {
    const c = normalizeUrl(canonical, finalUrl);
    const self = normalizeUrl(finalUrl, finalUrl);
    if (c && self) {
      c.search = "";
      self.search = "";
      if (c.href.replace(/\/$/, "") !== self.href.replace(/\/$/, ""))
        add("canonical_other", `→ ${c.href}`);
    }
  }

  if (!metaBy("og:title") || !metaBy("og:image")) add("og_missing");

  // hreflang
  const hreflang = links
    .filter(
      (l) =>
        (attr(l, "rel") ?? "").toLowerCase() === "alternate" &&
        attr(l, "hreflang"),
    )
    .map((l) => ({
      lang: String(attr(l, "hreflang")),
      href: normalizeUrl(attr(l, "href") ?? "", finalUrl)?.href ?? "",
    }));
  if (hreflang.length) {
    const self = normalizeUrl(canonical || finalUrl, finalUrl)?.href;
    if (!hreflang.some((h) => h.href === self))
      add("hreflang_issue", "no self-referencing hreflang");
    if (hreflang.some((h) => !h.href)) add("hreflang_issue", "hreflang without valid href");
  }

  if (/%[0-9A-F]{2}/i.test(path) || /[^\x20-\x7E]/.test(path))
    add("url_non_ascii", decodeURIComponentSafe(path));

  // ---- headings & content --------------------------------------------------
  const h1Els = body.querySelectorAll("h1");
  const h1 = h1Els.map((h) => {
    const t = text(h);
    if (t) return t;
    const img = h.querySelector("img");
    return (img && attr(img, "alt")) || "";
  });
  if (!h1Els.length) add("h1_missing");
  else {
    if (h1.some((t) => !t)) add("h1_empty");
    if (h1Els.length > 1) add("h1_multiple", `${h1Els.length} H1`);
  }

  const main = root.querySelector("main") ?? body;
  const mainText = text(main);
  const words = mainText ? mainText.split(" ").filter((w) => /\w/.test(w)).length : 0;
  if ((kind === "product" || kind === "article") && words < 150)
    add("thin_content", `${words} words in main content`);

  const domNodes = root.querySelectorAll("*").length;
  if (domNodes > 3000) add("dom_large", `${domNodes} elements`);
  const htmlBytes = Buffer.byteLength(html);
  if (htmlBytes > 600 * 1024) add("html_heavy", `${Math.round(htmlBytes / 1024)} KB`);

  // ---- images --------------------------------------------------------------
  const imgs = body
    .querySelectorAll("img")
    .filter((i) => !(attr(i, "src") ?? "").startsWith("data:"));
  let noAlt = 0;
  let noDims = 0;
  let oversized = 0;
  let noSrcset = 0;
  const oversizedSamples: string[] = [];
  for (const img of imgs) {
    if (img.closest("noscript")) continue;
    const src = attr(img, "src") ?? attr(img, "data-src") ?? "";
    if (attr(img, "alt") == null) noAlt++;
    if (!attr(img, "width") || !attr(img, "height")) noDims++;
    const isShopifyImg = /\/cdn\/shop\/|cdn\.shopify\.com\//.test(src);
    const isRaster = !/\.(svg|gif)(\?|$)/i.test(src);
    const srcset = attr(img, "srcset") ?? attr(img, "data-srcset");
    const inPicture = !!img.closest("picture")?.querySelector("source[srcset]");
    if (isShopifyImg && isRaster) {
      const sized =
        /[?&](width|height)=\d+/.test(src) ||
        /_(\d+x\d*|\d*x\d+|small|medium|large|grande|compact|master)(@2x)?[._]/i.test(src);
      if (!sized && !srcset && !inPicture) {
        oversized++;
        if (oversizedSamples.length < 3) oversizedSamples.push(src);
      }
      if (!srcset && !inPicture) noSrcset++;
    }
  }
  if (noAlt) add("img_no_alt", `${noAlt} of ${imgs.length} images`);
  if (noDims >= 3) add("img_no_dimensions", `${noDims} images`);
  if (oversized)
    add("img_oversized", `${oversized} images, e.g. ${oversizedSamples[0]}`);
  if (noSrcset >= 3) add("img_no_srcset", `${noSrcset} images`);

  const firstImg = (main.querySelectorAll("img") ?? []).find(
    (i) =>
      !i.closest("header") &&
      !i.closest("nav") &&
      !i.closest("noscript") &&
      !(attr(i, "src") ?? "").startsWith("data:"),
  );
  if (firstImg && (attr(firstImg, "loading") ?? "").toLowerCase() === "lazy")
    add("lcp_image_lazy", attr(firstImg, "src") ?? "");

  // ---- scripts / css / fonts / iframes -------------------------------------
  const scripts: ScriptInfo[] = [];
  const seenSrc = new Map<string, number>();
  for (const s of root.querySelectorAll("script")) {
    const src = attr(s, "src");
    const type = (attr(s, "type") ?? "").toLowerCase();
    if (!src) {
      // Shopify content_for_header loads app scripts via asyncLoad(urls)
      const m = s.rawText.match(/var urls = (\[[^\]]*\]);/);
      if (m) {
        try {
          for (const u of JSON.parse(m[1]) as string[]) {
            const nu = normalizeUrl(u, finalUrl);
            if (!nu) continue;
            scripts.push({
              src: nu.href,
              host: nu.host,
              thirdParty: !isShopifyHost(nu.host) && nu.host !== originHost,
              inHead: true,
              blocking: false,
            });
          }
        } catch {
          /* ignore */
        }
      }
      continue;
    }
    if (type && !/javascript|module|^$/.test(type)) continue;
    const nu = normalizeUrl(src, finalUrl);
    if (!nu) continue;
    const inHead = !!head && !!s.closest("head");
    const blocking =
      inHead &&
      attr(s, "async") == null &&
      attr(s, "defer") == null &&
      type !== "module";
    const key = nu.host + nu.pathname;
    seenSrc.set(key, (seenSrc.get(key) ?? 0) + 1);
    scripts.push({
      src: nu.href,
      host: nu.host,
      thirdParty: !isShopifyHost(nu.host) && nu.host !== originHost,
      inHead,
      blocking,
    });
  }
  const blockingJs = scripts.filter((s) => s.blocking);
  if (blockingJs.length)
    add(
      "render_blocking_js",
      blockingJs
        .slice(0, 4)
        .map((s) => shortUrl(s.src))
        .join(", ") + (blockingJs.length > 4 ? ` +${blockingJs.length - 4}` : ""),
    );
  const dups = [...seenSrc.entries()].filter(([, n]) => n > 1);
  if (dups.length)
    add("duplicate_script", dups.map(([k, n]) => `${k} ×${n}`).join(", "));
  const jq = new Set(
    scripts
      .filter((s) => /jquery(?:[.-]?\d[\w.]*)?(?:\.min)?\.js|\/jquery@|\/jquery\/\d/i.test(s.src))
      .map((s) => s.host + new URL(s.src).pathname),
  );
  if (jq.size > 1) add("jquery_multiple", [...jq].map(shortUrl).join(", "));
  const tpHosts = [...new Set(scripts.filter((s) => s.thirdParty).map((s) => s.host))];
  if (tpHosts.length >= 8)
    add("third_party_heavy", `${tpHosts.length} domains`);

  const headCss = (head?.querySelectorAll("link") ?? []).filter(
    (l) =>
      (attr(l, "rel") ?? "").toLowerCase() === "stylesheet" &&
      !/print/i.test(attr(l, "media") ?? ""),
  );
  if (headCss.length > 8) add("render_blocking_css", `${headCss.length} stylesheets`);

  const styleText = root
    .querySelectorAll("style")
    .map((s) => s.rawText)
    .join("\n");
  const faces = styleText.match(/@font-face\s*{[^}]*}/gi) ?? [];
  const noSwap = faces.filter((f) => !/font-display/i.test(f)).length;
  if (noSwap) add("font_no_swap", `${noSwap} @font-face rules`);

  const iframes = body
    .querySelectorAll("iframe")
    .filter((f) => attr(f, "src") && !/^about:|^javascript:/.test(attr(f, "src") ?? ""));
  const eagerFrames = iframes.filter(
    (f) => (attr(f, "loading") ?? "").toLowerCase() !== "lazy",
  ).length;
  if (eagerFrames) add("iframe_not_lazy", `${eagerFrames} iframe(s)`);

  const videos = [
    ...new Set(
      body
        .querySelectorAll("video, video source")
        .map((v) => attr(v, "src") ?? attr(v, "data-src") ?? "")
        .filter(Boolean)
        .map((s) => normalizeUrl(s, finalUrl)?.href ?? "")
        .filter(Boolean),
    ),
  ];

  // mixed content
  if (finalUrl.startsWith("https:")) {
    const insecure = root
      .querySelectorAll("img[src], script[src], iframe[src], source[src], video[src], link[rel=stylesheet]")
      .map((e) => attr(e, "src") ?? attr(e, "href") ?? "")
      .filter((s) => /^http:\/\//i.test(s));
    if (insecure.length) add("mixed_content", insecure.slice(0, 3).join(", "));
  }

  // ---- structured data -----------------------------------------------------
  const nodes: Node[] = [];
  for (const s of root.querySelectorAll('script[type="application/ld+json"]')) {
    const raw = s.rawText.trim();
    if (!raw) continue;
    try {
      nodes.push(...flattenLd(JSON.parse(raw)));
    } catch (e) {
      add("jsonld_invalid", String((e as Error).message).slice(0, 80));
    }
  }
  const schemaTypes = [...new Set(nodes.flatMap(typesOf))];
  checkStructuredData(kind, nodes, add);

  // ---- links ---------------------------------------------------------------
  const internal = new Set<string>();
  for (const a of body.querySelectorAll("a[href]")) {
    const href = attr(a, "href") ?? "";
    if (/^(mailto|tel|javascript|sms|whatsapp):/i.test(href) || href.startsWith("#"))
      continue;
    const u = normalizeUrl(href, finalUrl);
    if (!u || u.host !== originHost) continue;
    if (NON_PAGE.test(u.pathname)) continue;
    u.search = "";
    internal.add(u.href);
  }

  const facts: PageFacts = {
    url,
    finalUrl,
    status,
    kind,
    ms,
    title,
    description,
    canonical,
    robots,
    h1,
    words,
    htmlBytes,
    domNodes,
    images: imgs.length,
    imagesNoAlt: noAlt,
    scripts: scripts.length,
    thirdPartyHosts: tpHosts,
    schemaTypes,
    internalLinks: internal.size,
  };

  return {
    facts,
    findings,
    links: [...internal],
    scripts,
    videos,
    hreflang,
  };
}

function checkStructuredData(
  kind: string,
  nodes: Node[],
  add: (check: string, detail?: string) => void,
) {
  const has = (set: Set<string> | string[]) => {
    const s = Array.isArray(set) ? new Set(set) : set;
    return nodes.filter((n) => typesOf(n).some((t) => s.has(t)));
  };

  // Products: top-level Product/ProductGroup (variants inside hasVariant are
  // not separate products).
  const variantNodes = new Set<Node>();
  for (const n of nodes)
    for (const v of asArray(n.hasVariant as Node | Node[])) variantNodes.add(v);
  const products = has(["Product", "ProductGroup"]).filter(
    (n) => !variantNodes.has(n),
  );

  if (kind === "product" && !products.length) add("product_schema_missing");

  const ids = new Set(
    products.map((p) => String(p["@id"] ?? p.productGroupID ?? p.name ?? "")),
  );
  if (ids.size > 1) add("schema_duplicate", `${ids.size} different Product blocks`);

  let badOffer = 0;
  let noImage = false;
  let noId = false;
  let noReturn = true;
  let noShip = true;
  for (const p of products) {
    const variants = asArray(p.hasVariant as Node | Node[]);
    const items = variants.length ? variants : [p];
    if (!p.image && items.every((v) => !v.image)) noImage = true;
    if (!p.brand && !p.sku && !p.gtin && !p.gtin13 && !p.gtin12 && !p.mpn && items.every((v) => !v.sku && !v.gtin && !v.gtin13 && !v.gtin12 && !v.mpn))
      noId = true;
    if (p.hasMerchantReturnPolicy) noReturn = false;
    for (const v of items) {
      for (const o of asArray(v.offers as Node | Node[])) {
        const offers = typesOf(o).includes("AggregateOffer") ? [o] : [o];
        for (const off of offers) {
          const price = off.price ?? off.lowPrice;
          if (
            price == null ||
            Number.isNaN(Number(price)) ||
            !off.priceCurrency ||
            !off.availability
          )
            badOffer++;
          if (off.hasMerchantReturnPolicy) noReturn = false;
          if (off.shippingDetails) noShip = false;
        }
      }
    }
    const rating = (p.aggregateRating ?? null) as Node | null;
    if (rating) {
      const value = Number(rating.ratingValue);
      const best = Number(rating.bestRating ?? 5);
      const worst = Number(rating.worstRating ?? 1);
      const count = Number(rating.reviewCount ?? rating.ratingCount);
      if (!(value >= worst && value <= best) || !(count > 0))
        add("rating_invalid", `ratingValue ${rating.ratingValue}, count ${rating.reviewCount ?? rating.ratingCount}`);
    }
  }
  if (products.length) {
    if (badOffer) add("product_offer_invalid", `${badOffer} offer(s)`);
    if (noImage) add("product_no_image");
    if (noId) add("product_no_identifier");
    const orgReturn = nodes.some(
      (n) => typesOf(n).some((t) => ORG_TYPES.has(t)) && n.hasMerchantReturnPolicy,
    );
    if (noReturn && !orgReturn) add("product_no_return_policy");
    const orgShip = nodes.some(
      (n) => typesOf(n).some((t) => ORG_TYPES.has(t)) && n.hasShippingService,
    );
    if (noShip && !orgShip) add("product_no_shipping");
  }

  const orgs = has(ORG_TYPES);
  if (kind === "home" && !orgs.length && !has(["WebSite"]).length)
    add("org_schema_missing");
  const orgKeys = new Set(orgs.map((o) => String(o["@id"] ?? `${o.name}|${o.url}`)));
  if (orgKeys.size > 1) add("schema_duplicate", `${orgKeys.size} different Organization blocks`);

  if (kind === "article") {
    const arts = has(ARTICLE_TYPES);
    if (!arts.length) add("article_schema_missing");
    const artKeys = new Set(arts.map((a) => String(a["@id"] ?? a.headline ?? "")));
    if (artKeys.size > 1) add("schema_duplicate", `${artKeys.size} different Article blocks`);
  }
  if ((kind === "product" || kind === "article") && !has(["BreadcrumbList"]).length)
    add("breadcrumb_missing");
}

function decodeURIComponentSafe(s: string) {
  try {
    return decodeURIComponent(s);
  } catch {
    return s;
  }
}

export function shortUrl(u: string) {
  try {
    const x = new URL(u);
    const p = x.pathname.length > 40 ? `…${x.pathname.slice(-38)}` : x.pathname;
    return x.host + p;
  } catch {
    return u.slice(0, 60);
  }
}
