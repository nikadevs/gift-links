/**
 * SEO & Speed — site audit (crawler).
 *
 * quick: home + key pages (settings.keyPaths or a sample from the sitemap)
 * full:  every URL in the sitemap (up to settings.fullCrawlMax) + linked pages
 *
 * Polite: 2 requests at a time with a pause, identifies itself, read-only.
 * Runs inside the app process; progress is written to job-crawl.json so the
 * admin page can poll it. Only ONE crawl per shop at a time.
 */
import { analyzePage, isShopifyHost, normalizeUrl } from "./seo-html.server";
import {
  scoreFindings,
  type CrawlReport,
  type Finding,
  type PageFacts,
  type ScriptInfo,
} from "./seo.shared";
import {
  get404,
  getJob,
  getSettings,
  saveReport,
  setJob,
} from "./seo-store.server";

const UA =
  "Mozilla/5.0 (compatible; WoodenCrewAudit/1.0; +https://woodencrew.store)";
const PAGE_TIMEOUT = 25000;
const CONCURRENCY = 2;
const PAUSE_MS = 600;
const MAX_LINK_CHECKS = 400;
const MAX_SCRIPT_SIZES = 40;

const running = new Set<string>();

export function isCrawlRunning(shop: string) {
  return running.has(shop);
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

type Fetched = {
  status: number;
  finalUrl: string;
  html: string;
  ms: number;
  type: string;
  xRobots: string;
  error?: string;
};

async function fetchPage(url: string): Promise<Fetched> {
  let lastErr = "";
  for (let attempt = 0; attempt < 2; attempt++) {
    const t = Date.now();
    try {
      const r = await fetch(url, {
        redirect: "follow",
        signal: AbortSignal.timeout(PAGE_TIMEOUT),
        headers: { "user-agent": UA, accept: "text/html,application/xhtml+xml" },
      });
      if ((r.status === 429 || r.status >= 500) && attempt === 0) {
        await sleep(2500);
        continue;
      }
      const type = r.headers.get("content-type") ?? "";
      const html = type.includes("html") || type.includes("xml") || type.includes("text")
        ? await r.text()
        : "";
      return {
        status: r.status,
        finalUrl: r.url || url,
        html,
        ms: Date.now() - t,
        type,
        xRobots: r.headers.get("x-robots-tag") ?? "",
      };
    } catch (e) {
      lastErr = (e as Error).message;
      if (attempt === 0) await sleep(1500);
    }
  }
  return { status: 0, finalUrl: url, html: "", ms: 0, type: "", xRobots: "", error: lastErr };
}

/** Status of a URL without downloading it (HEAD, falls back to GET). */
async function probe(url: string): Promise<{ status: number; location?: string; bytes?: number }> {
  for (const method of ["HEAD", "GET"] as const) {
    try {
      const r = await fetch(url, {
        method,
        redirect: "manual",
        signal: AbortSignal.timeout(15000),
        headers: { "user-agent": UA },
      });
      if (method === "HEAD" && (r.status === 405 || r.status === 501)) continue;
      const len = Number(r.headers.get("content-length"));
      if (method === "GET") r.body?.cancel().catch(() => {});
      return {
        status: r.status,
        location: r.headers.get("location") ?? undefined,
        bytes: Number.isFinite(len) && len > 0 ? len : undefined,
      };
    } catch {
      /* try next method */
    }
  }
  return { status: 0 };
}

async function downloadSize(url: string): Promise<number | undefined> {
  try {
    const r = await fetch(url, {
      signal: AbortSignal.timeout(20000),
      headers: { "user-agent": UA, "accept-encoding": "identity" },
    });
    if (!r.ok) return undefined;
    const buf = await r.arrayBuffer();
    return buf.byteLength;
  } catch {
    return undefined;
  }
}

const locs = (xml: string) =>
  [...xml.matchAll(/<loc>\s*([^<\s]+)\s*<\/loc>/g)].map((m) =>
    m[1].replace(/&amp;/g, "&"),
  );

async function readSitemap(origin: string, max: number) {
  const index = await fetchPage(`${origin}/sitemap.xml`);
  const urls: string[] = [];
  if (index.status !== 200) return { status: index.status, urls };
  const host = new URL(origin).host;
  for (const loc of locs(index.html)) {
    let u: URL;
    try {
      u = new URL(loc);
    } catch {
      continue;
    }
    if (u.host !== host) continue;
    if (/sitemap/i.test(u.pathname) && u.pathname.endsWith(".xml")) {
      const child = await fetchPage(u.href);
      if (child.status === 200)
        for (const c of locs(child.html)) {
          try {
            if (new URL(c).host === host) urls.push(c);
          } catch {
            /* skip */
          }
        }
    } else urls.push(u.href);
    if (urls.length > max * 3) break;
  }
  return { status: 200, urls: [...new Set(urls)] };
}

function samplePaths(sitemap: string[], origin: string): string[] {
  const pick = (re: RegExp, n: number) =>
    sitemap.filter((u) => re.test(new URL(u).pathname)).slice(0, n);
  return [
    `${origin}/`,
    ...pick(/^\/products\//, 6),
    ...pick(/^\/collections\/[^/]+$/, 3),
    ...pick(/^\/blogs\/[^/]+$/, 1),
    ...pick(/^\/blogs\/[^/]+\/[^/]+/, 2),
    ...pick(/^\/pages\//, 2),
  ];
}

export async function runCrawl(opts: {
  shop: string;
  origin: string;
  mode: "quick" | "full";
}) {
  const { shop, origin, mode } = opts;
  if (running.has(shop)) return;
  running.add(shop);
  const startedAt = new Date().toISOString();
  const job = (progress: string, done = 0, total = 0) =>
    setJob(shop, { kind: "crawl", status: "running", startedAt, progress, done, total });
  try {
    await job("Reading robots.txt and sitemap…");
    const settings = await getSettings(shop);
    const findings: Finding[] = [];
    const notes: string[] = [];

    // robots.txt
    const robotsRes = await fetchPage(`${origin}/robots.txt`);
    const robotsTxt = robotsRes.html;
    const robots = {
      status: robotsRes.status,
      sitemapLine: /^\s*sitemap:/im.test(robotsTxt),
    };
    if (robotsRes.status === 200) {
      if (rootDisallowForAll(robotsTxt))
        findings.push({ check: "robots_root_disallow", url: `${origin}/robots.txt` });
      if (!robots.sitemapLine)
        findings.push({ check: "robots_no_sitemap", url: `${origin}/robots.txt` });
    }

    // sitemap
    const sm = await readSitemap(origin, settings.fullCrawlMax);
    if (sm.status !== 200)
      findings.push({ check: "sitemap_missing", url: `${origin}/sitemap.xml`, detail: `HTTP ${sm.status}` });
    const inSitemap = new Set(sm.urls.map((u) => u.replace(/\/$/, "")));

    // what to crawl
    let queue: string[];
    if (mode === "full") {
      queue = [`${origin}/`, ...sm.urls];
    } else if (settings.keyPaths.length) {
      queue = settings.keyPaths.map((p) => new URL(p, origin).href);
    } else queue = samplePaths(sm.urls, origin);
    queue = [...new Set(queue.map((u) => u.replace(/#.*$/, "")))];
    const discovered = queue.length;
    if (mode === "full" && queue.length > settings.fullCrawlMax) {
      notes.push(`Sitemap has ${queue.length} URLs; checked the first ${settings.fullCrawlMax} (Settings → max pages).`);
      queue = queue.slice(0, settings.fullCrawlMax);
    }

    // crawl pages
    const pages: PageFacts[] = [];
    const linkSources = new Map<string, Set<string>>();
    const scriptMap = new Map<string, ScriptInfo & { pages: number }>();
    const videos = new Set<string>();
    const canonicals = new Map<string, string>(); // target -> source page
    let done = 0;
    for (let i = 0; i < queue.length; i += CONCURRENCY) {
      if (i) await sleep(PAUSE_MS);
      await job(`Checking pages… ${done}/${queue.length}`, done, queue.length);
      await Promise.all(
        queue.slice(i, i + CONCURRENCY).map(async (url) => {
          const r = await fetchPage(url);
          done++;
          if (r.error) {
            findings.push({ check: "fetch_failed", url, detail: r.error.slice(0, 120) });
            pages.push(emptyFacts(url, r));
            return;
          }
          if (r.status >= 400) {
            findings.push({ check: "http_error", url, detail: `HTTP ${r.status}` });
            pages.push(emptyFacts(url, r));
            return;
          }
          const sameUrl =
            r.finalUrl.replace(/\/$/, "") === url.replace(/\/$/, "");
          if (!sameUrl)
            findings.push({ check: "redirected", url, detail: `→ ${r.finalUrl}` });
          if (!r.type.includes("html")) {
            pages.push(emptyFacts(url, r));
            return;
          }
          const a = analyzePage({
            url,
            finalUrl: r.finalUrl,
            status: r.status,
            html: r.html,
            ms: r.ms,
            origin,
            xRobotsTag: r.xRobots,
          });
          pages.push(a.facts);
          findings.push(...a.findings);
          if (/noindex/i.test(a.facts.robots) && inSitemap.has(url.replace(/\/$/, "")))
            findings.push({ check: "noindex_in_sitemap", url });
          for (const l of a.links) {
            if (!linkSources.has(l)) linkSources.set(l, new Set());
            linkSources.get(l)!.add(url);
          }
          for (const s of a.scripts) {
            const k = s.src.replace(/[?#].*$/, "");
            const e = scriptMap.get(k);
            if (e) e.pages++;
            else scriptMap.set(k, { ...s, src: k, pages: 1 });
          }
          a.videos.forEach((v) => videos.add(v));
          const c = a.findings.find((f) => f.check === "canonical_other");
          if (c?.detail) canonicals.set(c.detail.replace(/^→ /, ""), url);
        }),
      );
    }

    // site-wide: duplicate titles / descriptions
    dupFindings(pages, "title", "title_duplicate", findings);
    dupFindings(pages, "description", "desc_duplicate", findings);

    // links not yet seen + canonical targets
    const crawled = new Set(pages.map((p) => p.url.replace(/\/$/, "")));
    const toProbe = [...new Set([...linkSources.keys(), ...canonicals.keys()])].filter(
      (u) => !crawled.has(u.replace(/\/$/, "")),
    );
    const probeList = toProbe.slice(0, MAX_LINK_CHECKS);
    if (toProbe.length > probeList.length)
      notes.push(`Checked ${probeList.length} of ${toProbe.length} linked URLs.`);
    let pdone = 0;
    for (let i = 0; i < probeList.length; i += 4) {
      await job(`Checking links… ${pdone}/${probeList.length}`, pdone, probeList.length);
      await Promise.all(
        probeList.slice(i, i + 4).map(async (u) => {
          const p = await probe(u);
          pdone++;
          const from = [...(linkSources.get(u) ?? [])];
          const src = canonicals.get(u);
          if (p.status >= 400 || p.status === 0) {
            for (const f of from.slice(0, 5))
              findings.push({ check: "broken_link", url: f, detail: `${u} → HTTP ${p.status || "no answer"}` });
            if (src) findings.push({ check: "canonical_broken", url: src, detail: `${u} → HTTP ${p.status}` });
          } else if (p.status >= 300 && p.status < 400) {
            const target = p.location ? normalizeUrl(p.location, u)?.href : "";
            // trailing-slash / locale redirects are harmless noise; skip same path
            if (target && new URL(target).pathname !== new URL(u).pathname) {
              for (const f of from.slice(0, 3))
                findings.push({ check: "link_to_redirect", url: f, detail: `${u} → ${target}` });
              if (src) findings.push({ check: "canonical_broken", url: src, detail: `${u} redirects` });
            }
          }
        }),
      );
      await sleep(250);
    }
    // crawled pages that were linked but are broken are already http_error;
    // add the linking pages for them too
    for (const p of pages) {
      if (p.status >= 400) {
        for (const f of [...(linkSources.get(p.url) ?? [])].slice(0, 5))
          findings.push({ check: "broken_link", url: f, detail: `${p.url} → HTTP ${p.status}` });
      }
    }

    // videos (size)
    for (const v of [...videos].slice(0, 8)) {
      const p = await probe(v);
      if (p.bytes && p.bytes > 2 * 1024 * 1024)
        findings.push({
          check: "video_heavy",
          url: v,
          detail: `${(p.bytes / 1024 / 1024).toFixed(1)} MB`,
        });
    }

    // third-party script sizes (uncompressed)
    await job("Measuring scripts…");
    const scripts = [...scriptMap.values()].sort((a, b) => b.pages - a.pages);
    for (const s of scripts.filter((x) => x.thirdParty || !isShopifyHost(x.host)).slice(0, MAX_SCRIPT_SIZES)) {
      s.bytes = await downloadSize(s.src);
    }

    // 404 log → finding
    const log = await get404(shop);
    const since = Date.now() - 30 * 86400000;
    const recent = Object.values(log).filter((e) => !e.ignored && Date.parse(e.last) > since);
    if (recent.length) {
      const hits = recent.reduce((s, e) => s + e.hits, 0);
      findings.push({
        check: "not_found_hits",
        url: `${origin}/`,
        detail: `${recent.length} dead URLs, ${hits} visits (30 days)`,
      });
    }

    const uniq = dedupe(findings);
    const report: CrawlReport = {
      version: 1,
      id: startedAt.replace(/[:.]/g, "-"),
      mode,
      origin,
      startedAt,
      finishedAt: new Date().toISOString(),
      discovered,
      checked: pages.length,
      linksChecked: probeList.length,
      pages,
      findings: uniq,
      scripts,
      robots,
      sitemap: { status: sm.status, urls: sm.urls.length },
      score: scoreFindings(uniq, pages.length),
      notes,
    };
    await saveReport(shop, report);
    await setJob(shop, {
      kind: "crawl",
      status: "done",
      startedAt,
      finishedAt: report.finishedAt,
      progress: `${pages.length} pages checked`,
    });
    return report;
  } catch (e) {
    await setJob(shop, {
      kind: "crawl",
      status: "error",
      startedAt,
      finishedAt: new Date().toISOString(),
      error: (e as Error).message,
    });
  } finally {
    running.delete(shop);
  }
}

/** Start a crawl in the background; returns immediately. */
export async function startCrawl(shop: string, origin: string, mode: "quick" | "full") {
  if (running.has(shop) || !origin) return false;
  const job = await getJob(shop, "crawl");
  // stale "running" state from a restarted process is fine to overwrite
  void job;
  void runCrawl({ shop, origin, mode });
  return true;
}

function emptyFacts(url: string, r: Fetched): PageFacts {
  return {
    url,
    finalUrl: r.finalUrl,
    status: r.status,
    kind: "other",
    ms: r.ms,
    title: "",
    description: "",
    canonical: "",
    robots: r.xRobots,
    h1: [],
    words: 0,
    htmlBytes: r.html.length,
    domNodes: 0,
    images: 0,
    imagesNoAlt: 0,
    scripts: 0,
    thirdPartyHosts: [],
    schemaTypes: [],
    internalLinks: 0,
    ...(r.error ? { error: r.error } : {}),
  };
}

function dupFindings(
  pages: PageFacts[],
  field: "title" | "description",
  checkId: string,
  out: Finding[],
) {
  const by = new Map<string, PageFacts[]>();
  for (const p of pages) {
    if (p.status !== 200 || !p[field] || /noindex/i.test(p.robots)) continue;
    // pages whose canonical points elsewhere are duplicates on purpose
    if (p.canonical && p.canonical.replace(/\/$/, "") !== p.finalUrl.replace(/[?#].*$/, "").replace(/\/$/, ""))
      continue;
    // market/language subfolders (/en-gb/…) legitimately repeat the same text
    const locale = new URL(p.finalUrl || p.url).pathname.match(/^\/[a-z]{2}(-[a-z]{2})?(?=\/|$)/i)?.[0] ?? "";
    const k = `${locale}|${p[field].toLowerCase()}`;
    by.set(k, [...(by.get(k) ?? []), p]);
  }
  for (const group of by.values()) {
    if (group.length < 2) continue;
    for (const p of group)
      out.push({
        check: checkId,
        url: p.url,
        detail: `same as ${group.length - 1} other page(s), e.g. ${group.find((g) => g !== p)!.url}`,
      });
  }
}

function dedupe(findings: Finding[]) {
  const seen = new Set<string>();
  return findings.filter((f) => {
    const k = `${f.check}|${f.url}|${f.detail ?? ""}`;
    if (seen.has(k)) return false;
    seen.add(k);
    return true;
  });
}

/** True when a "User-agent: *" group (or Googlebot) has "Disallow: /". */
export function rootDisallowForAll(txt: string) {
  const lines = txt.split(/\r?\n/).map((l) => l.replace(/#.*/, "").trim());
  let agents: string[] = [];
  let inRules = false;
  for (const l of lines) {
    const m = l.match(/^([a-z-]+)\s*:\s*(.*)$/i);
    if (!m) continue;
    const key = m[1].toLowerCase();
    const val = m[2].trim();
    if (key === "user-agent") {
      if (inRules) agents = [];
      inRules = false;
      agents.push(val.toLowerCase());
    } else {
      inRules = true;
      if (
        key === "disallow" &&
        val === "/" &&
        agents.some((a) => a === "*" || a === "googlebot")
      )
        return true;
    }
  }
  return false;
}
