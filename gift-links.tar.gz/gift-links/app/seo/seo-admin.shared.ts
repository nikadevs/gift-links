/** Types and pure helpers shared by the admin tools (server + browser). */

export type SeoKind = "products" | "collections" | "pages" | "articles";


export type SeoRow = {
  id: string;
  kind: SeoKind;
  name: string;
  handle: string;
  path: string;
  status: string;
  seoTitle: string;
  seoDescription: string;
  fallbackDescription: string;
  hidden: boolean;
  image?: string;
};

/** Fill a meta template: {title} {shop} {type} {vendor} — kept intentionally small. */
export function fillTemplate(tpl: string, row: SeoRow, shopName: string) {
  return tpl
    .replace(/\{title\}/g, row.name)
    .replace(/\{shop\}/g, shopName)
    .replace(/\{summary\}/g, row.fallbackDescription)
    .replace(/\s+/g, " ")
    .trim();
}

export type ImageRow = {
  id: string;
  productId: string;
  productTitle: string;
  productHandle: string;
  position: number;
  alt: string;
  url: string;
  width?: number;
  height?: number;
  fileSize?: number;
};

export function altTemplate(tpl: string, img: ImageRow, shopName: string) {
  return tpl
    .replace(/\{title\}/g, img.productTitle)
    .replace(/\{shop\}/g, shopName)
    .replace(/\{n\}/g, String(img.position))
    .replace(/\s+/g, " ")
    .trim();
}

export type RedirectRow = { id: string; path: string; target: string };

export type ThemeScan = {
  themeId: string;
  themeName: string;
  files: number;
  totalBytes: number;
  largestAssets: Array<{ filename: string; size: number }>;
  unusedSnippets: string[];
  externalScripts: Array<{ file: string; src: string }>;
  blockingScripts: Array<{ file: string; src: string }>;
  appEmbeds: Array<{ type: string; disabled: boolean }>;
  leftovers: Array<{ file: string; match: string }>;
  scannedAt: string;
};
