/**
 * SEO & Speed — automatic checks inside the app process (pm2 keeps it alive).
 *
 * Every 30 min, for each shop with an offline session:
 *  - daily quick audit (key pages) when the last audit is older than 23 h;
 *    a full sitemap audit instead when the last full one is older than 7 days
 *  - daily PageSpeed test (home + first key product, mobile + desktop)
 * Disable per shop in Settings, or for the whole server with
 * WC_SEO_SCHEDULER=off.
 */
import prisma from "../db.server";
import { unauthenticated } from "../shopify.server";
import { startCrawl, isCrawlRunning } from "./seo-crawl.server";
import { startPsi, isPsiRunning } from "./seo-psi.server";
import {
  getLastFull,
  getLatestReport,
  getPsiRuns,
  getSettings,
} from "./seo-store.server";
import { loadShopBasics } from "./seo-admin.server";

const TICK_MS = 30 * 60 * 1000;
const DAY = 24 * 60 * 60 * 1000;

declare global {
  // eslint-disable-next-line no-var
  var wcSeoScheduler: NodeJS.Timeout | undefined;
}

async function tick() {
  let shops: string[] = [];
  try {
    const rows = await prisma.session.findMany({
      where: { isOnline: false },
      select: { shop: true },
    });
    shops = [...new Set<string>(rows.map((r: { shop: string }) => r.shop))];
  } catch {
    return;
  }
  for (const shop of shops) {
    try {
      const settings = await getSettings(shop);
      if (!settings.autoDaily && !settings.autoPsi) continue;
      const latest = await getLatestReport(shop);
      const lastFull = await getLastFull(shop);
      const now = Date.now();
      const needCrawl =
        settings.autoDaily &&
        !isCrawlRunning(shop) &&
        (!latest || now - Date.parse(latest.finishedAt) > DAY - 60 * 60 * 1000);
      const runs = await getPsiRuns(shop);
      const lastPsi = runs.reduce((m, r) => (r.at > m ? r.at : m), "");
      const needPsi =
        settings.autoPsi &&
        !isPsiRunning(shop) &&
        (!lastPsi || now - Date.parse(lastPsi) > DAY - 60 * 60 * 1000);
      if (!needCrawl && !needPsi) continue;

      const { admin } = await unauthenticated.admin(shop);
      const { origin } = await loadShopBasics(admin);
      if (needCrawl) {
        const full = !lastFull || now - Date.parse(lastFull.at) > 7 * DAY;
        await startCrawl(shop, origin, full ? "full" : "quick");
      }
      if (needPsi) {
        const product =
          settings.keyPaths.find((p) => p.includes("/products/")) ??
          latest?.pages.find((p) => p.kind === "product" && p.status === 200)?.url;
        const urls = [`${origin}/`, ...(product ? [new URL(product, origin).href] : [])];
        await startPsi(shop, urls);
      }
    } catch (e) {
      console.warn(`[wc-seo] scheduler ${shop}:`, (e as Error).message);
    }
  }
}

export function startSeoScheduler() {
  if (process.env.WC_SEO_SCHEDULER === "off") return;
  if (global.wcSeoScheduler) return;
  // first run a few minutes after start, so deploy health checks stay fast
  setTimeout(() => void tick(), 3 * 60 * 1000).unref?.();
  global.wcSeoScheduler = setInterval(() => void tick(), TICK_MS);
  global.wcSeoScheduler.unref?.();
}
