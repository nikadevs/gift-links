import { authenticate } from "../shopify.server";
import {
  loadEmbedConfig,
  loadShopBasics,
  saveEmbedConfig,
  type AdminGraphql,
} from "./seo-admin.server";
import { checkEmbed, embedActivateUrl } from "../embed-status.server";
import { getJob } from "./seo-store.server";
import { isCrawlRunning } from "./seo-crawl.server";
import { isPsiRunning } from "./seo-psi.server";

const basicsCache = new Map<string, { at: number; v: Awaited<ReturnType<typeof loadShopBasics>> }>();

export async function seoAuth(request: Request) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  let basics = basicsCache.get(shop);
  if (!basics || Date.now() - basics.at > 10 * 60 * 1000) {
    basics = { at: Date.now(), v: await loadShopBasics(admin) };
    basicsCache.set(shop, basics);
  }
  return { admin, session, shop, ...basics.v };
}

/** Make sure the storefront embed knows where to send 404 beacons. */
export async function ensureEmbedConfig(admin: AdminGraphql) {
  try {
    // eslint-disable-next-line no-undef
    const appUrl = (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, "");
    const { installationId, config } = await loadEmbedConfig(admin);
    if (appUrl && config.beaconUrl !== appUrl) {
      config.beaconUrl = appUrl;
      await saveEmbedConfig(admin, installationId, config);
    }
    return config;
  } catch {
    return null;
  }
}

export const SEO_EMBED_MARKERS = /name="wc-seo-embed"/;

export async function seoEmbedState(shop: string, origin: string, force = false) {
  const state = await checkEmbed(origin, SEO_EMBED_MARKERS, force);
  return {
    state,
    // eslint-disable-next-line no-undef
    activateUrl: embedActivateUrl(shop, process.env.SHOPIFY_API_KEY || "", "seo-speed"),
  };
}

/** Job states; a "running" job whose process is gone is shown as interrupted. */
export async function jobStates(shop: string) {
  const [crawl, psi] = await Promise.all([getJob(shop, "crawl"), getJob(shop, "psi")]);
  if (crawl.status === "running" && !isCrawlRunning(shop))
    Object.assign(crawl, { status: "error", error: "Interrupted (app restarted). Run again." });
  if (psi.status === "running" && !isPsiRunning(shop))
    Object.assign(psi, { status: "error", error: "Interrupted (app restarted). Run again." });
  return { crawl, psi };
}
