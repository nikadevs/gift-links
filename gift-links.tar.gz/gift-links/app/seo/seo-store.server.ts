/**
 * SEO & Speed — storage on the app server's disk.
 *
 * Reports are too big for metafields, so they live in JSON files:
 *   $WC_DATA_DIR/seo/<shop>/{settings,latest,job-crawl,job-psi,psi,404}.json
 *   $WC_DATA_DIR/seo/<shop>/reports/<id>.json   (last KEEP_REPORTS runs)
 * Default WC_DATA_DIR = <app dir>/data. The auto-deploy script only replaces
 * build/ app/ extensions/ prisma/ package*.json, so data/ survives deploys.
 * Nothing here is needed by the storefront.
 */
import fs from "node:fs/promises";
import path from "node:path";
import {
  DEFAULT_SETTINGS,
  type CrawlReport,
  type JobState,
  type PsiRun,
  type SeoSettings,
} from "./seo.shared";

const KEEP_REPORTS = 12;
const KEEP_PSI = 400;
const MAX_404_PATHS = 2000;

export const dataRoot = () =>
  path.resolve(process.env.WC_DATA_DIR || path.join(process.cwd(), "data"), "seo");

const safeShop = (shop: string) => shop.replace(/[^a-z0-9.-]/gi, "_");
const dir = (shop: string) => path.join(dataRoot(), safeShop(shop));

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return JSON.parse(await fs.readFile(file, "utf8")) as T;
  } catch {
    return fallback;
  }
}

async function writeJson(file: string, data: unknown) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data));
  await fs.rename(tmp, file);
}

// ---- settings --------------------------------------------------------------
export async function getSettings(shop: string): Promise<SeoSettings> {
  const s = await readJson<Partial<SeoSettings>>(
    path.join(dir(shop), "settings.json"),
    {},
  );
  return { ...DEFAULT_SETTINGS, ...s, version: 1 };
}

export async function saveSettings(shop: string, s: SeoSettings) {
  await writeJson(path.join(dir(shop), "settings.json"), s);
}

// ---- jobs ------------------------------------------------------------------
export async function getJob(shop: string, kind: JobState["kind"]) {
  return readJson<JobState>(path.join(dir(shop), `job-${kind}.json`), {
    kind,
    status: "idle",
  });
}

export async function setJob(shop: string, job: JobState) {
  await writeJson(path.join(dir(shop), `job-${job.kind}.json`), job);
}

// ---- crawl reports ---------------------------------------------------------
export async function getLatestReport(shop: string) {
  return readJson<CrawlReport | null>(path.join(dir(shop), "latest.json"), null);
}

export async function getLastFull(shop: string) {
  return readJson<{ at: string } | null>(path.join(dir(shop), "last-full.json"), null);
}

export async function saveReport(shop: string, report: CrawlReport) {
  await writeJson(path.join(dir(shop), "reports", `${report.id}.json`), report);
  await writeJson(path.join(dir(shop), "latest.json"), report);
  if (report.mode === "full")
    await writeJson(path.join(dir(shop), "last-full.json"), { at: report.finishedAt });
  // history of scores (small) for the trend line
  const histFile = path.join(dir(shop), "history.json");
  const hist = await readJson<HistoryPoint[]>(histFile, []);
  hist.push({
    at: report.finishedAt,
    mode: report.mode,
    score: report.score,
    pages: report.checked,
    findings: report.findings.length,
  });
  await writeJson(histFile, hist.slice(-200));
  // prune old full reports
  try {
    const files = (await fs.readdir(path.join(dir(shop), "reports")))
      .filter((f) => f.endsWith(".json"))
      .sort();
    for (const f of files.slice(0, Math.max(0, files.length - KEEP_REPORTS)))
      await fs.rm(path.join(dir(shop), "reports", f), { force: true });
  } catch {
    /* ignore */
  }
}

export type HistoryPoint = {
  at: string;
  mode: string;
  score: number;
  pages: number;
  findings: number;
};

export async function getHistory(shop: string) {
  return readJson<HistoryPoint[]>(path.join(dir(shop), "history.json"), []);
}

export async function listReports(shop: string) {
  try {
    return (await fs.readdir(path.join(dir(shop), "reports")))
      .filter((f) => f.endsWith(".json"))
      .map((f) => f.replace(/\.json$/, ""))
      .sort()
      .reverse();
  } catch {
    return [];
  }
}

export async function getReport(shop: string, id: string) {
  if (!/^[\w-]+$/.test(id)) return null;
  return readJson<CrawlReport | null>(path.join(dir(shop), "reports", `${id}.json`), null);
}

// ---- PageSpeed -------------------------------------------------------------
export async function getPsiRuns(shop: string) {
  return readJson<PsiRun[]>(path.join(dir(shop), "psi.json"), []);
}

export async function addPsiRuns(shop: string, runs: PsiRun[]) {
  const all = await getPsiRuns(shop);
  // keep opportunities only on the newest run per url+strategy (size)
  all.push(...runs);
  const seen = new Set<string>();
  for (let i = all.length - 1; i >= 0; i--) {
    const k = `${all[i].url}|${all[i].strategy}`;
    if (seen.has(k)) {
      all[i] = { ...all[i], opportunities: [], thirdParties: undefined };
    } else seen.add(k);
  }
  await writeJson(path.join(dir(shop), "psi.json"), all.slice(-KEEP_PSI));
}

// ---- 404 log ---------------------------------------------------------------
export type NotFoundEntry = {
  path: string;
  hits: number;
  first: string;
  last: string;
  referrers: Record<string, number>;
  ignored?: boolean;
};

export async function get404(shop: string) {
  return readJson<Record<string, NotFoundEntry>>(path.join(dir(shop), "404.json"), {});
}

export async function save404(shop: string, log: Record<string, NotFoundEntry>) {
  await writeJson(path.join(dir(shop), "404.json"), log);
}

// small write queue so concurrent beacons don't lose hits
const queues = new Map<string, Promise<void>>();
export function record404(shop: string, p: string, referrer: string) {
  const prev = queues.get(shop) ?? Promise.resolve();
  const next = prev
    .then(async () => {
      const log = await get404(shop);
      const now = new Date().toISOString();
      const e = log[p] ?? { path: p, hits: 0, first: now, last: now, referrers: {} };
      e.hits++;
      e.last = now;
      if (referrer) {
        e.referrers[referrer] = (e.referrers[referrer] ?? 0) + 1;
        const refs = Object.entries(e.referrers).sort((a, b) => b[1] - a[1]);
        e.referrers = Object.fromEntries(refs.slice(0, 10));
      }
      log[p] = e;
      const entries = Object.values(log);
      if (entries.length > MAX_404_PATHS) {
        entries.sort((a, b) => b.last.localeCompare(a.last));
        await save404(shop, Object.fromEntries(entries.slice(0, MAX_404_PATHS).map((x) => [x.path, x])));
      } else await save404(shop, log);
    })
    .catch(() => {});
  queues.set(shop, next);
  return next;
}

// ---- theme scan (cache of the last scan) ------------------------------------
export async function getThemeScan<T>(shop: string) {
  return readJson<T | null>(path.join(dir(shop), "theme-scan.json"), null);
}

export async function saveThemeScan(shop: string, scan: unknown) {
  await writeJson(path.join(dir(shop), "theme-scan.json"), scan);
}
