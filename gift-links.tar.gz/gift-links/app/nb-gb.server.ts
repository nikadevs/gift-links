/**
 * Bundles page on the Bundles v2 engine (Roman 2026-11-18).
 *
 * The Bundles page keeps its look; what "Active" means changed:
 * - the product stays a normal product (no Shopify bundle components), so
 *   Google / Facebook / TikTok accept it;
 * - right after an order is placed the app adds the bundle items to the order
 *   (Order Editing; priced items get a 100% discount, the order stays Paid).
 *
 * Settings live in wc_bundles.config per variant (items; `main` = the product
 * itself, never added to orders). The order engine (gb.server.ts) reads the
 * wc_gb app config, which is derived from those items on Save / Activate.
 */
import type { authenticate } from "./shopify.server";
import { loadGb, saveGb } from "./gb.server";
import type { GbGift, GbProduct } from "./gb.shared";
import {
  deleteBundleProduct,
  disableNativeByProductId,
  loadBundles,
  loadProductVariants,
  loadVariantInfo,
  writeOwn,
  type BundleProduct,
} from "./nb.server";
import { buildItems, gidVariant, itemsToComps, normalizeComps, numId, parseOwn, sortForDisplay, type Comp, type VariantInfo, type VariantState } from "./nb.shared";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];
const now = () => new Date().toISOString();

function label(v: VariantInfo | undefined, id: string) {
  return v ? `${v.productTitle}${v.title && v.title !== "Default Title" ? ` — ${v.title}` : ""}` : id;
}

/** Items added to orders for one variant = items with "Add to Order" ticked. */
export function giftsFrom(comps: Comp[], info: Record<string, VariantInfo | undefined>): GbGift[] {
  return normalizeComps(comps)
    .filter((c) => !c.noOrder)
    .map((c) => {
      const n = Number(numId(c.variantId));
      return { v: n, q: c.qty, src: n, title: label(info[c.variantId], c.variantId) };
    });
}

/** Page data: products from the Bundles settings, state from the order engine. */
export async function loadAll(admin: AdminGraphql) {
  const { products, info } = await loadBundles(admin);
  const { config } = await loadGb(admin);
  for (const p of products) {
    const gp = config.products.find((x) => `gid://shopify/Product/${x.productId}` === p.id);
    for (const v of p.variants) {
      let state: VariantState;
      if (v.native.length || v.requiresComponents) state = v.ownComps.length ? "differs" : "import";
      else if (!v.ownComps.length) state = "none";
      else state = gp?.active && gp.variants[numId(v.id)]?.length ? "active" : "disabled";
      v.state = state;
    }
  }
  return { products, info, gb: config };
}

/** Activate: items start being added to new orders; any old Shopify bundle on the product is removed. */
export async function activateBundle(admin: AdminGraphql, product: BundleProduct) {
  const ids = product.variants.flatMap((v) => v.ownComps.map((c) => c.variantId));
  if (!ids.length) throw new Error("No bundle settings for this product — click Edit and add components.");
  const info = await loadVariantInfo(admin, ids);
  const variants: Record<string, GbGift[]> = {};
  for (const v of product.variants) {
    const g = giftsFrom(v.ownComps, info);
    if (g.length) variants[numId(v.id)] = g;
  }
  if (!Object.keys(variants).length) throw new Error("No item has “Add to Order” ticked — nothing would be added to orders.");
  const { installationId, config } = await loadGb(admin);
  const pid = numId(product.id);
  const prev = config.products.find((x) => x.productId === pid);
  const entry: GbProduct = {
    productId: pid,
    title: product.title,
    handle: product.handle,
    active: true,
    activatedAt: prev?.active && prev.activatedAt ? prev.activatedAt : now(),
    variants,
    ...(prev?.removeParent ? { removeParent: true } : {}),
  };
  config.products = [...config.products.filter((x) => x.productId !== pid), entry];
  await saveGb(admin, installationId, config); // engine first …
  if (product.variants.some((v) => v.native.length || v.requiresComponents)) {
    await disableNativeByProductId(admin, product.id); // … then the old Shopify bundle goes
  }
  return { variants: Object.keys(variants).length };
}

/** Disable: items are no longer added to new orders. Settings stay. */
export async function disableBundle(admin: AdminGraphql, product: BundleProduct) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => `gid://shopify/Product/${x.productId}` === product.id);
  if (p?.active) {
    p.active = false;
    await saveGb(admin, installationId, config);
  }
  if (product.variants.some((v) => v.native.length || v.requiresComponents)) await disableNativeByProductId(admin, product.id);
  return { variants: product.variants.filter((v) => v.ownComps.length).length };
}

/**
 * Save one variant's items. Never creates a Shopify bundle. If the product is
 * in the engine, its items for this variant are updated at once.
 */
export async function saveBundleVariant(admin: AdminGraphql, productId: string, variantId: string, raw: Comp[]) {
  const desired = normalizeComps(raw);
  const product = await loadProductVariants(admin, productId);
  const v = product?.variants.nodes.find((x) => x.id === variantId);
  if (!product || !v) throw new Error("Variant not found");
  const info = desired.length ? await loadVariantInfo(admin, desired.map((c) => c.variantId)) : {};
  const missing = desired.filter((c) => !info[c.variantId]);
  if (missing.length) throw new Error(`Component variant not found: ${missing.map((c) => c.variantId).join(", ")}`);
  const prev = parseOwn(v.own?.value)?.items ?? null;
  await writeOwn(admin, [
    { ownerId: variantId, value: desired.length ? { v: 1, items: buildItems(desired, info, prev), updatedAt: now() } : null },
  ]);
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => `gid://shopify/Product/${x.productId}` === productId);
  if (p) {
    const g = giftsFrom(desired, info);
    if (g.length) p.variants[numId(variantId)] = g;
    else delete p.variants[numId(variantId)];
    await saveGb(admin, installationId, config);
  }
}

export async function deleteBundle(admin: AdminGraphql, productId: string) {
  await deleteBundleProduct(admin, productId);
  const { installationId, config } = await loadGb(admin);
  const n = config.products.length;
  config.products = config.products.filter((x) => `gid://shopify/Product/${x.productId}` !== productId);
  if (config.products.length !== n) await saveGb(admin, installationId, config);
}

/**
 * One-time move of Bundles v2 choices into the Bundles settings:
 * - items added in v2 that are not components yet → added as components;
 * - components v2 did not add (the main item) → marked main.
 * The engine config is not changed. Before writing, the result is checked:
 * the items derived from the new settings must equal what the engine adds now.
 */
export async function migrateFromV2(admin: AdminGraphql) {
  const { installationId, config } = await loadGb(admin);
  if (config.v1migrated) return { done: false, variants: 0, problems: [] as string[] };
  const problems: string[] = [];
  const writes: { ownerId: string; comps: Comp[]; prev: ReturnType<typeof parseOwn> }[] = [];
  for (const gp of config.products) {
    const prod = await loadProductVariants(admin, `gid://shopify/Product/${gp.productId}`);
    if (!prod) continue;
    for (const v of prod.variants.nodes) {
      const own = parseOwn(v.own?.value);
      const comps = itemsToComps(own?.items ?? null);
      const gifts = gp.variants[numId(v.id)] ?? [];
      if (!comps.length && !gifts.length) continue;
      const isGift = (id: string) => gifts.find((g) => String(g.src) === numId(id) || String(g.v) === numId(id));
      const next: Comp[] = comps.map((c) => {
        const g = isGift(c.variantId);
        return g ? { variantId: gidVariant(g.v), qty: g.q } : { variantId: c.variantId, qty: c.qty, noOrder: true };
      });
      for (const g of gifts) if (!next.some((c) => numId(c.variantId) === String(g.v))) next.push({ variantId: gidVariant(g.v), qty: g.q });
      // check: derived items == what the engine adds now
      const a = giftsFrom(next, {}).map((g) => `${g.v}x${g.q}`).sort().join(",");
      const b = gifts.map((g) => `${g.v}x${g.q}`).sort().join(",");
      if (a !== b) {
        problems.push(`${gp.title} / ${v.title}: ${a} ≠ ${b}`);
        continue;
      }
      const same =
        next.length === comps.length &&
        next.every((c, i) => c.variantId === comps[i].variantId && c.qty === comps[i].qty && !!c.noOrder === !!comps[i].noOrder);
      if (!same) writes.push({ ownerId: v.id, comps: next, prev: own });
    }
  }
  if (problems.length) return { done: false, variants: 0, problems };
  if (writes.length) {
    const info = await loadVariantInfo(admin, [...new Set(writes.flatMap((w) => w.comps.map((c) => c.variantId)))]);
    await writeOwn(
      admin,
      writes.map((w) => ({ ownerId: w.ownerId, value: { v: 1 as const, items: buildItems(w.comps, info, w.prev?.items ?? null), updatedAt: now() } })),
    );
  }
  config.v1migrated = true;
  await saveGb(admin, installationId, config);
  return { done: true, variants: writes.length, problems };
}

// ---------------------------------------------------------------------------
// Cart: "Included" block under bundle lines (assets/wc-bundle-items.js).
// app.metafields.wc_gb.cart = { v: { [parentVariantId]: [[shortTitle, imageUrl, qty], …] } }
// for variants of ACTIVE bundles, every component (price high → low, then name).

type CartRow = [string, string, number];
const shortName = (s: string) => s.replace(/^WoodenCrew™\s*\|?\s*/i, "").replace(/\s*\|\s*$/, "").trim();

export async function syncCartMap(admin: AdminGraphql, loaded?: BundleProduct[]) {
  const products = loaded ?? (await loadAll(admin)).products;
  const active = products.flatMap((p) => p.variants.filter((v) => v.state === "active" && v.ownComps.length));
  const ids = [...new Set(active.flatMap((v) => v.ownComps.map((c) => c.variantId)))];
  type N = {
    id: string;
    title: string;
    price: string;
    image: { url: string } | null;
    product: { title: string; short: { value: string } | null; featuredMedia: { preview: { image: { url: string } | null } | null } | null };
  } | null;
  const info = new Map<string, NonNullable<N>>();
  for (let i = 0; i < ids.length; i += 100) {
    const res = await admin.graphql(
      `#graphql
      query WcNbCartInfo($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id title price image { url(transform: { maxWidth: 120 }) }
            product { title short: metafield(namespace: "custom", key: "short_title") { value } featuredMedia { preview { image { url(transform: { maxWidth: 120 }) } } } }
          }
        }
      }`,
      { variables: { ids: ids.slice(i, i + 100) } },
    );
    const j = (await res.json()) as { data?: { nodes: N[] } };
    for (const n of j.data?.nodes ?? []) if (n?.id) info.set(n.id, n);
  }
  const v: Record<string, CartRow[]> = {};
  for (const pv of active) {
    const nameOf = (c: Comp) => {
      const n = info.get(c.variantId);
      return n ? shortName(n.product.short?.value?.trim() || n.product.title) : "";
    };
    const comps = sortForDisplay(pv.ownComps, (c) => Number(info.get(c.variantId)?.price ?? 0), nameOf);
    v[numId(pv.id)] = comps.map((c) => {
      const n = info.get(c.variantId);
      const title = nameOf(c);
      const img = n?.image?.url || n?.product.featuredMedia?.preview?.image?.url || "";
      return [title, img, c.qty] as CartRow;
    }).filter((r) => r[0]);
  }
  const value = JSON.stringify({ v });
  const cur = await admin.graphql(`#graphql
    query WcNbCartMap { currentAppInstallation { id metafield(namespace: "wc_gb", key: "cart") { value } } }`);
  const cj = (await cur.json()) as { data?: { currentAppInstallation: { id: string; metafield: { value: string } | null } } };
  const inst = cj.data?.currentAppInstallation;
  if (!inst || inst.metafield?.value === value) return { changed: false, variants: Object.keys(v).length };
  const w = await admin.graphql(
    `#graphql
    mutation WcNbCartMapSet($m: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $m) { userErrors { message } } }`,
    { variables: { m: [{ ownerId: inst.id, namespace: "wc_gb", key: "cart", type: "json", value }] } },
  );
  const wj = (await w.json()) as { data?: { metafieldsSet: { userErrors: { message: string }[] } } };
  const e = wj.data?.metafieldsSet.userErrors ?? [];
  if (e.length) throw new Error(e.map((x) => x.message).join("; "));
  return { changed: true, variants: Object.keys(v).length };
}

/**
 * Keep the order engine equal to the Bundles settings: for every product in the
 * engine, its variants' items = items with "Add to Order" ticked (wc_bundles).
 * Runs on each Bundles page load; writes only when something differs.
 */
export async function reconcileEngine(admin: AdminGraphql, products: BundleProduct[], info: Record<string, VariantInfo | undefined>) {
  const { installationId, config } = await loadGb(admin);
  const sig = (g: GbGift[] = []) => g.map((x) => `${x.v}x${x.q}`).sort().join(",");
  let changed = 0;
  for (const gp of config.products) {
    const p = products.find((x) => x.id === `gid://shopify/Product/${gp.productId}`);
    if (!p) continue;
    for (const v of p.variants) {
      const key = numId(v.id);
      const want = giftsFrom(v.ownComps, info);
      if (sig(want) === sig(gp.variants[key])) continue;
      if (want.length) gp.variants[key] = want;
      else delete gp.variants[key];
      changed++;
    }
  }
  if (changed) await saveGb(admin, installationId, config);
  return changed;
}

/**
 * Bulk: untick "Add to Order" for one component in every bundle (settings only;
 * reconcileEngine then updates the order engine). Returns variants changed.
 */
export async function untickEverywhere(admin: AdminGraphql, products: BundleProduct[], componentVariantId: string) {
  const writes: { ownerId: string; value: { v: 1; items: ReturnType<typeof buildItems>; updatedAt: string } }[] = [];
  for (const p of products)
    for (const v of p.variants) {
      if (!v.ownComps.some((c) => c.variantId === componentVariantId && !c.noOrder)) continue;
      const prod = await loadProductVariants(admin, p.id);
      const raw = prod?.variants.nodes.find((x) => x.id === v.id);
      const own = parseOwn(raw?.own?.value);
      if (!own?.items) continue;
      const items = own.items.map((i) => (gidVariant(i.variant_id) === componentVariantId ? { ...i, skip_order: true } : i));
      writes.push({ ownerId: v.id, value: { v: 1, items, updatedAt: now() } });
    }
  for (let i = 0; i < writes.length; i += 25) await writeOwn(admin, writes.slice(i, i + 25));
  return writes.length;
}

/**
 * "Remove bundle from order": the bundle's own line is removed from new orders and
 * its paid price is spread over its priced items (order total and Paid unchanged).
 */
export async function setRemoveParent(admin: AdminGraphql, product: BundleProduct, on: boolean) {
  const { installationId, config } = await loadGb(admin);
  const pid = numId(product.id);
  let p = config.products.find((x) => x.productId === pid);
  if (!p) {
    p = { productId: pid, title: product.title, handle: product.handle, active: false, activatedAt: "", variants: {} };
    config.products.push(p);
  }
  if (on) p.removeParent = true;
  else delete p.removeParent;
  await saveGb(admin, installationId, config);
}
