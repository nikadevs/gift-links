/**
 * Gift Links — campaign storage.
 *
 * Campaigns live in ONE app-owned JSON metafield on the AppInstallation
 * (namespace "gift_links", key "config"). The theme app embed reads the same
 * metafield in Liquid via `app.metafields.gift_links.config`, so the storefront
 * never needs to call this server.
 */

export const METAFIELD_NAMESPACE = "gift_links";
export const METAFIELD_KEY = "config";

import type { Campaign } from "./campaigns.shared";
export type { Campaign } from "./campaigns.shared";
export { campaignLink, campaignStatus } from "./campaigns.shared";

export type GiftConfig = { version: 1; campaigns: Campaign[] };

type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

export const emptyConfig = (): GiftConfig => ({ version: 1, campaigns: [] });

export async function loadConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query GiftLinksConfig {
      currentAppInstallation {
        id
        metafield(namespace: "gift_links", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: {
      currentAppInstallation?: {
        id: string;
        metafield?: { value?: string | null } | null;
      };
    };
  };
  const installation = json.data?.currentAppInstallation;
  let config = emptyConfig();
  const raw = installation?.metafield?.value;
  if (raw) {
    try {
      const parsed = JSON.parse(raw);
      if (parsed && Array.isArray(parsed.campaigns)) config = parsed;
    } catch {
      // corrupted value — start fresh rather than crash the admin
    }
  }
  return { installationId: installation?.id ?? "", config };
}

export async function saveConfig(
  admin: AdminGraphql,
  installationId: string,
  config: GiftConfig,
) {
  const res = await admin.graphql(
    `#graphql
    mutation GiftLinksSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) {
        userErrors { field message }
      }
    }`,
    {
      variables: {
        metafields: [
          {
            ownerId: installationId,
            namespace: METAFIELD_NAMESPACE,
            key: METAFIELD_KEY,
            type: "json",
            value: JSON.stringify(config),
          },
        ],
      },
    },
  );
  const json = (await res.json()) as {
    data?: { metafieldsSet?: { userErrors: { message: string }[] } };
  };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}

export type DiscountOption = { code: string; title: string; status: string };

/** Lists the store's discount codes so the merchant can pick one in the form. */
export async function loadDiscountCodes(
  admin: AdminGraphql,
): Promise<DiscountOption[]> {
  const res = await admin.graphql(
    `#graphql
    query GiftLinksDiscounts {
      discountNodes(first: 100, query: "method:code", sortKey: CREATED_AT, reverse: true) {
        nodes {
          discount {
            ... on DiscountCodeBasic { title status codes(first: 5) { nodes { code } } }
            ... on DiscountCodeBxgy { title status codes(first: 5) { nodes { code } } }
            ... on DiscountCodeFreeShipping { title status codes(first: 5) { nodes { code } } }
            ... on DiscountCodeApp { title status codes(first: 5) { nodes { code } } }
          }
        }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: {
      discountNodes?: {
        nodes: {
          discount?: {
            title?: string;
            status?: string;
            codes?: { nodes: { code: string }[] };
          };
        }[];
      };
    };
  };
  const out: DiscountOption[] = [];
  for (const n of json.data?.discountNodes?.nodes ?? []) {
    const d = n.discount;
    for (const c of d?.codes?.nodes ?? []) {
      out.push({
        code: c.code,
        title: d?.title ?? c.code,
        status: d?.status ?? "",
      });
    }
  }
  return out;
}

export async function loadShopDomain(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query GiftLinksShop { shop { primaryDomain { url } } }`,
  );
  const json = (await res.json()) as {
    data?: { shop?: { primaryDomain?: { url?: string } } };
  };
  return (json.data?.shop?.primaryDomain?.url ?? "").replace(/\/$/, "");
}

const slug = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9-]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);

/** Turns submitted form data into a validated campaign. */
export function campaignFromForm(
  form: FormData,
  existing: Campaign[],
  id: string,
): { campaign?: Campaign; errors: Record<string, string> } {
  const get = (k: string) => String(form.get(k) ?? "").trim();
  const on = (k: string) => {
    const v = form.get(k);
    return v !== null && v !== "" && v !== "false" && v !== "off";
  };
  const errors: Record<string, string> = {};

  const name = get("name");
  if (!name) errors.name = "Give the campaign a name";

  const linkKey = slug(get("linkKey") || name);
  if (!linkKey) errors.linkKey = "Use letters, numbers or dashes";
  else if (existing.some((c) => c.linkKey === linkKey && c.id !== id))
    errors.linkKey = "Another campaign already uses this link key";

  const giftVariantId = get("giftVariantId").replace(/\D/g, "");
  if (!giftVariantId) errors.gift = "Pick the gift product";

  const minSubtotal = Number(get("minSubtotal") || "0");
  if (!Number.isFinite(minSubtotal) || minSubtotal < 0)
    errors.minSubtotal = "Enter 0 or a positive amount";

  const dateOk = (d: string) => d === "" || /^\d{4}-\d{2}-\d{2}$/.test(d);
  const startsAt = get("startsAt");
  const endsAt = get("endsAt");
  if (!dateOk(startsAt)) errors.startsAt = "Use YYYY-MM-DD";
  if (!dateOk(endsAt)) errors.endsAt = "Use YYYY-MM-DD";
  if (startsAt && endsAt && endsAt < startsAt)
    errors.endsAt = "End date is before the start date";

  let landingPath = get("landingPath") || "/";
  if (!landingPath.startsWith("/")) landingPath = "/" + landingPath;

  if (Object.keys(errors).length) return { errors };

  return {
    errors,
    campaign: {
      id,
      name,
      active: on("active"),
      linkKey,
      giftVariantId,
      giftTitle: get("giftTitle"),
      giftImage: get("giftImage"),
      discountCode: get("discountCode").toUpperCase(),
      triggerOnCode: on("triggerOnCode"),
      minSubtotal,
      addWhenCartEmpty: on("addWhenCartEmpty"),
      removeWhenIneligible: on("removeWhenIneligible"),
      bannerText: get("bannerText").slice(0, 140),
      landingPath,
      startsAt,
      endsAt,
      updatedAt: new Date().toISOString(),
    },
  };
}
