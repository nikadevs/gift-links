/**
 * Bundles v2 (WoodenCrew Apps module) — "catalog" bundles.
 *
 * Why: the Bundles module makes Shopify fixed bundles (variants with
 * components). Google & YouTube, Facebook and TikTok refuse those
 * ("Channel Google & YouTube does not support variant-fixed bundles"), so
 * bundle products fell out of Merchant Center / Meta / TikTok catalogs.
 * Cart Transform (what Simple Bundles used) needs Shopify Functions, which a
 * custom app can't use on a non-Plus store.
 *
 * How: the product stays a NORMAL product (no components, requiresComponents
 * false) so every sales channel accepts it. Its free extras (gifts, warranty,
 * PDF book…) are added at $0:
 *  B. in the cart — storefront script keeps one line per gift with the hidden
 *     property _wc_gb (quantity = parents × qty in bundle);
 *  C. in the order — a server job checks new orders every minute and adds any
 *     missing gift through Order Editing at $0 (Buy now / Shop Pay / anything
 *     that skipped the script).
 * Gifts must be ACTIVE/UNLISTED, published to the Online Store and $0; other
 * components get a hidden "… — Gift" $0 copy (originals are not touched).
 *
 * Config: app-owned JSON metafield wc_gb.config on the AppInstallation,
 * read by the Gift Links embed (no separate app embed).
 */

export const GB_NS = "wc_gb";
export const GB_KEY = "config";
export const GB_PROP = "_wc_gb";
export const GB_GIFT_TAG = "wc-gb-gift";

/** One gift of a parent variant. v = variant put in cart/order (a $0 copy when needed). */
export type GbGift = {
  v: number; // variant added to cart / order
  q: number; // per 1 parent
  src: number; // original component variant (same as v when no copy was needed)
  title: string; // for the admin and logs
};

export type GbProduct = {
  productId: string; // numeric
  title: string;
  handle: string;
  active: boolean; // gifts are added (cart + orders)
  activatedAt: string; // orders created before this are never edited
  variants: Record<string, GbGift[]>; // parent variant numeric id → gifts
};

export type GbConfig = {
  version: 1;
  products: GbProduct[];
  copies: Record<string, string>; // source product numeric id → $0 copy product numeric id
  /** precomputed for the storefront (Liquid prints it as is): m = parent variant → [[gift, qty]], g = guarded copies */
  sf?: { on: boolean; m: Record<string, [number, number][]>; g: number[] };
  /** settings moved into the Bundles page (wc_bundles items with main flags) */
  v1migrated?: boolean;
  updatedAt: string;
};

export const emptyGb = (): GbConfig => ({ version: 1, products: [], copies: {}, updatedAt: "" });

export function parseGb(value: string | null | undefined): GbConfig {
  if (!value) return emptyGb();
  try {
    const o = JSON.parse(value);
    if (!o || !Array.isArray(o.products)) return emptyGb();
    return {
      version: 1,
      products: o.products.map(normalizeProduct).filter((p: GbProduct | null): p is GbProduct => !!p),
      copies: o.copies && typeof o.copies === "object" ? o.copies : {},
      ...(o.v1migrated ? { v1migrated: true } : {}),
      updatedAt: String(o.updatedAt || ""),
    };
  } catch {
    return emptyGb();
  }
}

function normalizeProduct(p: unknown): GbProduct | null {
  const o = p as Partial<GbProduct> | null;
  if (!o || !/^\d+$/.test(String(o.productId || ""))) return null;
  const variants: Record<string, GbGift[]> = {};
  for (const [k, list] of Object.entries(o.variants || {})) {
    if (!/^\d+$/.test(k) || !Array.isArray(list)) continue;
    const gifts = list
      .map((g) => ({
        v: Number(g?.v),
        q: Math.max(1, Math.floor(Number(g?.q) || 1)),
        src: Number(g?.src || g?.v),
        title: String(g?.title || ""),
      }))
      .filter((g) => Number.isSafeInteger(g.v) && g.v > 0);
    if (gifts.length) variants[k] = gifts;
  }
  return {
    productId: String(o.productId),
    title: String(o.title || ""),
    handle: String(o.handle || ""),
    active: !!o.active,
    activatedAt: String(o.activatedAt || ""),
    variants,
  };
}

/** parent variant id → gifts, for active products only (what the storefront gets). */
export function activeMap(cfg: GbConfig): Record<string, [number, number][]> {
  const m: Record<string, [number, number][]> = {};
  for (const p of cfg.products) {
    if (!p.active) continue;
    for (const [vid, gifts] of Object.entries(p.variants)) m[vid] = gifts.map((g) => [g.v, g.q]);
  }
  return m;
}

/** Variants that exist only as our $0 gift copies (never sold alone). */
export function guardedVariants(cfg: GbConfig): number[] {
  const out = new Set<number>();
  for (const p of cfg.products) for (const gifts of Object.values(p.variants)) for (const g of gifts) if (g.v !== g.src) out.add(g.v);
  return [...out];
}

export type CartLine = { key: string; variant_id: number; quantity: number; properties?: Record<string, unknown> | null };

/**
 * What to change in a cart (same logic as assets/wc-gift-bundles.js):
 * expected gift quantities from parent lines, our gift lines (with _wc_gb),
 * guarded copies sitting in the cart without our property.
 */
export function cartPlan(lines: CartLine[], map: Record<string, [number, number][]>, guarded: number[]) {
  const want = new Map<number, number>();
  for (const l of lines) {
    if (l.properties && l.properties[GB_PROP]) continue;
    for (const [g, q] of map[String(l.variant_id)] || []) want.set(g, (want.get(g) || 0) + l.quantity * q);
  }
  const ours = new Map<number, CartLine[]>();
  for (const l of lines) {
    if (!(l.properties && l.properties[GB_PROP])) continue;
    const list = ours.get(l.variant_id) || [];
    list.push(l);
    ours.set(l.variant_id, list);
  }
  const updates: Record<string, number> = {};
  const adds: { id: number; quantity: number }[] = [];
  for (const g of new Set([...want.keys(), ...ours.keys()])) {
    const w = want.get(g) || 0;
    const list = ours.get(g) || [];
    const have = list.reduce((s, l) => s + l.quantity, 0);
    if (have === w && list.length <= 1) continue;
    if (!list.length) {
      if (w > 0) adds.push({ id: g, quantity: w });
      continue;
    }
    list.forEach((l, i) => {
      const q = i === 0 ? w : 0;
      if (l.quantity !== q) updates[l.key] = q;
    });
  }
  const guard = new Set(guarded);
  for (const l of lines) if (guard.has(l.variant_id) && !(l.properties && l.properties[GB_PROP])) updates[l.key] = 0;
  return { updates, adds };
}

export type OrderLine = { variantId: number | null; quantity: number };

/**
 * Gifts missing from an order: expected from parent lines (current quantity),
 * present = any line of the gift variant or of its original component.
 */
export function orderMissing(lines: OrderLine[], products: GbProduct[]) {
  const gifts = new Map<string, GbGift[]>();
  for (const p of products) for (const [vid, list] of Object.entries(p.variants)) gifts.set(vid, list);
  const want = new Map<number, { q: number; gift: GbGift }>();
  for (const l of lines) {
    if (!l.variantId || l.quantity <= 0) continue;
    for (const g of gifts.get(String(l.variantId)) || []) {
      const cur = want.get(g.v);
      want.set(g.v, { q: (cur?.q || 0) + l.quantity * g.q, gift: g });
    }
  }
  const have = new Map<number, number>();
  for (const l of lines) if (l.variantId && l.quantity > 0) have.set(l.variantId, (have.get(l.variantId) || 0) + l.quantity);
  const missing: { variant: number; quantity: number; title: string }[] = [];
  for (const [v, { q, gift }] of want) {
    const present = (have.get(v) || 0) + (gift.src !== v ? have.get(gift.src) || 0 : 0);
    if (present < q) missing.push({ variant: v, quantity: q - present, title: gift.title });
  }
  return missing;
}

/** Sales channels the module publishes catalog products to. */
export const CATALOG_CHANNELS = [/google/i, /facebook/i, /tiktok/i];
