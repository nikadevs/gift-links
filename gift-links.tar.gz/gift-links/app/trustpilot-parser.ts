export const PROFILE = "https://www.trustpilot.com/review/woodencrew.store";
export type TrustpilotReview = { id: string; author: string; title: string; text: string; date: string; rating: number; url: string };
export type TrustpilotData = { score: number; count: number; label: string; reviews: TrustpilotReview[]; updatedAt: string; profile: string };
type PageReview = { id?: string; rating?: number; consumer?: { displayName?: string }; title?: string; text?: string; dates?: { publishedDate?: string } };

// Read the public page's structured payload, never the AI summary or featured reviews.
export function parseTrustpilot(summaryHtml: string, reviewsHtml: string): TrustpilotData {
  const payload = (html: string) => {
    const script = html.match(/<script\b[^>]*\bid=["']__NEXT_DATA__["'][^>]*>([\s\S]*?)<\/script>/i);
    if (!script) throw new Error("Trustpilot structured payload missing; previous cache retained.");
    return JSON.parse(script[1]).props.pageProps;
  };
  const summary = payload(summaryHtml);
  const page = payload(reviewsHtml);
  const unit = summary.businessUnit;
  const score = Number(unit?.trustScore);
  const count = Number(unit?.numberOfReviews?.total);
  if (!(score >= 1 && score <= 5) || !Number.isInteger(count) || count < 1) throw new Error("Invalid Trustpilot rating.");
  const seen = new Set<string>();
  const reviews: TrustpilotReview[] = (page.reviews || []).filter((r: PageReview) => Number(r.rating) === 5)
    .map((r: PageReview) => ({ id: String(r.id || ""), author: String(r.consumer?.displayName || "Customer"), title: String(r.title || ""), text: String(r.text || ""), date: String(r.dates?.publishedDate || ""), rating: 5, url: `https://www.trustpilot.com/reviews/${r.id}` }))
    .filter((r: TrustpilotReview) => { if (!/^[a-z\d]+$/i.test(r.id) || !r.text.trim() || !Number.isFinite(Date.parse(r.date)) || seen.has(r.id)) return false; seen.add(r.id); return true; })
    .sort((a: TrustpilotReview, b: TrustpilotReview) => Date.parse(b.date) - Date.parse(a.date)).slice(0, 7);
  if (reviews.length !== 7) throw new Error("Trustpilot returned fewer than seven five-star reviews.");
  return { score, count, label: String(unit?.trustScoreLabel || (score >= 4.3 ? "Excellent" : score >= 3.8 ? "Great" : "Average")), reviews, updatedAt: new Date().toISOString(), profile: PROFILE };
}
