/**
 * Tracking (replacement for Track123) — shared types and status logic.
 * Used by the server (poller, admin) and by the admin UI.
 */

export type TrkStatus =
  | "pending" // number known, carrier has no scans yet
  | "info_received" // label / pre-advice only
  | "in_transit" // moving between origin and destination country
  | "last_mile" // arrived in the destination country / handed to the local carrier
  | "out_for_delivery"
  | "attempt_fail" // delivery attempt failed / waiting for pickup
  | "delivered"
  | "exception" // customs hold, lost, damaged, delayed
  | "returned"
  | "expired"; // no updates for too long

export const TRK_STATUS_ORDER: TrkStatus[] = [
  "pending",
  "info_received",
  "in_transit",
  "last_mile",
  "out_for_delivery",
  "attempt_fail",
  "delivered",
  "exception",
  "returned",
  "expired",
];

export const TRK_STATUS_LABEL: Record<TrkStatus, string> = {
  pending: "Pending",
  info_received: "Info received",
  in_transit: "In transit",
  last_mile: "Arrived in country",
  out_for_delivery: "Out for delivery",
  attempt_fail: "Delivery attempt",
  delivered: "Delivered",
  exception: "Exception",
  returned: "Returned",
  expired: "No updates",
};

/** Statuses that stop polling. */
export const TRK_FINAL: TrkStatus[] = ["delivered", "returned", "expired"];

/** Shopify FulfillmentEventStatus for each of our statuses (null = don't post). */
export const TRK_TO_SHOPIFY: Record<TrkStatus, string | null> = {
  pending: null,
  info_received: "CONFIRMED",
  in_transit: "IN_TRANSIT",
  last_mile: "IN_TRANSIT",
  out_for_delivery: "OUT_FOR_DELIVERY",
  attempt_fail: "ATTEMPTED_DELIVERY",
  delivered: "DELIVERED",
  exception: "DELAYED",
  returned: "FAILURE",
  expired: null,
};

/** Omnisend custom event name per status (Roman builds workflows on these). */
export const TRK_OMNISEND_EVENT: Record<TrkStatus, string> = {
  pending: "",
  info_received: "",
  in_transit: "tracking in transit",
  last_mile: "tracking arrived in country",
  out_for_delivery: "tracking out for delivery",
  attempt_fail: "tracking delivery attempt",
  delivered: "tracking delivered",
  exception: "tracking exception",
  returned: "tracking returned",
  expired: "",
};

export type TrkEvent = {
  at: string; // ISO (UTC)
  local?: string; // carrier local time as given
  text: string;
  place: string;
  code: string; // carrier node code
  status: TrkStatus;
};

export type TrkShipment = {
  number: string; // tracking number in Shopify (YT…)
  carrier: string; // company in Shopify
  orderId: string; // gid://shopify/Order/…
  orderName: string; // "#39086"
  email: string;
  firstName: string;
  country: string; // destination ISO-2 from the order
  fulfillmentIds: string[];
  shippedAt: string;
  // carrier data
  status: TrkStatus;
  statusAt: string;
  lastMileNumber: string;
  lastMileCarrier: string;
  lastMileSite: string;
  events: TrkEvent[];
  transitDays: number | null;
  deliveredAt: string;
  // bookkeeping
  source: "yunexpress" | "none";
  lastPolledAt: string;
  lastError: string;
  pollCount: number;
  shopifyStatus: Record<string, string>; // fulfillmentId -> last Shopify status we posted
  urlUpdated: string[]; // fulfillmentIds whose tracking URL now points to our page
  notified: Record<string, string>; // omnisend event -> ISO sent
  paypal: { state: "" | "na" | "ok" | "error"; at: string; error: string };
  createdAt: string;
};

export type TrkSettings = {
  version: 1;
  // carrier API (YunExpress Open API, open.yunexpress.cn)
  yunAppId: string;
  yunAppSecret: string;
  yunSourceKey: string;
  yunSandbox: boolean;
  // polling
  pollEnabled: boolean;
  pollHours: number; // how often one active parcel is refreshed
  importDays: number; // how far back to import fulfilled orders
  maxDays: number; // stop tracking after N days without delivery
  // what the module writes (all OFF by default)
  shopifyEvents: boolean; // fulfillmentEventCreate on every fulfillment with the number
  shopifyUrl: boolean; // point the tracking URL of every fulfillment to our page
  omnisendEnabled: boolean;
  omnisendKey: string;
  omnisendStatuses: TrkStatus[];
  paypalEnabled: boolean;
  paypalClientId: string;
  paypalSecret: string;
  // storefront page
  pageHandle: string;
  hideOriginEvents: boolean; // hide China first-mile scans on the page (like Track123 can)
  updatedAt: string;
};

export const TRK_DEFAULTS: TrkSettings = {
  version: 1,
  yunAppId: "",
  yunAppSecret: "",
  yunSourceKey: "",
  yunSandbox: false,
  pollEnabled: false,
  pollHours: 6,
  importDays: 45,
  maxDays: 75,
  shopifyEvents: false,
  shopifyUrl: false,
  omnisendEnabled: false,
  omnisendKey: "",
  omnisendStatuses: ["in_transit", "last_mile", "out_for_delivery", "attempt_fail", "delivered", "exception"],
  paypalEnabled: false,
  paypalClientId: "",
  paypalSecret: "",
  pageHandle: "track-order",
  hideOriginEvents: false,
  updatedAt: "",
};

const bool = (v: unknown, d: boolean) => (typeof v === "boolean" ? v : d);
const str = (v: unknown, d = "") => (typeof v === "string" ? v.trim() : d);
const num = (v: unknown, d: number, min: number, max: number) => {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(max, Math.max(min, Math.round(n))) : d;
};

export function normalizeTrkSettings(raw: unknown): TrkSettings {
  const r = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const d = TRK_DEFAULTS;
  const statuses = Array.isArray(r.omnisendStatuses)
    ? (r.omnisendStatuses as unknown[]).filter((s): s is TrkStatus =>
        TRK_STATUS_ORDER.includes(s as TrkStatus) && !!TRK_OMNISEND_EVENT[s as TrkStatus],
      )
    : d.omnisendStatuses;
  const handle = str(r.pageHandle, d.pageHandle).toLowerCase().replace(/[^a-z0-9-]/g, "") || d.pageHandle;
  return {
    version: 1,
    yunAppId: str(r.yunAppId),
    yunAppSecret: str(r.yunAppSecret),
    yunSourceKey: str(r.yunSourceKey),
    yunSandbox: bool(r.yunSandbox, d.yunSandbox),
    pollEnabled: bool(r.pollEnabled, d.pollEnabled),
    pollHours: num(r.pollHours, d.pollHours, 2, 48),
    importDays: num(r.importDays, d.importDays, 1, 90),
    maxDays: num(r.maxDays, d.maxDays, 20, 180),
    shopifyEvents: bool(r.shopifyEvents, d.shopifyEvents),
    shopifyUrl: bool(r.shopifyUrl, d.shopifyUrl),
    omnisendEnabled: bool(r.omnisendEnabled, d.omnisendEnabled),
    omnisendKey: str(r.omnisendKey),
    omnisendStatuses: statuses,
    paypalEnabled: bool(r.paypalEnabled, d.paypalEnabled),
    paypalClientId: str(r.paypalClientId),
    paypalSecret: str(r.paypalSecret),
    pageHandle: handle,
    hideOriginEvents: bool(r.hideOriginEvents, d.hideOriginEvents),
    updatedAt: str(r.updatedAt),
  };
}

/** Settings sent to the browser: secrets replaced by "set"/"" flags. */
export type TrkSettingsPublic = Omit<TrkSettings, "yunAppSecret" | "omnisendKey" | "paypalSecret" | "yunSourceKey"> & {
  hasYunSecret: boolean;
  hasYunSourceKey: boolean;
  hasOmnisendKey: boolean;
  hasPaypalSecret: boolean;
};

export function publicSettings(s: TrkSettings): TrkSettingsPublic {
  const { yunAppSecret, omnisendKey, paypalSecret, yunSourceKey, ...rest } = s;
  return {
    ...rest,
    hasYunSecret: !!yunAppSecret,
    hasYunSourceKey: !!yunSourceKey,
    hasOmnisendKey: !!omnisendKey,
    hasPaypalSecret: !!paypalSecret,
  };
}

// ---------------------------------------------------------------------------
// YunExpress node codes → our status (Trajectory Node Table, open.yunexpress.cn,
// checked 2026-10-17). Text keywords cover last-mile scans that YunExpress
// relays with generic codes.

const CODE_MAP: Record<string, TrkStatus> = {
  ORDER_CREATION: "info_received",
  PRE_ADVICING: "info_received",
  PRE_INFO: "info_received",
  PICKED_UP: "in_transit",
  FIRST_MILE_ARRIVE: "in_transit",
  FIRST_MILE_DEPART: "in_transit",
  ARRIVE_CONFIRM_OC: "in_transit",
  DEPART_CONFIRM_OC: "in_transit",
  ARRIVE_ORIN_CUSTOMS: "in_transit",
  EXPORT_CUSTOMS_COMPLETE: "in_transit",
  MAIN_LINE_DEPART: "in_transit",
  MAIN_LINE_ARRIVE: "in_transit",
  TRANSIT_IN: "in_transit",
  TRANSIT_OUT: "in_transit",
  TRANSITHUB_ARRIVE: "in_transit",
  PICKUP_CARGO_TERMINAL: "in_transit",
  AIRPORT_RELEASE: "in_transit",
  CUSTOMS_PROCESSING: "in_transit",
  CUSTOMS_COMPLETE: "in_transit",
  CUSTOMS_RELEASE: "in_transit",
  CHANGE_WAYBILL_INFO: "in_transit",
  EDD: "in_transit",
  IN_TRANSIT: "in_transit",
  CARRIER_PICKUP: "last_mile",
  IN_TRANSIT_CARRIER: "last_mile",
  DELIVERY_ATTEMPT: "attempt_fail",
  DELIVERED: "delivered",
  AIRPORT_HOLD: "exception",
  AIRPORT_INSPECTION: "exception",
  CUSTOMS_DELAY: "exception",
  CUSTOMS_HOLD: "exception",
  CUSTOMS_INSPCTION: "exception",
  DELIVERY_FAILURE: "exception",
  PACKAGE_EXCEPTION: "exception",
  PACKAGE_LOST: "exception",
  OTHER: "in_transit",
  RETURNED: "returned",
  RETURNED_BACK: "returned",
  RETURNED_TO_SENDER: "returned",
};

// handover scans say "delivered to local carrier" — must not count as delivered
const HANDOVER = /delivered to (the )?(local|last[- ]mile|destination)?\s*(carrier|hub|facility|customs|airline|agent|post)|handed over to (the )?(local|last[- ]mile)|local carrier|arrived at destination/i;

const TEXT_RULES: [RegExp, TrkStatus][] = [
  [HANDOVER, "last_mile"],
  [/\bdelivered\b|pakken er udleveret|zugestellt|livr[ée]|entregado|consegnato/i, "delivered"],
  [/out for delivery|with (our )?(courier|driver)|on (its|the) way to you|in consegna|en cours de livraison|zustellung heute/i, "out_for_delivery"],
  [/no answer|attempted|not delivered|redelivery|held for retention|ready for (pick ?up|collection)|available for (pick ?up|collection)|klar til afhentning|awaiting collection/i, "attempt_fail"],
  [/return(ed)? to sender|returning to sender/i, "returned"],
];

export function statusFromCarrier(code: string, text: string): TrkStatus {
  const c = (code || "").toUpperCase().trim();
  const byText = TEXT_RULES.find(([re]) => re.test(text || ""))?.[1];
  // "delivered" text wins even when the code is generic; DELIVERY_ATTEMPT texts like
  // "Delivered - No Signature" are rare but must stay delivered.
  if (byText === "delivered" && c !== "DELIVERY_ATTEMPT") return "delivered";
  if (byText === "last_mile" && c !== "DELIVERED") return "last_mile";
  const byCode = CODE_MAP[c];
  if (byCode && byCode !== "in_transit") return byCode;
  return byText ?? byCode ?? "in_transit";
}

/**
 * Overall status from the event list (newest first). Uses the newest event,
 * except that an attempt/exception followed by later normal scans is history.
 */
export function overallStatus(events: TrkEvent[], hasLastMile: boolean): TrkStatus {
  if (!events.length) return "pending";
  const top = events[0].status;
  if (top === "in_transit" && hasLastMile && events.some((e) => e.status === "last_mile")) {
    // last-mile carrier scans relayed with a generic code
    const iLm = events.findIndex((e) => e.status === "last_mile");
    if (iLm >= 0) return "last_mile";
  }
  if (top === "info_received" && events.length > 1) {
    const moving = events.find((e) => e.status !== "info_received");
    if (moving) return moving.status;
  }
  return top;
}

/** Order of progress for "only go forward" checks and stats. */
export function progressRank(s: TrkStatus): number {
  const r: Partial<Record<TrkStatus, number>> = {
    pending: 0,
    info_received: 1,
    in_transit: 2,
    exception: 2,
    last_mile: 3,
    out_for_delivery: 4,
    attempt_fail: 4,
    delivered: 5,
    returned: 5,
    expired: 5,
  };
  return r[s] ?? 0;
}

/** First-mile events = before the parcel left China (hidden on the page if set). */
export function isOriginEvent(e: TrkEvent): boolean {
  return /china|\bCN\b|shenzhen|guangzhou|yiwu|dongguan/i.test(e.place) && e.status !== "last_mile";
}

export function maskEmail(email: string): string {
  const [u, d] = String(email || "").split("@");
  if (!d) return "";
  return `${u.slice(0, 1)}***@${d}`;
}

export function daysBetween(a: string, b: string): number | null {
  const x = Date.parse(a);
  const y = Date.parse(b);
  if (!Number.isFinite(x) || !Number.isFinite(y)) return null;
  return Math.round(((y - x) / 86400000) * 10) / 10;
}
