/**
 * Session Recordings — which visitors placed an order.
 *
 * The recorder writes the visitor id into a hidden cart attribute `_wc_rec`
 * after an add to cart; Shopify copies cart attributes to the order. Every
 * 15 min we read the orders of the last 3 days (scope read_orders, which the
 * app already has) and keep vid → orders in $WC_DATA_DIR/rec/<shop>/orders.json.
 * Only the order id, name, time and total are stored — no customer data.
 */
import fs from "node:fs/promises";
import path from "node:path";
import prisma from "./db.server";
import { unauthenticated } from "./shopify.server";
import { dataRoot, sessionsInRange } from "./rec.server";
import type { RecSession } from "./rec.shared";
import { REC_RETENTION_DAYS } from "./rec.shared";

/** how: "attr" = cart attribute _wc_rec (exact); "visit" = Shopify's visit (landing page + time) matched one recording */
export type RecOrder = { id: string; name: string; at: number; total: string; cur: string; how?: "attr" | "visit" };
type OrdersFile = { syncedAt: number; byVid: Record<string, RecOrder[]>; v?: number; seen?: Record<string, string> };

const DAY = 24 * 60 * 60 * 1000;
const file = (shop: string) => path.join(dataRoot(), shop.replace(/[^a-z0-9.-]/gi, "_"), "orders.json");
const cache = new Map<string, { at: number; v: OrdersFile }>();

async function read(shop: string): Promise<OrdersFile> {
  const hit = cache.get(shop);
  if (hit && Date.now() - hit.at < 60000) return hit.v;
  let v: OrdersFile = { syncedAt: 0, byVid: {} };
  try {
    v = JSON.parse(await fs.readFile(file(shop), "utf8")) as OrdersFile;
  } catch {
    /* none yet */
  }
  cache.set(shop, { at: Date.now(), v });
  return v;
}

/** vid → orders (for the list and the visitor page) */
export async function recOrders(shop: string) {
  return (await read(shop)).byVid;
}

type Visit = { landingPage?: string | null; occurredAt?: string | null } | null;
type Journey = { firstVisit?: Visit; lastVisit?: Visit };

type OrdersPage = {
  data?: {
    orders?: {
      nodes: {
        id: string;
        name: string;
        createdAt: string;
        customAttributes: { key: string; value: string | null }[];
        customerJourneySummary?: Journey | null;
        currentTotalPriceSet?: { shopMoney?: { amount: string; currencyCode: string } };
      }[];
      pageInfo: { hasNextPage: boolean; endCursor: string | null };
    };
  };
};

function pathKey(u: string) {
  try {
    return new URL(u, "https://x.invalid").pathname.replace(/\/+$/, "") || "/";
  } catch {
    return u.split("?")[0];
  }
}

/**
 * Orders made before the _wc_rec attribute (or without it): Shopify knows the
 * visit that led to the order (landing page + time). If exactly one recording
 * started on that page within ±3 min of that time (an add-to-cart recording
 * wins over others), it is the same visitor. Ambiguous → no match.
 */
function matchByVisit(
  j: Journey | null | undefined,
  orderAt: number,
  byPath: Map<string, RecSession[]>,
) {
  for (const v of [j?.lastVisit, j?.firstVisit]) {
    if (!v?.landingPage || !v.occurredAt) continue;
    const at = Date.parse(v.occurredAt);
    const cands = (byPath.get(pathKey(v.landingPage)) ?? []).filter(
      (m) => Math.abs((m.pages[0]?.t ?? m.start) - at) <= 3 * 60 * 1000 && m.start <= orderAt + 60 * 1000,
    );
    const withCart = cands.filter((m) => m.atc);
    const pick = withCart.length ? withCart : cands;
    const vids = [...new Set(pick.map((m) => m.vid))];
    if (vids.length === 1) return vids[0];
  }
  return "";
}

export async function syncRecOrders(shop: string) {
  const { admin } = await unauthenticated.admin(shop);
  const cur = await read(shop);
  // first run of this version: look back over the whole retention once
  const backfill = cur.v !== 2;
  const since = new Date(Date.now() - (backfill ? REC_RETENTION_DAYS : 3) * DAY).toISOString();
  cur.seen ??= {};
  // recordings by landing path, for orders made before the cart attribute existed
  const sessions = await sessionsInRange(shop, REC_RETENTION_DAYS);
  const byPath = new Map<string, RecSession[]>();
  for (const m of sessions) {
    const p0 = m.pages[0];
    if (!p0) continue;
    const k = pathKey(p0.url);
    const arr = byPath.get(k);
    if (arr) arr.push(m);
    else byPath.set(k, [m]);
  }
  let after: string | null = null;
  for (let page = 0; page < 30; page++) {
    const res = await admin.graphql(
      `#graphql
      query WcRecOrders($q: String!, $after: String) {
        orders(first: 100, after: $after, query: $q, sortKey: CREATED_AT, reverse: true) {
          nodes {
            id
            name
            createdAt
            customAttributes { key value }
            customerJourneySummary {
              firstVisit { landingPage occurredAt }
              lastVisit { landingPage occurredAt }
            }
            currentTotalPriceSet { shopMoney { amount currencyCode } }
          }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { variables: { q: `created_at:>='${since}'`, after } },
    );
    const json = (await res.json()) as OrdersPage;
    const o = json.data?.orders;
    if (!o) break;
    for (const n of o.nodes) {
      const id = n.id.split("/").pop() ?? n.id;
      if (cur.seen[id]) continue;
      let vid = n.customAttributes.find((a) => a.key === "_wc_rec")?.value ?? "";
      let how: RecOrder["how"] = "attr";
      if (!/^[a-z0-9]{8,40}$/.test(vid)) {
        vid = matchByVisit(n.customerJourneySummary, Date.parse(n.createdAt), byPath);
        how = "visit";
      }
      if (!vid) continue;
      cur.seen[id] = vid;
      const list = (cur.byVid[vid] ??= []);
      if (list.some((x) => x.id === id)) continue;
      list.push({
        id,
        name: n.name,
        at: Date.parse(n.createdAt),
        total: n.currentTotalPriceSet?.shopMoney?.amount ?? "",
        cur: n.currentTotalPriceSet?.shopMoney?.currencyCode ?? "",
        how,
      });
    }
    if (!o.pageInfo.hasNextPage) break;
    after = o.pageInfo.endCursor;
  }
  // forget orders older than the recordings themselves
  const keepFrom = Date.now() - (REC_RETENTION_DAYS + 1) * DAY;
  for (const [vid, list] of Object.entries(cur.byVid)) {
    const kept = list.filter((x) => x.at >= keepFrom);
    if (kept.length) cur.byVid[vid] = kept;
    else delete cur.byVid[vid];
  }
  for (const [id, vid] of Object.entries(cur.seen)) if (!cur.byVid[vid]) delete cur.seen[id];
  cur.v = 2;
  cur.syncedAt = Date.now();
  await fs.mkdir(path.dirname(file(shop)), { recursive: true });
  await fs.writeFile(file(shop), JSON.stringify(cur));
  cache.set(shop, { at: Date.now(), v: cur });
}

declare global {
  // eslint-disable-next-line no-var
  var wcRecOrders: NodeJS.Timeout | undefined;
}

async function tick() {
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    for (const shop of new Set<string>(rows.map((r: { shop: string }) => r.shop))) {
      try {
        await fs.access(path.dirname(file(shop)));
      } catch {
        continue; // recordings never used in this shop
      }
      await syncRecOrders(shop).catch(() => {});
    }
  } catch {
    /* next tick */
  }
}

export function startRecOrderSync() {
  if (globalThis.wcRecOrders) return;
  globalThis.wcRecOrders = setInterval(() => void tick(), 15 * 60 * 1000);
  setTimeout(() => void tick(), 20000);
}
