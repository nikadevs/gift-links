/**
 * Session Recordings — which visitors placed an order.
 *
 * The recorder writes the visitor id into a hidden cart attribute `_wc_rec`
 * after an add to cart; Shopify copies cart attributes to the order. Every
 * 15 min we read the orders of the last 3 days (scope read_orders, which the
 * app already has) and keep vid → orders in $WC_DATA_DIR/rec/<shop>/orders.json.
 * Only the order id, name, time and total are stored — no customer data.
 */
import fs from "node:fs/promises";
import path from "node:path";
import prisma from "./db.server";
import { unauthenticated } from "./shopify.server";
import { dataRoot } from "./rec.server";
import { REC_RETENTION_DAYS } from "./rec.shared";

export type RecOrder = { id: string; name: string; at: number; total: string; cur: string };
type OrdersFile = { syncedAt: number; byVid: Record<string, RecOrder[]> };

const DAY = 24 * 60 * 60 * 1000;
const file = (shop: string) => path.join(dataRoot(), shop.replace(/[^a-z0-9.-]/gi, "_"), "orders.json");
const cache = new Map<string, { at: number; v: OrdersFile }>();

async function read(shop: string): Promise<OrdersFile> {
  const hit = cache.get(shop);
  if (hit && Date.now() - hit.at < 60000) return hit.v;
  let v: OrdersFile = { syncedAt: 0, byVid: {} };
  try {
    v = JSON.parse(await fs.readFile(file(shop), "utf8")) as OrdersFile;
  } catch {
    /* none yet */
  }
  cache.set(shop, { at: Date.now(), v });
  return v;
}

/** vid → orders (for the list and the visitor page) */
export async function recOrders(shop: string) {
  return (await read(shop)).byVid;
}

type OrdersPage = {
  data?: {
    orders?: {
      nodes: {
        id: string;
        name: string;
        createdAt: string;
        customAttributes: { key: string; value: string | null }[];
        currentTotalPriceSet?: { shopMoney?: { amount: string; currencyCode: string } };
      }[];
      pageInfo: { hasNextPage: boolean; endCursor: string | null };
    };
  };
};

export async function syncRecOrders(shop: string) {
  const { admin } = await unauthenticated.admin(shop);
  const cur = await read(shop);
  const since = new Date(Date.now() - 3 * DAY).toISOString();
  let after: string | null = null;
  for (let page = 0; page < 30; page++) {
    const res = await admin.graphql(
      `#graphql
      query WcRecOrders($q: String!, $after: String) {
        orders(first: 100, after: $after, query: $q, sortKey: CREATED_AT, reverse: true) {
          nodes {
            id
            name
            createdAt
            customAttributes { key value }
            currentTotalPriceSet { shopMoney { amount currencyCode } }
          }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { variables: { q: `created_at:>='${since}'`, after } },
    );
    const json = (await res.json()) as OrdersPage;
    const o = json.data?.orders;
    if (!o) break;
    for (const n of o.nodes) {
      const vid = n.customAttributes.find((a) => a.key === "_wc_rec")?.value ?? "";
      if (!/^[a-z0-9]{8,40}$/.test(vid)) continue;
      const list = (cur.byVid[vid] ??= []);
      if (list.some((x) => x.id === n.id)) continue;
      list.push({
        id: n.id.split("/").pop() ?? n.id,
        name: n.name,
        at: Date.parse(n.createdAt),
        total: n.currentTotalPriceSet?.shopMoney?.amount ?? "",
        cur: n.currentTotalPriceSet?.shopMoney?.currencyCode ?? "",
      });
    }
    if (!o.pageInfo.hasNextPage) break;
    after = o.pageInfo.endCursor;
  }
  // forget orders older than the recordings themselves
  const keepFrom = Date.now() - (REC_RETENTION_DAYS + 1) * DAY;
  for (const [vid, list] of Object.entries(cur.byVid)) {
    const kept = list.filter((x) => x.at >= keepFrom);
    if (kept.length) cur.byVid[vid] = kept;
    else delete cur.byVid[vid];
  }
  cur.syncedAt = Date.now();
  await fs.mkdir(path.dirname(file(shop)), { recursive: true });
  await fs.writeFile(file(shop), JSON.stringify(cur));
  cache.set(shop, { at: Date.now(), v: cur });
}

declare global {
  // eslint-disable-next-line no-var
  var wcRecOrders: NodeJS.Timeout | undefined;
}

async function tick() {
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    for (const shop of new Set<string>(rows.map((r: { shop: string }) => r.shop))) {
      try {
        await fs.access(path.dirname(file(shop)));
      } catch {
        continue; // recordings never used in this shop
      }
      await syncRecOrders(shop).catch(() => {});
    }
  } catch {
    /* next tick */
  }
}

export function startRecOrderSync() {
  if (globalThis.wcRecOrders) return;
  globalThis.wcRecOrders = setInterval(() => void tick(), 15 * 60 * 1000);
  setTimeout(() => void tick(), 20000);
}
