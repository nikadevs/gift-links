import { parse, HTMLElement } from "node-html-parser";
import { createHash } from "node:crypto";
import { emptyFeatures, readFeatures, type FeaturesConfig, type FeaturePhoto } from "./features.shared";
type Admin = { graphql: (query: string, options?: { variables?: Record<string, unknown> }) => Promise<Response> };
const NS = "custom", KEY = "wc_features_image_slider";
async function query<T>(admin: Admin, q: string, variables: Record<string, unknown> = {}): Promise<T> {
  const r = await admin.graphql(q, { variables }); const j = await r.json();
  if (!r.ok || j.errors?.length) throw new Error(j.errors?.map((e: {message: string}) => e.message).join("; ") || "Shopify request failed.");
  return j.data;
}
const escape = (v: string) => v.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
const tags = new Set(["svg", "g", "path", "circle", "ellipse", "rect", "line", "polyline", "polygon", "defs", "linearGradient", "radialGradient", "stop", "clipPath", "mask"]);
const attributes = new Set(["viewBox", "fill", "stroke", "stroke-width", "stroke-linecap", "stroke-linejoin", "stroke-miterlimit", "fill-rule", "clip-rule", "opacity", "fill-opacity", "stroke-opacity", "d", "cx", "cy", "r", "rx", "ry", "x", "y", "x1", "y1", "x2", "y2", "width", "height", "points", "transform", "preserveAspectRatio", "id", "offset", "stop-color", "stop-opacity", "gradientUnits", "gradientTransform", "spreadMethod", "fx", "fy", "clip-path", "mask", "maskUnits", "maskContentUnits", "clipPathUnits"]);
export function sanitizeIcon(source: string): string {
  const storedPrefix = source.match(/wc-icon-[a-f0-9]{10}-/)?.[0];
  source = source.replace(/wc-icon-[a-f0-9]{10}-/g, "");
  if (!source.trim()) return "";
  if (Buffer.byteLength(source) > 16000) throw new Error("SVG icon must be smaller than 16 KB. Use a simple path-based icon.");
  const document = parse(source.replace(/<\?xml[\s\S]*?\?>/g, "").replace(/<!--[\s\S]*?-->/g, ""), { lowerCaseTagName: false });
  const roots = document.childNodes.filter(n => n instanceof HTMLElement);
  if (roots.length !== 1 || (roots[0] as HTMLElement).rawTagName !== "svg") throw new Error("Upload a valid SVG icon.");
  let nodes = 0;
  const prefix = storedPrefix || 'wc-icon-' + createHash('sha256').update(source).digest('hex').slice(0, 10) + '-';
  const ids = new Map(document.querySelectorAll('[id]').map(n => [n.getAttribute('id')!, prefix + n.getAttribute('id')!]));
  function clean(node: HTMLElement): string {
    if (["title", "desc"].includes(node.rawTagName)) return "";
    if (++nodes > 200 || !tags.has(node.rawTagName)) throw new Error("Use a simple SVG with paths and shapes; scripts, styles, images and external references are not supported.");
    const attrs: string[] = [];
    for (const [raw, original] of Object.entries(node.attributes)) {
      let val = original;
      const name = raw.toLowerCase() === "viewbox" ? "viewBox" : raw;
      if (["xmlns", "aria-hidden", "focusable"].includes(name)) continue;
      if (!attributes.has(name) || /javascript|data:|https?:|[<>]/i.test(val)) throw new Error(`Unsupported SVG attribute: ${raw}. Export the icon as simple paths.`);
      if (name === "id") {if (!/^[a-zA-Z_][\w.-]*$/.test(val)) throw new Error("Invalid SVG ID.");val=ids.get(val)!;}
      if (/url\s*\(/i.test(val)) {const match=val.match(/^url\(#([\w.-]+)\)$/);if(!match || !ids.has(match[1])) throw new Error("Only local SVG references are supported.");val=`url(#${ids.get(match[1])})`;}
      if (node.rawTagName === "svg" && (name === "width" || name === "height")) continue;
      attrs.push(`${name}="${escape(val)}"`);
    }
    if (node.rawTagName === "svg") {
      if (!node.getAttribute("viewBox") && !node.getAttribute("viewbox")) {
        const w = Number(node.getAttribute("width")), h = Number(node.getAttribute("height"));
        if (!(w > 0 && h > 0)) throw new Error("SVG needs a viewBox or numeric width and height.");
        attrs.push(`viewBox="0 0 ${w} ${h}"`);
      }
      attrs.push('xmlns="http://www.w3.org/2000/svg" aria-hidden="true" focusable="false"');
    }
    return `<${node.rawTagName} ${attrs.join(" ")}>${node.childNodes.filter(n => n instanceof HTMLElement).map(n => clean(n as HTMLElement)).join("")}</${node.rawTagName}>`;
  }
  return clean(roots[0] as HTMLElement);
}
function text(v: unknown, max: number, label: string) { if (typeof v !== "string" || v.length > max) throw new Error(`${label}: maximum ${max} characters.`); return v.trim(); }
export function normalizeFeatures(input: unknown): FeaturesConfig {
  if (!input || typeof input !== "object") throw new Error("Invalid slider settings.");
  const v = input as FeaturesConfig, result = emptyFeatures();
  result.enabled = v.enabled === true; result.heading = text(v.heading, 200, "Heading");
  if (!Number.isInteger(v.interval) || v.interval < 2 || v.interval > 20) throw new Error("Slide interval must be between 2 and 20 seconds.");
  result.interval = v.interval;
  for (const key of ["accent", "background", "textColor", "mutedColor"] as const) { if (!/^#[0-9a-f]{6}$/i.test(v[key])) throw new Error("Choose valid colors."); result[key] = v[key]; }
  for (const key of ["paddingTop", "paddingBottom"] as const) { if (!Number.isInteger(v[key]) || v[key] < 0 || v[key] > 120) throw new Error("Spacing must be between 0 and 120 px."); result[key] = v[key]; }
  if (!Array.isArray(v.features) || v.features.length > 10) throw new Error("Add up to 10 features.");
  result.features = v.features.map((f, i) => {
    const item = { id: `f${i}`, title: text(f.title, 100, "Feature title"), description: text(f.description, 500, "Description"), iconSvg: sanitizeIcon(text(f.iconSvg, 16000, "SVG")), photo: null as FeaturePhoto | null };
    const svg = parse(item.iconSvg).querySelector("svg"), tile = svg?.childNodes.find(n=>n instanceof HTMLElement && n.rawTagName==='rect') as HTMLElement | undefined;
    const box = (svg?.getAttribute('viewBox') || svg?.getAttribute('viewbox') || '').split(/[ ,]+/).map(Number);
    const iconTile = !!tile && Number(tile.getAttribute('width'))>=box[2]*.85 && Number(tile.getAttribute('height'))>=box[3]*.85;
    if (f.photo) { const u = new URL(f.photo.url); if (u.protocol !== "https:" || u.hostname !== "cdn.shopify.com") throw new Error("Choose a photo from Shopify Files or upload one here.");
      item.photo = { url: u.href, width: Math.max(1, Math.min(20000, Number(f.photo.width) || 600)), height: Math.max(1, Math.min(20000, Number(f.photo.height) || 1000)), alt: text(f.photo.alt || "", 200, "Photo alt text") }; }
    if (result.enabled && (!item.title || !item.description || !item.iconSvg || !item.photo)) throw new Error(`Feature ${i + 1}: add an SVG icon, title, description and photo before enabling.`);
    return {...item,iconTile};
  });
  if (result.enabled && !result.features.length) throw new Error("Add at least one complete feature before enabling.");
  result.updatedAt = new Date().toISOString();
  if (Buffer.byteLength(JSON.stringify(result)) > 60000) throw new Error("Slider data exceeds 60 KB. Simplify your SVG icons.");
  return result;
}
export async function loadFeaturesProduct(admin: Admin, id: string) {
  if (!/^gid:\/\/shopify\/Product\/\d+$/.test(id)) throw new Error("Choose a product first.");
  const data = await query<{product: {id: string; title: string; handle: string; config: {value: string; compareDigest: string} | null; images: {nodes: (FeaturePhoto & {id: string})[]}} | null}>(admin, `query FeaturesProduct($id: ID!) { product(id: $id) { id title handle config: metafield(namespace: "${NS}", key: "${KEY}") { value compareDigest } images(first: 100) { nodes { id url width height alt: altText } } } }`, { id });
  if (!data.product) throw new Error("Product was not found.");
  return { product: data.product, config: readFeatures(data.product.config?.value) };
}
export async function listFeaturesProducts(admin: Admin) {
  const rows: {id: string; title: string; enabled: boolean; count: number}[] = []; let after: string | null = null;
  do { const d: {products: {nodes: {id: string; title: string; config: {value: string} | null}[]; pageInfo: {hasNextPage: boolean; endCursor: string}}} = await query(admin, `query FeaturesOverview($after: String) { products(first: 100, after: $after) { nodes { id title config: metafield(namespace: "${NS}", key: "${KEY}") { value } } pageInfo { hasNextPage endCursor } } }`, { after });
    for (const p of d.products.nodes) { const c = readFeatures(p.config?.value); if (c) rows.push({id: p.id, title: p.title, enabled: c.enabled, count: c.features.length}); }
    after = d.products.pageInfo.hasNextPage ? d.products.pageInfo.endCursor : null;
  } while (after);
  return rows.sort((a,b) => a.title.localeCompare(b.title));
}
export async function saveFeatures(admin: Admin, id: string, input: unknown, digest: string | null) {
  const config = normalizeFeatures(input);
  // Merchant-owned data lets the shared theme and other store integrations read it.
  const defs = await query<{metafieldDefinitions: {nodes: {id: string; type: {name: string}}[]}}>(admin, `query { metafieldDefinitions(first: 1, ownerType: PRODUCT, namespace: "${NS}", key: "${KEY}") { nodes { id type { name } } } }`);
  if (!defs.metafieldDefinitions.nodes.length) {
    const d = await query<{metafieldDefinitionCreate: {userErrors: {message: string}[]}}>(admin, `mutation FeaturesDefinition($definition: MetafieldDefinitionInput!) { metafieldDefinitionCreate(definition: $definition) { userErrors { message } } }`, { definition: {name: "Features with Image Slider", namespace: NS, key: KEY, type: "json", ownerType: "PRODUCT", description: "Managed in WoodenCrew Apps → Features with Image Slider. Product-specific slider configuration.", access: {storefront: "PUBLIC_READ"}} });
    if (d.metafieldDefinitionCreate.userErrors.length) throw new Error(d.metafieldDefinitionCreate.userErrors.map(e=>e.message).join("; "));
  } else if (defs.metafieldDefinitions.nodes[0].type.name !== "json") throw new Error("Slider metafield must use JSON type.");
  const d = await query<{metafieldsSet: {userErrors: {message: string}[]}}>(admin, `mutation FeaturesSave($metafields: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $metafields) { userErrors { message } } }`, {metafields: [{ownerId: id, namespace: NS, key: KEY, type: "json", value: JSON.stringify(config), compareDigest: digest}]});
  if (d.metafieldsSet.userErrors.length) throw new Error(d.metafieldsSet.userErrors.map(e=>e.message).join("; "));
  return config;
}
export async function sliderFiles(admin: Admin, after: string | null = null) {
  return query<{files: {nodes: {id: string; image?: FeaturePhoto & {altText?: string}}[]; pageInfo: {hasNextPage: boolean; endCursor: string}}}>(admin, `query FeaturesFiles($after: String) { files(first: 40, after: $after, query: "media_type:IMAGE", sortKey: CREATED_AT, reverse: true) { nodes { ... on MediaImage { id image { url width height alt: altText } } } pageInfo { hasNextPage endCursor } } }`, {after});
}
export async function uploadSliderPhoto(admin: Admin, file: File) {
  if (!file.size || file.size > 10 * 1024 * 1024 || !["image/jpeg", "image/png", "image/webp"].includes(file.type)) throw new Error("Upload a JPG, PNG or WebP photo up to 10 MB.");
  const staged = await query<{stagedUploadsCreate: {stagedTargets: {url: string; resourceUrl: string; parameters: {name: string; value: string}[]}[]; userErrors: {message: string}[]}}>(admin, `mutation FeaturesUpload($input: [StagedUploadInput!]!) { stagedUploadsCreate(input: $input) { stagedTargets { url resourceUrl parameters { name value } } userErrors { message } } }`, {input: [{resource: "IMAGE", filename: file.name.replace(/[^a-zA-Z0-9_.-]/g,"_"), mimeType: file.type, httpMethod: "POST"}]});
  if (staged.stagedUploadsCreate.userErrors.length) throw new Error(staged.stagedUploadsCreate.userErrors.map(e=>e.message).join("; "));
  const target = staged.stagedUploadsCreate.stagedTargets[0], form = new FormData();
  for (const p of target.parameters) form.append(p.name,p.value); form.append("file",file);
  if (!(await fetch(target.url,{method:"POST",body:form})).ok) throw new Error("Photo upload failed. Try again.");
  const created = await query<{fileCreate: {files: {id: string}[]; userErrors: {message: string}[]}}>(admin, `mutation FeaturesFile($files: [FileCreateInput!]!) { fileCreate(files: $files) { files { id } userErrors { message } } }`, {files: [{originalSource: target.resourceUrl, contentType: "IMAGE", alt: file.name.replace(/\.[^.]+$/,"")}]});
  if (created.fileCreate.userErrors.length) throw new Error(created.fileCreate.userErrors.map(e=>e.message).join("; "));
  return photoStatus(admin, created.fileCreate.files[0].id);
}
export async function photoStatus(admin: Admin, id: string) {
  if (!/^gid:\/\/shopify\/MediaImage\/\d+$/.test(id)) throw new Error("Invalid uploaded photo.");
  const d = await query<{node: {fileStatus: string; image: FeaturePhoto | null}}>(admin, `query FeaturesPhoto($id: ID!) { node(id:$id) { ... on MediaImage { fileStatus image { url width height alt: altText } } } }`, {id});
  if (!d.node || d.node.fileStatus === "FAILED") throw new Error("Shopify could not process this photo.");
  return {id, photo: d.node.image};
}
