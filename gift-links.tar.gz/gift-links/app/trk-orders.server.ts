import { authenticate } from "./shopify.server";
import { loadShopDomain } from "./campaigns.server";
import { getTrkSettings, loadShipments } from "./trk-store.server";
import { TRK_FINAL, TRK_ORDER_PAGE as PAGE, TRK_ORDER_TABS as TABS, maskEmail, type TrkShipment } from "./trk.shared";

/** Tracking → Orders data (page + CSV export). */
const DAY = 86400000;

function match(r: TrkShipment, status: string, now: number) {
  if (!status) return true;
  if (status === "errors") return !!r.lastError;
  if (status === "stuck") return !TRK_FINAL.includes(r.status) && now - Date.parse(r.events[0]?.at || r.shippedAt) > 14 * DAY;
  return r.status === status;
}

export async function loadOrders(request: Request, exportAll = false) {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const url = new URL(request.url);
  const p = (k: string) => url.searchParams.get(k) || "";
  const days = Number(p("days")) || 30;
  const now = Date.now();
  const [s, domain] = await Promise.all([getTrkSettings(shop), loadShopDomain(admin)]);
  const all = [...(await loadShipments(shop)).values()]
    .filter((r) => days >= 9999 || now - Date.parse(r.shippedAt) <= days * DAY)
    .sort((a, b) => (a.shippedAt < b.shippedAt ? 1 : -1));
  const q = p("q").trim().toUpperCase().replace("#", "");
  const base = all.filter(
    (r) =>
      (!p("carrier") || r.carrier === p("carrier")) &&
      (!p("lastmile") || r.lastMileCarrier === p("lastmile")) &&
      (!p("country") || r.country === p("country")) &&
      (!q ||
        r.number.toUpperCase().includes(q) ||
        r.lastMileNumber.toUpperCase().includes(q) ||
        r.orderName.toUpperCase().replace("#", "").includes(q) ||
        r.email.toUpperCase() === q),
  );
  const counts = Object.fromEntries(TABS.map(([k]) => [k, base.filter((r) => match(r, k, now)).length]));
  const filtered = base.filter((r) => match(r, p("status"), now));
  const pg = Math.max(1, Number(p("page")) || 1);
  const view = (r: TrkShipment) => ({
    number: r.number,
    order: r.orderName.replace("#", ""),
    orderId: r.orderId.split("/").pop() ?? "",
    email: maskEmail(r.email),
    country: r.country,
    carrier: r.carrier,
    lastMileCarrier: r.lastMileCarrier,
    lastMileNumber: r.lastMileNumber,
    status: r.status,
    lastEvent: r.events[0]?.text ?? "",
    lastEventAt: r.events[0]?.at ?? "",
    orderDate: r.orderCreatedAt ?? "",
    shippedAt: r.shippedAt,
    deliveredAt: r.deliveredAt,
    transitDays: r.transitDays ?? (r.events.length ? Math.round(((now - Date.parse(r.shippedAt)) / DAY) * 10) / 10 : null),
    paypal: r.paypal.state,
    emails: Object.values(r.notified).filter((v) => !v.startsWith("skipped")).length,
    error: r.lastError,
  });
  const uniq = (a: string[]) => [...new Set(a.filter(Boolean))].sort();
  return {
    rows: (exportAll ? filtered : filtered.slice((pg - 1) * PAGE, pg * PAGE)).map(view),
    exportAll,
    counts,
    total: filtered.length,
    pg,
    pageUrl: domain ? `${domain}/pages/${s.pageHandle}` : "",
    carriers: uniq(all.map((r) => r.carrier)),
    lastMiles: uniq(all.map((r) => r.lastMileCarrier)),
    countries: uniq(all.map((r) => r.country)),
  };
}
