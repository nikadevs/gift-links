/**
 * Sale Banner (WoodenCrew Apps module): promo strip on product pages —
 * black badge ("HALLOWEEN SALE"), centered heading ("BUY 1 GET 1 FREE"),
 * white pill with a text ("Limited Time") or a personal HH:MM:SS countdown:
 * every visitor gets a random timer (default 20–40 min, kept in their browser);
 * when it reaches zero the whole banner is hidden for that visitor.
 *
 * Stored as one app-owned JSON metafield on the AppInstallation (wc_sb.config),
 * read by the theme app block blocks/sale-banner.liquid. No separate app embed:
 * the block prints nothing while `enabled` is false.
 */
export type SbOverride = { id: string; heading: string }; // id = numeric product id

export type SbConfig = {
  version: 1;
  enabled: boolean;
  badge: string; // black badge text; empty = badge hidden
  heading: string; // default heading for every product
  overrides: SbOverride[]; // custom heading per product
  pillText: string; // white pill text (Text mode)
  countdown: boolean; // true = pill shows the visitor's own HH:MM:SS timer
  timerMin: number; // minutes, random timer per visitor from timerMin…
  timerMax: number; // …to timerMax
  timerKey: string; // new value = every visitor gets a new timer
  updatedAt: string;
};

export const SB_DEFAULTS: SbConfig = {
  version: 1,
  enabled: false,
  badge: "HALLOWEEN SALE",
  heading: "BUY 1 GET 1 FREE",
  overrides: [],
  pillText: "Limited Time",
  countdown: false,
  timerMin: 20,
  timerMax: 40,
  timerKey: "1",
  updatedAt: "",
};

export const SB_MAX_OVERRIDES = 250;

const text = (v: unknown, max: number) => (typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "");

export function normalizeSb(raw: unknown): SbConfig {
  const p = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const has = (k: string) => typeof p[k] === "string";
  const seen = new Set<string>();
  const overrides: SbOverride[] = [];
  for (const o of Array.isArray(p.overrides) ? p.overrides : []) {
    const r = (o && typeof o === "object" ? o : {}) as Record<string, unknown>;
    const id = String(r.id ?? "").replace(/^gid:\/\/shopify\/Product\//, "");
    const heading = text(r.heading, 80);
    if (!/^\d+$/.test(id) || !heading || seen.has(id)) continue;
    seen.add(id);
    overrides.push({ id, heading });
    if (overrides.length >= SB_MAX_OVERRIDES) break;
  }
  const mins = (v: unknown, d: number) => {
    const n = Math.round(Number(v));
    return Number.isFinite(n) && n >= 1 ? Math.min(n, 1440) : d;
  };
  const timerMin = mins(p.timerMin, SB_DEFAULTS.timerMin);
  const timerMax = Math.max(timerMin, mins(p.timerMax, SB_DEFAULTS.timerMax));
  const timerKey = typeof p.timerKey === "string" && /^[\w-]{1,24}$/.test(p.timerKey) ? p.timerKey : SB_DEFAULTS.timerKey;
  return {
    version: 1,
    enabled: p.enabled === true,
    badge: has("badge") ? text(p.badge, 40) : SB_DEFAULTS.badge,
    heading: (has("heading") ? text(p.heading, 80) : "") || SB_DEFAULTS.heading,
    overrides,
    pillText: has("pillText") ? text(p.pillText, 40) : SB_DEFAULTS.pillText,
    countdown: p.countdown === true,
    timerMin,
    timerMax,
    timerKey,
    updatedAt: typeof p.updatedAt === "string" ? p.updatedAt : "",
  };
}

/** Same format as the storefront: total hours (can exceed 24), then MM:SS. */
export function formatLeft(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const pad = (n: number) => (n < 10 ? "0" : "") + n;
  return `${pad(h)}:${pad(m)}:${pad(s % 60)}`;
}
