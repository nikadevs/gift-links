/**
 * Sale Banner (WoodenCrew Apps module): promo strip on product pages —
 * black badge ("HALLOWEEN SALE"), centered heading ("BUY 1 GET 1 FREE"),
 * white pill with a text ("Limited Time") or a HH:MM:SS countdown to the end
 * of the sale. When the countdown reaches zero the pill shows the text.
 *
 * Stored as one app-owned JSON metafield on the AppInstallation (wc_sb.config),
 * read by the theme app block blocks/sale-banner.liquid. No separate app embed:
 * the block prints nothing while `enabled` is false.
 */
export type SbOverride = { id: string; heading: string }; // id = numeric product id

export type SbConfig = {
  version: 1;
  enabled: boolean;
  badge: string; // black badge text; empty = badge hidden
  heading: string; // default heading for every product
  overrides: SbOverride[]; // custom heading per product
  pillText: string; // white pill text; also shown after the countdown ends
  countdown: boolean; // true = pill shows HH:MM:SS until endsAt
  endsAt: string; // ISO UTC, "" = not set
  endsAtMs: number; // same moment in ms (for Liquid), 0 = not set
  updatedAt: string;
};

export const SB_DEFAULTS: SbConfig = {
  version: 1,
  enabled: false,
  badge: "HALLOWEEN SALE",
  heading: "BUY 1 GET 1 FREE",
  overrides: [],
  pillText: "Limited Time",
  countdown: false,
  endsAt: "",
  endsAtMs: 0,
  updatedAt: "",
};

export const SB_MAX_OVERRIDES = 250;

const text = (v: unknown, max: number) => (typeof v === "string" ? v.replace(/\s+/g, " ").trim().slice(0, max) : "");

export function normalizeSb(raw: unknown): SbConfig {
  const p = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  const has = (k: string) => typeof p[k] === "string";
  const seen = new Set<string>();
  const overrides: SbOverride[] = [];
  for (const o of Array.isArray(p.overrides) ? p.overrides : []) {
    const r = (o && typeof o === "object" ? o : {}) as Record<string, unknown>;
    const id = String(r.id ?? "").replace(/^gid:\/\/shopify\/Product\//, "");
    const heading = text(r.heading, 80);
    if (!/^\d+$/.test(id) || !heading || seen.has(id)) continue;
    seen.add(id);
    overrides.push({ id, heading });
    if (overrides.length >= SB_MAX_OVERRIDES) break;
  }
  let endsAt = "";
  let endsAtMs = 0;
  if (typeof p.endsAt === "string" && p.endsAt) {
    const t = Date.parse(p.endsAt);
    if (Number.isFinite(t)) {
      endsAt = new Date(t).toISOString();
      endsAtMs = t;
    }
  }
  return {
    version: 1,
    enabled: p.enabled === true,
    badge: has("badge") ? text(p.badge, 40) : SB_DEFAULTS.badge,
    heading: (has("heading") ? text(p.heading, 80) : "") || SB_DEFAULTS.heading,
    overrides,
    pillText: has("pillText") ? text(p.pillText, 40) : SB_DEFAULTS.pillText,
    countdown: p.countdown === true && endsAtMs > 0,
    endsAt,
    endsAtMs,
    updatedAt: typeof p.updatedAt === "string" ? p.updatedAt : "",
  };
}

/** Same format as the storefront: total hours (can exceed 24), then MM:SS. */
export function formatLeft(ms: number) {
  const s = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const pad = (n: number) => (n < 10 ? "0" : "") + n;
  return `${pad(h)}:${pad(m)}:${pad(s % 60)}`;
}
