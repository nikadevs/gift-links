import type { authenticate } from "./shopify.server";

/**
 * Currency Converter (replacement for Vitals «Currency Converter»).
 *
 * One app-owned JSON metafield on the AppInstallation: wc_cc.config.
 * The Gift Links app embed (blocks/gift-links.liquid) prints the switcher only
 * when config.enabled is true. No separate app embed (Roman's rule).
 *
 * Conversion is Shopify's own (Markets): picking a currency submits the
 * storefront /localization form with a country that uses that currency, so
 * prices, cart and checkout are all in that currency — the same thing the
 * Vitals switcher does on this store.
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

import type { CcConfig } from "./cc.shared";
import { normalizeCc } from "./cc.shared";

export type { CcConfig, CcPos } from "./cc.shared";
export { CC_DEFAULTS, CC_POSITIONS, normalizeCc } from "./cc.shared";

export type ShopCurrency = { code: string; name: string; enabled: boolean };

export async function loadCcConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcCcConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_cc", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let parsed: Record<string, unknown> | null = null;
  try {
    parsed = inst?.metafield?.value ? JSON.parse(inst.metafield.value) : null;
  } catch {
    parsed = null;
  }
  return { installationId: inst?.id ?? "", config: normalizeCc(parsed), saved: !!parsed };
}

/** Store currency + currencies enabled in Shopify (Settings → Markets). */
export async function loadShopCurrencies(admin: AdminGraphql) {
  try {
    const res = await admin.graphql(
      `#graphql
      query WcCcCurrencies {
        shop {
          currencyCode
          currencySettings(first: 250) { nodes { currencyCode currencyName enabled } }
        }
      }`,
    );
    const json = (await res.json()) as {
      data?: {
        shop?: {
          currencyCode: string;
          currencySettings?: { nodes: { currencyCode: string; currencyName: string; enabled: boolean }[] };
        };
      };
    };
    const shop = json.data?.shop;
    const list: ShopCurrency[] = (shop?.currencySettings?.nodes ?? []).map((n) => ({
      code: n.currencyCode,
      name: n.currencyName,
      enabled: n.enabled,
    }));
    const base = shop?.currencyCode || "USD";
    if (!list.some((c) => c.code === base)) list.unshift({ code: base, name: base, enabled: true });
    return { base, list };
  } catch {
    return { base: "USD", list: [] as ShopCurrency[] };
  }
}

export async function saveCcConfig(admin: AdminGraphql, installationId: string, config: CcConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcCcSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_cc", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}
