/**
 * Volume Discounts — types and pure helpers shared by server and UI code.
 *
 * Offer = a "Buy more, save more" block (like Vitals Volume Discounts):
 * tiers "Buy N with X% off" + optional free gifts per tier.
 *
 * Discount: custom apps can't use Shopify Functions on non-Plus stores, so the
 * percentage comes from NATIVE Shopify automatic discounts ("Amount off
 * products", minimum quantity N, products of the offer) — one per tier with
 * the tier's full %: 20% from 2 items, 30% from 3 items. Checked live on the
 * store 2026-10-08: two automatic discounts on one cart line do NOT stack,
 * Shopify applies the best one (3 items → 30%, 2 items → 20%).
 * Automatic discount titles must be unique, so each one gets an invisible
 * zero-width suffix (Vitals does the same) — shoppers see the same name.
 *
 * Gifts: any $0 product that can go into the cart (ACTIVE or UNLISTED) — an
 * existing $0 version or a copy made by "Make $0 gift copy" — added to the
 * cart by the storefront script with the hidden line property _wc_vd_gift.
 */

export type VdGiftVariant = { id: string; title: string; image: string };

export type VdGift = {
  productId: string; // numeric id of the $0 copy
  handle: string;
  title: string; // product title
  /** short name in the block: "Free <name>" (e.g. "Anti-Scan Wallet") */
  name?: string;
  image: string;
  /** regular price shown struck through, e.g. "19.95" */
  value: string;
  variants: VdGiftVariant[];
  /**
   * product is tagged gift-links-gift / wc-vd-gift → the storefront removes
   * this $0 product from the cart when it wasn't added as a gift (so it can't
   * be bought alone). Untagged $0 products (e.g. Simple Bundles parts) are
   * never removed by this module.
   */
  guard?: boolean;
};

export type VdTier = {
  /** items in the tier (for "Buy N Get N FREE": 2 × N) */
  qty: number;
  /** total % off for this tier, 0 = no discount (ignored when `free` > 0) */
  percent: number;
  /**
   * "Buy N Get N FREE": N items are free (the cheapest ones), qty = 2 × N.
   * 0 / missing = a normal "% off" tier. Shopify: automatic Buy X Get Y discount.
   */
  free?: number;
  /** small badge above the tier, e.g. "Top Pick" */
  label: string;
  gifts: VdGift[];
};

export type VdOffer = {
  id: string;
  /** internal name, not shown to shoppers */
  name: string;
  active: boolean;
  /** YYYY-MM-DD, empty = no limit */
  startsAt: string;
  endsAt: string;

  productIds: string[];
  productTitles: string[];
  productImages: string[];

  /** heading over the block */
  header: string;
  /** discount name customers see in the cart and at checkout */
  discountTitle: string;
  /** index of the tier that is selected when the page opens */
  defaultTier: number;
  /** tiers shown before "Show more options" */
  visibleTiers: number;

  tiers: VdTier[];

  /** Shopify automatic discounts created for this offer (gids) */
  discountIds: string[];
  /** last error from creating the Shopify discounts */
  discountError: string;

  updatedAt: string;
};

export type VdConfig = {
  version: 1;
  offers: VdOffer[];
  /** where the storefront sends impression/click beacons */
  beaconUrl?: string;
};

export const VD_NAMESPACE = "wc_vd";
export const VD_KEY = "config";
/** tag of $0 gift copies; same tag as Gift Links → their pages redirect home */
export const GIFT_TAG = "gift-links-gift";
export const VD_GIFT_TAG = "wc-vd-gift";
export const MAX_TIERS = 8;
/** Shopify limit of active automatic discounts per store */
export const AUTOMATIC_DISCOUNT_LIMIT = 25;

export const blankTier = (qty: number, percent: number): VdTier => ({
  qty,
  percent,
  label: "",
  gifts: [],
});

export const blankOffer = (): VdOffer => ({
  id: "new",
  name: "",
  active: false,
  startsAt: "",
  endsAt: "",
  productIds: [],
  productTitles: [],
  productImages: [],
  header: "Buy more, save more!",
  discountTitle: "Bundle discount",
  defaultTier: 1,
  visibleTiers: 3,
  tiers: [
    blankTier(1, 0),
    { ...blankTier(2, 20), label: "Top Pick" },
    blankTier(3, 30),
  ],
  discountIds: [],
  discountError: "",
  updatedAt: "",
});

export const MAX_FREE = 5;
export const isBogo = (t: Pick<VdTier, "free">) => (Number(t.free) || 0) > 0;
export const blankBogo = (free: number): VdTier => ({ qty: free * 2, percent: 0, free, label: "", gifts: [] });

/**
 * The Shopify automatic discounts needed for an offer: one per tier that
 * raises the %, with the tier's full % (Shopify picks the best one per line).
 * "Buy N Get N FREE" tiers are not here — see bogoSteps.
 */
export function discountSteps(tiers: VdTier[]) {
  const sorted = [...tiers].filter((t) => !isBogo(t)).sort((a, b) => a.qty - b.qty);
  const steps: { qty: number; pct: number; total: number }[] = [];
  let prev = 0;
  for (const t of sorted) {
    const total = Math.min(Math.max(Number(t.percent) || 0, 0), 100);
    if (total <= prev) continue;
    steps.push({ qty: t.qty, pct: Math.round(total * 100) / 10000, total });
    prev = total;
  }
  return steps;
}

/**
 * Shopify "Buy X Get Y" automatic discounts for the "Buy N Get N FREE" tiers. They repeat
 * (every N bought → N more free), so "Buy 1 Get 1" already covers "Buy 2 Get 2" (4 items →
 * 2 free): a tier whose N is a multiple of a smaller one gets no discount of its own — saves
 * the store's limit of 25 active automatic discounts.
 */
export function bogoSteps(tiers: VdTier[]) {
  const ns = [...new Set(tiers.filter(isBogo).map((t) => Number(t.free)))].sort((a, b) => a - b);
  const out: number[] = [];
  for (const n of ns) if (!out.some((m) => n % m === 0)) out.push(n);
  return out;
}

/** all Shopify automatic discounts an offer creates */
export const discountCount = (tiers: VdTier[]) => discountSteps(tiers).length + bogoSteps(tiers).length;

/** Zero-width characters used to make automatic discount titles unique. */
export const ZW_RE = /[\u200B-\u200D\u2060\uFEFF]/g;
export const cleanTitle = (t: string) => String(t ?? "").replace(ZW_RE, "").trim();

/** Invisible suffix that encodes `key` (e.g. "vd_abc:1") in zero-width chars. */
export function invisibleSuffix(key: string) {
  let h = 2166136261;
  for (let i = 0; i < key.length; i++) h = Math.imul(h ^ key.charCodeAt(i), 16777619) >>> 0;
  let out = "\u2060";
  for (let i = 0; i < 20; i++) out += h & (1 << i) ? "\u200C" : "\u200B";
  return out;
}

export const maxPercent = (o: Pick<VdOffer, "tiers">) =>
  o.tiers.reduce((m, t) => Math.max(m, t.percent), 0);

export function offerStatus(
  o: Pick<VdOffer, "active" | "startsAt" | "endsAt">,
  today = new Date().toISOString().slice(0, 10),
) {
  if (!o.active) return "Inactive" as const;
  if (o.startsAt && today < o.startsAt) return "Scheduled" as const;
  if (o.endsAt && today > o.endsAt) return "Ended" as const;
  return "Active" as const;
}

/** "Buy 2 · 20% + gift" style one-liner for tables */
export function tierSummary(t: VdTier) {
  if (isBogo(t)) {
    const g = t.gifts.length ? ` + ${t.gifts.length} gift${t.gifts.length > 1 ? "s" : ""}` : "";
    return `Buy ${t.free} Get ${t.free} FREE${g}`;
  }
  const parts = [`Buy ${t.qty}`];
  if (t.percent > 0) parts.push(`${t.percent}% off`);
  if (t.gifts.length) parts.push(`+ ${t.gifts.length} gift${t.gifts.length > 1 ? "s" : ""}`);
  return parts.join(" ");
}
