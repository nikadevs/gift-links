/** Types and pure helpers shared by server and UI code. */

export type Campaign = {
  id: string;
  name: string;
  active: boolean;
  /** value of ?gift=... in the email link */
  linkKey: string;
  /** numeric variant id, e.g. "54139559510335" */
  giftVariantId: string;
  giftTitle: string;
  giftImage: string;
  /** discount code to apply automatically (e.g. a Buy X Get Y code that makes the gift $0) */
  discountCode: string;
  /** also activate the campaign when the shopper types this code on the cart page */
  triggerOnCode: boolean;
  /** minimum cart subtotal (without the gift), in store currency units */
  minSubtotal: number;
  /** add the gift even while the cart is still empty */
  addWhenCartEmpty: boolean;
  /** remove the gift again when the cart stops qualifying */
  removeWhenIneligible: boolean;
  /** optional sticky banner text on the storefront while the campaign is active */
  bannerText: string;
  /** where the link sends the shopper, e.g. "/" or "/collections/all" */
  landingPath: string;
  /** ISO date strings (YYYY-MM-DD) or "" */
  startsAt: string;
  endsAt: string;
  updatedAt: string;
};

export function campaignLink(domain: string, c: Campaign) {
  const sep = c.landingPath.includes("?") ? "&" : "?";
  return `${domain}${c.landingPath}${sep}gift=${encodeURIComponent(c.linkKey)}`;
}

export function campaignStatus(c: Campaign, today = new Date()) {
  const d = today.toISOString().slice(0, 10);
  if (!c.active) return "Paused";
  if (c.startsAt && d < c.startsAt) return "Scheduled";
  if (c.endsAt && d > c.endsAt) return "Ended";
  return "Live";
}
