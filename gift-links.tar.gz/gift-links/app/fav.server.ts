import type { authenticate } from "./shopify.server";
import { normalizeFav, type FavConfig } from "./fav.shared";

/**
 * Favicon Cart Count: one app-owned JSON metafield on the AppInstallation
 * (wc_fav.config). The Gift Links app embed prints the storefront code only when
 * it is enabled — no separate app embed (Roman's rule).
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export async function loadFavConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcFavConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_fav", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let parsed: unknown = {};
  try {
    parsed = JSON.parse(inst?.metafield?.value || "{}");
  } catch {
    parsed = {};
  }
  return { installationId: inst?.id ?? "", config: normalizeFav(parsed), saved: !!inst?.metafield?.value };
}

export async function saveFavConfig(admin: AdminGraphql, installationId: string, config: FavConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcFavSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_fav", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}
