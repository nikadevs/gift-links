import type { authenticate } from "./shopify.server";

/**
 * Content Protection (replacement for the Vitals module of the same name).
 * Settings live in one app-owned JSON metafield on the AppInstallation
 * (namespace "wc_cp", key "config"); the theme app embed
 * blocks/content-protection.liquid reads it as app.metafields.wc_cp.config.
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export const CP_NAMESPACE = "wc_cp";
export const CP_KEY = "config";

export type CpConfig = {
  version: 1;
  /** Ctrl/⌘ + C, X (copy/cut events), U (view source), S (save page) */
  shortcuts: boolean;
  /** right click (and Android long-press menu, iOS image callout) */
  rightClick: boolean;
  /** text selection with the mouse / Ctrl+A */
  selection: boolean;
  /** dragging images and text out of the page */
  drag: boolean;
  updatedAt: string;
};

export const defaultCpConfig = (): CpConfig => ({
  version: 1,
  shortcuts: true,
  rightClick: true,
  selection: true,
  drag: true,
  updatedAt: "",
});

export async function loadCpConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcCpConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_cp", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: {
      currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null };
    };
  };
  const inst = json.data?.currentAppInstallation;
  const config = defaultCpConfig();
  const raw = inst?.metafield?.value;
  if (raw) {
    try {
      const p = JSON.parse(raw);
      for (const k of ["shortcuts", "rightClick", "selection", "drag"] as const) {
        if (typeof p?.[k] === "boolean") config[k] = p[k];
      }
      if (typeof p?.updatedAt === "string") config.updatedAt = p.updatedAt;
    } catch {
      // corrupted value — fall back to defaults (everything on, like the Liquid)
    }
  }
  return { installationId: inst?.id ?? "", config, saved: !!raw };
}

export async function saveCpConfig(admin: AdminGraphql, installationId: string, config: CpConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcCpSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          {
            ownerId: installationId,
            namespace: CP_NAMESPACE,
            key: CP_KEY,
            type: "json",
            value: JSON.stringify(config),
          },
        ],
      },
    },
  );
  const json = (await res.json()) as {
    data?: { metafieldsSet?: { userErrors: { message: string }[] } };
  };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}
