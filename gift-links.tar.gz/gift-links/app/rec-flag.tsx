import { useState } from "react";
import { countryName, tzCity } from "./rec.shared";

/** short country label: GB → UK, US → USA, others → ISO code */
export function countryShort(code?: string) {
  const c = (code || "").toUpperCase();
  if (c === "GB") return "UK";
  if (c === "US") return "USA";
  return c;
}

/**
 * Country flag (image from flagcdn.com — Windows Chrome has no flag emoji)
 * + city from the visitor's time zone. Falls back to the short code (UK, USA,
 * AU) if the image can't load.
 */
export function Location({ country, tz }: { country?: string; tz?: string }) {
  const [broken, setBroken] = useState(false);
  const code = (country || "").toLowerCase();
  const city = tzCity(tz);
  const title = [countryName(country), city].filter(Boolean).join(" · ") + (tz ? ` (time zone ${tz})` : "");
  if (!code && !city) return <span>—</span>;
  return (
    <span title={title} style={{ display: "inline-flex", alignItems: "center", gap: 6, minWidth: 0, maxWidth: "100%" }}>
      {code ? (
        broken ? (
          <b style={{ fontWeight: 600 }}>{countryShort(country)}</b>
        ) : (
          <img
            src={`https://flagcdn.com/w40/${code}.png`}
            width={20}
            height={15}
            alt={countryShort(country)}
            loading="lazy"
            onError={() => setBroken(true)}
            style={{ borderRadius: 2, boxShadow: "0 0 0 1px rgba(0,0,0,.12)", flex: "none", objectFit: "cover" }}
          />
        )
      ) : null}
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{city || countryName(country)}</span>
    </span>
  );
}

/** inline SVG device icon (no requests): phone / tablet / laptop */
export function DeviceIcon({ device, title }: { device: string; title?: string }) {
  const common = {
    width: 20,
    height: 20,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "#4a4a4a",
    strokeWidth: 1.8,
    strokeLinecap: "round" as const,
    strokeLinejoin: "round" as const,
    role: "img",
    "aria-label": device,
    style: { display: "block" },
  };
  return (
    <span title={title ? `${device} · ${title}` : device} style={{ display: "inline-flex" }}>
      {device === "desktop" ? (
        <svg {...common}>
          <rect x="4" y="5" width="16" height="11" rx="1.5" />
          <path d="M2 19h20" />
        </svg>
      ) : device === "tablet" ? (
        <svg {...common}>
          <rect x="5" y="2.5" width="14" height="19" rx="2" />
          <path d="M11 18.5h2" />
        </svg>
      ) : (
        <svg {...common}>
          <rect x="7" y="2.5" width="10" height="19" rx="2" />
          <path d="M11 18.5h2" />
        </svg>
      )}
    </span>
  );
}
