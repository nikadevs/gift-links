import { useState } from "react";
import { countryName, tzCity } from "./rec.shared";

/** short country label: GB → UK, US → USA, others → ISO code */
export function countryShort(code?: string) {
  const c = (code || "").toUpperCase();
  if (c === "GB") return "UK";
  if (c === "US") return "USA";
  return c;
}

/**
 * Country flag (image from flagcdn.com — Windows Chrome has no flag emoji)
 * + city from the visitor's time zone. Falls back to the short code (UK, USA,
 * AU) if the image can't load.
 */
export function Location({ country, tz }: { country?: string; tz?: string }) {
  const [broken, setBroken] = useState(false);
  const code = (country || "").toLowerCase();
  const city = tzCity(tz);
  const title = [countryName(country), city].filter(Boolean).join(" · ") + (tz ? ` (time zone ${tz})` : "");
  if (!code && !city) return <span>—</span>;
  return (
    <span title={title} style={{ display: "inline-flex", alignItems: "center", gap: 6, minWidth: 0, maxWidth: "100%" }}>
      {code ? (
        broken ? (
          <b style={{ fontWeight: 600 }}>{countryShort(country)}</b>
        ) : (
          <img
            src={`https://flagcdn.com/w40/${code}.png`}
            width={20}
            height={15}
            alt={countryShort(country)}
            loading="lazy"
            onError={() => setBroken(true)}
            style={{ borderRadius: 2, boxShadow: "0 0 0 1px rgba(0,0,0,.12)", flex: "none", objectFit: "cover" }}
          />
        )
      ) : null}
      <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{city || countryName(country)}</span>
    </span>
  );
}
