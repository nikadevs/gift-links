/**
 * Bundles module.
 *
 * Shopify Functions (Cart Transform) are not available to custom apps on a
 * non-Plus store, so this module uses Shopify's NATIVE fixed bundles instead
 * (productVariantRelationshipBulkUpdate): the parent variant gets component
 * variants + quantities and requiresComponents = true. Shopify itself then
 * expands the line in cart/checkout/orders (lineItemGroup), allocates the
 * parent price across components by their prices and computes stock.
 * Verified live 2026-10-17 on a temporary UNLISTED product.
 *
 * Our own settings: variant metafield wc_bundles.config (JSON, OwnConfig).
 * "Import" copies native components Shopify already has into those settings.
 * Active = Shopify has the native components + requiresComponents on the
 * variant (read live, not stored); Disable removes them, settings stay.
 * Bundle Contents reads the same settings to show what a bundle includes.
 */

export type Comp = { variantId: string; qty: number };

/** One component in wc_bundles.config. */
export type OwnItem = {
  variant_title: string;
  variant_id: number;
  price: number;
  compare_at_price: number | null;
  sku: string | null;
  inventory_management: string | null;
  inventory_policy: string;
  inventory_item_id: number | null;
  handle: string;
  vendor: string;
  product_title: string;
  product_id: number;
  quantity_in_bundle: number;
  type: string;
  bundle_discount_percentage: number;
  selection_token?: string;
};

export type VariantState = "active" | "disabled" | "differs" | "import" | "none";

export const OWN_NS = "wc_bundles";
export const OWN_KEY = "config";
export type OwnConfig = { v: 1; items: OwnItem[]; updatedAt: string };

export function parseOwn(value: string | null | undefined): OwnConfig | null {
  if (!value) return null;
  try {
    const o = JSON.parse(value);
    if (!o || !Array.isArray(o.items) || !o.items.length) return null;
    return { v: 1, items: o.items, updatedAt: String(o.updatedAt || "") };
  } catch {
    return null;
  }
}

export const gidVariant = (n: number | string) =>
  String(n).startsWith("gid://") ? String(n) : `gid://shopify/ProductVariant/${n}`;
export const numId = (gid: string) => gid.split("/").pop() || gid;

/** Settings items → components (same variant listed twice = quantities added). */
export function itemsToComps(items: OwnItem[] | null): Comp[] {
  return normalizeComps(
    (items || []).map((i) => ({ variantId: gidVariant(i.variant_id), qty: Number(i.quantity_in_bundle) || 1 })),
  );
}

/** Merge duplicates, drop qty < 1, keep first-seen order. */
export function normalizeComps(list: Comp[]): Comp[] {
  const out: Comp[] = [];
  const at = new Map<string, number>();
  for (const c of list) {
    const id = gidVariant(c.variantId);
    const q = Math.floor(Number(c.qty));
    if (!(q >= 1)) continue;
    if (at.has(id)) out[at.get(id)!].qty += q;
    else {
      at.set(id, out.length);
      out.push({ variantId: id, qty: q });
    }
  }
  return out;
}

export function sameComps(a: Comp[], b: Comp[]) {
  const A = normalizeComps(a);
  const B = normalizeComps(b);
  if (A.length !== B.length) return false;
  const m = new Map(B.map((c) => [c.variantId, c.qty]));
  return A.every((c) => m.get(c.variantId) === c.qty);
}

/**
 * active   — our settings + Shopify has exactly those native components + flag
 * disabled — our settings, nothing native
 * differs  — native components/flag don't match our settings (Activate fixes)
 * import   — no settings of ours yet; Shopify has native components to import
 */
export function variantState(own: Comp[], native: Comp[], requiresComponents: boolean): VariantState {
  if (own.length) {
    if (!native.length && !requiresComponents) return "disabled";
    return requiresComponents && sameComps(own, native) ? "active" : "differs";
  }
  if (native.length) return "import";
  return "none";
}

/**
 * Input for productVariantRelationshipBulkUpdate that turns `current` into
 * `desired` (create new variants, update changed quantities, remove the rest).
 */
export function relationshipInput(parentVariantId: string, current: Comp[], desired: Comp[]) {
  const cur = new Map(normalizeComps(current).map((c) => [c.variantId, c.qty]));
  const want = normalizeComps(desired);
  const toCreate = want.filter((c) => !cur.has(c.variantId)).map((c) => ({ id: c.variantId, quantity: c.qty }));
  const toUpdate = want
    .filter((c) => cur.has(c.variantId) && cur.get(c.variantId) !== c.qty)
    .map((c) => ({ id: c.variantId, quantity: c.qty }));
  const wantIds = new Set(want.map((c) => c.variantId));
  const toRemove = [...cur.keys()].filter((id) => !wantIds.has(id));
  // NONE: keep the parent's price. Without it Shopify re-prices the parent to
  // the SUM of component prices (seen live 2026-10-17: $49.95 → $44.95).
  const input: Record<string, unknown> = { parentProductVariantId: parentVariantId, priceInput: { calculation: "NONE" } };
  if (toCreate.length) input.productVariantRelationshipsToCreate = toCreate;
  if (toUpdate.length) input.productVariantRelationshipsToUpdate = toUpdate;
  if (toRemove.length) input.productVariantRelationshipsToRemove = toRemove;
  return { input, changed: toCreate.length + toUpdate.length + toRemove.length > 0 };
}

/** Live data of a component variant (for the admin list and the settings items). */
export type VariantInfo = {
  id: string;
  title: string;
  productTitle: string;
  productId: string;
  handle: string;
  vendor: string;
  price: number;
  compareAt: number | null;
  sku: string | null;
  tracked: boolean;
  inventoryPolicy: string;
  inventoryItemId: string | null;
  image: string | null;
  status: string;
};

/**
 * Items for wc_bundles.config (`price` = the component variant's own price;
 * Bundle Contents treats price 0 as "free"). Fields of items that already
 * existed are preserved.
 */
export function buildItems(
  comps: Comp[],
  info: Record<string, VariantInfo | undefined>,
  previous: OwnItem[] | null,
): OwnItem[] {
  const prev = new Map((previous || []).map((p) => [gidVariant(p.variant_id), p]));
  const list = normalizeComps(comps);
  return list.map((c) => {
    const v = info[c.variantId];
    const p = prev.get(c.variantId);
    const price = v ? v.price : (p?.price ?? 0);
    return {
      variant_title: v?.title ?? p?.variant_title ?? "",
      variant_id: Number(numId(c.variantId)),
      price,
      compare_at_price: v ? v.compareAt : (p?.compare_at_price ?? null),
      sku: v ? v.sku : (p?.sku ?? null),
      inventory_management: v ? (v.tracked ? "shopify" : null) : (p?.inventory_management ?? null),
      inventory_policy: v ? (v.inventoryPolicy || "deny").toLowerCase() : (p?.inventory_policy ?? "deny"),
      inventory_item_id: v?.inventoryItemId ? Number(numId(v.inventoryItemId)) : (p?.inventory_item_id ?? null),
      handle: v?.handle ?? p?.handle ?? "",
      vendor: v?.vendor ?? p?.vendor ?? "",
      product_title: v?.productTitle ?? p?.product_title ?? "",
      product_id: v ? Number(numId(v.productId)) : (p?.product_id ?? 0),
      quantity_in_bundle: c.qty,
      type: "Simple",
      bundle_discount_percentage: p?.bundle_discount_percentage ?? 0,
    };
  });
}

export const MAX_COMPONENTS = 30;
