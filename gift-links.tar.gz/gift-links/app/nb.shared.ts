/**
 * Bundles module (replacement for the Simple Bundles app).
 *
 * Shopify Functions (Cart Transform) are not available to custom apps on a
 * non-Plus store, so this module uses Shopify's NATIVE fixed bundles instead
 * (productVariantRelationshipBulkUpdate): the parent variant gets component
 * variants + quantities and requiresComponents = true. Shopify itself then
 * expands the line in cart/checkout/orders (lineItemGroup), allocates the
 * parent price across components by their prices and computes stock.
 * Verified live 2026-10-17 on a temporary UNLISTED product.
 *
 * Source of truth for the definitions that already exist = Simple Bundles'
 * variant metafield simple_bundles.bundled_variants (JSON). The module keeps
 * that metafield in the same format when a bundle is edited here, so the
 * Bundle Contents module (which imports it) keeps working.
 */

export type Comp = { variantId: string; qty: number };

/** One element of simple_bundles.bundled_variants (only the fields we use/write). */
export type SbItem = {
  variant_title: string;
  variant_id: number;
  price: number;
  compare_at_price: number | null;
  sku: string | null;
  inventory_management: string | null;
  inventory_policy: string;
  inventory_item_id: number | null;
  handle: string;
  vendor: string;
  product_title: string;
  product_id: number;
  quantity_in_bundle: number;
  type: string;
  bundle_discount_percentage: number;
  selection_token?: string;
};

export type VariantState = "native" | "simple" | "differs" | "unflagged" | "byob" | "none";

export const gidVariant = (n: number | string) =>
  String(n).startsWith("gid://") ? String(n) : `gid://shopify/ProductVariant/${n}`;
export const numId = (gid: string) => gid.split("/").pop() || gid;

/** Parse the Simple Bundles JSON. Returns null when it is empty/invalid. */
export function parseSb(value: string | null | undefined): SbItem[] | null {
  if (!value) return null;
  try {
    const arr = JSON.parse(value);
    if (!Array.isArray(arr) || !arr.length) return null;
    return arr.filter((x) => x && (typeof x.variant_id === "number" || typeof x.variant_id === "string"));
  } catch {
    return null;
  }
}

export const isByob = (items: SbItem[] | null) => !!items?.some((i) => i.type && i.type !== "Simple");

/** Simple Bundles items → components (same variant listed twice = quantities added). */
export function sbToComps(items: SbItem[] | null): Comp[] {
  return normalizeComps(
    (items || []).map((i) => ({ variantId: gidVariant(i.variant_id), qty: Number(i.quantity_in_bundle) || 1 })),
  );
}

/** Merge duplicates, drop qty < 1, keep first-seen order. */
export function normalizeComps(list: Comp[]): Comp[] {
  const out: Comp[] = [];
  const at = new Map<string, number>();
  for (const c of list) {
    const id = gidVariant(c.variantId);
    const q = Math.floor(Number(c.qty));
    if (!(q >= 1)) continue;
    if (at.has(id)) out[at.get(id)!].qty += q;
    else {
      at.set(id, out.length);
      out.push({ variantId: id, qty: q });
    }
  }
  return out;
}

export function sameComps(a: Comp[], b: Comp[]) {
  const A = normalizeComps(a);
  const B = normalizeComps(b);
  if (A.length !== B.length) return false;
  const m = new Map(B.map((c) => [c.variantId, c.qty]));
  return A.every((c) => m.get(c.variantId) === c.qty);
}

export function variantState(sb: SbItem[] | null, native: Comp[], requiresComponents: boolean): VariantState {
  if (isByob(sb)) return native.length ? "native" : "byob";
  const s = sbToComps(sb);
  if (native.length && requiresComponents) return !s.length || sameComps(s, native) ? "native" : "differs";
  if (native.length) return "unflagged"; // components but not flagged → "Make native" sets the flag
  return s.length ? "simple" : "none";
}

/**
 * Input for productVariantRelationshipBulkUpdate that turns `current` into
 * `desired` (create new variants, update changed quantities, remove the rest).
 */
export function relationshipInput(parentVariantId: string, current: Comp[], desired: Comp[]) {
  const cur = new Map(normalizeComps(current).map((c) => [c.variantId, c.qty]));
  const want = normalizeComps(desired);
  const toCreate = want.filter((c) => !cur.has(c.variantId)).map((c) => ({ id: c.variantId, quantity: c.qty }));
  const toUpdate = want
    .filter((c) => cur.has(c.variantId) && cur.get(c.variantId) !== c.qty)
    .map((c) => ({ id: c.variantId, quantity: c.qty }));
  const wantIds = new Set(want.map((c) => c.variantId));
  const toRemove = [...cur.keys()].filter((id) => !wantIds.has(id));
  // NONE: keep the parent's price. Without it Shopify re-prices the parent to
  // the SUM of component prices (seen live 2026-10-17: $49.95 → $44.95).
  const input: Record<string, unknown> = { parentProductVariantId: parentVariantId, priceInput: { calculation: "NONE" } };
  if (toCreate.length) input.productVariantRelationshipsToCreate = toCreate;
  if (toUpdate.length) input.productVariantRelationshipsToUpdate = toUpdate;
  if (toRemove.length) input.productVariantRelationshipsToRemove = toRemove;
  return { input, changed: toCreate.length + toUpdate.length + toRemove.length > 0 };
}

/** Live data of a component variant (for the admin list and to rebuild the SB JSON). */
export type VariantInfo = {
  id: string;
  title: string;
  productTitle: string;
  productId: string;
  handle: string;
  vendor: string;
  price: number;
  compareAt: number | null;
  sku: string | null;
  tracked: boolean;
  inventoryPolicy: string;
  inventoryItemId: string | null;
  image: string | null;
  status: string;
};

/**
 * Rebuild simple_bundles.bundled_variants from components, same shape Simple
 * Bundles writes (`price` = the component variant's own price, as Simple
 * Bundles stores it; Bundle Contents treats price 0 as "free"). Fields of
 * items that already existed are preserved.
 */
export function buildSbJson(
  comps: Comp[],
  info: Record<string, VariantInfo | undefined>,
  previous: SbItem[] | null,
): SbItem[] {
  const prev = new Map((previous || []).map((p) => [gidVariant(p.variant_id), p]));
  const list = normalizeComps(comps);
  return list.map((c) => {
    const v = info[c.variantId];
    const p = prev.get(c.variantId);
    const price = v ? v.price : (p?.price ?? 0);
    return {
      variant_title: v?.title ?? p?.variant_title ?? "",
      variant_id: Number(numId(c.variantId)),
      price,
      compare_at_price: v ? v.compareAt : (p?.compare_at_price ?? null),
      sku: v ? v.sku : (p?.sku ?? null),
      inventory_management: v ? (v.tracked ? "shopify" : null) : (p?.inventory_management ?? null),
      inventory_policy: v ? (v.inventoryPolicy || "deny").toLowerCase() : (p?.inventory_policy ?? "deny"),
      inventory_item_id: v?.inventoryItemId ? Number(numId(v.inventoryItemId)) : (p?.inventory_item_id ?? null),
      handle: v?.handle ?? p?.handle ?? "",
      vendor: v?.vendor ?? p?.vendor ?? "",
      product_title: v?.productTitle ?? p?.product_title ?? "",
      product_id: v ? Number(numId(v.productId)) : (p?.product_id ?? 0),
      quantity_in_bundle: c.qty,
      type: "Simple",
      bundle_discount_percentage: p?.bundle_discount_percentage ?? 0,
    };
  });
}

export const MAX_COMPONENTS = 30;
