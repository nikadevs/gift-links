/**
 * Is a theme app embed switched on in the live theme?
 *
 * The embed block prints a tiny marker element when it is enabled
 * (Checkbox Upsell: <div id="wcu-embed" hidden>). We open the storefront home
 * page and look for it. No extra API scope is needed.
 *
 * Results are cached for a minute per shop so the stats polling on the list
 * page doesn't hit the storefront every few seconds.
 */
export type EmbedState = "on" | "off" | "unknown";

const CACHE_MS = 60 * 1000;
const cache = new Map<string, { at: number; state: EmbedState }>();

export async function checkEmbed(
  domain: string,
  markers: RegExp,
  force = false,
): Promise<EmbedState> {
  if (!domain) return "unknown";
  const key = `${domain}|${markers.source}`;
  const hit = cache.get(key);
  if (!force && hit && Date.now() - hit.at < CACHE_MS) return hit.state;

  let state: EmbedState = "unknown";
  try {
    const res = await fetch(`${domain}/?wc_embed_check=${Date.now()}`, {
      redirect: "follow",
      signal: AbortSignal.timeout(8000),
      headers: { Accept: "text/html" },
    });
    // password page / bot challenge / errors → we can't tell
    if (res.ok && !/\/password/.test(res.url)) {
      const html = await res.text();
      state = markers.test(html) ? "on" : "off";
    }
  } catch {
    state = "unknown";
  }
  cache.set(key, { at: Date.now(), state });
  return state;
}

/** Marker printed by extensions/gift-links-embed/blocks/checkbox-upsell.liquid */
export const UPSELL_EMBED_MARKERS =
  /id="wcu-embed"|id="wcu-boot"|wc-checkbox-upsell\.js/;

/** Theme editor link that opens App embeds with the given block switched on. */
export function embedActivateUrl(shop: string, apiKey: string, handle: string) {
  const base = `https://${shop}/admin/themes/current/editor?context=apps`;
  return apiKey
    ? `${base}&activateAppId=${encodeURIComponent(apiKey)}/${encodeURIComponent(handle)}`
    : base;
}
