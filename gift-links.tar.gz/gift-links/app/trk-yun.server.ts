/**
 * YunExpress Open API client (open.yunexpress.cn, free for YunExpress customers).
 *
 * Docs checked 2026-10-17:
 *  - token: POST {base}/openapi/oauth2/token
 *      {grantType:"client_credentials", appId, appSecret, sourceKey} → {accessToken, expiresIn}
 *  - every call: headers token, date (ms), sign
 *      sign = Base64(HmacSHA256(appSecret, content))
 *      content = "body=<json>&date=<ms>&method=<M>&uri=<path>"  (no body → without "body=")
 *  - full history: GET /v1/track-service/getAllForOPenApi?order_number=<YT or last-mile number>
 *      result[0].track_Info { waybill_number, tracking_number (last mile), last_mile_name,
 *      last_mile_site, destination_code, interval_day, track_events[ {process_time,
 *      process_utc_time, process_content, process_country/province/city/location,
 *      track_node_code} ] }
 * Not verified on live keys yet: whether "uri" in the signature must include the
 * query string. We sign with the query string first and retry once without it if
 * the gateway rejects the signature.
 */
import crypto from "node:crypto";
import type { TrkEvent, TrkSettings } from "./trk.shared";
import { statusFromCarrier } from "./trk.shared";

const PROD = "https://openapi.yunexpress.cn";
const SBX = "https://openapi-sbx.yunexpress.cn";
const TRACK_PATH = "/v1/track-service/getAllForOPenApi";

type TokenCache = { key: string; token: string; until: number };
let tokenCache: TokenCache | null = null;
let signWithQuery = true;

const base = (s: TrkSettings) => (s.yunSandbox ? SBX : PROD);

export function yunConfigured(s: TrkSettings): boolean {
  return !!(s.yunAppId && s.yunAppSecret && s.yunSourceKey);
}

async function getToken(s: TrkSettings): Promise<string> {
  const key = `${s.yunSandbox}|${s.yunAppId}|${s.yunSourceKey}`;
  if (tokenCache && tokenCache.key === key && tokenCache.until > Date.now() + 60_000) return tokenCache.token;
  const res = await fetch(`${base(s)}/openapi/oauth2/token`, {
    method: "POST",
    headers: { "Content-Type": "application/json;charset=utf-8", Accept: "application/json" },
    body: JSON.stringify({
      grantType: "client_credentials",
      appId: s.yunAppId,
      appSecret: s.yunAppSecret,
      sourceKey: s.yunSourceKey,
    }),
    signal: AbortSignal.timeout(20000),
  });
  const text = await res.text();
  let json: Record<string, unknown> = {};
  try {
    json = JSON.parse(text);
  } catch {
    /* handled below */
  }
  const token = String(json.accessToken ?? (json.result as Record<string, unknown> | undefined)?.accessToken ?? "");
  if (!res.ok || !token) throw new Error(`YunExpress token: HTTP ${res.status} ${text.slice(0, 200)}`);
  const ttl = Number(json.expiresIn ?? 7200) * 1000;
  tokenCache = { key, token, until: Date.now() + (Number.isFinite(ttl) ? ttl : 7_200_000) };
  return token;
}

export function yunSign(secret: string, method: string, uri: string, date: number, body?: string): string {
  const content = `${body ? `body=${body}&` : ""}date=${date}&method=${method}&uri=${uri}`;
  return crypto.createHmac("sha256", secret).update(content, "utf8").digest("base64");
}

type YunEvent = {
  process_time?: string;
  process_utc_time?: string;
  process_content?: string;
  process_country?: string;
  process_province?: string;
  process_city?: string;
  process_location?: string;
  track_node_code?: string;
};

export type YunResult = {
  found: boolean;
  lastMileNumber: string;
  lastMileCarrier: string;
  lastMileSite: string;
  destination: string;
  intervalDays: number | null;
  events: TrkEvent[]; // newest first
  raw?: unknown;
};

function toIso(v: string | undefined): string {
  if (!v || v.startsWith("0001-")) return "";
  const t = Date.parse(v);
  return Number.isFinite(t) ? new Date(t).toISOString() : "";
}

export function parseYun(json: unknown, number: string): YunResult {
  const empty: YunResult = {
    found: false,
    lastMileNumber: "",
    lastMileCarrier: "",
    lastMileSite: "",
    destination: "",
    intervalDays: null,
    events: [],
  };
  const r = json as { success?: boolean; result?: unknown };
  const list = Array.isArray(r?.result) ? (r.result as Record<string, unknown>[]) : r?.result ? [r.result as Record<string, unknown>] : [];
  const row =
    list.find((x) => String(x.order_number ?? "").toUpperCase() === number.toUpperCase()) ?? list[0];
  const info = (row?.track_Info ?? row?.track_info) as Record<string, unknown> | undefined;
  if (!info) return empty;
  const evs = Array.isArray(info.track_events) ? (info.track_events as YunEvent[]) : [];
  const events: TrkEvent[] = evs
    .map((e) => {
      const text = String(e.process_content ?? "").trim();
      const code = String(e.track_node_code ?? "").trim();
      const place = [e.process_location, e.process_city, e.process_province, e.process_country]
        .map((x) => String(x ?? "").trim())
        .filter(Boolean)
        .filter((x, i, a) => a.indexOf(x) === i)
        .join(", ");
      const at = toIso(e.process_utc_time) || toIso(e.process_time);
      return { at, local: String(e.process_time ?? ""), text, place, code, status: statusFromCarrier(code, text) };
    })
    .filter((e) => e.at && (e.text || e.code))
    .sort((a, b) => (a.at < b.at ? 1 : a.at > b.at ? -1 : 0));
  const lmn = String(info.tracking_number ?? "").trim();
  const waybill = String(info.waybill_number ?? "").trim();
  const interval = Number(info.interval_day);
  return {
    found: true,
    lastMileNumber: lmn && lmn.toUpperCase() !== waybill.toUpperCase() && lmn.toUpperCase() !== number.toUpperCase() ? lmn : "",
    lastMileCarrier: String(info.last_mile_name ?? "").trim(),
    lastMileSite: String(info.last_mile_site ?? "").trim(),
    destination: String(info.destination_code ?? "").trim(),
    intervalDays: Number.isFinite(interval) && interval > 0 ? interval : null,
    events,
  };
}

/** Full history for one number. Throws on transport/auth errors. */
export async function yunTrack(s: TrkSettings, number: string, keepRaw = false): Promise<YunResult> {
  const token = await getToken(s);
  const query = `?order_number=${encodeURIComponent(number)}`;
  const attempt = async (withQuery: boolean) => {
    const date = Date.now();
    const sign = yunSign(s.yunAppSecret, "GET", withQuery ? TRACK_PATH + query : TRACK_PATH, date);
    const res = await fetch(`${base(s)}${TRACK_PATH}${query}`, {
      headers: {
        token,
        date: String(date),
        sign,
        "Accept-Language": "en-US",
        Accept: "application/json",
        "Content-Type": "application/json;charset=utf-8",
      },
      signal: AbortSignal.timeout(20000),
    });
    const text = await res.text();
    let json: unknown = null;
    try {
      json = JSON.parse(text);
    } catch {
      json = null;
    }
    return { res, text, json };
  };
  let out = await attempt(signWithQuery);
  const signError = (o: typeof out) =>
    o.res.status === 401 || o.res.status === 403 || /sign/i.test(String((o.json as { msg?: string })?.msg ?? o.text.slice(0, 300)));
  if (signError(out)) {
    const alt = await attempt(!signWithQuery);
    if (!signError(alt)) {
      signWithQuery = !signWithQuery;
      out = alt;
    }
  }
  if (out.res.status === 401) tokenCache = null;
  if (!out.res.ok || !out.json) throw new Error(`YunExpress: HTTP ${out.res.status} ${out.text.slice(0, 200)}`);
  const j = out.json as { success?: boolean; msg?: string; code?: string };
  if (j.success === false && !/no data|not found|不存在/i.test(String(j.msg ?? ""))) {
    throw new Error(`YunExpress: ${j.code ?? ""} ${j.msg ?? ""}`.trim());
  }
  const parsed = parseYun(out.json, number);
  if (keepRaw) parsed.raw = out.json;
  return parsed;
}
