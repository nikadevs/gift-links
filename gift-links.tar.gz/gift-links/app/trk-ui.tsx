import type { CSSProperties, ReactNode } from "react";
import { useEffect } from "react";
import { Link, useFetcher, useLocation } from "react-router";
import { useAppBridge } from "@shopify/app-bridge-react";
import { TRK_STATUS_LABEL, type TrkStatus } from "./trk.shared";
import type { TrkActionResult } from "./trk-actions.server";

/** Shared admin UI for the Tracking module pages (ideas from Track123's admin). */

export const TRK_PAGES: [string, string][] = [
  ["/app/tracking", "Dashboard"],
  ["/app/tracking/page", "Tracking page"],
  ["/app/tracking/orders", "Orders"],
  ["/app/tracking/notifications", "Notification"],
  ["/app/tracking/analytics", "Analytics"],
  ["/app/tracking/settings", "Settings"],
];

export function TrkNav() {
  const { pathname } = useLocation();
  const current = pathname.replace(/\/$/, "");
  return (
    <div style={{ display: "flex", gap: 4, flexWrap: "wrap", marginBottom: 12, background: "#e8e8e8", borderRadius: 10, padding: 3, width: "fit-content" }}>
      {TRK_PAGES.map(([to, label]) => {
        const on = current === to;
        return (
          <Link
            key={to}
            to={to}
            style={{
              padding: "6px 12px",
              borderRadius: 8,
              fontSize: 13,
              fontWeight: on ? 600 : 500,
              color: "#303030",
              textDecoration: "none",
              background: on ? "#fff" : "transparent",
              boxShadow: on ? "0 1px 2px rgba(0,0,0,.12)" : undefined,
            }}
          >
            {label}
          </Link>
        );
      })}
    </div>
  );
}

/** fetcher + App Bridge toast for every action result */
export function useTrkAction() {
  const fetcher = useFetcher<TrkActionResult>();
  const shopify = useAppBridge();
  useEffect(() => {
    if (fetcher.state === "idle" && fetcher.data) {
      shopify.toast.show(fetcher.data.message, fetcher.data.ok ? undefined : { isError: true });
    }
  }, [fetcher.state, fetcher.data, shopify]);
  const post = (fields: Record<string, string>) => {
    const fd = new FormData();
    for (const [k, v] of Object.entries(fields)) fd.set(k, v);
    fetcher.submit(fd, { method: "post" });
  };
  const busy = (intent?: string) => fetcher.state !== "idle" && (!intent || fetcher.formData?.get("intent") === intent);
  return { fetcher, post, busy };
}

export const lbl: CSSProperties = { display: "block", fontSize: 13, marginBottom: 4, color: "#303030" };
export const input: CSSProperties = {
  width: "100%",
  boxSizing: "border-box",
  height: 32,
  padding: "0 10px",
  border: "1px solid #8a8a8a",
  borderRadius: 8,
  fontSize: 13,
  background: "#fdfdfd",
};
export const th: CSSProperties = { textAlign: "left", padding: "8px 10px", borderBottom: "1px solid #e3e3e3", fontWeight: 600, whiteSpace: "nowrap", fontSize: 13 };
export const td: CSSProperties = { padding: "8px 10px", borderBottom: "1px solid #f1f1f1", verticalAlign: "top", fontSize: 13 };
export const card: CSSProperties = { border: "1px solid #e3e3e3", borderRadius: 12, padding: 14, background: "#fff" };

export function Field({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <span style={lbl}>{label}</span>
      {children}
      {hint ? <div style={{ fontSize: 12, color: "#616161", marginTop: 4 }}>{hint}</div> : null}
    </div>
  );
}

export function Check({ label, checked, onChange, hint }: { label: string; checked: boolean; onChange: (v: boolean) => void; hint?: string }) {
  return (
    <label style={{ display: "flex", gap: 8, alignItems: "flex-start", marginBottom: 12, fontSize: 13, cursor: "pointer" }}>
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} style={{ marginTop: 2 }} />
      <span>
        {label}
        {hint ? <span style={{ display: "block", fontSize: 12, color: "#616161", marginTop: 2 }}>{hint}</span> : null}
      </span>
    </label>
  );
}

export const fmt = (iso: string, time = true) => {
  if (!iso) return "";
  const d = new Date(iso);
  return Number.isNaN(d.getTime())
    ? ""
    : d.toLocaleString(undefined, time ? { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" } : { month: "short", day: "numeric" });
};

export const TONE: Record<TrkStatus, "success" | "info" | "warning" | "critical" | undefined> = {
  pending: undefined,
  info_received: undefined,
  in_transit: "info",
  last_mile: "info",
  out_for_delivery: "info",
  attempt_fail: "warning",
  delivered: "success",
  exception: "critical",
  returned: "critical",
  expired: "warning",
};

/** Colors for status charts (validated on white). */
export const STATUS_COLOR: Record<TrkStatus, string> = {
  pending: "#b5b5b5",
  info_received: "#8e6bd6",
  in_transit: "#3d8ee6",
  last_mile: "#2fb3c2",
  out_for_delivery: "#16a3a3",
  attempt_fail: "#e8a33d",
  delivered: "#5bb85d",
  exception: "#e0583e",
  returned: "#b0413e",
  expired: "#9a8f6b",
};

export function StatusBadge({ status }: { status: TrkStatus }) {
  return <s-badge tone={TONE[status]}>{TRK_STATUS_LABEL[status]}</s-badge>;
}

export function Kpi({ label, value, hint }: { label: string; value: ReactNode; hint?: string }) {
  return (
    <div style={card}>
      <div style={{ fontSize: 12, color: "#616161" }}>{label}</div>
      <div style={{ fontSize: 22, fontWeight: 600, marginTop: 4 }}>{value}</div>
      {hint ? <div style={{ fontSize: 12, color: "#616161", marginTop: 2 }}>{hint}</div> : null}
    </div>
  );
}

export function Grid({ min = 180, children }: { min?: number; children: ReactNode }) {
  return <div style={{ display: "grid", gridTemplateColumns: `repeat(auto-fill, minmax(${min}px, 1fr))`, gap: 12 }}>{children}</div>;
}

/** Horizontal bars: [{label, value, color?, note?}] */
export function HBars({ rows, unit = "" }: { rows: { label: string; value: number; color?: string; note?: string }[]; unit?: string }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  if (!rows.length) return <div style={{ fontSize: 13, color: "#616161" }}>No data yet.</div>;
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {rows.map((r) => (
        <div key={r.label} style={{ display: "grid", gridTemplateColumns: "140px 1fr 90px", alignItems: "center", gap: 8, fontSize: 13 }}>
          <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={r.label}>
            {r.label}
          </span>
          <span style={{ background: "#f1f1f1", borderRadius: 4, height: 10 }}>
            <span style={{ display: "block", height: 10, borderRadius: 4, width: `${(r.value / max) * 100}%`, background: r.color ?? "#155F56" }} />
          </span>
          <span style={{ textAlign: "right", color: "#303030" }}>
            {r.value}
            {unit}
            {r.note ? <span style={{ color: "#616161" }}> {r.note}</span> : null}
          </span>
        </div>
      ))}
    </div>
  );
}

/** Stacked daily columns (counts per status). */
export function StackedDays({ series, statuses }: { series: Record<string, number | string>[]; statuses: TrkStatus[] }) {
  if (!series.length) return <div style={{ fontSize: 13, color: "#616161" }}>No data yet.</div>;
  const totals = series.map((d) => statuses.reduce((s, k) => s + (Number(d[k]) || 0), 0));
  const max = Math.max(1, ...totals);
  const H = 160;
  return (
    <div>
      <div style={{ display: "flex", alignItems: "flex-end", gap: 2, height: H, borderBottom: "1px solid #e3e3e3" }}>
        {series.map((d, i) => (
          <div
            key={String(d.day)}
            title={`${d.day}: ${totals[i]}`}
            style={{ flex: 1, minWidth: 3, display: "flex", flexDirection: "column-reverse", height: (totals[i] / max) * H }}
          >
            {statuses.map((k) =>
              Number(d[k]) ? <div key={k} style={{ height: `${(Number(d[k]) / totals[i]) * 100}%`, background: STATUS_COLOR[k] }} /> : null,
            )}
          </div>
        ))}
      </div>
      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, color: "#616161", marginTop: 4 }}>
        <span>{String(series[0].day)}</span>
        <span>{String(series[series.length - 1].day)}</span>
      </div>
      <Legend statuses={statuses} />
    </div>
  );
}

export function Legend({ statuses }: { statuses: TrkStatus[] }) {
  return (
    <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 8, fontSize: 12, color: "#303030" }}>
      {statuses.map((k) => (
        <span key={k} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
          <span style={{ width: 10, height: 10, borderRadius: 2, background: STATUS_COLOR[k] }} />
          {TRK_STATUS_LABEL[k]}
        </span>
      ))}
    </div>
  );
}

/** One-row proportion bar. */
export function ShareBar({ parts }: { parts: { key: string; value: number; color: string; label: string }[] }) {
  const total = parts.reduce((s, p) => s + p.value, 0);
  if (!total) return <div style={{ fontSize: 13, color: "#616161" }}>No data yet.</div>;
  return (
    <div>
      <div style={{ display: "flex", height: 14, borderRadius: 7, overflow: "hidden" }}>
        {parts.filter((p) => p.value).map((p) => (
          <div key={p.key} title={`${p.label}: ${p.value}`} style={{ width: `${(p.value / total) * 100}%`, background: p.color }} />
        ))}
      </div>
      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 8, fontSize: 12 }}>
        {parts.map((p) => (
          <span key={p.key} style={{ display: "inline-flex", alignItems: "center", gap: 4 }}>
            <span style={{ width: 10, height: 10, borderRadius: 2, background: p.color }} />
            {p.label} {p.value} ({Math.round((p.value / total) * 100)}%)
          </span>
        ))}
      </div>
    </div>
  );
}
