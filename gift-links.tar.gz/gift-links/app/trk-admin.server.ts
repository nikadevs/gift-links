import type { authenticate } from "./shopify.server";

/**
 * Tracking — storefront switch. app-owned JSON metafield wc_trk.config on the
 * AppInstallation: {enabled, endpoint, pageHandle}. The Gift Links app embed
 * prints the tracking page code on /pages/<pageHandle> only when enabled.
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];
export type TrkPageConfig = { enabled: boolean; endpoint: string; pageHandle: string; updatedAt: string };

export async function loadTrkPageConfig(admin: AdminGraphql) {
  const res = await admin.graphql(`#graphql
    query WcTrkCfg { currentAppInstallation { id metafield(namespace: "wc_trk", key: "config") { value } } }`);
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let v: Partial<TrkPageConfig> = {};
  try {
    v = JSON.parse(inst?.metafield?.value || "{}");
  } catch {
    v = {};
  }
  return {
    installationId: inst?.id ?? "",
    config: {
      enabled: v.enabled === true,
      endpoint: String(v.endpoint ?? ""),
      pageHandle: String(v.pageHandle ?? "track-order"),
      updatedAt: String(v.updatedAt ?? ""),
    } as TrkPageConfig,
  };
}

export async function saveTrkPageConfig(admin: AdminGraphql, installationId: string, config: TrkPageConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcTrkCfgSave($m: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $m) { userErrors { message } } }`,
    {
      variables: {
        m: [{ ownerId: installationId, namespace: "wc_trk", key: "config", type: "json", value: JSON.stringify(config) }],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errs = json.data?.metafieldsSet?.userErrors ?? [];
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

/** Finds the tracking page; creates it (published, body = mount point) when missing. */
export async function ensureTrackingPage(admin: AdminGraphql, handle: string) {
  const res = await admin.graphql(
    `#graphql
    query WcTrkPage($q: String!) { pages(first: 1, query: $q) { nodes { id handle title isPublished } } }`,
    { variables: { q: `handle:${handle}` } },
  );
  const json = (await res.json()) as {
    data?: { pages?: { nodes: { id: string; handle: string; title: string; isPublished: boolean }[] } };
  };
  const found = json.data?.pages?.nodes.find((p) => p.handle === handle);
  if (found) return { created: false, page: found };
  const cr = await admin.graphql(
    `#graphql
    mutation WcTrkPageCreate($p: PageCreateInput!) {
      pageCreate(page: $p) { page { id handle title isPublished } userErrors { field message } }
    }`,
    {
      variables: {
        p: { title: "Track your order", handle, body: '<div id="wc-trk"></div>', isPublished: true },
      },
    },
  );
  const cj = (await cr.json()) as {
    data?: {
      pageCreate?: {
        page?: { id: string; handle: string; title: string; isPublished: boolean } | null;
        userErrors: { message: string }[];
      };
    };
  };
  const errs = cj.data?.pageCreate?.userErrors ?? [];
  if (errs.length || !cj.data?.pageCreate?.page) throw new Error(errs.map((e) => e.message).join("; ") || "Page not created");
  return { created: true, page: cj.data.pageCreate.page };
}

/** Is there a page template "page.<suffix>.json" in the published theme? Which template does the page use? */
export async function pageTemplateState(admin: AdminGraphql, handle: string, suffix: string) {
  const res = await admin.graphql(
    `#graphql
    query WcTrkTpl($q: String!, $files: [String!]) {
      pages(first: 1, query: $q) { nodes { id handle templateSuffix isPublished } }
      themes(first: 1, roles: [MAIN]) { nodes { id name files(first: 1, filenames: $files) { nodes { filename } } } }
    }`,
    { variables: { q: `handle:${handle}`, files: [`templates/page.${suffix}.json`] } },
  );
  const json = (await res.json()) as {
    data?: {
      pages?: { nodes: { id: string; handle: string; templateSuffix: string | null; isPublished: boolean }[] };
      themes?: { nodes: { id: string; name: string; files: { nodes: { filename: string }[] } }[] };
    };
  };
  const page = json.data?.pages?.nodes.find((p) => p.handle === handle) ?? null;
  const theme = json.data?.themes?.nodes[0];
  return {
    page,
    themeId: theme?.id.split("/").pop() ?? "",
    themeName: theme?.name ?? "",
    templateExists: !!theme?.files.nodes.length,
  };
}

export async function setPageTemplate(admin: AdminGraphql, pageId: string, suffix: string) {
  const res = await admin.graphql(
    `#graphql
    mutation WcTrkTplSet($id: ID!, $p: PageUpdateInput!) { pageUpdate(id: $id, page: $p) { page { id templateSuffix } userErrors { message } } }`,
    { variables: { id: pageId, p: { templateSuffix: suffix } } },
  );
  const json = (await res.json()) as { data?: { pageUpdate?: { userErrors: { message: string }[] } } };
  const errs = json.data?.pageUpdate?.userErrors ?? [];
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}
