import type { authenticate } from "./shopify.server";
import { normalizeSb, type SbConfig } from "./sb.shared";

/**
 * Sale Banner: one app-owned JSON metafield on the AppInstallation
 * (wc_sb.config), read by the theme app block "Sale Banner".
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export type SbProduct = { id: string; title: string; handle: string; image: string };

export async function loadSbConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcSbConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_sb", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let parsed: unknown = {};
  try {
    parsed = JSON.parse(inst?.metafield?.value || "{}");
  } catch {
    parsed = {};
  }
  return { installationId: inst?.id ?? "", config: normalizeSb(parsed) };
}

export async function saveSbConfig(admin: AdminGraphql, installationId: string, config: SbConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcSbSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_sb", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}

/** All ACTIVE products (title order), small thumbnail. */
export async function loadActiveProducts(admin: AdminGraphql): Promise<SbProduct[]> {
  const out: SbProduct[] = [];
  let after: string | null = null;
  for (let page = 0; page < 20; page++) {
    const res = await admin.graphql(
      `#graphql
      query WcSbProducts($after: String) {
        products(first: 250, after: $after, query: "status:active", sortKey: TITLE) {
          pageInfo { hasNextPage endCursor }
          nodes {
            legacyResourceId
            title
            handle
            featuredMedia { preview { image { url(transform: { maxWidth: 80, maxHeight: 80 }) } } }
          }
        }
      }`,
      { variables: { after } },
    );
    const json = (await res.json()) as {
      data?: {
        products?: {
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
          nodes: {
            legacyResourceId: string;
            title: string;
            handle: string;
            featuredMedia?: { preview?: { image?: { url?: string } | null } | null } | null;
          }[];
        };
      };
      errors?: { message: string }[];
    };
    if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
    const p = json.data?.products;
    if (!p) break;
    for (const n of p.nodes)
      out.push({ id: String(n.legacyResourceId), title: n.title, handle: n.handle, image: n.featuredMedia?.preview?.image?.url || "" });
    if (!p.pageInfo.hasNextPage) break;
    after = p.pageInfo.endCursor;
  }
  return out;
}
