import { authenticate } from "./shopify.server";
import { loadShopDomain } from "./campaigns.server";
import { ensureTrackingPage, loadTrkPageConfig, pageTemplateState, saveTrkPageConfig, setPageTemplate } from "./trk-admin.server";
import { addLog, getTrkSettings, loadShipments, saveShipments, saveTrkSettings, withShop } from "./trk-store.server";
import { applyOutputs, importOrders, isTickRunning, paypalTest, refreshOne, runTick, sendOmnisendTests } from "./trk.server";
import { yunConfigured, yunTrack } from "./trk-yun.server";
import { TRK_STATUS_LABEL, normalizeTrkSettings } from "./trk.shared";

/**
 * All Tracking admin actions (every sub-page posts here through its own action).
 */
export type TrkActionResult = { ok: boolean; intent: string; message: string; test?: unknown };

export const TRK_TEMPLATE_SUFFIX = "track-order";

export async function handleTrkAction(request: Request): Promise<TrkActionResult> {
  const { admin, session } = await authenticate.admin(request);
  const shop = session.shop;
  const form = await request.formData();
  const intent = String(form.get("intent") || "");
  const done = (ok: boolean, message: string, extra: Partial<TrkActionResult> = {}): TrkActionResult => ({ ok, intent, message, ...extra });
  try {
    if (intent === "save") {
      const cur = await getTrkSettings(shop);
      const patch = JSON.parse(String(form.get("settings") || "{}")) as Record<string, unknown>;
      // secrets: empty = keep, "__clear__" = remove
      for (const k of ["yunAppSecret", "yunSourceKey", "omnisendKey", "paypalSecret"] as const) {
        if (!(k in patch)) continue;
        const v = String(patch[k] ?? "");
        patch[k] = v === "__clear__" ? "" : v ? v : cur[k];
      }
      const next = normalizeTrkSettings({ ...cur, ...patch });
      await saveTrkSettings(shop, next);
      // page handle changed → keep the storefront config in sync
      const { installationId, config } = await loadTrkPageConfig(admin);
      if (config.pageHandle !== next.pageHandle && installationId) {
        await saveTrkPageConfig(admin, installationId, { ...config, pageHandle: next.pageHandle, updatedAt: new Date().toISOString() });
      }
      return done(true, "Saved");
    }
    if (intent === "poll") {
      const cur = await getTrkSettings(shop);
      const on = form.get("on") === "1";
      if (on && !yunConfigured(cur)) return done(false, "Enter the YunExpress keys first (Settings → Integration).");
      await saveTrkSettings(shop, { ...cur, pollEnabled: on });
      if (on) void runTick(shop).catch(() => {});
      return done(true, on ? "Automatic tracking is on — first sync started" : "Automatic tracking is off");
    }
    if (intent === "run") {
      if (isTickRunning(shop)) return done(false, "A sync is already running");
      void runTick(shop, { force: true }).catch((e) => console.warn("[wc-trk] run:", (e as Error).message));
      return done(true, "Sync started — reload in a minute to see the result");
    }
    if (intent === "import") {
      const s = await getTrkSettings(shop);
      const r = await withShop(shop, () => importOrders(shop, admin as never, s, s.importDays));
      await addLog(shop, [{ at: new Date().toISOString(), kind: "import", ok: true, text: `${r.added} new numbers, ${r.total} total` }]);
      return done(true, `Imported: ${r.added} new tracking numbers (${r.total} total).`);
    }
    if (intent === "test") {
      const s = await getTrkSettings(shop);
      const number = String(form.get("number") || "").trim();
      if (!number) return done(false, "Enter a tracking number");
      if (!yunConfigured(s)) return done(false, "Enter the YunExpress keys first");
      const r = await yunTrack(s, number, true);
      const rawText = JSON.stringify(r.raw ?? null);
      return done(true, r.found ? `Found: ${r.events.length} scans` : "YunExpress returned no data for this number", {
        test: { ...r, raw: rawText.length > 6000 ? `${rawText.slice(0, 6000)}…` : rawText },
      });
    }
    if (intent === "refresh") {
      const number = String(form.get("number") || "").trim().toUpperCase();
      const msg = await withShop(shop, async () => {
        const s = await getTrkSettings(shop);
        const m = await loadShipments(shop);
        const rec = m.get(number);
        if (!rec) return "Unknown number";
        if (rec.source === "none") rec.source = "yunexpress";
        await refreshOne(s, rec);
        const log: Parameters<typeof addLog>[1] = [];
        const domain = await loadShopDomain(admin);
        await applyOutputs(admin as never, s, rec, domain, log);
        await saveShipments(shop);
        await addLog(shop, log);
        return rec.lastError ? `Error: ${rec.lastError}` : `Updated: ${TRK_STATUS_LABEL[rec.status]}`;
      });
      return done(!msg.startsWith("Error") && msg !== "Unknown number", msg);
    }
    if (intent === "omnisendTest") {
      const s = await getTrkSettings(shop);
      const email = String(form.get("email") || "").trim();
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return done(false, "Enter a valid email");
      const domain = await loadShopDomain(admin);
      const m = await loadShipments(shop);
      const sample = [...m.values()].find((r) => r.lastMileNumber && r.events.length) ?? null;
      const sent = await sendOmnisendTests(s, email, domain, sample ? { ...sample, email } : null, form.get("admin") === "1");
      await addLog(shop, [{ at: new Date().toISOString(), kind: "omnisend", ok: true, text: `test events → ${email}: ${sent.join(", ")}` }]);
      return done(true, `Sent ${sent.length} test event(s) to ${email}. They now appear in Omnisend → Automation → custom event triggers.`);
    }
    if (intent === "paypalTest") {
      const s = await getTrkSettings(shop);
      const r = await paypalTest(admin as never, s);
      return done(
        true,
        r.transactionId
          ? `PayPal keys work. Latest PayPal payment in Shopify: order ${r.order}, transaction ${r.transactionId}. Nothing was sent.`
          : "PayPal keys work. No PayPal payment found in the last 25 orders.",
      );
    }
    if (intent === "page") {
      const on = form.get("on") === "1";
      const s = await getTrkSettings(shop);
      await saveTrkSettings(shop, s); // creates the shop folder (public lookup only answers for it)
      const { installationId, config } = await loadTrkPageConfig(admin);
      let created = false;
      let tplNote = "";
      if (on) {
        created = (await ensureTrackingPage(admin, s.pageHandle)).created;
        const st = await pageTemplateState(admin, s.pageHandle, TRK_TEMPLATE_SUFFIX);
        if (st.page && st.templateExists && st.page.templateSuffix !== TRK_TEMPLATE_SUFFIX) {
          await setPageTemplate(admin, st.page.id, TRK_TEMPLATE_SUFFIX);
          tplNote = ` Template “${TRK_TEMPLATE_SUFFIX}” assigned.`;
        }
      }
      await saveTrkPageConfig(admin, installationId, {
        ...config,
        enabled: on,
        endpoint: (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, ""),
        pageHandle: s.pageHandle,
        updatedAt: new Date().toISOString(),
      });
      return done(true, on ? `${created ? "Tracking page created and turned on." : "Tracking page turned on."}${tplNote}` : "Tracking page turned off");
    }
    if (intent === "useTemplate") {
      const s = await getTrkSettings(shop);
      const st = await pageTemplateState(admin, s.pageHandle, TRK_TEMPLATE_SUFFIX);
      if (!st.page) return done(false, "Turn the tracking page on first (it creates the page).");
      if (!st.templateExists) return done(false, `Template “page.${TRK_TEMPLATE_SUFFIX}” not found in the published theme — create it in the theme editor first.`);
      await setPageTemplate(admin, st.page.id, TRK_TEMPLATE_SUFFIX);
      return done(true, `Page /pages/${s.pageHandle} now uses template “${TRK_TEMPLATE_SUFFIX}”.`);
    }
    return done(false, "Unknown action");
  } catch (e) {
    return done(false, (e as Error).message.slice(0, 400));
  }
}
