import type { authenticate } from "./shopify.server";
import { normalizeCs, type CsConfig } from "./cs.shared";

/**
 * Cart Summary: one app-owned JSON metafield on the AppInstallation
 * (wc_cs.config). The Gift Links app embed prints the storefront code only when
 * it is enabled — no separate app embed (Roman's rule).
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export async function loadCsConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcCsConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_cs", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let parsed: unknown = {};
  try {
    parsed = JSON.parse(inst?.metafield?.value || "{}");
  } catch {
    parsed = {};
  }
  return { installationId: inst?.id ?? "", config: normalizeCs(parsed) };
}

export async function saveCsConfig(admin: AdminGraphql, installationId: string, config: CsConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcCsSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_cs", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}
