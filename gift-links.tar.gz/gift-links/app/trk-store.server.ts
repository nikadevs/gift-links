/**
 * Tracking — file storage on the app server (auto-deploy never touches data/).
 *   $WC_DATA_DIR/trk/<shop>/settings.json   carrier/Omnisend/PayPal keys + switches (never sent to the browser)
 *   $WC_DATA_DIR/trk/<shop>/shipments.json  one record per tracking number
 *   $WC_DATA_DIR/trk/<shop>/log.json        last 400 actions (sync, Shopify events, emails, PayPal)
 */
import fs from "node:fs/promises";
import path from "node:path";
import { normalizeTrkSettings, type TrkSettings, type TrkShipment } from "./trk.shared";

const ROOT = () => path.resolve(process.env.WC_DATA_DIR || path.join(process.cwd(), "data"), "trk");
const safe = (shop: string) => shop.replace(/[^a-z0-9.-]/gi, "_");
const dir = (shop: string) => path.join(ROOT(), safe(shop));

async function readJson<T>(file: string, fallback: T): Promise<T> {
  try {
    return JSON.parse(await fs.readFile(file, "utf8")) as T;
  } catch {
    return fallback;
  }
}

async function writeJson(file: string, data: unknown) {
  await fs.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fs.writeFile(tmp, JSON.stringify(data));
  await fs.rename(tmp, file);
}

export async function getTrkSettings(shop: string): Promise<TrkSettings> {
  return normalizeTrkSettings(await readJson(path.join(dir(shop), "settings.json"), {}));
}

export async function saveTrkSettings(shop: string, s: TrkSettings) {
  await writeJson(path.join(dir(shop), "settings.json"), { ...s, updatedAt: new Date().toISOString() });
}

// shipments: kept in memory per shop, written after each change batch
const mem = new Map<string, Map<string, TrkShipment>>();
const locks = new Map<string, Promise<unknown>>();

/** Serialise all read-modify-write work for one shop (scheduler + admin buttons). */
export async function withShop<T>(shop: string, fn: () => Promise<T>): Promise<T> {
  const prev = locks.get(shop) ?? Promise.resolve();
  let release: () => void = () => {};
  const next = new Promise<void>((r) => (release = r));
  locks.set(shop, prev.then(() => next));
  await prev.catch(() => {});
  try {
    return await fn();
  } finally {
    release();
  }
}

export async function loadShipments(shop: string): Promise<Map<string, TrkShipment>> {
  let m = mem.get(shop);
  if (m) return m;
  const list = await readJson<TrkShipment[]>(path.join(dir(shop), "shipments.json"), []);
  m = new Map(list.map((s) => [s.number.toUpperCase(), s]));
  mem.set(shop, m);
  return m;
}

export async function saveShipments(shop: string) {
  const m = await loadShipments(shop);
  await writeJson(path.join(dir(shop), "shipments.json"), [...m.values()]);
}

export type TrkLog = { at: string; kind: string; number?: string; order?: string; ok: boolean; text: string };

export async function addLog(shop: string, entries: TrkLog[]) {
  if (!entries.length) return;
  const file = path.join(dir(shop), "log.json");
  const cur = await readJson<TrkLog[]>(file, []);
  await writeJson(file, [...entries.reverse(), ...cur].slice(0, 400));
}

export async function getLog(shop: string): Promise<TrkLog[]> {
  return readJson<TrkLog[]>(path.join(dir(shop), "log.json"), []);
}

export async function getState(shop: string) {
  return readJson<{ lastImportAt: string; lastTickAt: string; lastError: string }>(
    path.join(dir(shop), "state.json"),
    { lastImportAt: "", lastTickAt: "", lastError: "" },
  );
}

export async function setState(shop: string, patch: Partial<{ lastImportAt: string; lastTickAt: string; lastError: string }>) {
  const cur = await getState(shop);
  await writeJson(path.join(dir(shop), "state.json"), { ...cur, ...patch });
}

/** Shops that have a tracking folder (the public lookup accepts only these). */
export async function trkShopExists(shop: string): Promise<boolean> {
  try {
    await fs.access(path.join(dir(shop), "settings.json"));
    return true;
  } catch {
    return false;
  }
}
