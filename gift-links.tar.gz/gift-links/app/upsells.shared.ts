/** Checkbox Upsell — types and pure helpers shared by server and UI code. */

export type UpsellOffer = {
  id: string;
  /** internal name, not shown to shoppers */
  name: string;
  active: boolean;

  /** the product added when the box is ticked */
  productId: string; // numeric product id
  productHandle: string; // storefront looks the live price up by handle
  productTitle: string;
  variantId: string; // numeric variant id
  variantTitle: string;
  image: string; // admin preview only — storefront uses the live product image

  /** text next to the checkbox */
  title: string;
  /** small line under the title */
  subtitle: string;
  /** optional text for the ⓘ popup next to the price (like AXE "Popup") */
  infoText: string;
  /** box is ticked when the page opens */
  precheck: boolean;
  /** lower number = shown first */
  order: number;

  /** where the checkbox appears */
  triggerAll: boolean;
  productIds: string[];
  productTitles: string[];
  collectionIds: string[];
  collectionTitles: string[];

  /** "one" = always 1, "match" = same quantity as the main product */
  quantityMode: "one" | "match";
  /** don't add again if this upsell is already in the cart */
  oncePerCart: boolean;

  updatedAt: string;
};

export type UpsellConfig = { version: 1; offers: UpsellOffer[] };

export const UPSELL_NAMESPACE = "wc_upsell";
export const UPSELL_KEY = "config";

export const blankOffer = (): UpsellOffer => ({
  id: "new",
  name: "",
  active: true,
  productId: "",
  productHandle: "",
  productTitle: "",
  variantId: "",
  variantTitle: "",
  image: "",
  title: "",
  subtitle: "",
  infoText: "",
  precheck: false,
  order: 0,
  triggerAll: false,
  productIds: [],
  productTitles: [],
  collectionIds: [],
  collectionTitles: [],
  quantityMode: "one",
  oncePerCart: true,
  updatedAt: "",
});

export function offerTriggerSummary(o: UpsellOffer) {
  if (o.triggerAll) return "All products";
  const parts: string[] = [];
  if (o.productIds.length)
    parts.push(
      `${o.productIds.length} product${o.productIds.length === 1 ? "" : "s"}`,
    );
  if (o.collectionIds.length)
    parts.push(
      `${o.collectionIds.length} collection${o.collectionIds.length === 1 ? "" : "s"}`,
    );
  return parts.join(" + ") || "Nowhere yet";
}
