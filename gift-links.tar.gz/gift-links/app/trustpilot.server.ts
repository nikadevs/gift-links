import { promises as fs } from "node:fs";
import path from "node:path";
import { execFile } from "node:child_process";
import { promisify } from "node:util";
import { PROFILE, parseTrustpilot, parseTrustpilotApi, normalizeTrustpilot, type TrustpilotData } from "./trustpilot-parser";
const file = path.resolve(process.env.WC_DATA_DIR || "data", "trustpilot", "woodencrew.json");
const DAY = 86400000;
let pending: Promise<TrustpilotData | null> | undefined;
let lastAttempt = 0;
let error = "";
export async function readTrustpilot(): Promise<TrustpilotData | null> {
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") console.warn("[trustpilot] Cache read failed", e);
    if ((e as NodeJS.ErrnoException).code === "ENOENT") {
      try {
        // Public reviews read from the brand's browser page for the initial launch.
        // Preserve the real capture date; never present a seed as a new scrape.
        const seed = await fs.readFile(path.join(process.cwd(), "app", "trustpilot-initial.json"), "utf8");
        const data: TrustpilotData = JSON.parse(seed);
        await fs.mkdir(path.dirname(file), { recursive: true });
        await fs.writeFile(`${file}.tmp`, seed);
        await fs.rename(`${file}.tmp`, file);
        return data;
      } catch { /* No initial snapshot in isolated tests or other installs. */ }
    }
    return null;
  }
}
export function trustpilotError() { return error; }
export async function importTrustpilotSnapshot(raw: string) {
  if (raw.length > 200000) throw new Error("Snapshot is too large.");
  const input = JSON.parse(raw) as TrustpilotData;
  if (input.profile !== PROFILE || !Array.isArray(input.reviews) || input.reviews.length !== 5) throw new Error("Import exactly five public WoodenCrew reviews.");
  const capturedAt = Date.parse(input.updatedAt);
  if (!Number.isFinite(capturedAt) || Math.abs(Date.now() - capturedAt) > 15 * 60000) throw new Error("Capture a fresh snapshot from the Trustpilot page (within 15 minutes).");
  if (input.reviews.some(r => r.rating !== 5 || typeof r.author !== "string" || typeof r.text !== "string" || r.text.length > 15000 || typeof r.id !== "string" || Date.parse(r.date) > Date.now() + 60000)) throw new Error("Invalid five-star review snapshot.");
  const data = normalizeTrustpilot({ trustScore: input.score, numberOfReviews: input.count }, input.reviews.map(r => ({ ...r, consumer: { displayName: r.author }, dates: { publishedDate: r.date } })));
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(`${file}.import.tmp`, JSON.stringify(data));
  await fs.rename(`${file}.import.tmp`, file);
  error = "";
  return data;
}
export async function refreshTrustpilot(force = false): Promise<TrustpilotData | null> {
  if (pending) return pending;
  pending = (async () => {
    const cached = await readTrustpilot();
    if (!force && cached && Date.now() - Date.parse(cached.updatedAt) < DAY) return cached;
    if (!force && Date.now() - lastAttempt < 3600000) return cached;
    lastAttempt = Date.now();
    try {
      let data: TrustpilotData;
      if (process.env.WC_TRUSTPILOT_API_KEY) {
        const api = "https://api.trustpilot.com/v1/business-units/664d1191ce1aed878ee8d822";
        const results = await Promise.all([api, `${api}/reviews?stars=5&orderBy=createdat.desc&perPage=20`].map(async url => {
          const res = await fetch(url, { headers: { apikey: process.env.WC_TRUSTPILOT_API_KEY! }, signal: AbortSignal.timeout(20000) });
          if (!res.ok) throw new Error(`Trustpilot API HTTP ${res.status}`);
          return res.json();
        }));
        data = parseTrustpilotApi(results[0], results[1]);
      } else {
      try {
      const pages = await Promise.all([PROFILE, `${PROFILE}?stars=5&sort=recency`].map(async url => {
        const res = await fetch(url, { headers: { "User-Agent": "WoodenCrew-Reviews/1.0", "Accept-Language": "en-US,en;q=0.9" }, signal: AbortSignal.timeout(20000) });
        if (!res.ok) throw new Error(`Trustpilot HTTP ${res.status}`);
        return res.text();
      }));
      data = parseTrustpilot(pages[0], pages[1]);
      } catch (e) {
        if (process.platform !== "linux" || process.env.WC_TRUSTPILOT_BROWSER === "off") throw e;
        const result = await promisify(execFile)(process.execPath, [path.resolve("app/trustpilot-browser.mjs")], { timeout: 90000, maxBuffer: 8 * 1024 * 1024 });
        data = parseTrustpilot(result.stdout, result.stdout);
      }
      }
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(`${file}.tmp`, JSON.stringify(data));
      await fs.rename(`${file}.tmp`, file);
      error = "";
      return data;
    } catch (e) { error = (e as Error).message; console.warn("[trustpilot]", error); return cached; }
  })();
  try { return await pending; } finally { pending = undefined; }
}
declare global {
  // eslint-disable-next-line no-var
  var wcTrustpilotTimer: NodeJS.Timeout | undefined;
}
export function startTrustpilotScheduler() {
  if (global.wcTrustpilotTimer || process.env.WC_TRUSTPILOT_SCHEDULER === "off") return;
  void refreshTrustpilot();
  global.wcTrustpilotTimer = setInterval(() => void refreshTrustpilot(), 60000);
  global.wcTrustpilotTimer.unref();
}
