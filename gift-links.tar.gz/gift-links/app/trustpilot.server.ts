import { promises as fs } from "node:fs";
import path from "node:path";
import { PROFILE, parseTrustpilot, type TrustpilotData } from "./trustpilot-parser";
const file = path.resolve(process.env.WC_DATA_DIR || "data", "trustpilot", "woodencrew.json");
const DAY = 86400000;
let pending: Promise<TrustpilotData | null> | undefined;
let lastAttempt = 0;
let error = "";
export async function readTrustpilot(): Promise<TrustpilotData | null> {
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch (e) {
    if ((e as NodeJS.ErrnoException).code !== "ENOENT") console.warn("[trustpilot] Cache read failed", e);
    return null;
  }
}
export function trustpilotError() { return error; }
export async function refreshTrustpilot(): Promise<TrustpilotData | null> {
  if (pending) return pending;
  pending = (async () => {
    const cached = await readTrustpilot();
    if (cached && Date.now() - Date.parse(cached.updatedAt) < DAY) return cached;
    if (Date.now() - lastAttempt < 3600000) return cached;
    lastAttempt = Date.now();
    try {
      const pages = await Promise.all([PROFILE, `${PROFILE}?stars=5&sort=recency`].map(async url => {
        const res = await fetch(url, { headers: { "User-Agent": "WoodenCrew-Reviews/1.0", "Accept-Language": "en-US,en;q=0.9" }, signal: AbortSignal.timeout(20000) });
        if (!res.ok) throw new Error(`Trustpilot HTTP ${res.status}`);
        return res.text();
      }));
      const data = parseTrustpilot(pages[0], pages[1]);
      await fs.mkdir(path.dirname(file), { recursive: true });
      await fs.writeFile(`${file}.tmp`, JSON.stringify(data));
      await fs.rename(`${file}.tmp`, file);
      error = "";
      return data;
    } catch (e) { error = (e as Error).message; console.warn("[trustpilot]", error); return cached; }
  })();
  try { return await pending; } finally { pending = undefined; }
}
declare global {
  // eslint-disable-next-line no-var
  var wcTrustpilotTimer: NodeJS.Timeout | undefined;
}
export function startTrustpilotScheduler() {
  if (global.wcTrustpilotTimer || process.env.WC_TRUSTPILOT_SCHEDULER === "off") return;
  void refreshTrustpilot();
  global.wcTrustpilotTimer = setInterval(() => void refreshTrustpilot(), 60000);
  global.wcTrustpilotTimer.unref();
}
