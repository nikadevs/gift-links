/**
 * Checkbox Upsell — sales statistics (like AXE's Revenue / Conversions).
 *
 * How it works
 *  - One Bulk Operation reads the last 60 days of orders (Shopify gives apps
 *    with read_orders the last 60 days) with their line items.
 *  - An upsell line is a line that carries our hidden property `_wc_upsell`
 *    OR AXE's `__UpsellCheckboxId` (so AXE history is counted too).
 *  - Result is aggregated per day and per upsell variant and cached in the
 *    app-owned metafield `wc_upsell.stats` (never read by the storefront).
 *  - The list page refreshes the cache when it is older than STALE_MS, and
 *    on demand ("Refresh").
 */

type AdminGraphql = {
  graphql: (
    query: string,
    options?: { variables?: Record<string, unknown> },
  ) => Promise<Response>;
};

export const STATS_WINDOW_DAYS = 60;
const STALE_MS = 6 * 60 * 60 * 1000;
const RUNNING_TIMEOUT_MS = 20 * 60 * 1000;

/** per upsell variant: [lines, revenue] */
type DayUp = Record<string, [number, number]>;
export type StatsDay = { d: string; orders: number; sales: number; up: DayUp };

export type UpsellStats = {
  version: 1;
  status: "idle" | "running" | "error" | "no_access";
  opId?: string;
  startedAt?: string;
  computedAt?: string;
  error?: string;
  currency?: string;
  windowDays: number;
  days: StatsDay[];
};

const empty = (): UpsellStats => ({
  version: 1,
  status: "idle",
  windowDays: STATS_WINDOW_DAYS,
  days: [],
});

async function gql<T>(
  admin: AdminGraphql,
  query: string,
  variables?: Record<string, unknown>,
): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: unknown };
  if (json.errors) throw new Error(JSON.stringify(json.errors).slice(0, 300));
  return json.data as T;
}

async function load(admin: AdminGraphql) {
  const data = await gql<{
    currentAppInstallation?: {
      id: string;
      metafield?: { value?: string | null } | null;
    };
  }>(
    admin,
    `#graphql
    query WcUpsellStatsCfg {
      currentAppInstallation {
        id
        metafield(namespace: "wc_upsell", key: "stats") { value }
      }
    }`,
  );
  const inst = data.currentAppInstallation;
  let stats = empty();
  if (inst?.metafield?.value) {
    try {
      const p = JSON.parse(inst.metafield.value);
      if (p && Array.isArray(p.days)) stats = p;
    } catch {
      // corrupted cache — rebuild
    }
  }
  return { installationId: inst?.id ?? "", stats };
}

async function save(admin: AdminGraphql, ownerId: string, stats: UpsellStats) {
  const data = await gql<{
    metafieldsSet?: { userErrors: { message: string }[] };
  }>(
    admin,
    `#graphql
    mutation WcUpsellStatsSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      metafields: [
        {
          ownerId,
          namespace: "wc_upsell",
          key: "stats",
          type: "json",
          value: JSON.stringify(stats),
        },
      ],
    },
  );
  const errs = data.metafieldsSet?.userErrors ?? [];
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

const isAccessError = (msg: string) =>
  /access denied|read_orders|not approved|access scope|ACCESS_DENIED/i.test(
    msg,
  );

async function start(admin: AdminGraphql, ownerId: string, prev: UpsellStats) {
  const since = new Date(Date.now() - STATS_WINDOW_DAYS * 86400000)
    .toISOString()
    .slice(0, 10);
  const query = `{
    orders(query: "created_at:>=${since} AND -status:cancelled") {
      edges { node {
        id createdAt test
        subtotalPriceSet { shopMoney { amount currencyCode } }
        lineItems { edges { node {
          quantity
          customAttributes { key value }
          variant { id }
          discountedTotalSet { shopMoney { amount } }
        } } }
      } }
    }
  }`;
  let next: UpsellStats;
  try {
    const data = await gql<{
      bulkOperationRunQuery?: {
        bulkOperation?: { id: string } | null;
        userErrors: { message: string }[];
      };
    }>(
      admin,
      `#graphql
      mutation WcUpsellStatsRun($query: String!) {
        bulkOperationRunQuery(query: $query) {
          bulkOperation { id status }
          userErrors { field message }
        }
      }`,
      { query },
    );
    const r = data.bulkOperationRunQuery;
    const err = (r?.userErrors ?? []).map((e) => e.message).join("; ");
    if (err || !r?.bulkOperation?.id) {
      next = {
        ...prev,
        status: isAccessError(err) ? "no_access" : "error",
        error: err || "Bulk operation was not created",
      };
    } else {
      next = {
        ...prev,
        status: "running",
        opId: r.bulkOperation.id,
        startedAt: new Date().toISOString(),
        error: undefined,
      };
    }
  } catch (e) {
    const msg = (e as Error).message;
    next = { ...prev, status: isAccessError(msg) ? "no_access" : "error", error: msg };
  }
  await save(admin, ownerId, next);
  return next;
}

/** Parses the bulk JSONL into per-day aggregates. Exported for tests. */
export function aggregate(jsonl: string) {
  type O = { d: string; sales: number; test: boolean };
  const orders = new Map<string, O>();
  const lines: { parent: string; variant: string; rev: number }[] = [];
  let currency: string | undefined;

  for (const raw of jsonl.split("\n")) {
    if (!raw.trim()) continue;
    let row: Record<string, unknown>;
    try {
      row = JSON.parse(raw);
    } catch {
      continue;
    }
    const parent = row.__parentId as string | undefined;
    if (!parent) {
      const sp = (row.subtotalPriceSet as { shopMoney?: { amount?: string; currencyCode?: string } })
        ?.shopMoney;
      currency = currency || sp?.currencyCode;
      orders.set(String(row.id), {
        d: String(row.createdAt ?? "").slice(0, 10),
        sales: Number(sp?.amount ?? 0),
        test: Boolean(row.test),
      });
      continue;
    }
    const attrs = (row.customAttributes as { key: string; value: string }[]) ?? [];
    const isUpsell = attrs.some(
      (a) => a.key === "_wc_upsell" || a.key === "__UpsellCheckboxId",
    );
    const vid = String((row.variant as { id?: string } | null)?.id ?? "").replace(/\D/g, "");
    if (!isUpsell || !vid) continue;
    const rev = Number(
      (row.discountedTotalSet as { shopMoney?: { amount?: string } })?.shopMoney?.amount ?? 0,
    );
    lines.push({ parent, variant: vid, rev });
  }

  const byDay = new Map<string, StatsDay>();
  for (const o of orders.values()) {
    if (o.test || !o.d) continue;
    const day = byDay.get(o.d) ?? { d: o.d, orders: 0, sales: 0, up: {} };
    day.orders += 1;
    day.sales = Math.round((day.sales + o.sales) * 100) / 100;
    byDay.set(o.d, day);
  }
  for (const l of lines) {
    const o = orders.get(l.parent);
    if (!o || o.test) continue;
    const day = byDay.get(o.d);
    if (!day) continue;
    const cur = day.up[l.variant] ?? [0, 0];
    day.up[l.variant] = [cur[0] + 1, Math.round((cur[1] + l.rev) * 100) / 100];
  }
  const days = [...byDay.values()].sort((a, b) => a.d.localeCompare(b.d));
  return { days, currency };
}

async function finish(admin: AdminGraphql, ownerId: string, prev: UpsellStats) {
  const data = await gql<{
    bulkOperation?: {
      status: string;
      errorCode?: string | null;
      url?: string | null;
    } | null;
  }>(
    admin,
    `#graphql
    query WcUpsellStatsOp($id: ID!) {
      bulkOperation(id: $id) { id status errorCode url objectCount completedAt }
    }`,
    { id: prev.opId },
  );
  const op = data.bulkOperation;
  const started = prev.startedAt ? Date.parse(prev.startedAt) : 0;
  if (!op || ["CREATED", "RUNNING"].includes(op.status)) {
    if (Date.now() - started > RUNNING_TIMEOUT_MS) {
      const next: UpsellStats = { ...prev, status: "error", error: "Timed out collecting orders" };
      await save(admin, ownerId, next);
      return next;
    }
    return prev; // still running
  }
  if (op.status !== "COMPLETED") {
    const next: UpsellStats = {
      ...prev,
      status: "error",
      error: `Bulk operation ${op.status}${op.errorCode ? ` (${op.errorCode})` : ""}`,
    };
    await save(admin, ownerId, next);
    return next;
  }
  let text = "";
  if (op.url) {
    const res = await fetch(op.url);
    if (!res.ok) throw new Error(`Download failed: ${res.status}`);
    text = await res.text();
  } // no url = no orders in the window
  const { days, currency } = aggregate(text);
  const next: UpsellStats = {
    version: 1,
    status: "idle",
    computedAt: new Date().toISOString(),
    currency: currency ?? prev.currency,
    windowDays: STATS_WINDOW_DAYS,
    days,
  };
  await save(admin, ownerId, next);
  return next;
}

/**
 * Returns cached stats, advancing the background job if needed.
 * force = start a new collection now (unless one is already running).
 */
export async function getUpsellStats(admin: AdminGraphql, force = false) {
  const { installationId, stats } = await load(admin);
  try {
    if (stats.status === "running" && stats.opId) {
      return await finish(admin, installationId, stats);
    }
    const age = stats.computedAt ? Date.now() - Date.parse(stats.computedAt) : Infinity;
    if (force || age > STALE_MS) {
      return await start(admin, installationId, stats);
    }
  } catch (e) {
    return { ...stats, status: "error" as const, error: (e as Error).message };
  }
  return stats;
}

export type OfferStat = { conversions: number; revenue: number };

/** Sums the cached days for the last `days` days. */
export function summarize(
  stats: UpsellStats,
  days: number,
  variantIds: string[],
) {
  const since = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10);
  let sales = 0;
  let orders = 0;
  let upsellRevenue = 0;
  let conversions = 0;
  const perVariant: Record<string, OfferStat> = {};
  for (const v of variantIds) perVariant[v] = { conversions: 0, revenue: 0 };
  for (const d of stats.days) {
    if (d.d < since) continue;
    sales += d.sales;
    orders += d.orders;
    for (const [vid, [n, rev]] of Object.entries(d.up)) {
      upsellRevenue += rev;
      conversions += n;
      if (perVariant[vid]) {
        perVariant[vid].conversions += n;
        perVariant[vid].revenue += rev;
      }
    }
  }
  const round = (n: number) => Math.round(n * 100) / 100;
  for (const v of Object.values(perVariant)) v.revenue = round(v.revenue);
  return {
    sales: round(sales),
    orders,
    upsellRevenue: round(upsellRevenue),
    conversions,
    boostPct: sales > 0 ? Math.round((upsellRevenue / sales) * 1000) / 10 : 0,
    perVariant,
  };
}
