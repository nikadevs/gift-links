/**
 * Warehouse API — Drop Ship China Pro (DSCP), "Easy Connection Guide" PDF, read 2026-11-13.
 *
 *  - token: POST https://app.dropshipchinapro.com/api/generateToken {email, password} → data = token, valid 7 days
 *  - every call: headers `token: <token>`, `Content-Type: application/json`
 *  - Feature 11: POST /api/tracking/query
 *      {queryType: "TRACKING", trackingNumber}  or  {queryType: "ORDER", storeId|storeName, outerOrderNo}
 *      → data.total, data.records[]: jstOrderNo, trackingNumber, carrierName, countryCode,
 *        status (external code of their tracking service), statusDescription (English),
 *        description (LATEST event only, English or null), lastSyncTime (or null), dataMode ("CURRENT_STORED")
 *      no event history, no last-mile number, stored data (not a fresh carrier lookup)
 *      rate limit 6 req/s per endpoint; errors 40001 params, 40302 account not verified, 50002 unavailable;
 *      rate-limit failures are not necessarily HTTP 429 → check code/success/msg.
 *  - Feature 10: POST /api/stores → data.stores[] {storeId, storeName}
 * The real status codes are not listed in the guide ("<status-code>" placeholders) → mapping by code
 * (17TRACK-style names and numbers) and by the English description; the admin "Test number" shows the raw answer.
 */
import type { TrkSettings, TrkStatus } from "./trk.shared";

const BASE = "https://app.dropshipchinapro.com/api";
let tokenCache: { key: string; token: string; until: number } | null = null;
let lastCall = 0;

export function dscpConfigured(s: TrkSettings) {
  return !!(s.dscpEmail && s.dscpPassword);
}

type Envelope<T> = { code?: number | string; msg?: string; success?: boolean; data?: T; requestId?: string };

async function token(s: TrkSettings, force = false): Promise<string> {
  const key = `${s.dscpEmail}|${s.dscpPassword.length}`;
  if (!force && tokenCache && tokenCache.key === key && tokenCache.until > Date.now()) return tokenCache.token;
  const res = await fetch(`${BASE}/generateToken`, {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify({ email: s.dscpEmail, password: s.dscpPassword }),
    signal: AbortSignal.timeout(20000),
  });
  const j = (await res.json().catch(() => ({}))) as Envelope<unknown> & Record<string, unknown>;
  const t = findToken(j.data) || findToken(j);
  if (!res.ok || !t || j.success === false) {
    throw new Error(`Warehouse login failed: ${j.msg || `HTTP ${res.status}`} (answer shape: ${shape(j)})`);
  }
  // valid 7 days → renew after 6
  tokenCache = { key, token: t, until: Date.now() + 6 * 24 * 3600 * 1000 };
  return t;
}

/** The guide says the token is `data`; accept `data` as a string or a token field inside it. */
function findToken(v: unknown, depth = 0): string {
  if (typeof v === "string") return v.length >= 6 && !/\s/.test(v) ? v : "";
  if (!v || typeof v !== "object" || depth > 2) return "";
  const o = v as Record<string, unknown>;
  for (const k of ["token", "accessToken", "access_token", "Token", "jwt", "authorization", "data"]) {
    const t = findToken(o[k], depth + 1);
    if (t) return t;
  }
  for (const [k, x] of Object.entries(o)) if (/token/i.test(k)) {
    const t = findToken(x, depth + 1);
    if (t) return t;
  }
  return "";
}

/** Keys and value types only (no values) — safe to show in the admin for debugging. */
function shape(v: unknown, depth = 0): string {
  if (v === null) return "null";
  if (Array.isArray(v)) return `array(${v.length})`;
  if (typeof v !== "object") return typeof v === "string" ? `string(${(v as string).length})` : typeof v;
  if (depth > 1) return "object";
  return `{${Object.entries(v as Record<string, unknown>).map(([k, x]) => `${k}: ${k === "msg" || k === "code" || k === "success" ? JSON.stringify(x) : shape(x, depth + 1)}`).join(", ")}}`;
}

async function call<T>(s: TrkSettings, path: string, body: unknown): Promise<Envelope<T>> {
  for (let attempt = 0; attempt < 3; attempt++) {
    // ≤ 5 requests per second (limit is 6/s per endpoint)
    const wait = lastCall + 200 - Date.now();
    if (wait > 0) await new Promise((r) => setTimeout(r, wait));
    lastCall = Date.now();
    const t = await token(s, attempt > 0 && tokenCache === null);
    const res = await fetch(`${BASE}${path}`, {
      method: "POST",
      headers: { token: t, "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify(body ?? {}),
      signal: AbortSignal.timeout(20000),
    });
    const j = (await res.json().catch(() => ({ msg: `HTTP ${res.status}` }))) as Envelope<T>;
    const code = Number(j.code);
    if (res.status === 401 || /token/i.test(String(j.msg ?? "")) && j.success === false) {
      tokenCache = null; // expired / revoked → log in again
      continue;
    }
    if (res.status === 429 || /rate|frequen|too many/i.test(String(j.msg ?? ""))) {
      await new Promise((r) => setTimeout(r, 1500 * (attempt + 1)));
      continue;
    }
    if (code === 50002) {
      await new Promise((r) => setTimeout(r, 2000));
      continue;
    }
    return j;
  }
  throw new Error("Warehouse API: no answer after 3 tries");
}

export type DscpRecord = {
  jstOrderNo: string;
  trackingNumber: string | null;
  carrierName: string;
  countryCode: string;
  status: string;
  statusDescription: string;
  description: string | null;
  lastSyncTime: string | null;
  dataMode: string;
};

export async function dscpStores(s: TrkSettings) {
  const j = await call<{ total: number; stores: { storeId: string; storeName: string }[] }>(s, "/stores", {});
  if (j.success === false || (j.code && Number(j.code) !== 200)) throw new Error(`Warehouse API: ${j.code} ${j.msg ?? ""}`);
  return j.data?.stores ?? [];
}

/** Stored tracking for one tracking number. */
export async function dscpTrack(s: TrkSettings, number: string, keepRaw = false) {
  const j = await call<{ total: number; records: DscpRecord[] }>(s, "/tracking/query", { queryType: "TRACKING", trackingNumber: number });
  if (j.success === false || (j.code && Number(j.code) !== 200)) throw new Error(`Warehouse API: ${j.code} ${j.msg ?? ""}`.trim());
  const recs = j.data?.records ?? [];
  const rec = recs.find((r) => String(r.trackingNumber ?? "").toUpperCase() === number.toUpperCase()) ?? recs[0];
  return { found: !!rec, record: rec ?? null, raw: keepRaw ? j : undefined };
}

// ---------------------------------------------------------------------------
// status mapping (the guide gives no list; cover 17TRACK-style codes, names and English text)

const BY_CODE: Record<string, TrkStatus> = {
  "0": "pending",
  "10": "in_transit",
  "20": "expired",
  "30": "out_for_delivery", // 17TRACK v1: pick up / available for pickup
  "35": "attempt_fail",
  "40": "delivered",
  "50": "exception",
  notfound: "pending",
  pending: "pending",
  inforeceived: "info_received",
  intransit: "in_transit",
  transit: "in_transit",
  expired: "expired",
  availableforpickup: "attempt_fail",
  pickup: "attempt_fail",
  outfordelivery: "out_for_delivery",
  deliveryfailure: "attempt_fail",
  undelivered: "attempt_fail",
  failedattempt: "attempt_fail",
  attemptfail: "attempt_fail",
  delivered: "delivered",
  exception: "exception",
  alert: "exception",
  returned: "returned",
  returntosender: "returned",
};

export function statusFromDscp(code: string, statusDescription: string, description: string): TrkStatus {
  const k = String(code || "").toLowerCase().replace(/[^a-z0-9]/g, "");
  const text = `${statusDescription || ""} ${description || ""}`;
  // explicit English first (more specific than numeric codes)
  if (/return(ed)? to sender|returning to sender|\breturned\b/i.test(statusDescription)) return "returned";
  if (/out for delivery/i.test(text)) return "out_for_delivery";
  if (/delivered to (the )?(local|last[- ]mile|destination)?\s*(carrier|hub|facility|customs|post)/i.test(text)) return "last_mile";
  if (/\bdelivered\b/i.test(statusDescription)) return "delivered";
  if (/fail|attempt|undeliver|available for pick ?up|ready for (pick ?up|collection)/i.test(statusDescription)) return "attempt_fail";
  if (/exception|alert|customs (hold|delay)|lost|damaged/i.test(statusDescription)) return "exception";
  if (/expired/i.test(statusDescription)) return "expired";
  if (/info(rmation)? received|label|pre-?advice|not ?found|pending/i.test(statusDescription)) {
    return /not ?found|pending/i.test(statusDescription) ? "pending" : "info_received";
  }
  if (BY_CODE[k]) return BY_CODE[k];
  if (/transit|departed|arrived|processed|customs/i.test(text)) return "in_transit";
  return description || statusDescription ? "in_transit" : "pending";
}
