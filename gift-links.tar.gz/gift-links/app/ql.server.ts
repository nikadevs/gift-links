import type { authenticate } from "./shopify.server";

/**
 * Quick Links (replacement for Vitals «Quick Access Links»).
 * One app-owned JSON metafield on the AppInstallation (wc_ql.config = {enabled});
 * the Gift Links app embed (blocks/gift-links.liquid) prints the bar code only
 * when it is enabled. No separate app embed (Roman's rule).
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export type QlConfig = { version: 1; enabled: boolean; updatedAt: string };

export async function loadQlConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcQlConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_ql", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  const config: QlConfig = { version: 1, enabled: false, updatedAt: "" };
  try {
    const p = JSON.parse(inst?.metafield?.value || "{}");
    if (typeof p?.enabled === "boolean") config.enabled = p.enabled;
    if (typeof p?.updatedAt === "string") config.updatedAt = p.updatedAt;
  } catch {
    // corrupted value — treat as off
  }
  return { installationId: inst?.id ?? "", config };
}

export async function saveQlConfig(admin: AdminGraphql, installationId: string, config: QlConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcQlSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_ql", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}
