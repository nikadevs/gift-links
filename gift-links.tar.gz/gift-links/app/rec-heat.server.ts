/**
 * Session Recordings — click maps ("where do people click on this page").
 *
 * The recorder sends clicks with its normal beacons ("c": [...]). Here they are
 * added up per page and device and day:
 *   $WC_DATA_DIR/rec/<shop>/heat/<YYYY-MM-DD>/<hash>.json
 *   { key: "/products/x", d: { mobile: { n, sel: { "<css path>": { n, l, t, p:[[rx,ry]…] } }, raw: [[x,y,w]…] } } }
 * Writes are batched in memory and flushed every 20 s. Days older than the
 * retention are removed by rec.server cleanup (it calls removeOldHeat).
 */
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

export type Click = { s: string; l: string; t: string; rx: number; ry: number; x: number; y: number; w: number };
type SelAgg = { n: number; l: string; t: string; p: [number, number][] };
type DevAgg = { n: number; sel: Record<string, SelAgg>; raw: [number, number, number][] };
type HeatFile = { key: string; d: Record<string, DevAgg> };

const MAX_PTS = 400; // points kept per element per day
const MAX_RAW = 4000; // raw page points per device per day
const MAX_SEL = 1500; // distinct elements per device per day

const root = () => path.resolve(process.env.WC_DATA_DIR || path.join(process.cwd(), "data"), "rec");
const safe = (shop: string) => shop.replace(/[^a-z0-9.-]/gi, "_");
const heatDir = (shop: string) => path.join(root(), safe(shop), "heat");
const hashKey = (key: string) => crypto.createHash("sha1").update(key).digest("hex").slice(0, 16);
const dayOf = (ts: number) => new Date(ts).toISOString().slice(0, 10);

/** "/collections/x/products/y?variant=1" → "/products/y" */
export function pageKey(url: string) {
  let p = url;
  try {
    p = new URL(url, "https://x.invalid").pathname;
  } catch {
    p = url.split("?")[0];
  }
  p = p.toLowerCase().replace(/\/+$/, "") || "/";
  p = p.replace(/^\/[a-z]{2}(-[a-z]{2})?(?=\/)/, ""); // /en-gb/products/... → /products/...
  const prod = p.match(/\/products\/[^/]+/);
  if (prod) return prod[0];
  return p.slice(0, 200) || "/";
}

const pending = new Map<string, HeatFile>(); // shop|day|hash
let timer: NodeJS.Timeout | null = null;

function clamp01(v: unknown) {
  const n = Number(v);
  return Number.isFinite(n) ? Math.min(1, Math.max(0, Math.round(n * 1000) / 1000)) : 0.5;
}

export function addClicks(shop: string, url: string, device: string, clicks: unknown[]) {
  if (!url || !Array.isArray(clicks) || !clicks.length) return;
  const key = pageKey(url);
  const day = dayOf(Date.now());
  const k = `${shop}|${day}|${hashKey(key)}`;
  const f = pending.get(k) ?? { key, d: {} };
  const dev = (f.d[device] ??= { n: 0, sel: {}, raw: [] });
  for (const c of clicks.slice(0, 300) as Partial<Click>[]) {
    if (!c || typeof c.s !== "string") continue;
    const s = c.s.slice(0, 300);
    dev.n++;
    let a = dev.sel[s];
    if (!a) {
      if (Object.keys(dev.sel).length >= MAX_SEL) continue;
      a = dev.sel[s] = { n: 0, l: String(c.l ?? "").slice(0, 60), t: String(c.t ?? "").slice(0, 12), p: [] };
    }
    a.n++;
    if (a.p.length < MAX_PTS) a.p.push([clamp01(c.rx), clamp01(c.ry)]);
    const y = Math.round(Number(c.y));
    const w = Math.round(Number(c.w));
    if (dev.raw.length < MAX_RAW && Number.isFinite(y) && y >= 0 && y < 100000 && w > 0 && w < 5000) {
      dev.raw.push([clamp01(c.x), y, w]);
    }
  }
  pending.set(k, f);
  if (!timer) timer = setTimeout(() => void flushHeat(), 20000);
}

function merge(into: HeatFile, add: HeatFile) {
  for (const [dev, a] of Object.entries(add.d)) {
    const t = (into.d[dev] ??= { n: 0, sel: {}, raw: [] });
    t.n += a.n;
    for (const [s, v] of Object.entries(a.sel)) {
      const x = t.sel[s];
      if (!x) {
        if (Object.keys(t.sel).length < MAX_SEL) t.sel[s] = { ...v, p: v.p.slice(0, MAX_PTS) };
      } else {
        x.n += v.n;
        if (!x.l && v.l) x.l = v.l;
        for (const pt of v.p) if (x.p.length < MAX_PTS) x.p.push(pt);
      }
    }
    for (const r of a.raw) if (t.raw.length < MAX_RAW) t.raw.push(r);
  }
}

export async function flushHeat() {
  timer = null;
  const batch = [...pending.entries()];
  pending.clear();
  for (const [k, add] of batch) {
    const [shop, day, h] = k.split("|");
    const dir = path.join(heatDir(shop), day);
    const file = path.join(dir, `${h}.json`);
    let cur: HeatFile = { key: add.key, d: {} };
    try {
      cur = JSON.parse(await fs.readFile(file, "utf8")) as HeatFile;
    } catch {
      /* new */
    }
    merge(cur, add);
    try {
      await fs.mkdir(dir, { recursive: true });
      await fs.writeFile(file, JSON.stringify(cur));
    } catch {
      /* lost this batch */
    }
  }
}

async function daysIn(shop: string, days: number) {
  const from = dayOf(Date.now() - (days - 1) * 86400000);
  try {
    return (await fs.readdir(heatDir(shop))).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d) && d >= from);
  } catch {
    return [];
  }
}

/** pages with clicks in the period: [{ key, n }] (all devices or one) */
export async function heatPages(shop: string, days: number, device: string) {
  await flushHeat();
  const tot = new Map<string, number>();
  for (const d of await daysIn(shop, days)) {
    let files: string[] = [];
    try {
      files = await fs.readdir(path.join(heatDir(shop), d));
    } catch {
      continue;
    }
    for (const f of files) {
      try {
        const h = JSON.parse(await fs.readFile(path.join(heatDir(shop), d, f), "utf8")) as HeatFile;
        const n = device ? (h.d[device]?.n ?? 0) : Object.values(h.d).reduce((s, x) => s + x.n, 0);
        if (n) tot.set(h.key, (tot.get(h.key) ?? 0) + n);
      } catch {
        /* skip */
      }
    }
  }
  return [...tot.entries()].map(([key, n]) => ({ key, n })).sort((a, b) => b.n - a.n);
}

/** merged click map of one page (one device) over the period */
export async function heatOf(shop: string, key: string, days: number, device: string) {
  await flushHeat();
  const out: HeatFile = { key, d: {} };
  const h = hashKey(key);
  for (const d of await daysIn(shop, days)) {
    try {
      merge(out, JSON.parse(await fs.readFile(path.join(heatDir(shop), d, `${h}.json`), "utf8")) as HeatFile);
    } catch {
      /* no clicks that day */
    }
  }
  const dev = out.d[device] ?? { n: 0, sel: {}, raw: [] };
  const sel = Object.entries(dev.sel)
    .map(([s, v]) => ({ s, ...v }))
    .sort((a, b) => b.n - a.n)
    .slice(0, 300);
  return { key, device, n: dev.n, sel, raw: dev.raw };
}

export async function removeOldHeat(shop: string, keepDays: number) {
  const oldest = dayOf(Date.now() - (keepDays - 1) * 86400000);
  let days: string[] = [];
  try {
    days = await fs.readdir(heatDir(shop));
  } catch {
    return;
  }
  for (const d of days) {
    if (/^\d{4}-\d{2}-\d{2}$/.test(d) && d < oldest) {
      await fs.rm(path.join(heatDir(shop), d), { recursive: true, force: true }).catch(() => {});
    }
  }
}
