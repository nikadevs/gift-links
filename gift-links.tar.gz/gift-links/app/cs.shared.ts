/**
 * Cart Summary (WoodenCrew Apps module): clear totals on the /cart page —
 * Subtotal (full prices) − each discount (bundle / volume discounts, codes) =
 * Total, plus Shipping. Shared types, defaults and validation. Numbers always
 * come from Shopify's cart.
 */
export type CsConfig = {
  version: 1;
  enabled: boolean;
  subtotal: string;
  discount: string; // label in front of the discount title / code
  shipping: string;
  free: string; // shipping value when the theme's free-shipping bar is reached
  total: string;
  note: string; // small text under Total; empty = hidden
  updatedAt: string;
};

export const CS_DEFAULTS: CsConfig = {
  version: 1,
  enabled: false,
  subtotal: "Subtotal",
  discount: "Discount",
  shipping: "Shipping",
  free: "FREE",
  total: "Total",
  note: "Taxes, if applicable, are calculated at checkout.",
  updatedAt: "",
};

export const CS_TEXT_FIELDS: { key: Exclude<keyof CsConfig, "version" | "enabled" | "updatedAt">; label: string; help?: string }[] = [
  { key: "subtotal", label: "Subtotal label", help: "All items at full price, before any discount." },
  { key: "discount", label: "Discount label", help: "Shown with the discount name, e.g. “Discount (Bundle discount)”, “Discount (GIFTSCALE)”. One row per discount." },
  { key: "shipping", label: "Shipping label", help: "The row appears only when the theme's free-shipping bar is reached." },
  { key: "free", label: "Free shipping value" },
  { key: "total", label: "Total label", help: "Subtotal minus all discounts = Shopify's cart total." },
  { key: "note", label: "Note under Total", help: "Leave empty to hide. Shipping and tax are final only at checkout." },
];

const text = (v: unknown, d: string, max = 120) => (typeof v === "string" ? v.trim().slice(0, max) : d);

export function normalizeCs(raw: unknown): CsConfig {
  const p = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    version: 1,
    enabled: p.enabled === true,
    subtotal: text(p.subtotal, CS_DEFAULTS.subtotal, 40) || CS_DEFAULTS.subtotal,
    discount: text(p.discount, CS_DEFAULTS.discount, 40) || CS_DEFAULTS.discount,
    shipping: text(p.shipping, CS_DEFAULTS.shipping, 40) || CS_DEFAULTS.shipping,
    free: text(p.free, CS_DEFAULTS.free, 40) || CS_DEFAULTS.free,
    total: text(p.total, CS_DEFAULTS.total, 40) || CS_DEFAULTS.total,
    note: text(p.note, CS_DEFAULTS.note, 200),
    updatedAt: typeof p.updatedAt === "string" ? p.updatedAt : "",
  };
}
