/**
 * Cart Summary (WoodenCrew Apps module): clear totals on the /cart page —
 * Subtotal, each discount code, Shipping, Total, "You save". Shared types,
 * defaults and validation. Numbers always come from Shopify's /cart.js.
 */
export type CsConfig = {
  version: 1;
  enabled: boolean;
  subtotal: string;
  discount: string; // label in front of the code / discount title
  shipping: string;
  free: string; // shipping value when the theme's free-shipping bar is reached
  total: string;
  savings: string; // "You save" row (all discounts together); empty = hidden
  note: string; // small text under Total; empty = hidden
  updatedAt: string;
};

export const CS_DEFAULTS: CsConfig = {
  version: 1,
  enabled: false,
  subtotal: "Subtotal",
  discount: "Discount",
  shipping: "Shipping",
  free: "FREE",
  total: "Total",
  savings: "You save",
  note: "Taxes, if applicable, are calculated at checkout.",
  updatedAt: "",
};

export const CS_TEXT_FIELDS: { key: Exclude<keyof CsConfig, "version" | "enabled" | "updatedAt">; label: string; help?: string }[] = [
  { key: "subtotal", label: "Subtotal label", help: "Items after their own discounts (bundle prices), before discount codes." },
  { key: "discount", label: "Discount label", help: "Shown with the code, e.g. “Discount (GIFTSCALE)”. One row per code." },
  { key: "shipping", label: "Shipping label", help: "The row appears only when the theme's free-shipping bar is reached." },
  { key: "free", label: "Free shipping value" },
  { key: "total", label: "Total label", help: "What the customer pays (Shopify's cart total)." },
  { key: "savings", label: "Savings label", help: "All discounts together (bundle + codes). Leave empty to hide the row." },
  { key: "note", label: "Note under Total", help: "Leave empty to hide. Shipping and tax are final only at checkout." },
];

const text = (v: unknown, d: string, max = 120) => (typeof v === "string" ? v.trim().slice(0, max) : d);

export function normalizeCs(raw: unknown): CsConfig {
  const p = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    version: 1,
    enabled: p.enabled === true,
    subtotal: text(p.subtotal, CS_DEFAULTS.subtotal, 40) || CS_DEFAULTS.subtotal,
    discount: text(p.discount, CS_DEFAULTS.discount, 40) || CS_DEFAULTS.discount,
    shipping: text(p.shipping, CS_DEFAULTS.shipping, 40) || CS_DEFAULTS.shipping,
    free: text(p.free, CS_DEFAULTS.free, 40) || CS_DEFAULTS.free,
    total: text(p.total, CS_DEFAULTS.total, 40) || CS_DEFAULTS.total,
    savings: text(p.savings, CS_DEFAULTS.savings, 40),
    note: text(p.note, CS_DEFAULTS.note, 200),
    updatedAt: typeof p.updatedAt === "string" ? p.updatedAt : "",
  };
}
