/**
 * Session Recordings — storage on our server (no third-party service).
 *
 *   $WC_DATA_DIR/rec/<shop>/settings.json            enabled + retention mirror
 *   $WC_DATA_DIR/rec/<shop>/<YYYY-MM-DD>/<sid>/meta.json
 *   $WC_DATA_DIR/rec/<shop>/<YYYY-MM-DD>/<sid>/<page>-<seq>.gz   rrweb events
 *   $WC_DATA_DIR/rec/<shop>/<YYYY-MM-DD>/index.json   list cache of a closed day
 *
 * Day = UTC day the session started (encoded in the session id). Days older
 * than the retention (30, Roman 2026-10-14) are deleted hourly. When the disk has less than
 * MIN_FREE bytes free, new chunks are dropped (the admin shows a warning).
 * The auto-deploy script never touches data/.
 */
import fs from "node:fs/promises";
import path from "node:path";
import zlib from "node:zlib";
import { promisify } from "node:util";
import maxmind, { type CountryResponse, type Reader } from "maxmind";
import {
  REC_KEY,
  REC_NAMESPACE,
  REC_RETENTION_DAYS,
  browserOf,
  deviceOf,
  osOf,
  type RecConfig,
  type RecListItem,
  type RecSession,
} from "./rec.shared";

const gunzip = promisify(zlib.gunzip);
const gzip = promisify(zlib.gzip);

const MIN_FREE = 1.5 * 1024 ** 3; // stop accepting below 1.5 GB free disk
const MAX_SESSION_BYTES = 40 * 1024 ** 2; // per recording, compressed
const MAX_RAW = 8 * 1024 ** 2; // per request, after decompression
const DAY_MS = 24 * 60 * 60 * 1000;

type AdminGraphql = {
  graphql: (query: string, options?: { variables?: Record<string, unknown> }) => Promise<Response>;
};

export const dataRoot = () =>
  path.resolve(process.env.WC_DATA_DIR || path.join(process.cwd(), "data"), "rec");
const safe = (shop: string) => shop.replace(/[^a-z0-9.-]/gi, "_");
const shopDir = (shop: string) => path.join(dataRoot(), safe(shop));
const dayOf = (ts: number) => new Date(ts).toISOString().slice(0, 10);
export const SID_RE = /^[a-z0-9]{12,24}$/;

/** session ids start with Date.now().toString(36) (8 chars until year 2059) */
export function sidTime(sid: string) {
  return parseInt(sid.slice(0, 8), 36);
}
const sessionDir = (shop: string, sid: string) =>
  path.join(shopDir(shop), dayOf(sidTime(sid)), sid);

// ---------------------------------------------------------------------------
// settings (metafield for the theme + file mirror for the server)

type ShopSettings = { enabled: boolean; retentionDays: number };
const settingsCache = new Map<string, { at: number; v: ShopSettings }>();

export async function getShopSettings(shop: string): Promise<ShopSettings> {
  const hit = settingsCache.get(shop);
  if (hit && Date.now() - hit.at < 30000) return hit.v;
  let v: ShopSettings = { enabled: false, retentionDays: REC_RETENTION_DAYS };
  try {
    const saved = JSON.parse(await fs.readFile(path.join(shopDir(shop), "settings.json"), "utf8")) as Partial<ShopSettings>;
    v = { ...v, enabled: !!saved.enabled };
  } catch {
    /* defaults */
  }
  settingsCache.set(shop, { at: Date.now(), v });
  return v;
}

async function writeShopSettings(shop: string, v: ShopSettings) {
  await fs.mkdir(shopDir(shop), { recursive: true });
  await fs.writeFile(path.join(shopDir(shop), "settings.json"), JSON.stringify(v));
  settingsCache.set(shop, { at: Date.now(), v });
}

export async function loadRecConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcRecConfig {
      currentAppInstallation { id metafield(namespace: "${REC_NAMESPACE}", key: "${REC_KEY}") { value } }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  let config: RecConfig = { version: 1, enabled: false, endpoint: "", updatedAt: "" };
  try {
    const v = JSON.parse(inst?.metafield?.value || "null");
    if (v && typeof v === "object") config = { ...config, ...v };
  } catch {
    /* corrupted → defaults */
  }
  return { installationId: inst?.id ?? "", config };
}

export async function setRecEnabled(admin: AdminGraphql, shop: string, enabled: boolean) {
  const { installationId } = await loadRecConfig(admin);
  if (!installationId) throw new Error("App installation not found");
  // eslint-disable-next-line no-undef
  const appUrl = (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, "");
  const config: RecConfig = {
    version: 1,
    enabled,
    endpoint: appUrl ? `${appUrl}/api/rec` : "",
    updatedAt: new Date().toISOString(),
  };
  if (enabled && !config.endpoint) throw new Error("SHOPIFY_APP_URL is not set on the server");
  // server first: when the theme starts sending, ingest is already open
  const cur = await getShopSettings(shop);
  await writeShopSettings(shop, { ...cur, enabled });
  const res = await admin.graphql(
    `#graphql
    mutation WcRecSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          {
            ownerId: installationId,
            namespace: REC_NAMESPACE,
            key: REC_KEY,
            type: "json",
            value: JSON.stringify(config),
          },
        ],
      },
    },
  );
  const json = (await res.json()) as {
    data?: { metafieldsSet?: { userErrors: { message: string }[] } };
  };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) {
    await writeShopSettings(shop, cur);
    throw new Error(errors.map((e) => e.message).join("; "));
  }
  return config;
}

// ---------------------------------------------------------------------------
// disk guard

let disk = { at: 0, free: Infinity, total: 0 };
export async function diskInfo() {
  if (Date.now() - disk.at < 60000) return disk;
  try {
    await fs.mkdir(dataRoot(), { recursive: true });
    const s = await fs.statfs(dataRoot());
    disk = { at: Date.now(), free: s.bavail * s.bsize, total: s.blocks * s.bsize };
  } catch {
    disk = { at: Date.now(), free: Infinity, total: 0 };
  }
  return disk;
}
export const lowDisk = (free: number) => free < MIN_FREE;

// ---------------------------------------------------------------------------
// geo (country only): DB-IP "IP to Country Lite", CC BY 4.0 — attribution
// "IP Geolocation by DB-IP" is shown in the admin. ~5 MB, refreshed monthly.
// The visitor IP is only looked up, never stored.

const geoDir = () => path.join(path.dirname(dataRoot()), "geo");
let geo: Reader<CountryResponse> | null = null;
let geoMonth = "";
let geoTry = 0;

async function loadGeoFile(file: string, month: string) {
  geo = await maxmind.open<CountryResponse>(file);
  geoMonth = month;
}

async function ensureGeo() {
  const now = new Date();
  const month = now.toISOString().slice(0, 7);
  if (geo && geoMonth === month) return;
  if (Date.now() - geoTry < 6 * 60 * 60 * 1000) return;
  geoTry = Date.now();
  const dir = geoDir();
  const file = path.join(dir, "dbip-country-lite.mmdb");
  try {
    await fs.mkdir(dir, { recursive: true });
    if (!geo) {
      try {
        const m = (await fs.readFile(path.join(dir, "month.txt"), "utf8")).trim();
        await loadGeoFile(file, m);
        if (m === month) return;
      } catch {
        /* no file yet */
      }
    }
    const prev = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - 1, 1)).toISOString().slice(0, 7);
    for (const m of [month, prev]) {
      if (geo && m === geoMonth) return;
      const res = await fetch(`https://download.db-ip.com/free/dbip-country-lite-${m}.mmdb.gz`, {
        signal: AbortSignal.timeout(60000),
      });
      if (!res.ok) continue;
      const buf = await gunzip(Buffer.from(await res.arrayBuffer()));
      const tmp = `${file}.tmp`;
      await fs.writeFile(tmp, buf);
      await fs.rename(tmp, file);
      await fs.writeFile(path.join(dir, "month.txt"), m);
      await loadGeoFile(file, m);
      return;
    }
  } catch {
    /* try again in 6 h; recordings work without a country */
  }
}

function countryOf(ip: string) {
  if (!geo || !ip || !maxmind.validate(ip)) return "";
  try {
    return geo.get(ip)?.country?.iso_code ?? "";
  } catch {
    return "";
  }
}

// ---------------------------------------------------------------------------
// ingest

type Incoming = {
  shop: string;
  sid: string;
  vid: string;
  page: number;
  seq: number;
  zipped: boolean;
  body: Buffer;
  ua: string;
  ip: string;
};

type RrEvent = { type: number; timestamp: number; data?: { source?: number; type?: number; tag?: string } };
type Payload = {
  m?: { url?: string; title?: string; ref?: string; w?: number; h?: number; tz?: string; lang?: string; touch?: boolean };
  f?: { atc?: number; co?: number };
  e?: RrEvent[];
};

const metas = new Map<string, { m: RecSession; dirty: boolean; at: number }>();
let flushTimer: NodeJS.Timeout | null = null;

async function readMeta(file: string): Promise<RecSession | null> {
  try {
    return JSON.parse(await fs.readFile(file, "utf8")) as RecSession;
  } catch {
    return null;
  }
}

async function flushMetas() {
  flushTimer = null;
  const now = Date.now();
  for (const [key, entry] of metas) {
    if (entry.dirty) {
      entry.dirty = false;
      const [shop, sid] = key.split("|");
      const dir = sessionDir(shop, sid);
      try {
        await fs.mkdir(dir, { recursive: true });
        await fs.writeFile(path.join(dir, "meta.json"), JSON.stringify(entry.m));
      } catch {
        /* retried with the next chunk */
      }
    } else if (now - entry.at > 15 * 60 * 1000) metas.delete(key);
  }
}

const scheduleFlush = () => {
  if (!flushTimer) flushTimer = setTimeout(flushMetas, 2000);
};

function cleanUrl(u: string) {
  return String(u || "").slice(0, 500);
}

function utmOf(url: string, ref: string) {
  try {
    const q = new URL(url, "https://x.invalid").searchParams;
    const src = q.get("utm_source");
    const camp = q.get("utm_campaign");
    if (src || camp) return [src, camp].filter(Boolean).join(" / ").slice(0, 120);
  } catch {
    /* ignore */
  }
  if (ref) {
    try {
      return new URL(ref).hostname.replace(/^www\./, "").slice(0, 120);
    } catch {
      return "";
    }
  }
  return "";
}

/** returns false when the chunk was dropped */
export async function ingest(x: Incoming): Promise<boolean> {
  startRecScheduler();
  const settings = await getShopSettings(x.shop);
  if (!settings.enabled) return false;
  const t0 = sidTime(x.sid);
  const now = Date.now();
  if (!(t0 > now - 3 * DAY_MS && t0 < now + 60 * 60 * 1000)) return false;
  const dk = await diskInfo();
  if (dk.free < MIN_FREE + 1024 ** 3) void cleanup();
  if (lowDisk(dk.free)) return false;

  let raw: Buffer;
  try {
    raw = x.zipped ? await gunzip(x.body, { maxOutputLength: MAX_RAW }) : x.body;
  } catch {
    return false;
  }
  let data: Payload;
  try {
    data = JSON.parse(raw.toString("utf8")) as Payload;
  } catch {
    return false;
  }
  if (!data || !Array.isArray(data.e) || !data.e.length) return false;
  const events = data.e.filter((e) => e && typeof e.type === "number" && typeof e.timestamp === "number");
  if (!events.length) return false;

  const key = `${x.shop}|${x.sid}`;
  const dir = sessionDir(x.shop, x.sid);
  let entry = metas.get(key);
  if (!entry) {
    const m = (await readMeta(path.join(dir, "meta.json"))) ?? {
      id: x.sid,
      vid: x.vid,
      day: dayOf(t0),
      start: Infinity,
      end: 0,
      pages: [],
      device: "desktop",
      w: 0,
      h: 0,
      ua: x.ua.slice(0, 400),
      browser: browserOf(x.ua),
      os: osOf(x.ua),
      ref: "",
      utm: "",
      lang: "",
      tz: "",
      atc: false,
      checkout: false,
      clicks: 0,
      chunks: 0,
      bytes: 0,
    };
    entry = { m, dirty: false, at: now };
    metas.set(key, entry);
  }
  const m = entry.m;
  if (m.bytes > MAX_SESSION_BYTES) return false;
  if (!m.country) {
    void ensureGeo();
    const c = countryOf(x.ip);
    if (c) m.country = c;
  }

  const stored = x.zipped ? x.body : await gzip(raw);
  await fs.mkdir(dir, { recursive: true });
  const name = `${String(x.page).padStart(4, "0")}-${String(x.seq).padStart(5, "0")}.gz`;
  await fs.writeFile(path.join(dir, name), stored);

  for (const e of events) {
    if (e.timestamp < m.start) m.start = e.timestamp;
    if (e.timestamp > m.end) m.end = e.timestamp;
    // IncrementalSnapshot (3) / MouseInteraction (2) / Click (2)
    if (e.type === 3 && e.data?.source === 2 && e.data?.type === 2) m.clicks++;
    if (e.type === 5 && e.data?.tag === "Add to cart") m.atc = true;
    if (e.type === 5 && e.data?.tag === "Checkout click") m.checkout = true;
  }
  if (data.f?.atc) m.atc = true;
  if (data.f?.co) m.checkout = true;
  if (data.m) {
    const pm = data.m;
    if (!m.pages.some((p) => p.p === x.page)) {
      m.pages.push({ p: x.page, url: cleanUrl(pm.url ?? ""), title: String(pm.title ?? "").slice(0, 200), t: events[0].timestamp });
      m.pages.sort((a, b) => a.p - b.p);
      if (m.pages.length > 300) m.pages.length = 300;
    }
    if (x.page === 0 || !m.w) {
      m.w = Number(pm.w) || 0;
      m.h = Number(pm.h) || 0;
      m.device = deviceOf(m.ua, m.w, !!pm.touch);
      m.lang = String(pm.lang ?? "").slice(0, 20);
      m.tz = String(pm.tz ?? "").slice(0, 60);
    }
    if (x.page === 0 && pm.ref !== undefined) m.ref = cleanUrl(pm.ref);
    if (!m.utm) m.utm = utmOf(pm.url ?? "", m.ref);
  }
  m.chunks++;
  m.bytes += stored.length;
  entry.dirty = true;
  entry.at = now;
  scheduleFlush();
  return true;
}

// ---------------------------------------------------------------------------
// reading

async function listDays(shop: string) {
  try {
    return (await fs.readdir(shopDir(shop))).filter((d) => /^\d{4}-\d{2}-\d{2}$/.test(d)).sort().reverse();
  } catch {
    return [];
  }
}

const dayCache = new Map<string, { at: number; list: RecSession[] }>();

async function sessionsOfDay(shop: string, day: string): Promise<RecSession[]> {
  const key = `${shop}|${day}`;
  const closed = day < dayOf(Date.now() - DAY_MS);
  const hit = dayCache.get(key);
  if (hit && (closed || Date.now() - hit.at < 15000)) return hit.list;
  const dir = path.join(shopDir(shop), day);
  if (closed) {
    try {
      const list = JSON.parse(await fs.readFile(path.join(dir, "index.json"), "utf8")) as RecSession[];
      dayCache.set(key, { at: Date.now(), list });
      return list;
    } catch {
      /* build it */
    }
  }
  let names: string[] = [];
  try {
    names = (await fs.readdir(dir)).filter((n) => SID_RE.test(n));
  } catch {
    names = [];
  }
  const list: RecSession[] = [];
  for (let i = 0; i < names.length; i += 64) {
    const part = await Promise.all(
      names.slice(i, i + 64).map((n) => {
        const live = metas.get(`${shop}|${n}`);
        return live ? Promise.resolve(live.m) : readMeta(path.join(dir, n, "meta.json"));
      }),
    );
    for (const m of part) if (m && Number.isFinite(m.start)) list.push(m);
  }
  if (closed) await fs.writeFile(path.join(dir, "index.json"), JSON.stringify(list)).catch(() => {});
  dayCache.set(key, { at: Date.now(), list });
  return list;
}

/** list filters from the URL (?days&device&min&atc&url&page) */
export function parseFilter(sp: URLSearchParams): RecFilter {
  return {
    days: [1, 3, 7, 14, 30].includes(Number(sp.get("days"))) ? Number(sp.get("days")) : 7,
    device: ["mobile", "tablet", "desktop"].includes(sp.get("device") ?? "") ? String(sp.get("device")) : "",
    minSec: [0, 10, 30, 60, 180].includes(Number(sp.get("min"))) ? Number(sp.get("min")) : 0,
    atc: sp.get("atc") === "1",
    url: (sp.get("url") ?? "").slice(0, 100),
    page: Math.max(0, Number(sp.get("page")) || 0),
  };
}

/** the same filters back as a query string (without page) */
export function filterQuery(f: RecFilter) {
  const q = new URLSearchParams();
  if (f.days !== 7) q.set("days", String(f.days));
  if (f.device) q.set("device", f.device);
  if (f.minSec) q.set("min", String(f.minSec));
  if (f.atc) q.set("atc", "1");
  if (f.url) q.set("url", f.url);
  return q.toString();
}

export type RecFilter = {
  days: number;
  device: string;
  minSec: number;
  atc: boolean;
  url: string;
  page: number;
};

export async function listSessions(shop: string, f: RecFilter) {
  const from = dayOf(Date.now() - (f.days - 1) * DAY_MS);
  const days = (await listDays(shop)).filter((d) => d >= from);
  let all: RecSession[] = [];
  for (const d of days) all = all.concat(await sessionsOfDay(shop, d));
  const total = all.length;
  const needle = f.url.trim().toLowerCase();
  const rows = all
    .filter((m) => (f.device ? m.device === f.device : true))
    .filter((m) => m.end - m.start >= f.minSec * 1000)
    .filter((m) => (f.atc ? m.atc : true))
    .filter((m) => (needle ? m.pages.some((p) => p.url.toLowerCase().includes(needle)) : true))
    .sort((a, b) => b.start - a.start);
  const PER = 50;
  const items: RecListItem[] = rows.slice(f.page * PER, f.page * PER + PER).map((m) => {
    const { ua: _ua, ...rest } = m;
    void _ua;
    return { ...rest, duration: Math.max(0, m.end - m.start) };
  });
  return {
    items,
    matched: rows.length,
    total,
    pages: Math.max(1, Math.ceil(rows.length / PER)),
    withAtc: all.filter((m) => m.atc).length,
    bytes: all.reduce((s, m) => s + (m.bytes || 0), 0),
  };
}

/** One row per visitor (all their visits merged), newest activity first. */
export type RecVisitor = {
  vid: string;
  first: number;
  last: number;
  visits: number;
  pages: number;
  duration: number;
  device: RecSession["device"];
  os: string;
  browser: string;
  w: number;
  h: number;
  source: string;
  country: string;
  tz: string;
  landing: string;
  lastUrl: string;
  atc: boolean;
  checkout: boolean;
  clicks: number;
  bytes: number;
};

async function sessionsInRange(shop: string, days: number) {
  const from = dayOf(Date.now() - (days - 1) * DAY_MS);
  const list = (await listDays(shop)).filter((d) => d >= from);
  let all: RecSession[] = [];
  for (const d of list) all = all.concat(await sessionsOfDay(shop, d));
  return all;
}

async function visitorRows(shop: string, f: RecFilter) {
  const all = await sessionsInRange(shop, f.days);
  const byVid = new Map<string, RecSession[]>();
  for (const m of all) {
    const arr = byVid.get(m.vid);
    if (arr) arr.push(m);
    else byVid.set(m.vid, [m]);
  }
  const needle = f.url.trim().toLowerCase();
  const rows: RecVisitor[] = [];
  for (const [vid, ss] of byVid) {
    ss.sort((a, b) => a.start - b.start);
    const v: RecVisitor = {
      vid,
      first: ss[0].start,
      last: Math.max(...ss.map((m) => m.end)),
      visits: ss.length,
      pages: ss.reduce((n, m) => n + m.pages.length, 0),
      duration: ss.reduce((n, m) => n + Math.max(0, m.end - m.start), 0),
      device: ss[ss.length - 1].device,
      os: ss[ss.length - 1].os,
      browser: ss[ss.length - 1].browser,
      w: ss[ss.length - 1].w,
      h: ss[ss.length - 1].h,
      source: ss.find((m) => m.utm)?.utm ?? "",
      country: [...ss].reverse().find((m) => m.country)?.country ?? "",
      tz: ss[ss.length - 1].tz,
      landing: ss[0].pages[0]?.url ?? "",
      lastUrl: ss[ss.length - 1].pages[ss[ss.length - 1].pages.length - 1]?.url ?? "",
      atc: ss.some((m) => m.atc),
      checkout: ss.some((m) => m.checkout),
      clicks: ss.reduce((n, m) => n + m.clicks, 0),
      bytes: ss.reduce((n, m) => n + (m.bytes || 0), 0),
    };
    if (f.device && v.device !== f.device) continue;
    if (v.duration < f.minSec * 1000) continue;
    if (f.atc && !v.atc) continue;
    if (needle && !ss.some((m) => m.pages.some((p) => p.url.toLowerCase().includes(needle)))) continue;
    rows.push(v);
  }
  rows.sort((a, b) => b.last - a.last);
  return { rows, all, visitors: byVid.size };
}

/** visitor ids in list order for the given filters (prev / next on the visitor page) */
export async function visitorOrder(shop: string, f: RecFilter) {
  return (await visitorRows(shop, f)).rows.map((r) => r.vid);
}

export async function listVisitors(shop: string, f: RecFilter) {
  const { rows, all, visitors } = await visitorRows(shop, f);
  const PER = 50;
  return {
    items: rows.slice(f.page * PER, f.page * PER + PER),
    matched: rows.length,
    total: visitors,
    sessions: all.length,
    pages: Math.max(1, Math.ceil(rows.length / PER)),
    withAtc: rows.filter((v) => v.atc).length,
    bytes: all.reduce((n, m) => n + (m.bytes || 0), 0),
  };
}

export const VID_RE = /^[a-z0-9]{8,40}$/;

/** every recording of one visitor within the retention, oldest first */
export async function getVisitor(shop: string, vid: string) {
  if (!VID_RE.test(vid)) return [];
  const all = await sessionsInRange(shop, REC_RETENTION_DAYS);
  return all
    .filter((m) => m.vid === vid)
    .sort((a, b) => a.start - b.start)
    .map((m) => {
      const { ua: _ua, ...rest } = m;
      void _ua;
      return rest;
    });
}

export async function deleteVisitor(shop: string, vid: string) {
  for (const m of await getVisitor(shop, vid)) await deleteSession(shop, m.id);
}

export async function getSession(shop: string, sid: string) {
  if (!SID_RE.test(sid)) return null;
  const live = metas.get(`${shop}|${sid}`);
  return live?.m ?? (await readMeta(path.join(sessionDir(shop, sid), "meta.json")));
}

/** all events of a recording, every page in order, as one JSON array string */
export async function readEvents(shop: string, sid: string, page?: number) {
  if (!SID_RE.test(sid)) return null;
  const dir = sessionDir(shop, sid);
  const prefix = page === undefined ? "" : `${String(page).padStart(4, "0")}-`;
  let names: string[];
  try {
    names = (await fs.readdir(dir))
      .filter((n) => /^\d{4}-\d{5}\.gz$/.test(n) && n.startsWith(prefix))
      .sort();
  } catch {
    return null;
  }
  const parts: string[] = [];
  for (const n of names) {
    try {
      const raw = await gunzip(await fs.readFile(path.join(dir, n)));
      const json = JSON.parse(raw.toString("utf8")) as Payload;
      const ev = (json.e ?? []).map((e) => JSON.stringify(e));
      if (ev.length) parts.push(ev.join(","));
    } catch {
      /* skip a broken chunk */
    }
  }
  return `[${parts.join(",")}]`;
}

export async function deleteSession(shop: string, sid: string) {
  if (!SID_RE.test(sid)) return;
  metas.delete(`${shop}|${sid}`);
  const day = dayOf(sidTime(sid));
  await fs.rm(sessionDir(shop, sid), { recursive: true, force: true });
  await fs.rm(path.join(shopDir(shop), day, "index.json"), { force: true });
  dayCache.delete(`${shop}|${day}`);
}

// ---------------------------------------------------------------------------
// retention

/** oldest day folder across all shops (to free space when the disk is low) */
async function oldestDay(shops: string[]) {
  let best: { shop: string; day: string } | null = null;
  for (const s of shops) {
    const days = await listDays(s); // newest first
    const today = dayOf(Date.now());
    const d = days.filter((x) => x < today).pop(); // never the current day
    if (d && (!best || d < best.day)) best = { shop: s, day: d };
  }
  return best;
}

async function removeDay(shop: string, day: string) {
  await fs.rm(path.join(dataRoot(), shop, day), { recursive: true, force: true }).catch(() => {});
  dayCache.delete(`${shop}|${day}`);
}

let cleaning = false;
async function cleanup() {
  if (cleaning) return;
  cleaning = true;
  try {
    let shops: string[] = [];
    try {
      shops = (await fs.readdir(dataRoot())).filter((n) => !n.startsWith("."));
    } catch {
      return;
    }
    // 1) retention: 30 days
    for (const s of shops) {
      const keep = (await getShopSettings(s)).retentionDays || REC_RETENTION_DAYS;
      const oldest = dayOf(Date.now() - (keep - 1) * DAY_MS);
      for (const d of await listDays(s)) if (d < oldest) await removeDay(s, d);
    }
    // 2) disk: keep ≥ MIN_FREE + 1 GB free by dropping the oldest days first,
    //    so recording never stops — the store keeps as many days as fit
    for (let i = 0; i < 40; i++) {
      disk.at = 0;
      const { free } = await diskInfo();
      if (free >= MIN_FREE + 1024 ** 3) break;
      const o = await oldestDay(shops);
      if (!o) break;
      await removeDay(o.shop, o.day);
    }
  } finally {
    cleaning = false;
  }
}

/** first day still stored (for the admin: "keeping N days") */
export async function storedSince(shop: string) {
  const days = await listDays(shop);
  return days.length ? days[days.length - 1] : "";
}

declare global {
  // eslint-disable-next-line no-var
  var wcRecScheduler: NodeJS.Timeout | undefined;
}

export function startRecScheduler() {
  if (globalThis.wcRecScheduler) return;
  globalThis.wcRecScheduler = setInterval(() => void cleanup(), 60 * 60 * 1000);
  setTimeout(() => void cleanup(), 30000);
}
