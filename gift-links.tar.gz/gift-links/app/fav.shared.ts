/**
 * Favicon Cart Count (replacement for Vitals «Favicon Cart Count»): shared types,
 * defaults (= Roman's Vitals settings on 2026-10-15) and validation.
 */
export type FavShape = "circle" | "rectangle";
export type FavPos = "top-left" | "top-right" | "bottom-left" | "bottom-right";
export type FavAnim = "slide" | "fade" | "pop" | "popFade" | "none";

export type FavConfig = {
  version: 1;
  enabled: boolean;
  shape: FavShape;
  position: FavPos;
  animation: FavAnim;
  bg: string; // 6 hex, no #
  color: string; // 6 hex, no #
  interval: number; // seconds between repeats, 0 = never
  updatedAt: string;
};

export const FAV_SHAPES: { value: FavShape; label: string }[] = [
  { value: "circle", label: "Circle" },
  { value: "rectangle", label: "Rectangle" },
];
export const FAV_POSITIONS: { value: FavPos; label: string }[] = [
  { value: "top-left", label: "Top Left" },
  { value: "top-right", label: "Top Right" },
  { value: "bottom-left", label: "Bottom Left" },
  { value: "bottom-right", label: "Bottom Right" },
];
export const FAV_ANIMS: { value: FavAnim; label: string }[] = [
  { value: "slide", label: "Slide" },
  { value: "fade", label: "Fade" },
  { value: "pop", label: "Pop" },
  { value: "popFade", label: "Pop & Fade" },
  { value: "none", label: "No animation" },
];
export const FAV_INTERVALS: { value: number; label: string }[] = [
  { value: 1, label: "1 second" },
  { value: 2, label: "2 seconds" },
  { value: 3, label: "3 seconds" },
  { value: 5, label: "5 seconds" },
  { value: 0, label: "Never" },
];

export const FAV_DEFAULTS: FavConfig = {
  version: 1,
  enabled: false,
  shape: "circle",
  position: "bottom-left",
  animation: "pop",
  bg: "ff0101",
  color: "ffffff",
  interval: 2,
  updatedAt: "",
};

const hex = (v: unknown, d: string) => {
  const s = String(v ?? "").replace(/^#/, "").trim().toLowerCase();
  return /^[0-9a-f]{6}$/.test(s) ? s : d;
};
const pick = <T,>(v: unknown, list: { value: T }[], d: T): T => (list.some((x) => x.value === v) ? (v as T) : d);

export function normalizeFav(raw: unknown): FavConfig {
  const p = (raw && typeof raw === "object" ? raw : {}) as Record<string, unknown>;
  return {
    version: 1,
    enabled: p.enabled === true,
    shape: pick(p.shape, FAV_SHAPES, FAV_DEFAULTS.shape),
    position: pick(p.position, FAV_POSITIONS, FAV_DEFAULTS.position),
    animation: pick(p.animation, FAV_ANIMS, FAV_DEFAULTS.animation),
    bg: hex(p.bg, FAV_DEFAULTS.bg),
    color: hex(p.color, FAV_DEFAULTS.color),
    interval: pick(Number(p.interval), FAV_INTERVALS, FAV_DEFAULTS.interval),
    updatedAt: typeof p.updatedAt === "string" ? p.updatedAt : "",
  };
}
