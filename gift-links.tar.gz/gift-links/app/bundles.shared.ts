export type BundleItem = {
  productId: string; variantId: string; title: string; image: string;
  value: number | null; quantity: number; free: boolean;
};
export type BundlePanel = { id: string; items: BundleItem[] };
export type BundleConfig = {
  version: 1; enabled: boolean; includePaid: boolean; updatedAt: string; currencyCode: string;
  panels: BundlePanel[]; variants: Record<string, string>;
  manualVariantIds?: string[];
};
export function cents(value: unknown): number | null {
  if (value === null || value === undefined || value === "") return null;
  const n = Number(value);
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : null;
}
export function sortItems(items: BundleItem[]): BundleItem[] {
  return [...items].sort((a, b) => (b.value ?? -1) - (a.value ?? -1) || a.title.localeCompare(b.title));
}
export function readBundle(value?: string | null): BundleConfig | null {
  try {
    const c = JSON.parse(value || "null");
    return c?.version === 1 && Array.isArray(c.panels) && c.variants ? c : null;
  } catch { return null; }
}
