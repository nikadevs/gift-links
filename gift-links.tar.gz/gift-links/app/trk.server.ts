/**
 * Tracking module engine (replacement for Track123).
 *
 *  1. import  — Shopify orders with fulfillments → one record per tracking number
 *               (the warehouse makes 2–3 fulfillments with the same YT number).
 *  2. poll    — YunExpress Open API, every `pollHours` per active parcel
 *               (gives the last-mile number + carrier and all last-mile scans).
 *  3. outputs — only when switched on in Settings:
 *               Shopify fulfillment events on EVERY fulfillment with the number,
 *               tracking URL → our page, Omnisend custom events, PayPal tracking.
 * Runs inside the app process (pm2), started from entry.server.tsx.
 */
import prisma from "./db.server";
import { unauthenticated } from "./shopify.server";
import {
  TRK_FINAL,
  TRK_OMNISEND_EVENT,
  TRK_STATUS_LABEL,
  TRK_TO_SHOPIFY,
  daysBetween,
  overallStatus,
  type TrkSettings,
  type TrkShipment,
  type TrkStatus,
} from "./trk.shared";
import {
  addLog,
  getState,
  getTrkSettings,
  loadShipments,
  saveShipments,
  setState,
  withShop,
  type TrkLog,
} from "./trk-store.server";
import { yunConfigured, yunTrack } from "./trk-yun.server";

type Admin = Awaited<ReturnType<typeof unauthenticated.admin>>["admin"];

const HOUR = 3_600_000;
const DAY = 24 * HOUR;
const TICK_MS = 20 * 60 * 1000;
const MAX_POLLS_PER_TICK = 300;

async function gql<T = Record<string, unknown>>(admin: Admin, query: string, variables?: Record<string, unknown>) {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  return json.data as T;
}

export function isYunNumber(number: string, carrier: string) {
  return /^YT\d{10,}$/i.test(number) || /yun/i.test(carrier);
}

// ---------------------------------------------------------------------------
// 1. import from Shopify

type OrderNode = {
  id: string;
  name: string;
  createdAt: string;
  email: string | null;
  displayFulfillmentStatus: string;
  customer: { firstName: string | null } | null;
  shippingAddress: { countryCodeV2: string | null; firstName: string | null } | null;
  fulfillments: {
    id: string;
    createdAt: string;
    status: string;
    trackingInfo: { company: string | null; number: string | null; url: string | null }[];
  }[];
};

const ORDERS_Q = `#graphql
query WcTrkOrders($q: String!, $after: String) {
  orders(first: 50, after: $after, query: $q, sortKey: UPDATED_AT) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id name createdAt email displayFulfillmentStatus
      customer { firstName }
      shippingAddress { countryCodeV2 firstName }
      fulfillments(first: 10) { id createdAt status trackingInfo(first: 5) { company number url } }
    }
  }
}`;

function blankShipment(number: string, carrier: string, o: OrderNode, shippedAt: string): TrkShipment {
  const now = new Date().toISOString();
  return {
    number,
    carrier,
    orderId: o.id,
    orderName: o.name,
    email: o.email ?? "",
    firstName: o.customer?.firstName || o.shippingAddress?.firstName || "",
    country: o.shippingAddress?.countryCodeV2 ?? "",
    fulfillmentIds: [],
    shippedAt,
    status: "pending",
    statusAt: shippedAt,
    lastMileNumber: "",
    lastMileCarrier: "",
    lastMileSite: "",
    events: [],
    transitDays: null,
    deliveredAt: "",
    // YunExpress finds its own waybills and the last-mile numbers it handed over
    source: "yunexpress",
    lastPolledAt: "",
    lastError: "",
    pollCount: 0,
    shopifyStatus: {},
    urlUpdated: [],
    notified: {},
    paypal: { state: "", at: "", error: "" },
    createdAt: now,
  };
}

export async function importOrders(shop: string, admin: Admin, s: TrkSettings, fullDays?: number) {
  const st = await getState(shop);
  const since = fullDays
    ? new Date(Date.now() - fullDays * DAY)
    : st.lastImportAt
      ? new Date(Date.parse(st.lastImportAt) - HOUR)
      : new Date(Date.now() - s.importDays * DAY);
  const startedAt = new Date().toISOString();
  const q = `(fulfillment_status:shipped OR fulfillment_status:partial) updated_at:>='${since.toISOString()}' created_at:>='${new Date(Date.now() - s.maxDays * DAY).toISOString()}'`;
  const m = await loadShipments(shop);
  let after: string | null = null;
  let added = 0;
  let pages = 0;
  do {
    const data: { orders: { pageInfo: { hasNextPage: boolean; endCursor: string }; nodes: OrderNode[] } } = await gql(
      admin,
      ORDERS_Q,
      { q, after },
    );
    for (const o of data.orders.nodes) {
      for (const f of o.fulfillments) {
        if (f.status === "CANCELLED" || f.status === "ERROR" || f.status === "FAILURE") continue;
        for (const t of f.trackingInfo) {
          const number = String(t.number ?? "").trim();
          if (!number) continue;
          const key = number.toUpperCase();
          let rec = m.get(key);
          if (!rec) {
            rec = blankShipment(number, String(t.company ?? ""), o, f.createdAt);
            m.set(key, rec);
            added++;
          }
          if (!rec.fulfillmentIds.includes(f.id)) rec.fulfillmentIds.push(f.id);
          if (!rec.email && o.email) rec.email = o.email;
          if (f.createdAt < rec.shippedAt) rec.shippedAt = f.createdAt;
        }
      }
    }
    after = data.orders.pageInfo.hasNextPage ? data.orders.pageInfo.endCursor : null;
    pages++;
  } while (after && pages < 60);
  await saveShipments(shop);
  await setState(shop, { lastImportAt: startedAt });
  return { added, total: m.size };
}

// ---------------------------------------------------------------------------
// 2. poll the carrier

export async function refreshOne(s: TrkSettings, rec: TrkShipment): Promise<boolean> {
  const before = `${rec.status}|${rec.events.length}|${rec.lastMileNumber}`;
  rec.lastPolledAt = new Date().toISOString();
  rec.pollCount++;
  if (rec.source !== "yunexpress" || !yunConfigured(s)) return false;
  try {
    const r = await yunTrack(s, rec.number);
    rec.lastError = r.found ? "" : "Not found at YunExpress yet";
    // not a YunExpress parcel (other carrier) → stop asking after a few tries
    if (!r.found && !rec.events.length && rec.pollCount >= 4 && !isYunNumber(rec.number, rec.carrier)) {
      rec.source = "none";
      rec.lastError = "Not a YunExpress parcel — link to the carrier website only";
    }
    if (r.found) {
      rec.events = r.events;
      if (r.lastMileNumber) rec.lastMileNumber = r.lastMileNumber;
      if (r.lastMileCarrier) rec.lastMileCarrier = r.lastMileCarrier;
      if (r.lastMileSite) rec.lastMileSite = r.lastMileSite;
      const st = overallStatus(r.events, !!rec.lastMileNumber);
      if (st !== rec.status) {
        rec.status = st;
        rec.statusAt = r.events[0]?.at || rec.lastPolledAt;
      }
      if (st === "delivered") {
        rec.deliveredAt = r.events.find((e) => e.status === "delivered")?.at || rec.statusAt;
        rec.transitDays = r.intervalDays ?? daysBetween(rec.shippedAt, rec.deliveredAt);
      }
    }
  } catch (e) {
    rec.lastError = (e as Error).message.slice(0, 300);
  }
  const age = Date.now() - Date.parse(rec.shippedAt);
  const lastAt = Date.parse(rec.events[0]?.at || rec.shippedAt);
  if (!TRK_FINAL.includes(rec.status) && Date.now() - lastAt > 30 * DAY && age > 45 * DAY) {
    rec.status = "expired";
    rec.statusAt = new Date().toISOString();
  }
  return before !== `${rec.status}|${rec.events.length}|${rec.lastMileNumber}`;
}

function isDue(s: TrkSettings, rec: TrkShipment, now: number) {
  if (TRK_FINAL.includes(rec.status) || rec.source === "none") return false;
  if (now - Date.parse(rec.shippedAt) > s.maxDays * DAY) return false;
  if (!rec.lastPolledAt) return true;
  // fresh labels and parcels close to delivery are checked more often
  const hours = rec.status === "out_for_delivery" || rec.status === "attempt_fail" ? Math.min(3, s.pollHours) : s.pollHours;
  return now - Date.parse(rec.lastPolledAt) >= hours * HOUR - 5 * 60 * 1000;
}

// ---------------------------------------------------------------------------
// 3. outputs

export function pageUrl(domain: string, s: TrkSettings, number: string) {
  return `${domain}/pages/${s.pageHandle}?nums=${encodeURIComponent(number)}`;
}

async function postShopify(admin: Admin, s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  const status = TRK_TO_SHOPIFY[rec.status];
  const now = new Date().toISOString();
  for (const fid of rec.fulfillmentIds) {
    if (s.shopifyEvents && status && rec.shopifyStatus[fid] !== status) {
      const top = rec.events[0];
      try {
        const d: { fulfillmentEventCreate: { userErrors: { message: string }[] } } = await gql(
          admin,
          `#graphql
          mutation WcTrkEvent($e: FulfillmentEventInput!) {
            fulfillmentEventCreate(fulfillmentEvent: $e) { fulfillmentEvent { id } userErrors { field message } }
          }`,
          {
            e: {
              fulfillmentId: fid,
              status,
              happenedAt: rec.statusAt || now,
              message: top?.text?.slice(0, 250) || TRK_STATUS_LABEL[rec.status],
              ...(rec.country ? { country: rec.country } : {}),
            },
          },
        );
        const errs = d.fulfillmentEventCreate.userErrors;
        if (errs.length) throw new Error(errs.map((x) => x.message).join("; "));
        rec.shopifyStatus[fid] = status;
        log.push({ at: now, kind: "shopify", number: rec.number, order: rec.orderName, ok: true, text: `${status} → ${fid.split("/").pop()}` });
      } catch (e) {
        log.push({ at: now, kind: "shopify", number: rec.number, order: rec.orderName, ok: false, text: (e as Error).message.slice(0, 200) });
      }
    }
    if (s.shopifyUrl && domain && !rec.urlUpdated.includes(fid)) {
      try {
        const d: { fulfillmentTrackingInfoUpdate: { userErrors: { message: string }[] } } = await gql(
          admin,
          `#graphql
          mutation WcTrkUrl($id: ID!, $t: FulfillmentTrackingInput!) {
            fulfillmentTrackingInfoUpdate(fulfillmentId: $id, trackingInfoInput: $t, notifyCustomer: false) {
              fulfillment { id } userErrors { field message }
            }
          }`,
          { id: fid, t: { number: rec.number, company: rec.carrier || "YunExpress", url: pageUrl(domain, s, rec.number) } },
        );
        const errs = d.fulfillmentTrackingInfoUpdate.userErrors;
        if (errs.length) throw new Error(errs.map((x) => x.message).join("; "));
        rec.urlUpdated.push(fid);
        log.push({ at: now, kind: "url", number: rec.number, order: rec.orderName, ok: true, text: `link → our page (${fid.split("/").pop()})` });
      } catch (e) {
        log.push({ at: now, kind: "url", number: rec.number, order: rec.orderName, ok: false, text: (e as Error).message.slice(0, 200) });
      }
    }
  }
}

async function postOmnisend(s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  const name = TRK_OMNISEND_EVENT[rec.status];
  if (!s.omnisendEnabled || !s.omnisendKey || !name || !s.omnisendStatuses.includes(rec.status)) return;
  if (rec.notified[name] || !rec.email) return;
  // don't email old news: only events that happened in the last 3 days
  if (Date.now() - Date.parse(rec.statusAt) > 3 * DAY) {
    rec.notified[name] = `skipped-old:${new Date().toISOString()}`;
    return;
  }
  const now = new Date().toISOString();
  const top = rec.events[0];
  const body = {
    eventName: name,
    origin: "api",
    eventID: `${rec.number}-${rec.status}`,
    eventTime: now,
    contact: { email: rec.email },
    properties: {
      orderNumber: rec.orderName,
      trackingNumber: rec.number,
      carrier: rec.carrier || "YunExpress",
      lastMileNumber: rec.lastMileNumber,
      lastMileCarrier: rec.lastMileCarrier,
      status: TRK_STATUS_LABEL[rec.status],
      statusCode: rec.status,
      lastEvent: top?.text ?? "",
      lastEventPlace: top?.place ?? "",
      lastEventTime: top?.at ?? "",
      trackingUrl: domain ? pageUrl(domain, s, rec.number) : "",
      firstName: rec.firstName,
      country: rec.country,
    },
  };
  try {
    const res = await fetch("https://api.omnisend.com/api/events", {
      method: "POST",
      headers: {
        Authorization: `Omnisend-API-Key ${s.omnisendKey}`,
        "Omnisend-Version": "2026-03-15",
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(15000),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
    rec.notified[name] = now;
    log.push({ at: now, kind: "omnisend", number: rec.number, order: rec.orderName, ok: true, text: name });
  } catch (e) {
    log.push({ at: now, kind: "omnisend", number: rec.number, order: rec.orderName, ok: false, text: `${name}: ${(e as Error).message.slice(0, 200)}` });
  }
}

let ppToken: { key: string; token: string; until: number } | null = null;

async function paypalToken(s: TrkSettings) {
  const key = s.paypalClientId;
  if (ppToken && ppToken.key === key && ppToken.until > Date.now() + 60_000) return ppToken.token;
  const res = await fetch("https://api-m.paypal.com/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${s.paypalClientId}:${s.paypalSecret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    signal: AbortSignal.timeout(15000),
  });
  const j = (await res.json().catch(() => ({}))) as { access_token?: string; expires_in?: number; error_description?: string };
  if (!res.ok || !j.access_token) throw new Error(`PayPal token: HTTP ${res.status} ${j.error_description ?? ""}`);
  ppToken = { key, token: j.access_token, until: Date.now() + (j.expires_in ?? 3000) * 1000 };
  return ppToken.token;
}

const PP_CARRIERS: [RegExp, string][] = [
  [/yun/i, "YUNEXPRESS"],
  [/gofo/i, "GOFO_EXPRESS"],
  [/\bubi\b/i, "UBI_LOGISTICS"],
  [/canada post/i, "CA_CANADA_POST"],
];

async function postPaypal(admin: Admin, s: TrkSettings, rec: TrkShipment, log: TrkLog[]) {
  if (!s.paypalEnabled || !s.paypalClientId || !s.paypalSecret) return;
  if (rec.paypal.state === "ok" || rec.paypal.state === "na") return;
  // retry failed uploads at most every 12 h
  if (rec.paypal.state === "error" && Date.now() - Date.parse(rec.paypal.at) < 12 * HOUR) return;
  const now = new Date().toISOString();
  try {
    const d: { order: { transactions: { kind: string; status: string; gateway: string; authorizationCode: string | null }[] } | null } =
      await gql(
        admin,
        `#graphql
        query WcTrkTx($id: ID!) { order(id: $id) { transactions(first: 20) { kind status gateway authorizationCode } } }`,
        { id: rec.orderId },
      );
    const tx = d.order?.transactions ?? [];
    if (!tx.some((t) => /paypal/i.test(t.gateway))) {
      rec.paypal = { state: "na", at: now, error: "" };
      return;
    }
    const cap = tx.find((t) => /paypal/i.test(t.gateway) && (t.kind === "CAPTURE" || t.kind === "SALE") && t.status === "SUCCESS" && t.authorizationCode);
    if (!cap) {
      rec.paypal = { state: "error", at: now, error: "No captured PayPal payment yet" };
      return;
    }
    const carrier = PP_CARRIERS.find(([re]) => re.test(rec.carrier))?.[1] ?? "OTHER";
    const tracker: Record<string, string> = {
      transaction_id: String(cap.authorizationCode),
      tracking_number: rec.number,
      status: "SHIPPED",
      carrier,
    };
    if (carrier === "OTHER") tracker.carrier_name_other = rec.carrier || "YunExpress";
    const token = await paypalToken(s);
    const res = await fetch("https://api-m.paypal.com/v1/shipping/trackers-batch", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ trackers: [tracker] }),
      signal: AbortSignal.timeout(20000),
    });
    const j = (await res.json().catch(() => ({}))) as { errors?: { message?: string; details?: { issue?: string; description?: string }[] }[] };
    const errs = j.errors ?? [];
    // already present on PayPal = fine
    const dup = errs.some((e) => /exist|duplicate/i.test(JSON.stringify(e)));
    if (!res.ok || (errs.length && !dup)) throw new Error(`HTTP ${res.status} ${JSON.stringify(errs).slice(0, 200)}`);
    rec.paypal = { state: "ok", at: now, error: "" };
    log.push({ at: now, kind: "paypal", number: rec.number, order: rec.orderName, ok: true, text: `tracking sent (${carrier})` });
  } catch (e) {
    rec.paypal = { state: "error", at: now, error: (e as Error).message.slice(0, 200) };
    log.push({ at: now, kind: "paypal", number: rec.number, order: rec.orderName, ok: false, text: rec.paypal.error });
  }
}

export async function applyOutputs(admin: Admin, s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  await postPaypal(admin, s, rec, log);
  if (rec.status === "pending") return;
  await postShopify(admin, s, rec, domain, log);
  await postOmnisend(s, rec, domain, log);
}

// ---------------------------------------------------------------------------
// tick

const domainCache = new Map<string, { at: number; url: string }>();
export async function storefrontDomain(shop: string, admin: Admin) {
  const hit = domainCache.get(shop);
  if (hit && Date.now() - hit.at < 6 * HOUR) return hit.url;
  const d: { shop: { primaryDomain: { url: string } } } = await gql(admin, `#graphql
    query WcTrkDomain { shop { primaryDomain { url } } }`);
  const url = d.shop.primaryDomain.url.replace(/\/$/, "");
  domainCache.set(shop, { at: Date.now(), url });
  return url;
}

const running = new Set<string>();
export const isTickRunning = (shop: string) => running.has(shop);

export async function runTick(shop: string, opts: { force?: boolean; limit?: number } = {}) {
  if (running.has(shop)) return { skipped: true };
  running.add(shop);
  try {
    return await withShop(shop, async () => {
      const s = await getTrkSettings(shop);
      if (!s.pollEnabled && !opts.force) return { skipped: true };
      const { admin } = await unauthenticated.admin(shop);
      const log: TrkLog[] = [];
      const now = Date.now();
      const imp = await importOrders(shop, admin, s);
      const domain = await storefrontDomain(shop, admin).catch(() => "");
      const m = await loadShipments(shop);
      const due = [...m.values()]
        .filter((r) => isDue(s, r, now))
        .sort((a, b) => (a.lastPolledAt || "") < (b.lastPolledAt || "") ? -1 : 1)
        .slice(0, opts.limit ?? MAX_POLLS_PER_TICK);
      let changed = 0;
      let errors = 0;
      for (const rec of due) {
        const ch = await refreshOne(s, rec);
        if (rec.lastError && !/not found/i.test(rec.lastError)) errors++;
        if (ch) changed++;
        await applyOutputs(admin, s, rec, domain, log);
        await new Promise((r) => setTimeout(r, 400));
        if (errors >= 10 && errors === due.indexOf(rec) + 1) break; // keys wrong → stop early
      }
      // PayPal can go before the first carrier scan
      for (const rec of m.values()) {
        if (!due.includes(rec) && s.paypalEnabled && (rec.paypal.state === "" || rec.paypal.state === "error")) {
          await postPaypal(admin, s, rec, log);
        }
      }
      await saveShipments(shop);
      await addLog(shop, [
        ...log,
        { at: new Date().toISOString(), kind: "sync", ok: errors === 0, text: `imported ${imp.added} new, checked ${due.length}, changed ${changed}, errors ${errors}` },
      ]);
      await setState(shop, { lastTickAt: new Date().toISOString(), lastError: errors ? `${errors} carrier errors` : "" });
      return { skipped: false, imported: imp.added, checked: due.length, changed, errors };
    });
  } finally {
    running.delete(shop);
  }
}

declare global {
  // eslint-disable-next-line no-var
  var wcTrkScheduler: NodeJS.Timeout | undefined;
}

async function tickAll() {
  if (process.env.WC_TRK_SCHEDULER === "off") return;
  let shops: string[] = [];
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    shops = [...new Set<string>(rows.map((r: { shop: string }) => r.shop))];
  } catch {
    return;
  }
  for (const shop of shops) {
    try {
      await runTick(shop);
    } catch (e) {
      console.warn(`[wc-trk] ${shop}:`, (e as Error).message);
      await setState(shop, { lastError: (e as Error).message.slice(0, 300) }).catch(() => {});
    }
  }
}

export function startTrkScheduler() {
  if (globalThis.wcTrkScheduler) return;
  globalThis.wcTrkScheduler = setInterval(() => void tickAll(), TICK_MS);
  setTimeout(() => void tickAll(), 90_000);
}

// ---------------------------------------------------------------------------
// stats for the admin page

export type TrkStats = {
  total: number;
  byStatus: Record<TrkStatus, number>;
  avgDeliveryDays: number | null;
  byCountry: { country: string; delivered: number; avg: number | null; active: number }[];
  byCarrier: { carrier: string; delivered: number; avg: number | null }[];
  stuck: number; // active, no scan for 7+ days
};

export function computeStats(list: TrkShipment[], days: number): TrkStats {
  const since = Date.now() - days * DAY;
  const rows = list.filter((r) => Date.parse(r.shippedAt) >= since);
  const byStatus = Object.fromEntries(
    (Object.keys(TRK_STATUS_LABEL) as TrkStatus[]).map((k) => [k, 0]),
  ) as Record<TrkStatus, number>;
  const delivered: number[] = [];
  const country = new Map<string, { d: number[]; active: number }>();
  const carrier = new Map<string, number[]>();
  let stuck = 0;
  for (const r of rows) {
    byStatus[r.status]++;
    const c = country.get(r.country || "—") ?? { d: [], active: 0 };
    if (r.status === "delivered" && r.transitDays != null) {
      delivered.push(r.transitDays);
      c.d.push(r.transitDays);
      const k = r.lastMileCarrier || r.carrier || "—";
      carrier.set(k, [...(carrier.get(k) ?? []), r.transitDays]);
    } else if (!TRK_FINAL.includes(r.status)) {
      c.active++;
      const last = Date.parse(r.events[0]?.at || r.shippedAt);
      if (Date.now() - last > 7 * DAY) stuck++;
    }
    country.set(r.country || "—", c);
  }
  const avg = (a: number[]) => (a.length ? Math.round((a.reduce((x, y) => x + y, 0) / a.length) * 10) / 10 : null);
  return {
    total: rows.length,
    byStatus,
    avgDeliveryDays: avg(delivered),
    byCountry: [...country.entries()]
      .map(([k, v]) => ({ country: k, delivered: v.d.length, avg: avg(v.d), active: v.active }))
      .sort((a, b) => b.delivered + b.active - (a.delivered + a.active))
      .slice(0, 15),
    byCarrier: [...carrier.entries()]
      .map(([k, v]) => ({ carrier: k, delivered: v.length, avg: avg(v) }))
      .sort((a, b) => b.delivered - a.delivered)
      .slice(0, 15),
    stuck,
  };
}
