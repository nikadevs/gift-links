/**
 * Tracking module engine (replacement for Track123).
 *
 *  1. import  — Shopify orders with fulfillments → one record per tracking number
 *               (the warehouse makes 2–3 fulfillments with the same YT number).
 *  2. poll    — YunExpress Open API, every `pollHours` per active parcel
 *               (gives the last-mile number + carrier and all last-mile scans).
 *  3. outputs — only when switched on in Settings:
 *               Shopify fulfillment events on EVERY fulfillment with the number,
 *               tracking URL → our page, Omnisend custom events, PayPal tracking.
 * Runs inside the app process (pm2), started from entry.server.tsx.
 */
import prisma from "./db.server";
import { unauthenticated } from "./shopify.server";
import {
  TRK_FINAL,
  TRK_OMNISEND_EVENT,
  TRK_ADMIN_EVENT,
  TRK_DAY_BUCKETS,
  TRK_STATUS_LABEL,
  TRK_STATUS_ORDER,
  TRK_TO_SHOPIFY,
  daysBetween,
  overallStatus,
  stripChinese,
  type TrkSettings,
  type TrkShipment,
  type TrkStatus,
} from "./trk.shared";
import {
  addLog,
  getState,
  getTrkSettings,
  loadShipments,
  saveShipments,
  setState,
  withShop,
  type TrkLog,
} from "./trk-store.server";
import { yunConfigured, yunTrack } from "./trk-yun.server";
import { dscpConfigured, dscpTrack, isYunName, statusFromDscp } from "./trk-dscp.server";

/** Any carrier data source set up: YunExpress Open API (full history + last mile) or the warehouse API. */
export function carrierConfigured(s: TrkSettings) {
  return yunConfigured(s) || dscpConfigured(s);
}

/** Warehouse API: latest status + latest event only → history is built from the changes we see. */
async function refreshFromDscp(s: TrkSettings, rec: TrkShipment) {
  const r = await dscpTrack(s, rec.number);
  rec.lastError = r.found ? "" : "Not found at the warehouse API yet";
  if (!r.found || !r.record) return;
  const x = r.record;
  const st = statusFromDscp(x.status, x.statusDescription, x.description ?? "");
  const text = (x.description || x.statusDescription || "").trim();
  const syncAt = x.lastSyncTime && Number.isFinite(Date.parse(x.lastSyncTime)) ? new Date(x.lastSyncTime).toISOString() : new Date().toISOString();
  const top = rec.events[0];
  if (text && (!top || top.text !== text || top.code !== x.status)) {
    rec.events = [{ at: syncAt, text, place: x.countryCode || "", code: x.status, status: st }, ...rec.events].slice(0, 100);
  }
  if (x.carrierName && !rec.lastMileCarrier && !isYunName(x.carrierName) && x.carrierName !== rec.carrier) rec.lastMileCarrier = stripChinese(x.carrierName) || "";
  if (st !== rec.status && !(st === "pending" && rec.status !== "pending")) {
    rec.status = st;
    rec.statusAt = syncAt;
  }
  if (st === "delivered" && !rec.deliveredAt) {
    rec.deliveredAt = syncAt; // the API has no delivery time; first time we see "delivered"
    rec.transitDays = daysBetween(rec.shippedAt, rec.deliveredAt);
  }
}

type Admin = Awaited<ReturnType<typeof unauthenticated.admin>>["admin"];

const HOUR = 3_600_000;
const DAY = 24 * HOUR;
const TICK_MS = 20 * 60 * 1000;
const MAX_POLLS_PER_TICK = 300;

async function gql<T = Record<string, unknown>>(admin: Admin, query: string, variables?: Record<string, unknown>) {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  return json.data as T;
}

export function isYunNumber(number: string, carrier: string) {
  return /^YT\d{10,}$/i.test(number) || /yun/i.test(carrier);
}

// ---------------------------------------------------------------------------
// 1. import from Shopify

type OrderNode = {
  id: string;
  name: string;
  createdAt: string;
  email: string | null;
  displayFulfillmentStatus: string;
  shippingAddress: { countryCodeV2: string | null; firstName: string | null } | null;
  fulfillments: {
    id: string;
    createdAt: string;
    status: string;
    trackingInfo: { company: string | null; number: string | null; url: string | null }[];
  }[];
};

const ORDERS_Q = `#graphql
query WcTrkOrders($q: String!, $after: String) {
  orders(first: 50, after: $after, query: $q, sortKey: UPDATED_AT) {
    pageInfo { hasNextPage endCursor }
    nodes {
      id name createdAt email displayFulfillmentStatus
      shippingAddress { countryCodeV2 firstName }
      fulfillments(first: 10) { id createdAt status trackingInfo(first: 5) { company number url } }
    }
  }
}`;

function blankShipment(number: string, carrier: string, o: OrderNode, shippedAt: string): TrkShipment {
  const now = new Date().toISOString();
  return {
    number,
    carrier,
    orderId: o.id,
    orderName: o.name,
    orderCreatedAt: o.createdAt,
    email: o.email ?? "",
    firstName: o.shippingAddress?.firstName || "", // no read_customers scope: name from the shipping address
    country: o.shippingAddress?.countryCodeV2 ?? "",
    fulfillmentIds: [],
    shippedAt,
    status: "pending",
    statusAt: shippedAt,
    lastMileNumber: "",
    lastMileCarrier: "",
    lastMileSite: "",
    events: [],
    transitDays: null,
    deliveredAt: "",
    // YunExpress finds its own waybills and the last-mile numbers it handed over
    source: "yunexpress",
    lastPolledAt: "",
    lastError: "",
    pollCount: 0,
    shopifyStatus: {},
    urlUpdated: [],
    notified: {},
    paypal: { state: "", at: "", error: "" },
    createdAt: now,
  };
}

export async function importOrders(shop: string, admin: Admin, s: TrkSettings, fullDays?: number) {
  const st = await getState(shop);
  const since = fullDays
    ? new Date(Date.now() - fullDays * DAY)
    : st.lastImportAt
      ? new Date(Date.parse(st.lastImportAt) - HOUR)
      : new Date(Date.now() - s.importDays * DAY);
  const startedAt = new Date().toISOString();
  const q = `(fulfillment_status:shipped OR fulfillment_status:partial) updated_at:>='${since.toISOString()}' created_at:>='${new Date(Date.now() - s.maxDays * DAY).toISOString()}'`;
  const m = await loadShipments(shop);
  let after: string | null = null;
  let added = 0;
  let pages = 0;
  do {
    const data: { orders: { pageInfo: { hasNextPage: boolean; endCursor: string }; nodes: OrderNode[] } } = await gql(
      admin,
      ORDERS_Q,
      { q, after },
    );
    for (const o of data.orders.nodes) {
      for (const f of o.fulfillments) {
        if (f.status === "CANCELLED" || f.status === "ERROR" || f.status === "FAILURE") continue;
        for (const t of f.trackingInfo) {
          const number = String(t.number ?? "").trim();
          if (!number) continue;
          const key = number.toUpperCase();
          let rec = m.get(key);
          if (!rec) {
            rec = blankShipment(number, String(t.company ?? ""), o, f.createdAt);
            m.set(key, rec);
            added++;
          }
          if (!rec.fulfillmentIds.includes(f.id)) rec.fulfillmentIds.push(f.id);
          if (!rec.email && o.email) rec.email = o.email;
          if (!rec.orderCreatedAt) rec.orderCreatedAt = o.createdAt;
          if (f.createdAt < rec.shippedAt) rec.shippedAt = f.createdAt;
        }
      }
    }
    after = data.orders.pageInfo.hasNextPage ? data.orders.pageInfo.endCursor : null;
    pages++;
  } while (after && pages < 60);
  await saveShipments(shop);
  await setState(shop, { lastImportAt: startedAt });
  return { added, total: m.size };
}

// ---------------------------------------------------------------------------
// 2. poll the carrier

export async function refreshOne(s: TrkSettings, rec: TrkShipment): Promise<boolean> {
  const before = `${rec.status}|${rec.events.length}|${rec.lastMileNumber}`;
  rec.lastPolledAt = new Date().toISOString();
  rec.pollCount++;
  if (rec.source !== "yunexpress" || !carrierConfigured(s)) return false;
  if (!yunConfigured(s)) {
    try {
      await refreshFromDscp(s, rec);
    } catch (e) {
      rec.lastError = (e as Error).message.slice(0, 300);
    }
    return before !== `${rec.status}|${rec.events.length}|${rec.lastMileNumber}`;
  }
  try {
    const r = await yunTrack(s, rec.number);
    rec.lastError = r.found ? "" : "Not found at YunExpress yet";
    // not a YunExpress parcel (other carrier) → stop asking after a few tries
    if (!r.found && !rec.events.length && rec.pollCount >= 4 && !isYunNumber(rec.number, rec.carrier)) {
      rec.source = "none";
      rec.lastError = "Not a YunExpress parcel — link to the carrier website only";
    }
    if (r.found) {
      rec.events = r.events;
      if (r.lastMileNumber) rec.lastMileNumber = r.lastMileNumber;
      if (r.lastMileCarrier) rec.lastMileCarrier = r.lastMileCarrier;
      if (r.lastMileSite) rec.lastMileSite = r.lastMileSite;
      const st = overallStatus(r.events, !!rec.lastMileNumber);
      if (st !== rec.status) {
        rec.status = st;
        rec.statusAt = r.events[0]?.at || rec.lastPolledAt;
      }
      if (st === "delivered") {
        rec.deliveredAt = r.events.find((e) => e.status === "delivered")?.at || rec.statusAt;
        rec.transitDays = r.intervalDays ?? daysBetween(rec.shippedAt, rec.deliveredAt);
      }
    }
  } catch (e) {
    rec.lastError = (e as Error).message.slice(0, 300);
  }
  const age = Date.now() - Date.parse(rec.shippedAt);
  const lastAt = Date.parse(rec.events[0]?.at || rec.shippedAt);
  if (!TRK_FINAL.includes(rec.status) && Date.now() - lastAt > 30 * DAY && age > 45 * DAY) {
    rec.status = "expired";
    rec.statusAt = new Date().toISOString();
  }
  return before !== `${rec.status}|${rec.events.length}|${rec.lastMileNumber}`;
}

function isDue(s: TrkSettings, rec: TrkShipment, now: number) {
  if (TRK_FINAL.includes(rec.status) || rec.source === "none") return false;
  if (now - Date.parse(rec.shippedAt) > s.maxDays * DAY) return false;
  if (!rec.lastPolledAt) return true;
  // fresh labels and parcels close to delivery are checked more often
  const hours = rec.status === "out_for_delivery" || rec.status === "attempt_fail" ? Math.min(3, s.pollHours) : s.pollHours;
  return now - Date.parse(rec.lastPolledAt) >= hours * HOUR - 5 * 60 * 1000;
}

// ---------------------------------------------------------------------------
// 3. outputs

export function pageUrl(domain: string, s: TrkSettings, number: string) {
  return `${domain}/pages/${s.pageHandle}?nums=${encodeURIComponent(number)}`;
}

async function postShopify(admin: Admin, s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  const status = TRK_TO_SHOPIFY[rec.status];
  const now = new Date().toISOString();
  for (const fid of rec.fulfillmentIds) {
    if (s.shopifyEvents && status && rec.shopifyStatus[fid] !== status) {
      const top = rec.events[0];
      try {
        const d: { fulfillmentEventCreate: { userErrors: { message: string }[] } } = await gql(
          admin,
          `#graphql
          mutation WcTrkEvent($e: FulfillmentEventInput!) {
            fulfillmentEventCreate(fulfillmentEvent: $e) { fulfillmentEvent { id } userErrors { field message } }
          }`,
          {
            e: {
              fulfillmentId: fid,
              status,
              happenedAt: rec.statusAt || now,
              message: top?.text?.slice(0, 250) || TRK_STATUS_LABEL[rec.status],
              ...(rec.country ? { country: rec.country } : {}),
            },
          },
        );
        const errs = d.fulfillmentEventCreate.userErrors;
        if (errs.length) throw new Error(errs.map((x) => x.message).join("; "));
        rec.shopifyStatus[fid] = status;
        log.push({ at: now, kind: "shopify", number: rec.number, order: rec.orderName, ok: true, text: `${status} → ${fid.split("/").pop()}` });
      } catch (e) {
        log.push({ at: now, kind: "shopify", number: rec.number, order: rec.orderName, ok: false, text: (e as Error).message.slice(0, 200) });
      }
    }
    if (s.shopifyUrl && domain && !rec.urlUpdated.includes(fid)) {
      try {
        const d: { fulfillmentTrackingInfoUpdate: { userErrors: { message: string }[] } } = await gql(
          admin,
          `#graphql
          mutation WcTrkUrl($id: ID!, $t: FulfillmentTrackingInput!) {
            fulfillmentTrackingInfoUpdate(fulfillmentId: $id, trackingInfoInput: $t, notifyCustomer: false) {
              fulfillment { id } userErrors { field message }
            }
          }`,
          { id: fid, t: { number: rec.number, company: rec.carrier || "YunExpress", url: pageUrl(domain, s, rec.number) } },
        );
        const errs = d.fulfillmentTrackingInfoUpdate.userErrors;
        if (errs.length) throw new Error(errs.map((x) => x.message).join("; "));
        rec.urlUpdated.push(fid);
        log.push({ at: now, kind: "url", number: rec.number, order: rec.orderName, ok: true, text: `link → our page (${fid.split("/").pop()})` });
      } catch (e) {
        log.push({ at: now, kind: "url", number: rec.number, order: rec.orderName, ok: false, text: (e as Error).message.slice(0, 200) });
      }
    }
  }
}

export async function omnisendEvent(key: string, eventName: string, email: string, eventID: string, properties: Record<string, string>) {
  const res = await fetch("https://api.omnisend.com/api/events", {
    method: "POST",
    headers: {
      Authorization: `Omnisend-API-Key ${key}`,
      "Omnisend-Version": "2026-03-15",
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ eventName, origin: "api", eventID, eventTime: new Date().toISOString(), contact: { email }, properties }),
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status} ${(await res.text()).slice(0, 200)}`);
}

/** Same property set for every event — Omnisend accepts strings only and locks field names. */
export function omnisendProps(s: TrkSettings, rec: TrkShipment, domain: string, isTest: boolean): Record<string, string> {
  const top = rec.events[0];
  return {
    orderNumber: rec.orderName,
    trackingNumber: rec.number,
    carrier: rec.carrier || "YunExpress",
    lastMileNumber: rec.lastMileNumber,
    lastMileCarrier: rec.lastMileCarrier,
    status: TRK_STATUS_LABEL[rec.status],
    statusCode: rec.status,
    lastEvent: top?.text ?? "",
    lastEventPlace: top?.place ?? "",
    lastEventTime: top?.at ?? "",
    trackingUrl: domain ? pageUrl(domain, s, rec.number) : "",
    firstName: rec.firstName,
    country: rec.country,
    isTest: isTest ? "yes" : "no",
  };
}

async function postOmnisend(s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  const name = TRK_OMNISEND_EVENT[rec.status];
  const fresh = Date.now() - Date.parse(rec.statusAt) <= 3 * DAY; // don't email old news
  const now = new Date().toISOString();
  // to customers
  if (s.omnisendEnabled && s.omnisendKey && name && s.omnisendStatuses.includes(rec.status) && !rec.notified[name] && rec.email) {
    if (!fresh) rec.notified[name] = `skipped-old:${now}`;
    else {
      try {
        await omnisendEvent(s.omnisendKey, name, rec.email, `${rec.number}-${rec.status}`, omnisendProps(s, rec, domain, false));
        rec.notified[name] = now;
        log.push({ at: now, kind: "omnisend", number: rec.number, order: rec.orderName, ok: true, text: name });
      } catch (e) {
        log.push({ at: now, kind: "omnisend", number: rec.number, order: rec.orderName, ok: false, text: `${name}: ${(e as Error).message.slice(0, 200)}` });
      }
    }
  }
  // to yourself
  const akey = `admin:${rec.status}`;
  if (s.adminAlertsEnabled && s.omnisendKey && s.adminEmail && s.adminStatuses.includes(rec.status) && !rec.notified[akey]) {
    if (!fresh) rec.notified[akey] = `skipped-old:${now}`;
    else {
      try {
        await omnisendEvent(s.omnisendKey, TRK_ADMIN_EVENT, s.adminEmail, `${rec.number}-admin-${rec.status}`, omnisendProps(s, rec, domain, false));
        rec.notified[akey] = now;
        log.push({ at: now, kind: "alert", number: rec.number, order: rec.orderName, ok: true, text: `${TRK_STATUS_LABEL[rec.status]} → ${s.adminEmail}` });
      } catch (e) {
        log.push({ at: now, kind: "alert", number: rec.number, order: rec.orderName, ok: false, text: (e as Error).message.slice(0, 200) });
      }
    }
  }
}

/** Sends one test event per chosen status to `email` (so the events appear as workflow triggers in Omnisend). */
export async function sendOmnisendTests(s: TrkSettings, email: string, domain: string, sample: TrkShipment | null, admin: boolean) {
  if (!s.omnisendKey) throw new Error("Enter the Omnisend API key first");
  const base: TrkShipment =
    sample ??
    ({
      number: "YT0000000000000000",
      carrier: "YunExpress",
      orderName: "#00000",
      email,
      firstName: "Test",
      country: "GB",
      lastMileNumber: "QP000000000GB",
      lastMileCarrier: "Royal Mail",
      events: [{ at: new Date().toISOString(), text: "Test scan", place: "London, GB", code: "", status: "in_transit" }],
    } as unknown as TrkShipment);
  const sent: string[] = [];
  const statuses = admin ? s.adminStatuses.slice(0, 1) : s.omnisendStatuses;
  for (const st of statuses) {
    const name = admin ? TRK_ADMIN_EVENT : TRK_OMNISEND_EVENT[st];
    if (!name) continue;
    const rec = { ...base, status: st } as TrkShipment;
    await omnisendEvent(s.omnisendKey, name, email, `test-${st}-${Date.now()}`, omnisendProps(s, rec, domain, true));
    sent.push(name);
  }
  return sent;
}

let ppToken: { key: string; token: string; until: number } | null = null;

async function paypalToken(s: TrkSettings) {
  const key = s.paypalClientId;
  if (ppToken && ppToken.key === key && ppToken.until > Date.now() + 60_000) return ppToken.token;
  const res = await fetch("https://api-m.paypal.com/v1/oauth2/token", {
    method: "POST",
    headers: {
      Authorization: `Basic ${Buffer.from(`${s.paypalClientId}:${s.paypalSecret}`).toString("base64")}`,
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: "grant_type=client_credentials",
    signal: AbortSignal.timeout(15000),
  });
  const j = (await res.json().catch(() => ({}))) as { access_token?: string; expires_in?: number; error_description?: string };
  if (!res.ok || !j.access_token) throw new Error(`PayPal token: HTTP ${res.status} ${j.error_description ?? ""}`);
  ppToken = { key, token: j.access_token, until: Date.now() + (j.expires_in ?? 3000) * 1000 };
  return ppToken.token;
}

const PP_CARRIERS: [RegExp, string][] = [
  [/yun/i, "YUNEXPRESS"],
  [/gofo/i, "GOFO_EXPRESS"],
  [/\bubi\b/i, "UBI_LOGISTICS"],
  [/canada post/i, "CA_CANADA_POST"],
];

/** Checks the PayPal keys (token) and finds the last PayPal capture in Shopify — writes nothing. */
export async function paypalTest(admin: Admin, s: TrkSettings) {
  if (!s.paypalClientId || !s.paypalSecret) throw new Error("Enter Client ID and Secret first");
  ppToken = null;
  await paypalToken(s);
  const d: { orders: { nodes: { name: string; transactions: { kind: string; status: string; gateway: string; authorizationCode: string | null }[] }[] } } =
    await gql(admin, `#graphql
      query WcTrkPpTest { orders(first: 25, sortKey: CREATED_AT, reverse: true) { nodes { name transactions(first: 10) { kind status gateway authorizationCode } } } }`);
  const o = d.orders.nodes.find((n) => n.transactions.some((t) => /paypal/i.test(t.gateway) && t.kind === "CAPTURE" && t.status === "SUCCESS"));
  const cap = o?.transactions.find((t) => /paypal/i.test(t.gateway) && t.kind === "CAPTURE" && t.status === "SUCCESS");
  return { order: o?.name ?? "", transactionId: cap?.authorizationCode ?? "" };
}

async function postPaypal(admin: Admin, s: TrkSettings, rec: TrkShipment, log: TrkLog[]) {
  if (!s.paypalEnabled || !s.paypalClientId || !s.paypalSecret) return;
  if (rec.paypal.state === "ok" || rec.paypal.state === "na") return;
  // retry failed uploads at most every 12 h
  if (rec.paypal.state === "error" && Date.now() - Date.parse(rec.paypal.at) < 12 * HOUR) return;
  const now = new Date().toISOString();
  try {
    const d: { order: { transactions: { kind: string; status: string; gateway: string; authorizationCode: string | null }[] } | null } =
      await gql(
        admin,
        `#graphql
        query WcTrkTx($id: ID!) { order(id: $id) { transactions(first: 20) { kind status gateway authorizationCode } } }`,
        { id: rec.orderId },
      );
    const tx = d.order?.transactions ?? [];
    if (!tx.some((t) => /paypal/i.test(t.gateway))) {
      rec.paypal = { state: "na", at: now, error: "" };
      return;
    }
    const cap = tx.find((t) => /paypal/i.test(t.gateway) && (t.kind === "CAPTURE" || t.kind === "SALE") && t.status === "SUCCESS" && t.authorizationCode);
    if (!cap) {
      rec.paypal = { state: "error", at: now, error: "No captured PayPal payment yet" };
      return;
    }
    const carrier = PP_CARRIERS.find(([re]) => re.test(rec.carrier))?.[1] ?? "OTHER";
    const tracker: Record<string, string> = {
      transaction_id: String(cap.authorizationCode),
      tracking_number: rec.number,
      status: "SHIPPED",
      carrier,
    };
    if (carrier === "OTHER") tracker.carrier_name_other = rec.carrier || "YunExpress";
    const token = await paypalToken(s);
    const res = await fetch("https://api-m.paypal.com/v1/shipping/trackers-batch", {
      method: "POST",
      headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json" },
      body: JSON.stringify({ trackers: [tracker] }),
      signal: AbortSignal.timeout(20000),
    });
    const j = (await res.json().catch(() => ({}))) as { errors?: { message?: string; details?: { issue?: string; description?: string }[] }[] };
    const errs = j.errors ?? [];
    // already present on PayPal = fine
    const dup = errs.some((e) => /exist|duplicate/i.test(JSON.stringify(e)));
    if (!res.ok || (errs.length && !dup)) throw new Error(`HTTP ${res.status} ${JSON.stringify(errs).slice(0, 200)}`);
    rec.paypal = { state: "ok", at: now, error: "" };
    log.push({ at: now, kind: "paypal", number: rec.number, order: rec.orderName, ok: true, text: `tracking sent (${carrier})` });
  } catch (e) {
    rec.paypal = { state: "error", at: now, error: (e as Error).message.slice(0, 200) };
    log.push({ at: now, kind: "paypal", number: rec.number, order: rec.orderName, ok: false, text: rec.paypal.error });
  }
}

export async function applyOutputs(admin: Admin, s: TrkSettings, rec: TrkShipment, domain: string, log: TrkLog[]) {
  await postPaypal(admin, s, rec, log);
  if (rec.status === "pending") return;
  await postShopify(admin, s, rec, domain, log);
  await postOmnisend(s, rec, domain, log);
}

// ---------------------------------------------------------------------------
// tick

const domainCache = new Map<string, { at: number; url: string }>();
export async function storefrontDomain(shop: string, admin: Admin) {
  const hit = domainCache.get(shop);
  if (hit && Date.now() - hit.at < 6 * HOUR) return hit.url;
  const d: { shop: { primaryDomain: { url: string } } } = await gql(admin, `#graphql
    query WcTrkDomain { shop { primaryDomain { url } } }`);
  const url = d.shop.primaryDomain.url.replace(/\/$/, "");
  domainCache.set(shop, { at: Date.now(), url });
  return url;
}

const running = new Set<string>();
export const isTickRunning = (shop: string) => running.has(shop);

export async function runTick(shop: string, opts: { force?: boolean; limit?: number } = {}) {
  if (running.has(shop)) return { skipped: true };
  running.add(shop);
  try {
    return await withShop(shop, async () => {
      const s = await getTrkSettings(shop);
      if (!s.pollEnabled && !s.paypalEnabled && !opts.force) return { skipped: true };
      const pollCarrier = s.pollEnabled || !!opts.force;
      const { admin } = await unauthenticated.admin(shop);
      const log: TrkLog[] = [];
      const now = Date.now();
      const imp = await importOrders(shop, admin, s);
      const domain = await storefrontDomain(shop, admin).catch(() => "");
      const m = await loadShipments(shop);
      const due = [...m.values()]
        .filter((r) => pollCarrier && carrierConfigured(s) && isDue(s, r, now))
        .sort((a, b) => (a.lastPolledAt || "") < (b.lastPolledAt || "") ? -1 : 1)
        .slice(0, opts.limit ?? MAX_POLLS_PER_TICK);
      let changed = 0;
      let errors = 0;
      for (const rec of due) {
        const ch = await refreshOne(s, rec);
        if (rec.lastError && !/not found/i.test(rec.lastError)) errors++;
        if (ch) changed++;
        await applyOutputs(admin, s, rec, domain, log);
        await new Promise((r) => setTimeout(r, 400));
        if (errors >= 10 && errors === due.indexOf(rec) + 1) break; // keys wrong → stop early
      }
      // PayPal doesn't need carrier data: every imported shipment, ≤200 per tick
      let pp = 0;
      for (const rec of m.values()) {
        if (pp >= 200) break;
        if (!due.includes(rec) && s.paypalEnabled && (rec.paypal.state === "" || rec.paypal.state === "error")) {
          const before = rec.paypal.at;
          await postPaypal(admin, s, rec, log);
          if (rec.paypal.at !== before) pp++;
        }
      }
      await saveShipments(shop);
      await addLog(shop, [
        ...log,
        { at: new Date().toISOString(), kind: "sync", ok: errors === 0, text: `imported ${imp.added} new, checked ${due.length}, changed ${changed}, errors ${errors}` },
      ]);
      await setState(shop, { lastTickAt: new Date().toISOString(), lastError: errors ? `${errors} carrier errors` : "" });
      return { skipped: false, imported: imp.added, checked: due.length, changed, errors };
    });
  } finally {
    running.delete(shop);
  }
}

declare global {
  // eslint-disable-next-line no-var
  var wcTrkScheduler: NodeJS.Timeout | undefined;
}

async function tickAll() {
  if (process.env.WC_TRK_SCHEDULER === "off") return;
  let shops: string[] = [];
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    shops = [...new Set<string>(rows.map((r: { shop: string }) => r.shop))];
  } catch {
    return;
  }
  for (const shop of shops) {
    try {
      await runTick(shop);
    } catch (e) {
      console.warn(`[wc-trk] ${shop}:`, (e as Error).message);
      await setState(shop, { lastError: (e as Error).message.slice(0, 300) }).catch(() => {});
    }
  }
}

export function startTrkScheduler() {
  if (globalThis.wcTrkScheduler) return;
  globalThis.wcTrkScheduler = setInterval(() => void tickAll(), TICK_MS);
  setTimeout(() => void tickAll(), 90_000);
}

// ---------------------------------------------------------------------------
// analytics (ideas from Track123: Dashboard + Analytics tabs)

const dayKey = (iso: string) => (iso ? iso.slice(0, 10) : "");
const avg = (a: number[]) => (a.length ? Math.round((a.reduce((x, y) => x + y, 0) / a.length) * 10) / 10 : null);
const buckets = (a: number[]) =>
  TRK_DAY_BUCKETS.map(([label, lo, hi]) => ({ label, count: a.filter((v) => v >= lo && v < hi + 1).length }));
const days = (a: string | undefined, b: string | undefined) => {
  const x = Date.parse(a || "");
  const y = Date.parse(b || "");
  return Number.isFinite(x) && Number.isFinite(y) && y >= x ? (y - x) / DAY : null;
};

export type TrkFilter = { days: number; carrier?: string; country?: string };

export function filterShipments(list: TrkShipment[], f: TrkFilter) {
  const since = Date.now() - f.days * DAY;
  return list.filter(
    (r) =>
      Date.parse(r.shippedAt) >= since &&
      (!f.carrier || (r.lastMileCarrier || r.carrier) === f.carrier || r.carrier === f.carrier) &&
      (!f.country || r.country === f.country),
  );
}

export function computeStats(all: TrkShipment[], f: TrkFilter) {
  const rows = filterShipments(all, f);
  const byStatus = Object.fromEntries(TRK_STATUS_ORDER.map((k) => [k, 0])) as Record<TrkStatus, number>;
  const processing: number[] = [];
  const transit: number[] = [];
  const o2d: number[] = [];
  const carrier = new Map<string, { n: number; d: number[] }>();
  const lastMile = new Map<string, { n: number; d: number[] }>();
  const country = new Map<string, { n: number; d: number[]; active: number }>();
  const daily = new Map<string, Record<string, number>>();
  const now = Date.now();
  const perf = { attemptStuck: 0, outStuck: 0, noUpdates: 0 };
  const exceptions: { number: string; order: string; status: TrkStatus; lastEvent: string; at: string; country: string }[] = [];
  for (const r of rows) {
    byStatus[r.status]++;
    const p = days(r.orderCreatedAt, r.shippedAt);
    if (p != null) processing.push(p);
    const dl = r.status === "delivered" ? days(r.shippedAt, r.deliveredAt) : null;
    if (dl != null) transit.push(dl);
    const od = r.status === "delivered" ? days(r.orderCreatedAt, r.deliveredAt) : null;
    if (od != null) o2d.push(od);
    const c = carrier.get(r.carrier || "—") ?? { n: 0, d: [] };
    c.n++;
    if (dl != null) c.d.push(dl);
    carrier.set(r.carrier || "—", c);
    if (r.lastMileCarrier) {
      const l = lastMile.get(r.lastMileCarrier) ?? { n: 0, d: [] };
      l.n++;
      if (dl != null) l.d.push(dl);
      lastMile.set(r.lastMileCarrier, l);
    }
    const k = r.country || "—";
    const ct = country.get(k) ?? { n: 0, d: [], active: 0 };
    ct.n++;
    if (dl != null) ct.d.push(dl);
    if (!TRK_FINAL.includes(r.status)) ct.active++;
    country.set(k, ct);
    const dk = dayKey(r.shippedAt);
    const dd = daily.get(dk) ?? {};
    dd[r.status] = (dd[r.status] ?? 0) + 1;
    daily.set(dk, dd);
    const lastAt = Date.parse(r.events[0]?.at || r.shippedAt);
    if (r.status === "attempt_fail" && now - lastAt > 3 * DAY) perf.attemptStuck++;
    if (r.status === "out_for_delivery" && now - lastAt > 3 * DAY) perf.outStuck++;
    // only parcels the carrier was asked about (no carrier data yet ≠ stuck)
    if (r.lastPolledAt && !TRK_FINAL.includes(r.status) && now - lastAt > 14 * DAY) perf.noUpdates++;
    if (r.status === "exception" || r.status === "attempt_fail" || r.status === "returned") {
      exceptions.push({ number: r.number, order: r.orderName, status: r.status, lastEvent: r.events[0]?.text ?? "", at: r.events[0]?.at ?? "", country: r.country });
    }
  }
  const series = [...daily.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([day, v]) => ({ day, ...v }));
  const total = rows.length;
  return {
    total,
    byStatus,
    deliveryRate: total ? Math.round((byStatus.delivered / total) * 1000) / 10 : 0,
    pendingRate: total ? Math.round((byStatus.pending / total) * 1000) / 10 : 0,
    processing: { avg: avg(processing), buckets: buckets(processing) },
    transit: { avg: avg(transit), buckets: buckets(transit) },
    orderToDelivery: { avg: avg(o2d), buckets: buckets(o2d) },
    perf,
    series,
    carriers: [...carrier.entries()].map(([name, v]) => ({ name, count: v.n, avg: avg(v.d) })).sort((a, b) => b.count - a.count).slice(0, 10),
    lastMile: [...lastMile.entries()].map(([name, v]) => ({ name, count: v.n, avg: avg(v.d) })).sort((a, b) => b.count - a.count).slice(0, 10),
    countries: [...country.entries()].map(([name, v]) => ({ name, count: v.n, avg: avg(v.d), active: v.active })).sort((a, b) => b.count - a.count).slice(0, 20),
    exceptions: exceptions.sort((a, b) => (a.at < b.at ? 1 : -1)).slice(0, 100),
  };
}
export type TrkStats = ReturnType<typeof computeStats>;
