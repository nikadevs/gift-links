import { addCurrencyValues } from "./bundles-currency.server";
import { cents, readBundle, sortItems, type BundleConfig, type BundleItem } from "./bundles.shared";

type Admin = { graphql: (query: string, options?: { variables?: Record<string, unknown> }) => Promise<Response> };
type Variant = { id: string; title: string; price: string; compareAtPrice: string | null;
  media: { nodes: { image?: { url: string } }[] }; product: { id: string; title: string; shortTitle: { value: string } | null; featuredMedia: { image?: { url: string } } | null } };
type ParentVariant = { id: string; title: string; own?: { value: string } | null;
  pvc?: { nodes: { quantity: number; productVariant: { id: string } }[] } };
/**
 * What the variant includes, from our Bundles module: its settings (wc_bundles.config),
 * or — if it has none yet — the native bundle components Shopify has on the variant.
 * price: null = use the component's own price (0 = free).
 */
function componentSources(v: ParentVariant): Source[] {
  try {
    const own = v.own?.value ? JSON.parse(v.own.value) : null;
    if (own && Array.isArray(own.items) && own.items.length) return sources(own.items);
  } catch {
    // fall through to native components
  }
  return (v.pvc?.nodes || []).map(n => ({ variant_id: Number(n.productVariant.id.split("/").pop()), quantity_in_bundle: n.quantity || 1, price: null }));
}
type ParentProduct = { id: string; title: string; handle: string; config: { value: string; compareDigest: string } | null };
type ProductResponse = { shop: { currencyCode: string }; product: (ParentProduct & { variants: { nodes: ParentVariant[]; pageInfo: { hasNextPage: boolean; endCursor: string } } }) | null };
export async function listBundleProducts(admin: Admin) {
  const products: { id: string; title: string; enabled: boolean; updatedAt: string; variants: number }[] = [];
  let after: string | null = null;
  do {
    const data: { products: { nodes: { id: string; title: string; config: { value: string } | null }[]; pageInfo: { hasNextPage: boolean; endCursor: string } } } = await request(admin, `#graphql
      query BundleOverview($after: String) {
        products(first: 100, after: $after) {
          nodes { id title config: metafield(namespace: "custom", key: "wc_bundle_contents") { value } }
          pageInfo { hasNextPage endCursor }
        }
      }`, { after });
    for (const product of data.products.nodes) {
      const config = readBundle(product.config?.value);
      if (config) products.push({ id: product.id, title: product.title, enabled: config.enabled, updatedAt: config.updatedAt, variants: Object.keys(config.variants).length });
    }
    after = data.products.pageInfo.hasNextPage ? data.products.pageInfo.endCursor : null;
  } while (after);
  return products.sort((a, b) => a.title.localeCompare(b.title));
}
export const PRODUCT_QUERY = `#graphql
  query BundleProduct($id: ID!, $after: String) {
    shop { currencyCode }
    product(id: $id) {
      id title handle
      config: metafield(namespace: "custom", key: "wc_bundle_contents") { value compareDigest }
      variants(first: 100, after: $after) {
        nodes { id title own: metafield(namespace: "wc_bundles", key: "config") { value }
          pvc: productVariantComponents(first: 30) { nodes { quantity productVariant { id } } } }
        pageInfo { hasNextPage endCursor }
      }
    }
  }`;
export const COMPONENT_QUERY = `#graphql
  query BundleComponents($ids: [ID!]!) {
    nodes(ids: $ids) { ... on ProductVariant {
      id title price compareAtPrice media(first: 1) { nodes { ... on MediaImage { image { url(transform: {maxWidth: 600}) } } } }
      product { id title shortTitle: metafield(namespace: "custom", key: "short_title") { value }
        featuredMedia { ... on MediaImage { image { url(transform: {maxWidth: 600}) } } }
      }
    } }
  }`;
export const SAVE_QUERY = `#graphql
  mutation BundleSave($metafields: [MetafieldsSetInput!]!) {
    metafieldsSet(metafields: $metafields) { userErrors { field message } }
  }`;
async function request<T>(admin: Admin, query: string, variables: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, { variables });
  const json = await res.json();
  if (!res.ok || json.errors?.length) throw new Error(json.errors?.map((e: { message: string }) => e.message).join("; ") || "Shopify request failed");
  return json.data as T;
}
export async function loadBundleProduct(admin: Admin, id: string) {
  if (!/^gid:\/\/shopify\/Product\/\d+$/.test(id)) throw new Error("Choose a product first.");
  let after: string | null = null;
  let product: ParentProduct | null = null;
  let currencyCode = "";
  const variants: ParentVariant[] = [];
  do {
    const data: ProductResponse = await request<ProductResponse>(admin, PRODUCT_QUERY, { id, after });
    if (!data.product) throw new Error("Product was not found.");
    product = data.product;
    currencyCode = data.shop.currencyCode;
    variants.push(...data.product.variants.nodes);
    after = data.product.variants.pageInfo.hasNextPage ? data.product.variants.pageInfo.endCursor : null;
  } while (after);
  return { product: product!, variants, currencyCode, config: readBundle(product!.config?.value) };
}
type Source = { variant_id: number; quantity_in_bundle: number; price: number | null };
function sources(parsed: unknown): Source[] {
  if (!Array.isArray(parsed)) throw new Error("Unsupported bundle settings format.");
  return parsed.map((v) => {
    const id = Number(v.variant_id);
    if (!Number.isSafeInteger(id) || !Number.isInteger(v.quantity_in_bundle) || v.quantity_in_bundle < 1) throw new Error("Invalid bundle component in the Bundles settings; nothing was saved.");
    return { variant_id: id, quantity_in_bundle: v.quantity_in_bundle, price: Number.isFinite(Number(v.price)) ? Number(v.price) : null };
  });
}
export async function buildBundle(admin: Admin, id: string, includePaid: boolean, enabled: boolean, manualVariantIds: string[] = []) {
  const loaded = await loadBundleProduct(admin, id);
  if (manualVariantIds.length > 24 || manualVariantIds.some(v => !/^gid:\/\/shopify\/ProductVariant\/\d+$/.test(v))) throw new Error("Choose up to 24 valid component variants.");
  const manual = [...new Set(manualVariantIds)].map(id => ({ variant_id: Number(id.split("/").pop()), quantity_in_bundle: 1, price: 0 }));
  const byParent = loaded.variants.map(v => ({ id: v.id.split("/").pop()!, sources: manual.length ? manual : componentSources(v) }));
  const ids = [...new Set(byParent.flatMap(v => v.sources.map(s => `gid://shopify/ProductVariant/${s.variant_id}`)))];
  if (!ids.length) throw new Error("This product has no components in Bundles. Set them up in Bundles first, or choose included products manually.");
  const components = new Map<string, Variant>();
  for (let i = 0; i < ids.length; i += 100) {
    const data = await request<{ nodes: (Variant | null)[] }>(admin, COMPONENT_QUERY, { ids: ids.slice(i, i + 100) });
    for (const v of data.nodes) if (v) components.set(v.id, v);
  }
  const config: BundleConfig = { version: 1, enabled, includePaid, updatedAt: new Date().toISOString(), currencyCode: loaded.currencyCode, manualVariantIds, panels: [], variants: {} };
  const signatures = new Map<string, string>();
  for (const parent of byParent) {
    const items: BundleItem[] = parent.sources.flatMap(s => {
      const v = components.get(`gid://shopify/ProductVariant/${s.variant_id}`);
      if (!v) throw new Error(`Component ${s.variant_id} is missing. Nothing was saved.`);
      const free = Number(s.price ?? v.price) === 0;
      if (!manual.length && !includePaid && !free) return [];
      return [{ productId: v.product.id, variantId: v.id, title: v.product.shortTitle?.value?.trim() || v.product.title,
        image: v.product.featuredMedia?.image?.url || v.media.nodes[0]?.image?.url || "", value: cents(v.compareAtPrice), quantity: s.quantity_in_bundle, free }];
    });
    const sorted = sortItems(items);
    const signature = JSON.stringify(sorted);
    let panel = signatures.get(signature);
    if (!panel) { panel = `p${config.panels.length}`; signatures.set(signature, panel); config.panels.push({ id: panel, items: sorted }); }
    config.variants[parent.id] = panel;
  }
  if (config.panels.length > 50) throw new Error("This product has more than 50 distinct bundle layouts. Reduce the distinct component combinations.");
  await addCurrencyValues(admin, config);
  return { ...loaded, preview: config };
}
export async function saveBundle(admin: Admin, id: string, config: BundleConfig, compareDigest: string | null) {
  const value = JSON.stringify(config);
  if (new TextEncoder().encode(value).length > 60000) throw new Error("This bundle exceeds the display data limit. Reduce the number of distinct component combinations.");
  await saveFields(admin, [{ ownerId: id, namespace: "custom", key: "wc_bundle_contents", type: "json", value, compareDigest }]);
}
export async function saveFields(admin: Admin, metafields: Record<string, unknown>[]) {
  for (let i = 0; i < metafields.length; i += 25) {
    const data = await request<{ metafieldsSet: { userErrors: { message: string }[] } }>(admin, SAVE_QUERY, { metafields: metafields.slice(i, i + 25) });
    if (data.metafieldsSet.userErrors.length) throw new Error(data.metafieldsSet.userErrors.map(e => e.message).join("; "));
  }
}
