import { cents, readBundle, sortItems, type BundleConfig, type BundleItem } from "./bundles.shared";

type Admin = { graphql: (query: string, options?: { variables?: Record<string, unknown> }) => Promise<Response> };
type Variant = { id: string; title: string; price: string; compareAtPrice: string | null;
  media: { nodes: { image?: { url: string } }[] }; product: { id: string; title: string; shortTitle: { value: string } | null; featuredMedia: { image?: { url: string } } | null } };
type ParentVariant = { id: string; title: string; bundle: { value: string } | null };
type ParentProduct = { id: string; title: string; handle: string; config: { value: string; compareDigest: string } | null };
type ProductResponse = { shop: { currencyCode: string }; product: (ParentProduct & { variants: { nodes: ParentVariant[]; pageInfo: { hasNextPage: boolean; endCursor: string } } }) | null };
export const PRODUCT_QUERY = `#graphql
  query BundleProduct($id: ID!, $after: String) {
    shop { currencyCode }
    product(id: $id) {
      id title handle
      config: metafield(namespace: "custom", key: "wc_bundle_contents") { value compareDigest }
      variants(first: 100, after: $after) {
        nodes { id title bundle: metafield(namespace: "simple_bundles", key: "bundled_variants") { value } }
        pageInfo { hasNextPage endCursor }
      }
    }
  }`;
export const COMPONENT_QUERY = `#graphql
  query BundleComponents($ids: [ID!]!) {
    nodes(ids: $ids) { ... on ProductVariant {
      id title price compareAtPrice media(first: 1) { nodes { ... on MediaImage { image { url(transform: {maxWidth: 600}) } } } }
      product { id title shortTitle: metafield(namespace: "custom", key: "short_title") { value }
        featuredMedia { ... on MediaImage { image { url(transform: {maxWidth: 600}) } } }
      }
    } }
  }`;
export const SAVE_QUERY = `#graphql
  mutation BundleSave($metafields: [MetafieldsSetInput!]!) {
    metafieldsSet(metafields: $metafields) { userErrors { field message } }
  }`;
async function request<T>(admin: Admin, query: string, variables: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, { variables });
  const json = await res.json();
  if (!res.ok || json.errors?.length) throw new Error(json.errors?.map((e: { message: string }) => e.message).join("; ") || "Shopify request failed");
  return json.data as T;
}
export async function loadBundleProduct(admin: Admin, id: string) {
  if (!/^gid:\/\/shopify\/Product\/\d+$/.test(id)) throw new Error("Choose a product first.");
  let after: string | null = null;
  let product: ParentProduct | null = null;
  let currencyCode = "";
  const variants: ParentVariant[] = [];
  do {
    const data: ProductResponse = await request<ProductResponse>(admin, PRODUCT_QUERY, { id, after });
    if (!data.product) throw new Error("Product was not found.");
    product = data.product;
    currencyCode = data.shop.currencyCode;
    variants.push(...data.product.variants.nodes);
    after = data.product.variants.pageInfo.hasNextPage ? data.product.variants.pageInfo.endCursor : null;
  } while (after);
  return { product: product!, variants, currencyCode, config: readBundle(product!.config?.value) };
}
type Source = { variant_id: number; quantity_in_bundle: number; price: number };
function sources(value?: string): Source[] {
  if (!value) return [];
  const parsed = JSON.parse(value);
  if (!Array.isArray(parsed)) throw new Error("Unsupported Simple Bundles data format.");
  return parsed.map((v) => {
    if (!Number.isSafeInteger(v.variant_id) || !Number.isInteger(v.quantity_in_bundle) || v.quantity_in_bundle < 1 || !Number.isFinite(Number(v.price))) throw new Error("Invalid Simple Bundles component; nothing was saved.");
    return v as Source;
  });
}
export async function buildBundle(admin: Admin, id: string, includePaid: boolean, enabled: boolean, manualVariantIds: string[] = []) {
  const loaded = await loadBundleProduct(admin, id);
  if (manualVariantIds.length > 24 || manualVariantIds.some(v => !/^gid:\/\/shopify\/ProductVariant\/\d+$/.test(v))) throw new Error("Choose up to 24 valid component variants.");
  const manual = [...new Set(manualVariantIds)].map(id => ({ variant_id: Number(id.split("/").pop()), quantity_in_bundle: 1, price: 0 }));
  const byParent = loaded.variants.map(v => ({ id: v.id.split("/").pop()!, sources: manual.length ? manual : sources(v.bundle?.value).filter(s => includePaid || Number(s.price) === 0) }));
  const ids = [...new Set(byParent.flatMap(v => v.sources.map(s => `gid://shopify/ProductVariant/${s.variant_id}`)))];
  if (!ids.length) throw new Error("No matching Simple Bundles components. Choose a bundle product or include paid components.");
  const components = new Map<string, Variant>();
  for (let i = 0; i < ids.length; i += 100) {
    const data = await request<{ nodes: (Variant | null)[] }>(admin, COMPONENT_QUERY, { ids: ids.slice(i, i + 100) });
    for (const v of data.nodes) if (v) components.set(v.id, v);
  }
  const config: BundleConfig = { version: 1, enabled, includePaid, updatedAt: new Date().toISOString(), currencyCode: loaded.currencyCode, manualVariantIds, panels: [], variants: {} };
  const signatures = new Map<string, string>();
  for (const parent of byParent) {
    const items: BundleItem[] = parent.sources.map(s => {
      const v = components.get(`gid://shopify/ProductVariant/${s.variant_id}`);
      if (!v) throw new Error(`Component ${s.variant_id} is missing. Nothing was saved.`);
      return { productId: v.product.id, variantId: v.id, title: v.product.shortTitle?.value?.trim() || v.product.title,
        image: v.media.nodes[0]?.image?.url || v.product.featuredMedia?.image?.url || "", value: cents(v.compareAtPrice), quantity: s.quantity_in_bundle, free: Number(s.price) === 0 };
    });
    const sorted = sortItems(items);
    const signature = JSON.stringify(sorted);
    let panel = signatures.get(signature);
    if (!panel) { panel = `p${config.panels.length}`; signatures.set(signature, panel); config.panels.push({ id: panel, items: sorted }); }
    config.variants[parent.id] = panel;
  }
  if (config.panels.length > 50) throw new Error("This product has more than 50 distinct bundle layouts. Reduce the distinct component combinations.");
  return { ...loaded, preview: config };
}
export async function saveBundle(admin: Admin, id: string, config: BundleConfig, compareDigest: string | null) {
  const value = JSON.stringify(config);
  if (new TextEncoder().encode(value).length > 60000) throw new Error("This bundle exceeds the display data limit. Reduce the number of distinct component combinations.");
  await saveFields(admin, [{ ownerId: id, namespace: "custom", key: "wc_bundle_contents", type: "json", value, compareDigest }]);
}
export async function saveFields(admin: Admin, metafields: Record<string, unknown>[]) {
  for (let i = 0; i < metafields.length; i += 25) {
    const data = await request<{ metafieldsSet: { userErrors: { message: string }[] } }>(admin, SAVE_QUERY, { metafields: metafields.slice(i, i + 25) });
    if (data.metafieldsSet.userErrors.length) throw new Error(data.metafieldsSet.userErrors.map(e => e.message).join("; "));
  }
}
