import type { authenticate } from "./shopify.server";
import {
  MAX_COMPONENTS,
  OWN_KEY,
  OWN_NS,
  buildItems,
  gidVariant,
  normalizeComps,
  parseOwn,
  relationshipInput,
  itemsToComps,
  variantState,
  type Comp,
  type OwnConfig,
  type VariantInfo,
  type VariantState,
} from "./nb.shared";
import { parseGb } from "./gb.shared";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export type BundleVariant = {
  id: string;
  title: string;
  price: number;
  requiresComponents: boolean;
  own: OwnConfig | null;
  ownComps: Comp[];
  native: Comp[];
  state: VariantState;
};
export type BundleProduct = {
  id: string;
  title: string;
  handle: string;
  status: string;
  image: string | null;
  variants: BundleVariant[];
};

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  if (!json.data) throw new Error("Empty response from Shopify");
  return json.data;
}

type RawVariant = {
  id: string;
  title: string;
  price: string;
  requiresComponents: boolean;
  own: { value: string } | null;
  pvc: { nodes: { id: string }[] };
  product: { id: string; title: string; handle: string; status: string; featuredMedia: { preview: { image: { url: string } | null } | null } | null };
};

/** Every variant of the store (cheap fields only), paginated. */
async function loadAllVariants(admin: AdminGraphql): Promise<RawVariant[]> {
  const out: RawVariant[] = [];
  let after: string | null = null;
  for (let i = 0; i < 100; i++) {
    const d: {
      productVariants: { nodes: RawVariant[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } };
    } = await gql(
      admin,
      `#graphql
      query WcNbVariants($after: String) {
        productVariants(first: 100, after: $after) {
          nodes {
            id title price requiresComponents
            own: metafield(namespace: "wc_bundles", key: "config") { value }
            pvc: productVariantComponents(first: 1) { nodes { id } }
            product { id title handle status featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } } }
          }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { after },
    );
    out.push(...d.productVariants.nodes);
    if (!d.productVariants.pageInfo.hasNextPage) break;
    after = d.productVariants.pageInfo.endCursor;
  }
  return out;
}

/** Native components of the given parent variants (10 per request — query cost). */
export async function loadNativeComponents(admin: AdminGraphql, ids: string[]) {
  const map: Record<string, Comp[]> = {};
  for (let i = 0; i < ids.length; i += 10) {
    const d: {
      nodes: ({ id: string; productVariantComponents: { nodes: { quantity: number; productVariant: { id: string } }[] } } | null)[];
    } = await gql(
      admin,
      `#graphql
      query WcNbNative($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id
            productVariantComponents(first: 50) { nodes { quantity productVariant { id } } }
          }
        }
      }`,
      { ids: ids.slice(i, i + 10) },
    );
    for (const n of d.nodes) {
      if (!n?.id) continue;
      map[n.id] = n.productVariantComponents.nodes.map((c) => ({ variantId: c.productVariant.id, qty: c.quantity }));
    }
  }
  return map;
}

/** Live data of component variants (title, price, image…), 100 per request. */
export async function loadVariantInfo(admin: AdminGraphql, ids: string[]) {
  const info: Record<string, VariantInfo> = {};
  const uniq = [...new Set(ids.map(gidVariant))];
  for (let i = 0; i < uniq.length; i += 100) {
    const d: {
      nodes: ({
        id: string;
        title: string;
        price: string;
        compareAtPrice: string | null;
        sku: string | null;
        inventoryPolicy: string;
        image: { url: string } | null;
        inventoryItem: { id: string; tracked: boolean } | null;
        product: {
          id: string;
          title: string;
          handle: string;
          vendor: string;
          status: string;
          featuredMedia: { preview: { image: { url: string } | null } | null } | null;
        };
      } | null)[];
    } = await gql(
      admin,
      `#graphql
      query WcNbInfo($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id title price compareAtPrice sku inventoryPolicy
            image { url(transform: {maxWidth: 120}) }
            inventoryItem { id tracked }
            product { id title handle vendor status featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } } }
          }
        }
      }`,
      { ids: uniq.slice(i, i + 100) },
    );
    for (const n of d.nodes) {
      if (!n?.id) continue;
      info[n.id] = {
        id: n.id,
        title: n.title,
        productTitle: n.product.title,
        productId: n.product.id,
        handle: n.product.handle,
        vendor: n.product.vendor,
        price: Number(n.price) || 0,
        compareAt: n.compareAtPrice != null ? Number(n.compareAtPrice) : null,
        sku: n.sku,
        tracked: !!n.inventoryItem?.tracked,
        inventoryPolicy: n.inventoryPolicy,
        inventoryItemId: n.inventoryItem?.id ?? null,
        image: n.image?.url ?? n.product.featuredMedia?.preview?.image?.url ?? null,
        status: n.product.status,
      };
    }
  }
  return info;
}

/** All bundle variants: our settings, native components or the flag. */
export async function loadBundles(admin: AdminGraphql) {
  const all = await loadAllVariants(admin);
  // A native bundle can exist without the flag (seen 2026-10-17)
  const candidates = all.filter((v) => v.requiresComponents || v.pvc?.nodes?.length || parseOwn(v.own?.value));
  const native = await loadNativeComponents(
    admin,
    candidates.filter((v) => v.requiresComponents || v.pvc?.nodes?.length).map((v) => v.id),
  );
  const products = new Map<string, BundleProduct>();
  const compIds: string[] = [];
  for (const v of candidates) {
    const own = parseOwn(v.own?.value);
    const nat = native[v.id] || [];
    const ownComps = itemsToComps(own?.items ?? null);
    compIds.push(...ownComps.map((c) => c.variantId), ...nat.map((c) => c.variantId));
    let p = products.get(v.product.id);
    if (!p) {
      p = {
        id: v.product.id,
        title: v.product.title,
        handle: v.product.handle,
        status: v.product.status,
        image: v.product.featuredMedia?.preview?.image?.url ?? null,
        variants: [],
      };
      products.set(v.product.id, p);
    }
    p.variants.push({
      id: v.id,
      title: v.title,
      price: Number(v.price) || 0,
      requiresComponents: v.requiresComponents,
      own,
      ownComps,
      native: nat,
      state: variantState(ownComps, nat, v.requiresComponents),
    });
  }
  const info = await loadVariantInfo(admin, compIds);
  return { products: [...products.values()], info };
}

/** Variants of one product (for "Add bundle"). */
export async function loadProductVariants(admin: AdminGraphql, productId: string) {
  const d: {
    product: {
      id: string;
      title: string;
      variants: {
        nodes: { id: string; title: string; price: string; requiresComponents: boolean; own: { value: string } | null }[];
      };
    } | null;
  } = await gql(
    admin,
    `#graphql
    query WcNbProduct($id: ID!) {
      product(id: $id) {
        id title
        variants(first: 100) {
          nodes {
            id title price requiresComponents
            own: metafield(namespace: "wc_bundles", key: "config") { value }
          }
        }
      }
    }`,
    { id: productId },
  );
  return d.product;
}

async function setRequiresComponents(admin: AdminGraphql, productId: string, variantIds: string[], value: boolean) {
  if (!variantIds.length) return;
  const d: { productVariantsBulkUpdate: { userErrors: { field: string[] | null; message: string }[] } } = await gql(
    admin,
    `#graphql
    mutation WcNbFlag($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
      productVariantsBulkUpdate(productId: $productId, variants: $variants) { userErrors { field message } }
    }`,
    { productId, variants: variantIds.map((id) => ({ id, requiresComponents: value })) },
  );
  const errs = d.productVariantsBulkUpdate.userErrors;
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

async function variantPrices(admin: AdminGraphql, ids: string[]) {
  const out: Record<string, { price: string; compareAtPrice: string | null; productId: string }> = {};
  for (let i = 0; i < ids.length; i += 100) {
    const d: { nodes: ({ id: string; price: string; compareAtPrice: string | null; product: { id: string } } | null)[] } = await gql(
      admin,
      `#graphql
      query WcNbPrices($ids: [ID!]!) { nodes(ids: $ids) { ... on ProductVariant { id price compareAtPrice product { id } } } }`,
      { ids: ids.slice(i, i + 100) },
    );
    for (const n of d.nodes) if (n?.id) out[n.id] = { price: n.price, compareAtPrice: n.compareAtPrice, productId: n.product.id };
  }
  return out;
}

/**
 * Relationship changes must never change what the customer pays: read the
 * parents' prices first, apply, and put back any price Shopify changed.
 */
async function applyRelationships(admin: AdminGraphql, inputs: Record<string, unknown>[]) {
  if (!inputs.length) return;
  const ids = inputs.map((i) => String(i.parentProductVariantId));
  const before = await variantPrices(admin, ids);
  await applyRelationshipsRaw(admin, inputs);
  const after = await variantPrices(admin, ids);
  const byProduct = new Map<string, { id: string; price: string; compareAtPrice: string | null }[]>();
  for (const id of ids) {
    const b = before[id];
    const a = after[id];
    if (!b || !a || (a.price === b.price && a.compareAtPrice === b.compareAtPrice)) continue;
    const list = byProduct.get(b.productId) || [];
    list.push({ id, price: b.price, compareAtPrice: b.compareAtPrice });
    byProduct.set(b.productId, list);
  }
  for (const [productId, variants] of byProduct) {
    const d: { productVariantsBulkUpdate: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcNbPriceFix($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
        productVariantsBulkUpdate(productId: $productId, variants: $variants) { userErrors { message } }
      }`,
      { productId, variants },
    );
    const errs = d.productVariantsBulkUpdate.userErrors;
    if (errs.length) throw new Error(`Bundle saved but its price changed and could not be restored: ${errs.map((e) => e.message).join("; ")}`);
  }
}

async function applyRelationshipsRaw(admin: AdminGraphql, inputs: Record<string, unknown>[]) {
  const d: {
    productVariantRelationshipBulkUpdate: { userErrors: { code: string | null; field: string[] | null; message: string }[] };
  } = await gql(
    admin,
    `#graphql
    mutation WcNbRel($input: [ProductVariantRelationshipUpdateInput!]!) {
      productVariantRelationshipBulkUpdate(input: $input) { userErrors { code field message } }
    }`,
    { input: inputs },
  );
  const errs = d.productVariantRelationshipBulkUpdate.userErrors;
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

async function writeOwn(admin: AdminGraphql, items: { ownerId: string; value: OwnConfig | null }[]) {
  const set = items.filter((i) => i.value && i.value.items.length);
  for (let i = 0; i < set.length; i += 25) {
    const d: { metafieldsSet: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcNbOwn($metafields: [MetafieldsSetInput!]!) {
        metafieldsSet(metafields: $metafields) { userErrors { message } }
      }`,
      {
        metafields: set.slice(i, i + 25).map((x) => ({
          ownerId: x.ownerId,
          namespace: OWN_NS,
          key: OWN_KEY,
          type: "json",
          value: JSON.stringify(x.value),
        })),
      },
    );
    const errs = d.metafieldsSet.userErrors;
    if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
  }
  const clear = items.filter((i) => !i.value || !i.value.items.length);
  if (clear.length) {
    const d: { metafieldsDelete: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcNbOwnDel($metafields: [MetafieldIdentifierInput!]!) {
        metafieldsDelete(metafields: $metafields) { userErrors { message } }
      }`,
      { metafields: clear.map((x) => ({ ownerId: x.ownerId, namespace: OWN_NS, key: OWN_KEY })) },
    );
    const errs = d.metafieldsDelete.userErrors;
    if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
  }
}

const now = () => new Date().toISOString();

/**
 * Copy settings into our metafield for every variant that has none yet,
 * from the native components Shopify already has. Runs automatically when the
 * Bundles page opens. Nothing customer-visible changes.
 */
export async function importAll(admin: AdminGraphql, products: BundleProduct[]) {
  const todo = products.flatMap((p) => p.variants.filter((v) => v.state === "import"));
  if (!todo.length) return { variants: 0 };
  const info = await loadVariantInfo(
    admin,
    todo.flatMap((v) => v.native.map((c) => c.variantId)),
  );
  await writeOwn(
    admin,
    todo.map((v) => {
      return { ownerId: v.id, value: { v: 1 as const, items: buildItems(v.native, info, null), updatedAt: now() } };
    }),
  );
  return { variants: todo.length };
}

/** Turn the product's bundles on in Shopify: native components = our settings, flag on. */
export async function activateProduct(admin: AdminGraphql, product: BundleProduct) {
  // Bundles v2: a catalog product must stay a normal product (Google/Facebook/TikTok refuse fixed bundles)
  const gbData = await gql<{ currentAppInstallation: { metafield: { value: string } | null } | null }>(
    admin,
    `#graphql
    query WcNbGbGuard { currentAppInstallation { metafield(namespace: "wc_gb", key: "config") { value } } }`,
  );
  const gbProduct = parseGb(gbData.currentAppInstallation?.metafield?.value).products.find(
    (p) => p.active && `gid://shopify/Product/${p.productId}` === product.id,
  );
  if (gbProduct) {
    throw new Error("This product is on in Bundles v2 (catalog mode, gifts added in cart/order). Turn it off there first.");
  }
  const inputs: Record<string, unknown>[] = [];
  const flag: string[] = [];
  for (const v of product.variants) {
    if (!v.ownComps.length) continue;
    const { input, changed } = relationshipInput(v.id, v.native, v.ownComps);
    if (changed) inputs.push(input);
    if (!v.requiresComponents) flag.push(v.id);
  }
  if (!inputs.length && !flag.length && !product.variants.some((v) => v.ownComps.length)) {
    throw new Error("No bundle settings for this product — click Edit and add components.");
  }
  // components first, then the flag (a variant can't require components it doesn't have)
  for (let i = 0; i < inputs.length; i += 10) await applyRelationships(admin, inputs.slice(i, i + 10));
  await setRequiresComponents(admin, product.id, flag, true);
  return { variants: product.variants.filter((v) => v.ownComps.length).length };
}

/** Turn the product's bundles off in Shopify (components + flag removed). Our settings stay. */
export async function disableProduct(admin: AdminGraphql, product: BundleProduct) {
  const withNative = product.variants.filter((v) => v.native.length || v.requiresComponents);
  await setRequiresComponents(
    admin,
    product.id,
    withNative.filter((v) => v.requiresComponents).map((v) => v.id),
    false,
  );
  const inputs = withNative
    .filter((v) => v.native.length)
    .map((v) => ({ parentProductVariantId: v.id, removeAllProductVariantRelationships: true, priceInput: { calculation: "NONE" } }));
  for (let i = 0; i < inputs.length; i += 10) await applyRelationships(admin, inputs.slice(i, i + 10));
  return { variants: withNative.length };
}

/** Remove the native bundle of every variant of one product (Bundles v2 switch). Our settings stay. */
export async function disableNativeByProductId(admin: AdminGraphql, productId: string) {
  const d = await gql<{
    product: { id: string; variants: { nodes: { id: string; requiresComponents: boolean; productVariantComponents: { nodes: { quantity: number; productVariant: { id: string } }[] } }[] } } | null;
  }>(
    admin,
    `#graphql
    query WcNbDisableOne($id: ID!) {
      product(id: $id) {
        id
        variants(first: 100) { nodes { id requiresComponents productVariantComponents(first: 50) { nodes { quantity productVariant { id } } } } }
      }
    }`,
    { id: productId },
  );
  if (!d.product) throw new Error("Product not found");
  const product = {
    id: d.product.id,
    title: "",
    handle: "",
    status: "",
    image: null,
    variants: d.product.variants.nodes.map((v) => ({
      id: v.id,
      title: "",
      price: 0,
      requiresComponents: v.requiresComponents,
      own: null,
      ownComps: [],
      native: v.productVariantComponents.nodes.map((c) => ({ variantId: c.productVariant.id, qty: c.quantity })),
      state: "none" as VariantState,
    })),
  } as BundleProduct;
  return disableProduct(admin, product);
}

/** Permanently delete the parent product. Component products remain in Shopify. */
export async function deleteBundleProduct(admin: AdminGraphql, productId: string) {
  const { productDelete } = await gql<{
    productDelete: {
      deletedProductId: string | null;
      userErrors: { message: string }[];
    };
  }>(admin, `#graphql
    mutation DeleteBundleProduct($id: ID!) {
      productDelete(input: { id: $id }) {
        deletedProductId
        userErrors { message }
      }
    }
  `, { id: productId });
  if (productDelete.userErrors.length) {
    throw new Error(productDelete.userErrors.map(({ message }) => message).join("\n"));
  }
  if (productDelete.deletedProductId !== productId) {
    throw new Error("Shopify did not confirm deletion.");
  }
}

/**
 * Save one variant's components from the editor into our settings. If the
 * bundle is active in Shopify (or `activate`), Shopify is updated too.
 * Empty list = the variant stops being a bundle (settings deleted, native removed).
 */
export async function saveVariant(
  admin: AdminGraphql,
  productId: string,
  variantId: string,
  desiredRaw: Comp[],
  activate = false,
) {
  const desired = normalizeComps(desiredRaw);
  if (desired.some((c) => c.variantId === variantId)) throw new Error("A bundle can't contain itself.");
  if (desired.length > MAX_COMPONENTS) throw new Error(`Max ${MAX_COMPONENTS} components per bundle.`);
  const product = await loadProductVariants(admin, productId);
  const v = product?.variants.nodes.find((x) => x.id === variantId);
  if (!product || !v) throw new Error("Variant not found");
  const current = (await loadNativeComponents(admin, [variantId]))[variantId] || [];
  const info = desired.length ? await loadVariantInfo(admin, desired.map((c) => c.variantId)) : {};
  const missing = desired.filter((c) => !info[c.variantId]);
  if (missing.length) throw new Error(`Component variant not found: ${missing.map((c) => c.variantId).join(", ")}`);

  if (!desired.length) {
    if (v.requiresComponents) await setRequiresComponents(admin, productId, [variantId], false);
    if (current.length) {
      await applyRelationships(admin, [
        { parentProductVariantId: variantId, removeAllProductVariantRelationships: true, priceInput: { calculation: "NONE" } },
      ]);
    }
    await writeOwn(admin, [{ ownerId: variantId, value: null }]);
    return;
  }
  const prev = parseOwn(v.own?.value)?.items ?? null;
  await writeOwn(admin, [{ ownerId: variantId, value: { v: 1, items: buildItems(desired, info, prev), updatedAt: now() } }]);
  const isActive = current.length > 0 || v.requiresComponents;
  if (isActive || activate) {
    const { input, changed } = relationshipInput(variantId, current, desired);
    if (changed) await applyRelationships(admin, [input]);
    if (!v.requiresComponents) await setRequiresComponents(admin, productId, [variantId], true);
  }
}
