import type { authenticate } from "./shopify.server";
import {
  MAX_COMPONENTS,
  buildSbJson,
  isByob,
  gidVariant,
  normalizeComps,
  parseSb,
  relationshipInput,
  sbToComps,
  variantState,
  type Comp,
  type SbItem,
  type VariantInfo,
  type VariantState,
} from "./nb.shared";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export type BundleVariant = {
  id: string;
  title: string;
  price: number;
  requiresComponents: boolean;
  sb: SbItem[] | null;
  sbComps: Comp[];
  native: Comp[];
  state: VariantState;
};
export type BundleProduct = {
  id: string;
  title: string;
  handle: string;
  status: string;
  image: string | null;
  variants: BundleVariant[];
};

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  if (!json.data) throw new Error("Empty response from Shopify");
  return json.data;
}

type RawVariant = {
  id: string;
  title: string;
  price: string;
  requiresComponents: boolean;
  sb: { value: string } | null;
  product: { id: string; title: string; handle: string; status: string; featuredMedia: { preview: { image: { url: string } | null } | null } | null };
};

/** Every variant of the store (cheap fields only), paginated. */
async function loadAllVariants(admin: AdminGraphql): Promise<RawVariant[]> {
  const out: RawVariant[] = [];
  let after: string | null = null;
  for (let i = 0; i < 40; i++) {
    const d: {
      productVariants: { nodes: RawVariant[]; pageInfo: { hasNextPage: boolean; endCursor: string | null } };
    } = await gql(
      admin,
      `#graphql
      query WcNbVariants($after: String) {
        productVariants(first: 250, after: $after) {
          nodes {
            id title price requiresComponents
            sb: metafield(namespace: "simple_bundles", key: "bundled_variants") { value }
            product { id title handle status featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } } }
          }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { after },
    );
    out.push(...d.productVariants.nodes);
    if (!d.productVariants.pageInfo.hasNextPage) break;
    after = d.productVariants.pageInfo.endCursor;
  }
  return out;
}

/** Native components of the given parent variants (10 per request — query cost). */
export async function loadNativeComponents(admin: AdminGraphql, ids: string[]) {
  const map: Record<string, Comp[]> = {};
  for (let i = 0; i < ids.length; i += 10) {
    const d: {
      nodes: ({ id: string; productVariantComponents: { nodes: { quantity: number; productVariant: { id: string } }[] } } | null)[];
    } = await gql(
      admin,
      `#graphql
      query WcNbNative($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id
            productVariantComponents(first: 50) { nodes { quantity productVariant { id } } }
          }
        }
      }`,
      { ids: ids.slice(i, i + 10) },
    );
    for (const n of d.nodes) {
      if (!n?.id) continue;
      map[n.id] = n.productVariantComponents.nodes.map((c) => ({ variantId: c.productVariant.id, qty: c.quantity }));
    }
  }
  return map;
}

/** Live data of component variants (title, price, image…), 100 per request. */
export async function loadVariantInfo(admin: AdminGraphql, ids: string[]) {
  const info: Record<string, VariantInfo> = {};
  const uniq = [...new Set(ids.map(gidVariant))];
  for (let i = 0; i < uniq.length; i += 100) {
    const d: {
      nodes: ({
        id: string;
        title: string;
        price: string;
        compareAtPrice: string | null;
        sku: string | null;
        inventoryPolicy: string;
        image: { url: string } | null;
        inventoryItem: { id: string; tracked: boolean } | null;
        product: {
          id: string;
          title: string;
          handle: string;
          vendor: string;
          status: string;
          featuredMedia: { preview: { image: { url: string } | null } | null } | null;
        };
      } | null)[];
    } = await gql(
      admin,
      `#graphql
      query WcNbInfo($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id title price compareAtPrice sku inventoryPolicy
            image { url(transform: {maxWidth: 120}) }
            inventoryItem { id tracked }
            product { id title handle vendor status featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } } }
          }
        }
      }`,
      { ids: uniq.slice(i, i + 100) },
    );
    for (const n of d.nodes) {
      if (!n?.id) continue;
      info[n.id] = {
        id: n.id,
        title: n.title,
        productTitle: n.product.title,
        productId: n.product.id,
        handle: n.product.handle,
        vendor: n.product.vendor,
        price: Number(n.price) || 0,
        compareAt: n.compareAtPrice != null ? Number(n.compareAtPrice) : null,
        sku: n.sku,
        tracked: !!n.inventoryItem?.tracked,
        inventoryPolicy: n.inventoryPolicy,
        inventoryItemId: n.inventoryItem?.id ?? null,
        image: n.image?.url ?? n.product.featuredMedia?.preview?.image?.url ?? null,
        status: n.product.status,
      };
    }
  }
  return info;
}

/** All bundle products: variants with Simple Bundles data or native components. */
export async function loadBundles(admin: AdminGraphql) {
  const all = await loadAllVariants(admin);
  const candidates = all.filter((v) => v.requiresComponents || parseSb(v.sb?.value));
  // Native components exist only on variants we touched or flagged; read them for all candidates
  const native = await loadNativeComponents(
    admin,
    candidates.map((v) => v.id),
  );
  const products = new Map<string, BundleProduct>();
  const compIds: string[] = [];
  for (const v of candidates) {
    const sb = parseSb(v.sb?.value);
    const nat = native[v.id] || [];
    const sbComps = sbToComps(sb);
    compIds.push(...sbComps.map((c) => c.variantId), ...nat.map((c) => c.variantId));
    let p = products.get(v.product.id);
    if (!p) {
      p = {
        id: v.product.id,
        title: v.product.title,
        handle: v.product.handle,
        status: v.product.status,
        image: v.product.featuredMedia?.preview?.image?.url ?? null,
        variants: [],
      };
      products.set(v.product.id, p);
    }
    p.variants.push({
      id: v.id,
      title: v.title,
      price: Number(v.price) || 0,
      requiresComponents: v.requiresComponents,
      sb,
      sbComps,
      native: nat,
      state: variantState(sb, nat, v.requiresComponents),
    });
  }
  const info = await loadVariantInfo(admin, compIds);
  return { products: [...products.values()], info };
}

/** Variants of one product (for "Add bundle"): id, title, price, flags, SB data and native comps. */
export async function loadProductVariants(admin: AdminGraphql, productId: string) {
  const d: {
    product: {
      id: string;
      title: string;
      variants: { nodes: { id: string; title: string; price: string; requiresComponents: boolean; sb: { value: string } | null }[] };
    } | null;
  } = await gql(
    admin,
    `#graphql
    query WcNbProduct($id: ID!) {
      product(id: $id) {
        id title
        variants(first: 100) { nodes { id title price requiresComponents sb: metafield(namespace: "simple_bundles", key: "bundled_variants") { value } } }
      }
    }`,
    { id: productId },
  );
  return d.product;
}

async function setRequiresComponents(admin: AdminGraphql, productId: string, variantIds: string[], value: boolean) {
  if (!variantIds.length) return;
  const d: { productVariantsBulkUpdate: { userErrors: { field: string[] | null; message: string }[] } } = await gql(
    admin,
    `#graphql
    mutation WcNbFlag($productId: ID!, $variants: [ProductVariantsBulkInput!]!) {
      productVariantsBulkUpdate(productId: $productId, variants: $variants) { userErrors { field message } }
    }`,
    { productId, variants: variantIds.map((id) => ({ id, requiresComponents: value })) },
  );
  const errs = d.productVariantsBulkUpdate.userErrors;
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

async function applyRelationships(admin: AdminGraphql, inputs: Record<string, unknown>[]) {
  if (!inputs.length) return;
  const d: {
    productVariantRelationshipBulkUpdate: { userErrors: { code: string | null; field: string[] | null; message: string }[] };
  } = await gql(
    admin,
    `#graphql
    mutation WcNbRel($input: [ProductVariantRelationshipUpdateInput!]!) {
      productVariantRelationshipBulkUpdate(input: $input) { userErrors { code field message } }
    }`,
    { input: inputs },
  );
  const errs = d.productVariantRelationshipBulkUpdate.userErrors;
  if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
}

async function writeSbJson(admin: AdminGraphql, items: { ownerId: string; value: SbItem[] | null }[]) {
  const set = items.filter((i) => i.value && i.value.length);
  for (let i = 0; i < set.length; i += 25) {
    const d: { metafieldsSet: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcNbSb($metafields: [MetafieldsSetInput!]!) {
        metafieldsSet(metafields: $metafields) { userErrors { message } }
      }`,
      {
        metafields: set.slice(i, i + 25).map((x) => ({
          ownerId: x.ownerId,
          namespace: "simple_bundles",
          key: "bundled_variants",
          type: "json",
          value: JSON.stringify(x.value),
        })),
      },
    );
    const errs = d.metafieldsSet.userErrors;
    if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
  }
  const clear = items.filter((i) => !i.value || !i.value.length);
  if (clear.length) {
    const d: { metafieldsDelete: { userErrors: { message: string }[] } } = await gql(
      admin,
      `#graphql
      mutation WcNbSbDel($metafields: [MetafieldIdentifierInput!]!) {
        metafieldsDelete(metafields: $metafields) { userErrors { message } }
      }`,
      { metafields: clear.map((x) => ({ ownerId: x.ownerId, namespace: "simple_bundles", key: "bundled_variants" })) },
    );
    const errs = d.metafieldsDelete.userErrors;
    if (errs.length) throw new Error(errs.map((e) => e.message).join("; "));
  }
}

/**
 * Convert one product: every variant that has Simple Bundles components gets
 * the same components as a native Shopify bundle. BYOB (mix & match) variants
 * are skipped — a fixed bundle can't do customer-chosen components.
 */
export async function convertProduct(admin: AdminGraphql, product: BundleProduct) {
  const inputs: Record<string, unknown>[] = [];
  const flag: string[] = [];
  for (const v of product.variants) {
    if (v.state === "byob" || !v.sbComps.length) continue;
    const { input, changed } = relationshipInput(v.id, v.native, v.sbComps);
    if (changed) inputs.push(input);
    if (!v.requiresComponents) flag.push(v.id);
  }
  // components first, then the flag (a variant can't require components it doesn't have)
  for (let i = 0; i < inputs.length; i += 10) await applyRelationships(admin, inputs.slice(i, i + 10));
  await setRequiresComponents(admin, product.id, flag, true);
  return { variants: inputs.length || flag.length };
}

/** Back to Simple Bundles: remove the native components and the flag (SB data is untouched). */
export async function revertProduct(admin: AdminGraphql, product: BundleProduct) {
  const withNative = product.variants.filter((v) => v.native.length || v.requiresComponents);
  await setRequiresComponents(
    admin,
    product.id,
    withNative.filter((v) => v.requiresComponents).map((v) => v.id),
    false,
  );
  const inputs = withNative
    .filter((v) => v.native.length)
    .map((v) => ({ parentProductVariantId: v.id, removeAllProductVariantRelationships: true }));
  for (let i = 0; i < inputs.length; i += 10) await applyRelationships(admin, inputs.slice(i, i + 10));
  return { variants: withNative.length };
}

/**
 * Save one variant's components from the editor: native components + flag,
 * and the Simple Bundles JSON in the same format (Bundle Contents reads it).
 * Empty list = the variant stops being a bundle.
 */
export async function saveVariant(
  admin: AdminGraphql,
  productId: string,
  variantId: string,
  desiredRaw: Comp[],
) {
  const desired = normalizeComps(desiredRaw);
  if (desired.some((c) => c.variantId === variantId)) throw new Error("A bundle can't contain itself.");
  const product = await loadProductVariants(admin, productId);
  const v = product?.variants.nodes.find((x) => x.id === variantId);
  if (!product || !v) throw new Error("Variant not found");
  const current = (await loadNativeComponents(admin, [variantId]))[variantId] || [];
  const info = desired.length ? await loadVariantInfo(admin, desired.map((c) => c.variantId)) : {};
  const missing = desired.filter((c) => !info[c.variantId]);
  if (missing.length) throw new Error(`Component variant not found: ${missing.map((c) => c.variantId).join(", ")}`);
  if (desired.length > MAX_COMPONENTS) throw new Error(`Max ${MAX_COMPONENTS} components per bundle.`);
  if (isByob(parseSb(v.sb?.value))) throw new Error("This variant is a Simple Bundles mix & match (BYOB) bundle — not editable here.");

  if (!desired.length) {
    if (v.requiresComponents) await setRequiresComponents(admin, productId, [variantId], false);
    if (current.length) await applyRelationships(admin, [{ parentProductVariantId: variantId, removeAllProductVariantRelationships: true }]);
    await writeSbJson(admin, [{ ownerId: variantId, value: null }]);
    return;
  }
  const { input, changed } = relationshipInput(variantId, current, desired);
  if (changed) await applyRelationships(admin, [input]);
  if (!v.requiresComponents) await setRequiresComponents(admin, productId, [variantId], true);
  await writeSbJson(admin, [{ ownerId: variantId, value: buildSbJson(desired, info, parseSb(v.sb?.value)) }]);
}
