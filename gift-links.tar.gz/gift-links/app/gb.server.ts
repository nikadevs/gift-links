import fs from "node:fs/promises";
import path from "node:path";
import type { authenticate } from "./shopify.server";
import { unauthenticated } from "./shopify.server";
import prisma from "./db.server";
import {
  CATALOG_CHANNELS,
  GB_GIFT_TAG,
  GB_KEY,
  GB_NS,
  activeMap,
  guardedVariants,
  orderMissing,
  parseGb,
  type GbConfig,
  type GbGift,
  type GbProduct,
} from "./gb.shared";
import { itemsToComps, parseOwn } from "./nb.shared";
import { disableNativeByProductId } from "./nb.server";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  if (!json.data) throw new Error("Empty response from Shopify");
  return json.data;
}
const errs = (l?: { message: string }[] | null) => (l ?? []).map((e) => e.message).join("; ");
const num = (gid: string) => gid.split("/").pop() || gid;
const PGID = (n: string) => (n.startsWith("gid://") ? n : `gid://shopify/Product/${n}`);
const VGID = (n: number | string) => (String(n).startsWith("gid://") ? String(n) : `gid://shopify/ProductVariant/${n}`);

// ---------------------------------------------------------------------------
// config

export async function loadGb(admin: AdminGraphql) {
  const d = await gql<{ currentAppInstallation: { id: string; metafield: { value: string } | null } }>(
    admin,
    `#graphql
    query WcGbConfig { currentAppInstallation { id metafield(namespace: "${GB_NS}", key: "${GB_KEY}") { value } } }`,
  );
  return { installationId: d.currentAppInstallation.id, config: parseGb(d.currentAppInstallation.metafield?.value) };
}

/**
 * Gifts saved earlier point at $0 copies we made (tag wc-gb-gift). Point them
 * at the original $0 item (same product the copy was made from, same variant
 * title). Uses config.copies (source product → copy product) and, as a
 * fallback, the original title. Returns how many were repointed.
 */
export async function repointCopies(admin: AdminGraphql) {
  const { installationId, config } = await loadGb(admin);
  const all = new Set<number>();
  for (const p of config.products) for (const gs of Object.values(p.variants)) for (const g of gs) all.add(g.v);
  if (!all.size) return 0;
  type VN = { id: string; title: string; price: string; product: { id: string; title: string; tags: string[] } } | null;
  const d = await gql<{ nodes: VN[] }>(
    admin,
    `#graphql
    query WcGbGiftVars($ids: [ID!]!) { nodes(ids: $ids) { ... on ProductVariant { id title price product { id title tags } } } }`,
    { ids: [...all].map((n) => VGID(n)) },
  );
  const copyToSrc = new Map(Object.entries(config.copies).map(([src, copy]) => [String(copy), String(src)]));
  const map = new Map<number, number>();
  for (const n of d.nodes) {
    if (!n || !n.product.tags.includes(GB_GIFT_TAG)) continue;
    let srcPid = copyToSrc.get(num(n.product.id));
    if (!srcPid) {
      const base = n.product.title.replace(/\s+—\s+Gift$/, "");
      const f = await gql<{ products: { nodes: { id: string; tags: string[] }[] } }>(
        admin,
        `#graphql
        query WcGbOrig($q: String!) { products(first: 10, query: $q) { nodes { id tags } } }`,
        { q: `title:${JSON.stringify(base)}` },
      );
      srcPid = f.products.nodes.filter((x) => !x.tags.includes(GB_GIFT_TAG)).map((x) => num(x.id))[0];
    }
    if (!srcPid) continue;
    const o = await gql<{ product: { variants: { nodes: { id: string; title: string; price: string }[] } } | null }>(
      admin,
      `#graphql
      query WcGbOrigVars($id: ID!) { product(id: $id) { variants(first: 100) { nodes { id title price } } } }`,
      { id: PGID(srcPid) },
    );
    const ov = o.product?.variants.nodes.find((x) => x.title === n.title && Number(x.price) === 0);
    if (ov) map.set(Number(num(n.id)), Number(num(ov.id)));
  }
  let changed = 0;
  for (const p of config.products)
    for (const gs of Object.values(p.variants))
      for (const g of gs) {
        const clean = g.title.replace(/\s*\(\$0 copy\)\s*$/, "");
        if (clean !== g.title) {
          g.title = clean;
          changed++;
        }
        const to = map.get(g.v);
        if (to) {
          g.v = to;
          g.src = to;
          changed++;
        }
      }
  if (changed) {
    config.copies = {};
    await saveGb(admin, installationId, config);
  }
  return changed;
}

export async function saveGb(admin: AdminGraphql, installationId: string, config: GbConfig) {
  config.updatedAt = new Date().toISOString();
  // cart part is off (Roman 2026-11-17: cart/checkout show only the product; items are added to the order)
  config.sf = { on: false, m: activeMap(config), g: guardedVariants(config) };
  const d = await gql<{ metafieldsSet: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbSave($m: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $m) { userErrors { field message } } }`,
    { m: [{ ownerId: installationId, namespace: GB_NS, key: GB_KEY, type: "json", value: JSON.stringify(config) }] },
  );
  const e = errs(d.metafieldsSet.userErrors);
  if (e) throw new Error(e);
}

// ---------------------------------------------------------------------------
// product inspection

type Pub = { id: string; name: string };
async function publications(admin: AdminGraphql): Promise<Pub[]> {
  const d = await gql<{ publications: { nodes: { id: string; name: string | null }[] } }>(
    admin,
    `#graphql
    query WcGbPubs { publications(first: 30) { nodes { id name } } }`,
  );
  return d.publications.nodes.map((p) => ({ id: p.id, name: p.name || "" }));
}

export type CompRow = {
  variantId: string;
  qty: number;
  title: string;
  productId: string;
  productStatus: string;
  price: number;
  onlineStore: boolean;
  gift: boolean; // proposed as a gift (false = the main item, shipped as the product itself)
  extra: boolean; // added in Bundles v2 (not a component in the Bundles module)
  needsCopy: boolean; // priced item: added with a 100% discount
  copyVariant: number | null; // existing $0 copy variant for this component
};
export type ProductView = {
  id: string;
  title: string;
  handle: string;
  status: string;
  image: string | null;
  channels: { name: string; published: boolean }[];
  variants: {
    id: string;
    title: string;
    price: number;
    requiresComponents: boolean;
    nativeCount: number;
    source: "settings" | "native" | "none";
    comps: CompRow[];
  }[];
};

export async function inspectProduct(admin: AdminGraphql, productId: string, cfg: GbConfig): Promise<ProductView> {
  const pubs = await publications(admin);
  const shown = pubs.filter((p) => /online store/i.test(p.name) || CATALOG_CHANNELS.some((re) => re.test(p.name)));
  const pubFields = shown.map((p, i) => `p${i}: publishedOnPublication(publicationId: "${p.id}")`).join(" ");
  const d = await gql<{
    product:
      | ({
          id: string;
          title: string;
          handle: string;
          status: string;
          featuredMedia: { preview: { image: { url: string } | null } | null } | null;
          variants: {
            nodes: {
              id: string;
              title: string;
              price: string;
              requiresComponents: boolean;
              own: { value: string } | null;
              productVariantComponents: { nodes: { quantity: number; productVariant: { id: string } }[] };
            }[];
          };
        } & Record<string, unknown>)
      | null;
  }>(
    admin,
    `#graphql
    query WcGbProduct($id: ID!) {
      product(id: $id) {
        id title handle status ${pubFields}
        featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } }
        variants(first: 100) {
          nodes {
            id title price requiresComponents
            own: metafield(namespace: "wc_bundles", key: "config") { value }
            productVariantComponents(first: 30) { nodes { quantity productVariant { id } } }
          }
        }
      }
    }`,
    { id: PGID(productId) },
  );
  const p = d.product;
  if (!p) throw new Error("Product not found");

  const savedEntry = cfg.products.find((x) => x.productId === num(p.id));
  const raw = p.variants.nodes.map((v) => {
    const own = itemsToComps(parseOwn(v.own?.value)?.items ?? null);
    const native = v.productVariantComponents.nodes.map((c) => ({ variantId: c.productVariant.id, qty: c.quantity }));
    const base: { variantId: string; qty: number; extra?: boolean }[] = own.length ? own : native;
    // items added in Bundles v2 itself (any product, not a component in the Bundles module)
    const extras = (savedEntry?.variants[num(v.id)] ?? [])
      .filter((g) => !base.some((c) => num(c.variantId) === String(g.src)))
      .map((g) => ({ variantId: VGID(g.src), qty: g.q, extra: true }));
    return { v, comps: [...base, ...extras], source: (own.length ? "settings" : native.length ? "native" : "none") as "settings" | "native" | "none", nativeCount: native.length };
  });
  const compIds = [...new Set(raw.flatMap((r) => r.comps.map((c) => c.variantId)))];
  const online = pubs.find((x) => /online store/i.test(x.name));
  type CI = {
    id: string;
    title: string;
    price: string;
    product: { id: string; title: string; status: string; onlineStore?: boolean };
  };
  const info = new Map<string, CI>();
  for (let i = 0; i < compIds.length; i += 50) {
    const r = await gql<{ nodes: (CI | null)[] }>(
      admin,
      `#graphql
      query WcGbComps($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id title price
            product { id title status ${online ? `onlineStore: publishedOnPublication(publicationId: "${online.id}")` : ""} }
          }
        }
      }`,
      { ids: compIds.slice(i, i + 50) },
    );
    for (const n of r.nodes) if (n?.id) info.set(n.id, n);
  }

  const existing = cfg.products.find((x) => x.productId === num(p.id));
  const variants = raw.map(({ v, comps, source, nativeCount }) => {
    // main item = the priciest priced component (it ships as the product itself)
    let mainId = "";
    let best = 0;
    for (const c of comps) {
      if ((c as { extra?: boolean }).extra) continue;
      const pr = Number(info.get(c.variantId)?.price ?? 0);
      if (pr > best) {
        best = pr;
        mainId = c.variantId;
      }
    }
    const saved = existing?.variants[num(v.id)];
    const rows: CompRow[] = comps.map((c) => {
      const ci = info.get(c.variantId);
      const price = Number(ci?.price ?? 0);
      const status = ci?.product.status ?? "";
      const onlineStore = !!ci?.product.onlineStore;
      // Roman 2026-11-18: never create $0 copies. Draft $0 items go into orders as they are
      // (orderEditAddVariant accepts Draft variants). Only a priced item is a problem.
      const needsCopy = price > 0;
      const copyProduct = ci ? cfg.copies[num(ci.product.id)] : undefined;
      const savedGift = saved?.find((g) => g.src === Number(num(c.variantId)));
      return {
        variantId: c.variantId,
        qty: c.qty,
        title: ci ? `${ci.product.title}${ci.title && ci.title !== "Default Title" ? ` — ${ci.title}` : ""}` : c.variantId,
        productId: ci ? num(ci.product.id) : "",
        productStatus: status,
        price,
        onlineStore,
        gift: saved ? !!savedGift : c.variantId !== mainId,
        extra: !!(c as { extra?: boolean }).extra,
        needsCopy,
        copyVariant: savedGift && savedGift.v !== savedGift.src ? savedGift.v : copyProduct ? -1 : null,
      };
    });
    return {
      id: v.id,
      title: v.title,
      price: Number(v.price),
      requiresComponents: v.requiresComponents,
      nativeCount,
      source,
      comps: rows,
    };
  });
  return {
    id: p.id,
    title: p.title,
    handle: p.handle,
    status: p.status,
    image: p.featuredMedia?.preview?.image?.url ?? null,
    channels: shown.map((x, i) => ({ name: x.name, published: !!(p as Record<string, unknown>)[`p${i}`] })),
    variants,
  };
}

// ---------------------------------------------------------------------------
// prepare: gifts per variant (+ $0 copies where needed). Nothing customer-visible.

/**
 * Saves the product into Bundles v2 (switched OFF): for every variant the
 * chosen gifts; components that can't go into a cart as they are get a $0
 * copy (made once per source product, reused). `gifts` = variant id → list of
 * component variant ids chosen as gifts.
 */
export async function prepareProduct(
  admin: AdminGraphql,
  productId: string,
  chosen: Record<string, string[]>,
  extra: Record<string, { variantId: string; qty: number }[]> = {},
) {
  const { installationId, config } = await loadGb(admin);
  const view = await inspectProduct(admin, productId, config);
  const extraIds = [...new Set(Object.values(extra).flat().map((x) => x.variantId))];
  const extraInfo = new Map<string, string>();
  if (extraIds.length) {
    const r = await gql<{ nodes: ({ id: string; title: string; product: { title: string } } | null)[] }>(
      admin,
      `#graphql
      query WcGbExtra($ids: [ID!]!) { nodes(ids: $ids) { ... on ProductVariant { id title product { title } } } }`,
      { ids: extraIds.map((x) => VGID(num(x))) },
    );
    for (const n of r.nodes)
      if (n?.id) extraInfo.set(num(n.id), `${n.product.title}${n.title && n.title !== "Default Title" ? ` — ${n.title}` : ""}`);
  }
  const notes: string[] = [];
  const variants: Record<string, GbGift[]> = {};
  for (const v of view.variants) {
    const pick = new Set(chosen[v.id] || []);
    const gifts: GbGift[] = [];
    for (const c of v.comps) {
      if (!pick.has(c.variantId)) continue;
      const target = Number(num(c.variantId));
      gifts.push({ v: target, q: c.qty, src: Number(num(c.variantId)), title: c.title });
    }
    for (const x of extra[v.id] || []) {
      const id = num(x.variantId);
      if (!pick.has(x.variantId) || gifts.some((g) => String(g.v) === id) || !extraInfo.has(id)) continue;
      gifts.push({ v: Number(id), q: Math.max(1, Math.floor(x.qty || 1)), src: Number(id), title: extraInfo.get(id)! });
    }
    if (gifts.length) variants[num(v.id)] = gifts;
  }
  if (!Object.keys(variants).length) throw new Error("Choose at least one bundle item.");
  const pid = num(view.id);
  const prev = config.products.find((p) => p.productId === pid);
  const entry: GbProduct = {
    productId: pid,
    title: view.title,
    handle: view.handle,
    active: prev?.active ?? false,
    activatedAt: prev?.activatedAt ?? "",
    variants,
  };
  config.products = [...config.products.filter((p) => p.productId !== pid), entry];
  await saveGb(admin, installationId, config);
  return { notes };
}

/**
 * Switch ON: gifts start being added (cart + orders) FIRST, then the native
 * bundle is removed from the product. Returns what happened.
 */
export async function activateProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (!p) throw new Error("Save the bundle items first.");
  p.active = true;
  p.activatedAt = new Date().toISOString();
  await saveGb(admin, installationId, config);
  const r = await disableNativeByProductId(admin, PGID(p.productId));
  return { removedNative: r.variants };
}

/** Switch OFF: gifts are no longer added. The product stays a normal product. */
export async function deactivateProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (!p) return;
  p.active = false;
  await saveGb(admin, installationId, config);
}

export async function removeProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (p?.active) throw new Error("Switch it off first.");
  config.products = config.products.filter((x) => x.productId !== num(productId));
  await saveGb(admin, installationId, config);
}

/** Publish the product to Google & YouTube, Facebook & Instagram, TikTok (by channel name). */
export async function publishCatalog(admin: AdminGraphql, productId: string) {
  const pubs = (await publications(admin)).filter((p) => CATALOG_CHANNELS.some((re) => re.test(p.name)));
  if (!pubs.length) throw new Error("Google / Facebook / TikTok channels not found");
  const out: { name: string; error: string }[] = [];
  for (const p of pubs) {
    const d = await gql<{ publishablePublish: { userErrors: { message: string }[] } | null }>(
      admin,
      `#graphql
      mutation WcGbPublish($id: ID!, $input: [PublicationInput!]!) {
        publishablePublish(id: $id, input: $input) { userErrors { field message } }
      }`,
      { id: PGID(productId), input: [{ publicationId: p.id }] },
    );
    out.push({ name: p.name, error: errs(d.publishablePublish?.userErrors) });
  }
  return out;
}

// ---------------------------------------------------------------------------
// C. order backstop: every minute, add missing gifts to new orders (Order Editing, $0)

const DATA_DIR = process.env.WC_DATA_DIR || path.join(process.cwd(), "data");
const dir = (shop: string) => path.join(DATA_DIR, "gb", shop.replace(/[^a-z0-9.-]/gi, "_"));

export type GbLog = { at: string; order: string; ok: boolean; text: string };
type GbState = { done: string[]; log: GbLog[]; lastRunAt: string; lastError: string };

async function readState(shop: string): Promise<GbState> {
  try {
    const s = JSON.parse(await fs.readFile(path.join(dir(shop), "state.json"), "utf8"));
    return { done: s.done || [], log: s.log || [], lastRunAt: s.lastRunAt || "", lastError: s.lastError || "" };
  } catch {
    return { done: [], log: [], lastRunAt: "", lastError: "" };
  }
}
async function writeState(shop: string, s: GbState) {
  await fs.mkdir(dir(shop), { recursive: true });
  s.done = s.done.slice(-3000);
  s.log = s.log.slice(-200);
  const f = path.join(dir(shop), "state.json");
  await fs.writeFile(`${f}.tmp`, JSON.stringify(s));
  await fs.rename(`${f}.tmp`, f);
}
export const gbState = readState;

type OrderNode = {
  id: string;
  name: string;
  createdAt: string;
  cancelledAt: string | null;
  displayFulfillmentStatus: string;
  totalOutstandingSet?: { shopMoney: { amount: string } };
  lineItems: { nodes: { id?: string; quantity: number; currentQuantity: number; variant: { id: string } | null }[] };
};

type Missing = { variant: number; quantity: number; title: string };
type Calc = string;
const PRICE_DESC = "Bundle price";

async function editBegin(admin: AdminGraphql, orderId: string) {
  const begin = await gql<{ orderEditBegin: { calculatedOrder: { id: string } | null; userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbEditBegin($id: ID!) { orderEditBegin(id: $id) { calculatedOrder { id } userErrors { field message } } }`,
    { id: orderId },
  );
  return { calc: begin.orderEditBegin.calculatedOrder?.id ?? null, err: errs(begin.orderEditBegin.userErrors) };
}

async function editAdd(admin: AdminGraphql, calc: Calc, m: Missing) {
  const add = await gql<{
    orderEditAddVariant: {
      calculatedLineItem: { id: string; originalUnitPriceSet: { shopMoney: { amount: string } } } | null;
      userErrors: { message: string }[];
    };
  }>(
    admin,
    `#graphql
    mutation WcGbEditAdd($id: ID!, $variantId: ID!, $quantity: Int!) {
      orderEditAddVariant(id: $id, variantId: $variantId, quantity: $quantity, allowDuplicates: true) {
        calculatedLineItem { id originalUnitPriceSet { shopMoney { amount } } }
        userErrors { field message }
      }
    }`,
    { id: calc, variantId: VGID(m.variant), quantity: m.quantity },
  );
  const li = add.orderEditAddVariant.calculatedLineItem;
  return { id: li?.id ?? "", priced: !!li && Number(li.originalUnitPriceSet.shopMoney.amount) > 0, err: errs(add.orderEditAddVariant.userErrors) };
}

async function editDiscount(admin: AdminGraphql, calc: Calc, li: string, percent: number, description: string) {
  const d = await gql<{ orderEditAddLineItemDiscount: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbEditDisc($id: ID!, $li: ID!, $p: Float!, $d: String) {
      orderEditAddLineItemDiscount(id: $id, lineItemId: $li, discount: { percentValue: $p, description: $d }) {
        userErrors { field message }
      }
    }`,
    { id: calc, li, p: percent, d: description },
  );
  return errs(d.orderEditAddLineItemDiscount.userErrors);
}

/** Balance due of the edit (order currency) and the current subtotal of some added lines. */
async function editState(admin: AdminGraphql, calc: Calc, lineIds: string[] = []) {
  const r = await gql<{
    node: {
      totalOutstandingSet: { shopMoney: { amount: string }; presentmentMoney: { amount: string } };
      totalPriceSet: { presentmentMoney: { amount: string } };
      addedLineItems: { nodes: { id: string; editableSubtotalSet: { presentmentMoney: { amount: string } } }[] };
    } | null;
  }>(
    admin,
    `#graphql
    query WcGbEditChk($id: ID!) {
      node(id: $id) {
        ... on CalculatedOrder {
          totalOutstandingSet { shopMoney { amount } presentmentMoney { amount } }
          totalPriceSet { presentmentMoney { amount } }
          addedLineItems(first: 100) { nodes { id editableSubtotalSet { presentmentMoney { amount } } } }
        }
      }
    }`,
    { id: calc },
  );
  const n = r.node;
  const want = new Set(lineIds);
  const sub = (n?.addedLineItems?.nodes ?? []).filter((x) => want.has(x.id)).reduce((s, x) => s + Number(x.editableSubtotalSet.presentmentMoney.amount), 0);
  return {
    shop: Number(n?.totalOutstandingSet?.shopMoney?.amount ?? NaN),
    due: Number(n?.totalOutstandingSet?.presentmentMoney?.amount ?? NaN),
    total: Number(n?.totalPriceSet?.presentmentMoney?.amount ?? NaN),
    sub,
  };
}

async function editCommit(admin: AdminGraphql, calc: Calc, note: string) {
  const commit = await gql<{ orderEditCommit: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbEditCommit($id: ID!, $note: String) {
      orderEditCommit(id: $id, notifyCustomer: false, staffNote: $note) { order { id } userErrors { field message } }
    }`,
    { id: calc, note },
  );
  return errs(commit.orderEditCommit.userErrors);
}

/**
 * Plain mode: add the missing items; priced items get a 100% discount, so the
 * order total does not change. Never commits if the balance due would grow.
 */
async function addItemsFree(admin: AdminGraphql, o: OrderNode, missing: Missing[], at: string, why = ""): Promise<GbLog> {
  const { calc, err } = await editBegin(admin, o.id);
  if (!calc) return { at, order: o.name, ok: false, text: `orderEditBegin: ${err}` };
  const discounted: string[] = [];
  for (const m of missing) {
    const a = await editAdd(admin, calc, m);
    if (a.err) return { at, order: o.name, ok: false, text: `add ${m.title}: ${a.err}` };
    if (a.priced) {
      const de = await editDiscount(admin, calc, a.id, 100, "Bundle item");
      if (de) return { at, order: o.name, ok: false, text: `discount ${m.title}: ${de}` };
      discounted.push(m.title);
    }
  }
  const before = Number(o.totalOutstandingSet?.shopMoney.amount ?? 0);
  const after = (await editState(admin, calc)).shop;
  if (!(after <= before + 0.001))
    return { at, order: o.name, ok: false, text: `not committed: balance due would become ${after} (was ${before})` };
  const ce = await editCommit(
    admin,
    calc,
    discounted.length ? `Bundles: bundle items added (100% discount: ${discounted.join(", ")})` : "Bundles: bundle items added ($0)",
  );
  if (ce) return { at, order: o.name, ok: false, text: `commit: ${ce}` };
  return { at, order: o.name, ok: true, text: `${why}added ${missing.map((m) => `${m.quantity}× ${m.title}`).join(", ")}` };
}

/**
 * "Remove the bundle line" mode: the bundle's own line is removed and what the
 * customer paid for it moves to its priced items (the same % discount on each),
 * so the order total and the Paid status do not change. If the items cost less
 * than was paid (or anything does not add up), nothing is committed and the
 * plain mode runs instead (bundle line kept).
 */
async function addItemsRemoveParent(
  admin: AdminGraphql,
  o: OrderNode,
  free: Missing[],
  paid: Missing[],
  parentLines: string[],
  at: string,
): Promise<{ log: GbLog } | { fallback: string }> {
  const { calc, err } = await editBegin(admin, o.id);
  if (!calc) return { log: { at, order: o.name, ok: false, text: `orderEditBegin: ${err}` } };
  for (const m of free) {
    const a = await editAdd(admin, calc, m);
    if (a.err) return { fallback: `add ${m.title}: ${a.err}` };
    if (a.priced && (await editDiscount(admin, calc, a.id, 100, "Bundle item"))) return { fallback: `discount ${m.title}` };
  }
  for (const li of parentLines) {
    const r = await gql<{ orderEditSetQuantity: { userErrors: { message: string }[] } }>(
      admin,
      `#graphql
      mutation WcGbEditRemove($id: ID!, $li: ID!) {
        orderEditSetQuantity(id: $id, lineItemId: $li, quantity: 0, restock: false) { userErrors { field message } }
      }`,
      { id: calc, li },
    );
    const e = errs(r.orderEditSetQuantity.userErrors);
    if (e) return { fallback: `remove bundle line: ${e}` };
  }
  const t0 = (await editState(admin, calc)).total;
  const pricedIds: string[] = [];
  const freeInBundle: string[] = [];
  for (const m of paid) {
    const a = await editAdd(admin, calc, m);
    if (a.err) return { fallback: `add ${m.title}: ${a.err}` };
    if (a.priced) pricedIds.push(a.id);
    else freeInBundle.push(a.id);
  }
  const s1 = await editState(admin, calc, pricedIds);
  if (s1.due < -0.005) return { fallback: `items cost less than the bundle (${(-s1.due).toFixed(2)} short) — bundle line kept` };
  if (s1.due > 0.005) {
    // what the priced items really add to the total (after order-level discount codes)
    const eff = s1.total - t0;
    if (!(eff > 0)) return { fallback: "no priced items to carry the bundle price — bundle line kept" };
    // same % on every priced item; a hair more so that rounding never leaves the customer owing
    const pct = Math.min(100, (100 * s1.due) / eff + 0.0005);
    if (pct >= 100) return { fallback: "bundle price is not covered by the items — bundle line kept" };
    for (const li of pricedIds) {
      const de = await editDiscount(admin, calc, li, Math.round(pct * 10000) / 10000, PRICE_DESC);
      if (de) return { fallback: `discount: ${de}` };
    }
  }
  const s2 = await editState(admin, calc);
  // paid stays paid: the customer never owes; at most a few cents of rounding the other way
  if (!(s2.due <= 0.001 && s2.due >= -0.05)) return { fallback: `price does not add up (balance ${s2.due}) — bundle line kept` };
  const ce = await editCommit(admin, calc, "Bundles: bundle line removed, its price moved to the bundle items");
  if (ce) return { log: { at, order: o.name, ok: false, text: `commit: ${ce}` } };
  const all = [...free, ...paid];
  return { log: { at, order: o.name, ok: true, text: `bundle line removed; added ${all.map((m) => `${m.quantity}× ${m.title}`).join(", ")}` } };
}

/** Adds missing gifts to one order. Returns the log line (or null when nothing was missing). */
async function fixOrder(admin: AdminGraphql, o: OrderNode, products: GbProduct[]): Promise<GbLog | null> {
  const lines = o.lineItems.nodes.map((l) => ({ variantId: l.variant ? Number(num(l.variant.id)) : null, quantity: l.currentQuantity }));
  const missing = orderMissing(lines, products);
  if (!missing.length) return null;
  const at = new Date().toISOString();
  const rp = products.filter((p) => p.removeParent);
  if (rp.length) {
    const rpVariants = new Set(rp.flatMap((p) => Object.keys(p.variants)));
    const parentLines = o.lineItems.nodes
      .filter((l) => l.variant && rpVariants.has(num(l.variant.id)) && l.currentQuantity > 0 && l.id)
      .map((l) => `gid://shopify/CalculatedLineItem/${num(l.id!)}`);
    if (parentLines.length) {
      const paid = orderMissing(lines, rp);
      const free = orderMissing(lines, products.filter((p) => !p.removeParent));
      const r = await addItemsRemoveParent(admin, o, free, paid, parentLines, at);
      if ("log" in r) return r.log;
      return addItemsFree(admin, o, missing, at, `${r.fallback}; `);
    }
  }
  return addItemsFree(admin, o, missing, at);
}

// one job at a time per shop: the webhook and the 30-second check never edit the same order twice
const queues = new Map<string, Promise<unknown>>();
function withShop<T>(shop: string, fn: () => Promise<T>): Promise<T> {
  const prev = queues.get(shop) ?? Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  queues.set(shop, next.catch(() => {}));
  return next;
}

const ORDER_FIELDS = `id name createdAt cancelledAt displayFulfillmentStatus totalOutstandingSet { shopMoney { amount } }
  lineItems(first: 100) { nodes { id quantity currentQuantity variant { id } } }`;

/** Same rules for the webhook and the periodic check. Mutates state; returns true if items were added. */
async function handleOrder(a: AdminGraphql, o: OrderNode, active: GbProduct[], state: GbState) {
  if (state.done.includes(o.id)) return false;
  // only products switched on before this order was placed
  const products = active.filter((p) => p.activatedAt <= o.createdAt);
  if (o.cancelledAt || !products.length || !["UNFULFILLED", "PARTIALLY_FULFILLED", "ON_HOLD", "SCHEDULED"].includes(o.displayFulfillmentStatus)) {
    state.done.push(o.id);
    return false;
  }
  try {
    const r = await fixOrder(a, o, products);
    if (!r) {
      state.done.push(o.id);
      return false;
    }
    state.log.push(r);
    // a failed order stays "not done" and is retried by the periodic check, at most 5 times
    const tries = state.log.filter((l) => l.order === o.name && !l.ok).length;
    if (r.ok || tries >= 5) state.done.push(o.id);
    return r.ok;
  } catch (e) {
    state.log.push({ at: new Date().toISOString(), order: o.name, ok: false, text: (e as Error).message.slice(0, 300) });
    const tries = state.log.filter((l) => l.order === o.name && !l.ok).length;
    if (tries >= 5) state.done.push(o.id);
    return false;
  }
}

/** orders/create webhook: process this one order right away. */
export function processOrderNow(shop: string, orderId: string, admin?: AdminGraphql) {
  return withShop(shop, async () => {
    const a = admin ?? (await unauthenticated.admin(shop)).admin;
    const { config } = await loadGb(a);
    const active = config.products.filter((p) => p.active && p.activatedAt);
    if (!active.length) return { skipped: true };
    const state = await readState(shop);
    if (state.done.includes(orderId)) return { skipped: true };
    const d = await gql<{ order: OrderNode | null }>(
      a,
      `#graphql
      query WcGbOrder($id: ID!) { order(id: $id) { ${ORDER_FIELDS} } }`,
      { id: orderId },
    );
    if (!d.order) return { skipped: true };
    const added = await handleOrder(a, d.order, active, state);
    await writeState(shop, state);
    return { skipped: false, added };
  });
}

// orders/create webhook, registered per shop through the API (the server's toml is
// not synced by auto-deploy). Needs "Protected customer data" access for the app.
const hookOk = new Map<string, number>();
export type HookStatus = { ok: boolean; error: string; at: string };
const hookStatus = new Map<string, HookStatus>();
export const webhookStatus = (shop: string) => hookStatus.get(shop) ?? null;

export async function ensureOrderWebhook(shop: string, a: AdminGraphql, force = false) {
  if (!force && Date.now() - (hookOk.get(shop) ?? 0) < 6 * 3600_000) return hookStatus.get(shop);
  const base = (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, "");
  const at = new Date().toISOString();
  if (!base) {
    const st = { ok: false, error: "SHOPIFY_APP_URL not set", at };
    hookStatus.set(shop, st);
    return st;
  }
  const uri = `${base}/webhooks/orders/create`;
  try {
    const d = await gql<{ webhookSubscriptions: { nodes: { id: string; uri?: string; endpoint?: { callbackUrl?: string } }[] } }>(
      a,
      `#graphql
      query WcGbHooks { webhookSubscriptions(first: 20, topics: [ORDERS_CREATE]) { nodes { id uri } } }`,
    );
    if (!d.webhookSubscriptions.nodes.some((n) => n.uri === uri)) {
      const c = await gql<{ webhookSubscriptionCreate: { userErrors: { message: string }[] } }>(
        a,
        `#graphql
        mutation WcGbHookCreate($sub: WebhookSubscriptionInput!) {
          webhookSubscriptionCreate(topic: ORDERS_CREATE, webhookSubscription: $sub) { webhookSubscription { id } userErrors { field message } }
        }`,
        { sub: { uri, format: "JSON", includeFields: ["id", "admin_graphql_api_id"] } },
      );
      const e = errs(c.webhookSubscriptionCreate.userErrors);
      if (e) throw new Error(e);
    }
    hookOk.set(shop, Date.now());
    const st = { ok: true, error: "", at };
    hookStatus.set(shop, st);
    return st;
  } catch (e) {
    const st = { ok: false, error: (e as Error).message.slice(0, 300), at };
    hookStatus.set(shop, st);
    return st;
  }
}

/** Periodic safety net (every 30 s): every order since the earliest switch-on, max 3 days back. */
export function runGbTick(shop: string, admin?: AdminGraphql) {
  return withShop(shop, async () => {
    try {
      const a = admin ?? (await unauthenticated.admin(shop)).admin;
      const { config } = await loadGb(a);
      const active = config.products.filter((p) => p.active && p.activatedAt);
      if (!active.length) return { skipped: true, fixed: 0 };
      await ensureOrderWebhook(shop, a);
      const state = await readState(shop);
      const since = active.map((p) => p.activatedAt).sort()[0];
      const floor = new Date(Date.now() - 3 * 86400_000).toISOString();
      const from = since > floor ? since : floor;
      const d = await gql<{ orders: { nodes: OrderNode[] } }>(
        a,
        `#graphql
        query WcGbOrders($q: String!) {
          orders(first: 50, sortKey: CREATED_AT, reverse: true, query: $q) { nodes { ${ORDER_FIELDS} } }
        }`,
        { q: `created_at:>='${from}'` },
      );
      let fixed = 0;
      for (const o of d.orders.nodes.reverse()) if (await handleOrder(a, o, active, state)) fixed++;
      state.lastRunAt = new Date().toISOString();
      state.lastError = "";
      await writeState(shop, state);
      return { skipped: false, fixed };
    } catch (e) {
      const s = await readState(shop);
      s.lastRunAt = new Date().toISOString();
      s.lastError = (e as Error).message.slice(0, 300);
      await writeState(shop, s).catch(() => {});
      throw e;
    }
  });
}

declare global {
  // eslint-disable-next-line no-var
  var wcGbScheduler: NodeJS.Timeout | undefined;
}

async function tickAll() {
  if (process.env.WC_GB_SCHEDULER === "off") return;
  let shops: string[] = [];
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    shops = [...new Set<string>(rows.map((r: { shop: string }) => r.shop))];
  } catch {
    return;
  }
  for (const shop of shops) {
    try {
      const { admin } = await unauthenticated.admin(shop);
      await repointCopies(admin as unknown as AdminGraphql).catch((e) => console.warn(`[wc-gb] repoint ${shop}:`, (e as Error).message));
      await runGbTick(shop);
    } catch (e) {
      console.warn(`[wc-gb] ${shop}:`, (e as Error).message);
    }
  }
}

export function startGbScheduler() {
  if (globalThis.wcGbScheduler) return;
  globalThis.wcGbScheduler = setInterval(() => void tickAll(), 30_000);
  setTimeout(() => void tickAll(), 30_000);
}
