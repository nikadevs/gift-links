declare global {
  // eslint-disable-next-line no-var
  var wcGbRepointDbg: string | undefined;
}
import fs from "node:fs/promises";
import path from "node:path";
import type { authenticate } from "./shopify.server";
import { unauthenticated } from "./shopify.server";
import prisma from "./db.server";
import {
  CATALOG_CHANNELS,
  GB_GIFT_TAG,
  GB_KEY,
  GB_NS,
  activeMap,
  guardedVariants,
  orderMissing,
  parseGb,
  type GbConfig,
  type GbGift,
  type GbProduct,
} from "./gb.shared";
import { itemsToComps, parseOwn } from "./nb.shared";
import { disableNativeByProductId } from "./nb.server";

type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

async function gql<T>(admin: AdminGraphql, query: string, variables?: Record<string, unknown>): Promise<T> {
  const res = await admin.graphql(query, variables ? { variables } : undefined);
  const json = (await res.json()) as { data?: T; errors?: { message: string }[] };
  if (json.errors?.length) throw new Error(json.errors.map((e) => e.message).join("; "));
  if (!json.data) throw new Error("Empty response from Shopify");
  return json.data;
}
const errs = (l?: { message: string }[] | null) => (l ?? []).map((e) => e.message).join("; ");
const num = (gid: string) => gid.split("/").pop() || gid;
const PGID = (n: string) => (n.startsWith("gid://") ? n : `gid://shopify/Product/${n}`);
const VGID = (n: number | string) => (String(n).startsWith("gid://") ? String(n) : `gid://shopify/ProductVariant/${n}`);

// ---------------------------------------------------------------------------
// config

export async function loadGb(admin: AdminGraphql) {
  const d = await gql<{ currentAppInstallation: { id: string; metafield: { value: string } | null } }>(
    admin,
    `#graphql
    query WcGbConfig { currentAppInstallation { id metafield(namespace: "${GB_NS}", key: "${GB_KEY}") { value } } }`,
  );
  return { installationId: d.currentAppInstallation.id, config: parseGb(d.currentAppInstallation.metafield?.value) };
}

/**
 * Gifts saved earlier point at $0 copies we made (tag wc-gb-gift). Point them
 * at the original $0 item (same product the copy was made from, same variant
 * title). Uses config.copies (source product → copy product) and, as a
 * fallback, the original title. Returns how many were repointed.
 */
export async function repointCopies(admin: AdminGraphql) {
  const { installationId, config } = await loadGb(admin);
  const all = new Set<number>();
  for (const p of config.products) for (const gs of Object.values(p.variants)) for (const g of gs) all.add(g.v);
  if (!all.size) return 0;
  type VN = { id: string; title: string; price: string; product: { id: string; title: string; tags: string[] } } | null;
  const d = await gql<{ nodes: VN[] }>(
    admin,
    `#graphql
    query WcGbGiftVars($ids: [ID!]!) { nodes(ids: $ids) { ... on ProductVariant { id title price product { id title tags } } } }`,
    { ids: [...all].map((n) => VGID(n)) },
  );
  const copyToSrc = new Map(Object.entries(config.copies).map(([src, copy]) => [String(copy), String(src)]));
  const map = new Map<number, number>();
  for (const n of d.nodes) {
    if (!n || !n.product.tags.includes(GB_GIFT_TAG)) continue;
    let srcPid = copyToSrc.get(num(n.product.id));
    if (!srcPid) {
      const base = n.product.title.replace(/\s+—\s+Gift$/, "");
      const f = await gql<{ products: { nodes: { id: string; tags: string[] }[] } }>(
        admin,
        `#graphql
        query WcGbOrig($q: String!) { products(first: 10, query: $q) { nodes { id tags } } }`,
        { q: `title:${JSON.stringify(base)}` },
      );
      srcPid = f.products.nodes.filter((x) => !x.tags.includes(GB_GIFT_TAG)).map((x) => num(x.id))[0];
    }
    if (!srcPid) continue;
    const o = await gql<{ product: { variants: { nodes: { id: string; title: string; price: string }[] } } | null }>(
      admin,
      `#graphql
      query WcGbOrigVars($id: ID!) { product(id: $id) { variants(first: 100) { nodes { id title price } } } }`,
      { id: PGID(srcPid) },
    );
    const ov = o.product?.variants.nodes.find((x) => x.title === n.title && Number(x.price) === 0);
    if (ov) map.set(Number(num(n.id)), Number(num(ov.id)));
  }
  let changed = 0;
  for (const p of config.products)
    for (const gs of Object.values(p.variants))
      for (const g of gs) {
        const clean = g.title.replace(/\s*\(\$0 copy\)\s*$/, "");
        if (clean !== g.title) {
          g.title = clean;
          changed++;
        }
        const to = map.get(g.v);
        if (to) {
          g.v = to;
          g.src = to;
          changed++;
        }
      }
  globalThis.wcGbRepointDbg = `repointed ${changed}`;
  if (changed) {
    config.copies = {};
    await saveGb(admin, installationId, config);
  }
  return changed;
}

export async function saveGb(admin: AdminGraphql, installationId: string, config: GbConfig) {
  config.updatedAt = new Date().toISOString();
  // cart part is off (Roman 2026-11-17: cart/checkout show only the product; items are added to the order)
  config.sf = { on: false, m: activeMap(config), g: guardedVariants(config) };
  const d = await gql<{ metafieldsSet: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbSave($m: [MetafieldsSetInput!]!) { metafieldsSet(metafields: $m) { userErrors { field message } } }`,
    { m: [{ ownerId: installationId, namespace: GB_NS, key: GB_KEY, type: "json", value: JSON.stringify(config) }] },
  );
  const e = errs(d.metafieldsSet.userErrors);
  if (e) throw new Error(e);
}

// ---------------------------------------------------------------------------
// product inspection

type Pub = { id: string; name: string };
async function publications(admin: AdminGraphql): Promise<Pub[]> {
  const d = await gql<{ publications: { nodes: { id: string; name: string | null }[] } }>(
    admin,
    `#graphql
    query WcGbPubs { publications(first: 30) { nodes { id name } } }`,
  );
  return d.publications.nodes.map((p) => ({ id: p.id, name: p.name || "" }));
}

export type CompRow = {
  variantId: string;
  qty: number;
  title: string;
  productId: string;
  productStatus: string;
  price: number;
  onlineStore: boolean;
  gift: boolean; // proposed as a gift (false = the main item, shipped as the product itself)
  needsCopy: boolean; // Draft / not on the Online Store / not $0
  copyVariant: number | null; // existing $0 copy variant for this component
};
export type ProductView = {
  id: string;
  title: string;
  handle: string;
  status: string;
  image: string | null;
  channels: { name: string; published: boolean }[];
  variants: {
    id: string;
    title: string;
    price: number;
    requiresComponents: boolean;
    nativeCount: number;
    source: "settings" | "native" | "none";
    comps: CompRow[];
  }[];
};

export async function inspectProduct(admin: AdminGraphql, productId: string, cfg: GbConfig): Promise<ProductView> {
  const pubs = await publications(admin);
  const shown = pubs.filter((p) => /online store/i.test(p.name) || CATALOG_CHANNELS.some((re) => re.test(p.name)));
  const pubFields = shown.map((p, i) => `p${i}: publishedOnPublication(publicationId: "${p.id}")`).join(" ");
  const d = await gql<{
    product:
      | ({
          id: string;
          title: string;
          handle: string;
          status: string;
          featuredMedia: { preview: { image: { url: string } | null } | null } | null;
          variants: {
            nodes: {
              id: string;
              title: string;
              price: string;
              requiresComponents: boolean;
              own: { value: string } | null;
              productVariantComponents: { nodes: { quantity: number; productVariant: { id: string } }[] };
            }[];
          };
        } & Record<string, unknown>)
      | null;
  }>(
    admin,
    `#graphql
    query WcGbProduct($id: ID!) {
      product(id: $id) {
        id title handle status ${pubFields}
        featuredMedia { preview { image { url(transform: {maxWidth: 120}) } } }
        variants(first: 100) {
          nodes {
            id title price requiresComponents
            own: metafield(namespace: "wc_bundles", key: "config") { value }
            productVariantComponents(first: 30) { nodes { quantity productVariant { id } } }
          }
        }
      }
    }`,
    { id: PGID(productId) },
  );
  const p = d.product;
  if (!p) throw new Error("Product not found");

  const raw = p.variants.nodes.map((v) => {
    const own = itemsToComps(parseOwn(v.own?.value)?.items ?? null);
    const native = v.productVariantComponents.nodes.map((c) => ({ variantId: c.productVariant.id, qty: c.quantity }));
    return { v, comps: own.length ? own : native, source: (own.length ? "settings" : native.length ? "native" : "none") as "settings" | "native" | "none", nativeCount: native.length };
  });
  const compIds = [...new Set(raw.flatMap((r) => r.comps.map((c) => c.variantId)))];
  const online = pubs.find((x) => /online store/i.test(x.name));
  type CI = {
    id: string;
    title: string;
    price: string;
    product: { id: string; title: string; status: string; onlineStore?: boolean };
  };
  const info = new Map<string, CI>();
  for (let i = 0; i < compIds.length; i += 50) {
    const r = await gql<{ nodes: (CI | null)[] }>(
      admin,
      `#graphql
      query WcGbComps($ids: [ID!]!) {
        nodes(ids: $ids) {
          ... on ProductVariant {
            id title price
            product { id title status ${online ? `onlineStore: publishedOnPublication(publicationId: "${online.id}")` : ""} }
          }
        }
      }`,
      { ids: compIds.slice(i, i + 50) },
    );
    for (const n of r.nodes) if (n?.id) info.set(n.id, n);
  }

  const existing = cfg.products.find((x) => x.productId === num(p.id));
  const variants = raw.map(({ v, comps, source, nativeCount }) => {
    // main item = the priciest priced component (it ships as the product itself)
    let mainId = "";
    let best = 0;
    for (const c of comps) {
      const pr = Number(info.get(c.variantId)?.price ?? 0);
      if (pr > best) {
        best = pr;
        mainId = c.variantId;
      }
    }
    const saved = existing?.variants[num(v.id)];
    const rows: CompRow[] = comps.map((c) => {
      const ci = info.get(c.variantId);
      const price = Number(ci?.price ?? 0);
      const status = ci?.product.status ?? "";
      const onlineStore = !!ci?.product.onlineStore;
      // Roman 2026-11-18: never create $0 copies. Draft $0 items go into orders as they are
      // (orderEditAddVariant accepts Draft variants). Only a priced item is a problem.
      const needsCopy = price > 0;
      const copyProduct = ci ? cfg.copies[num(ci.product.id)] : undefined;
      const savedGift = saved?.find((g) => g.src === Number(num(c.variantId)));
      return {
        variantId: c.variantId,
        qty: c.qty,
        title: ci ? `${ci.product.title}${ci.title && ci.title !== "Default Title" ? ` — ${ci.title}` : ""}` : c.variantId,
        productId: ci ? num(ci.product.id) : "",
        productStatus: status,
        price,
        onlineStore,
        gift: saved ? !!savedGift : c.variantId !== mainId,
        needsCopy,
        copyVariant: savedGift && savedGift.v !== savedGift.src ? savedGift.v : copyProduct ? -1 : null,
      };
    });
    return {
      id: v.id,
      title: v.title,
      price: Number(v.price),
      requiresComponents: v.requiresComponents,
      nativeCount,
      source,
      comps: rows,
    };
  });
  return {
    id: p.id,
    title: p.title,
    handle: p.handle,
    status: p.status,
    image: p.featuredMedia?.preview?.image?.url ?? null,
    channels: shown.map((x, i) => ({ name: x.name, published: !!(p as Record<string, unknown>)[`p${i}`] })),
    variants,
  };
}

// ---------------------------------------------------------------------------
// prepare: gifts per variant (+ $0 copies where needed). Nothing customer-visible.

/**
 * Saves the product into Bundles v2 (switched OFF): for every variant the
 * chosen gifts; components that can't go into a cart as they are get a $0
 * copy (made once per source product, reused). `gifts` = variant id → list of
 * component variant ids chosen as gifts.
 */
export async function prepareProduct(admin: AdminGraphql, productId: string, chosen: Record<string, string[]>) {
  const { installationId, config } = await loadGb(admin);
  const view = await inspectProduct(admin, productId, config);
  const notes: string[] = [];
  const variants: Record<string, GbGift[]> = {};
  for (const v of view.variants) {
    const pick = new Set(chosen[v.id] || []);
    const gifts: GbGift[] = [];
    for (const c of v.comps) {
      if (!pick.has(c.variantId)) continue;
      const target = Number(num(c.variantId));
      if (c.needsCopy) {
        throw new Error(
          `"${c.title}" costs $${c.price.toFixed(2)} and would be charged. Use its $0 version in the Bundles module (no copies are created).`,
        );
      }
      gifts.push({ v: target, q: c.qty, src: Number(num(c.variantId)), title: c.title });
    }
    if (gifts.length) variants[num(v.id)] = gifts;
  }
  if (!Object.keys(variants).length) throw new Error("Choose at least one bundle item.");
  const pid = num(view.id);
  const prev = config.products.find((p) => p.productId === pid);
  const entry: GbProduct = {
    productId: pid,
    title: view.title,
    handle: view.handle,
    active: prev?.active ?? false,
    activatedAt: prev?.activatedAt ?? "",
    variants,
  };
  config.products = [...config.products.filter((p) => p.productId !== pid), entry];
  await saveGb(admin, installationId, config);
  return { notes };
}

/**
 * Switch ON: gifts start being added (cart + orders) FIRST, then the native
 * bundle is removed from the product. Returns what happened.
 */
export async function activateProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (!p) throw new Error("Save the bundle items first.");
  p.active = true;
  p.activatedAt = new Date().toISOString();
  await saveGb(admin, installationId, config);
  const r = await disableNativeByProductId(admin, PGID(p.productId));
  return { removedNative: r.variants };
}

/** Switch OFF: gifts are no longer added. The product stays a normal product. */
export async function deactivateProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (!p) return;
  p.active = false;
  await saveGb(admin, installationId, config);
}

export async function removeProduct(admin: AdminGraphql, productId: string) {
  const { installationId, config } = await loadGb(admin);
  const p = config.products.find((x) => x.productId === num(productId));
  if (p?.active) throw new Error("Switch it off first.");
  config.products = config.products.filter((x) => x.productId !== num(productId));
  await saveGb(admin, installationId, config);
}

/** Publish the product to Google & YouTube, Facebook & Instagram, TikTok (by channel name). */
export async function publishCatalog(admin: AdminGraphql, productId: string) {
  const pubs = (await publications(admin)).filter((p) => CATALOG_CHANNELS.some((re) => re.test(p.name)));
  if (!pubs.length) throw new Error("Google / Facebook / TikTok channels not found");
  const out: { name: string; error: string }[] = [];
  for (const p of pubs) {
    const d = await gql<{ publishablePublish: { userErrors: { message: string }[] } | null }>(
      admin,
      `#graphql
      mutation WcGbPublish($id: ID!, $input: [PublicationInput!]!) {
        publishablePublish(id: $id, input: $input) { userErrors { field message } }
      }`,
      { id: PGID(productId), input: [{ publicationId: p.id }] },
    );
    out.push({ name: p.name, error: errs(d.publishablePublish?.userErrors) });
  }
  return out;
}

// ---------------------------------------------------------------------------
// C. order backstop: every minute, add missing gifts to new orders (Order Editing, $0)

const DATA_DIR = process.env.WC_DATA_DIR || path.join(process.cwd(), "data");
const dir = (shop: string) => path.join(DATA_DIR, "gb", shop.replace(/[^a-z0-9.-]/gi, "_"));

export type GbLog = { at: string; order: string; ok: boolean; text: string };
type GbState = { done: string[]; log: GbLog[]; lastRunAt: string; lastError: string };

async function readState(shop: string): Promise<GbState> {
  try {
    const s = JSON.parse(await fs.readFile(path.join(dir(shop), "state.json"), "utf8"));
    return { done: s.done || [], log: s.log || [], lastRunAt: s.lastRunAt || "", lastError: s.lastError || "" };
  } catch {
    return { done: [], log: [], lastRunAt: "", lastError: "" };
  }
}
async function writeState(shop: string, s: GbState) {
  await fs.mkdir(dir(shop), { recursive: true });
  s.done = s.done.slice(-3000);
  s.log = s.log.slice(-200);
  const f = path.join(dir(shop), "state.json");
  await fs.writeFile(`${f}.tmp`, JSON.stringify(s));
  await fs.rename(`${f}.tmp`, f);
}
export const gbState = readState;

type OrderNode = {
  id: string;
  name: string;
  createdAt: string;
  cancelledAt: string | null;
  displayFulfillmentStatus: string;
  lineItems: { nodes: { quantity: number; currentQuantity: number; variant: { id: string } | null }[] };
};

/** Adds missing gifts to one order. Returns the log line (or null when nothing was missing). */
async function fixOrder(admin: AdminGraphql, o: OrderNode, products: GbProduct[]): Promise<GbLog | null> {
  const lines = o.lineItems.nodes.map((l) => ({ variantId: l.variant ? Number(num(l.variant.id)) : null, quantity: l.currentQuantity }));
  const missing = orderMissing(lines, products);
  if (!missing.length) return null;
  const at = new Date().toISOString();
  const begin = await gql<{
    orderEditBegin: { calculatedOrder: { id: string } | null; userErrors: { message: string }[] };
  }>(
    admin,
    `#graphql
    mutation WcGbEditBegin($id: ID!) { orderEditBegin(id: $id) { calculatedOrder { id } userErrors { field message } } }`,
    { id: o.id },
  );
  const calc = begin.orderEditBegin.calculatedOrder?.id;
  if (!calc) return { at, order: o.name, ok: false, text: `orderEditBegin: ${errs(begin.orderEditBegin.userErrors)}` };
  for (const m of missing) {
    const add = await gql<{ orderEditAddVariant: { userErrors: { message: string }[] } }>(
      admin,
      `#graphql
      mutation WcGbEditAdd($id: ID!, $variantId: ID!, $quantity: Int!) {
        orderEditAddVariant(id: $id, variantId: $variantId, quantity: $quantity, allowDuplicates: true) { userErrors { field message } }
      }`,
      { id: calc, variantId: VGID(m.variant), quantity: m.quantity },
    );
    const e = errs(add.orderEditAddVariant.userErrors);
    if (e) return { at, order: o.name, ok: false, text: `add ${m.title}: ${e}` };
  }
  const commit = await gql<{ orderEditCommit: { userErrors: { message: string }[] } }>(
    admin,
    `#graphql
    mutation WcGbEditCommit($id: ID!, $note: String) {
      orderEditCommit(id: $id, notifyCustomer: false, staffNote: $note) { order { id } userErrors { field message } }
    }`,
    { id: calc, note: "Bundles v2: bundle items added ($0)" },
  );
  const ce = errs(commit.orderEditCommit.userErrors);
  if (ce) return { at, order: o.name, ok: false, text: `commit: ${ce}` };
  return { at, order: o.name, ok: true, text: `added ${missing.map((m) => `${m.quantity}× ${m.title}`).join(", ")}` };
}

// one job at a time per shop: the webhook and the 30-second check never edit the same order twice
const queues = new Map<string, Promise<unknown>>();
function withShop<T>(shop: string, fn: () => Promise<T>): Promise<T> {
  const prev = queues.get(shop) ?? Promise.resolve();
  const next = prev.catch(() => {}).then(fn);
  queues.set(shop, next.catch(() => {}));
  return next;
}

const ORDER_FIELDS = `id name createdAt cancelledAt displayFulfillmentStatus
  lineItems(first: 100) { nodes { quantity currentQuantity variant { id } } }`;

/** Same rules for the webhook and the periodic check. Mutates state; returns true if items were added. */
async function handleOrder(a: AdminGraphql, o: OrderNode, active: GbProduct[], state: GbState) {
  if (state.done.includes(o.id)) return false;
  // only products switched on before this order was placed
  const products = active.filter((p) => p.activatedAt <= o.createdAt);
  if (o.cancelledAt || !products.length || !["UNFULFILLED", "PARTIALLY_FULFILLED", "ON_HOLD", "SCHEDULED"].includes(o.displayFulfillmentStatus)) {
    state.done.push(o.id);
    return false;
  }
  try {
    const r = await fixOrder(a, o, products);
    if (!r) {
      state.done.push(o.id);
      return false;
    }
    state.log.push(r);
    // a failed order stays "not done" and is retried by the periodic check, at most 5 times
    const tries = state.log.filter((l) => l.order === o.name && !l.ok).length;
    if (r.ok || tries >= 5) state.done.push(o.id);
    return r.ok;
  } catch (e) {
    state.log.push({ at: new Date().toISOString(), order: o.name, ok: false, text: (e as Error).message.slice(0, 300) });
    const tries = state.log.filter((l) => l.order === o.name && !l.ok).length;
    if (tries >= 5) state.done.push(o.id);
    return false;
  }
}

/** orders/create webhook: process this one order right away. */
export function processOrderNow(shop: string, orderId: string, admin?: AdminGraphql) {
  return withShop(shop, async () => {
    const a = admin ?? (await unauthenticated.admin(shop)).admin;
    const { config } = await loadGb(a);
    const active = config.products.filter((p) => p.active && p.activatedAt);
    if (!active.length) return { skipped: true };
    const state = await readState(shop);
    if (state.done.includes(orderId)) return { skipped: true };
    const d = await gql<{ order: OrderNode | null }>(
      a,
      `#graphql
      query WcGbOrder($id: ID!) { order(id: $id) { ${ORDER_FIELDS} } }`,
      { id: orderId },
    );
    if (!d.order) return { skipped: true };
    const added = await handleOrder(a, d.order, active, state);
    await writeState(shop, state);
    return { skipped: false, added };
  });
}

// orders/create webhook, registered per shop through the API (the server's toml is
// not synced by auto-deploy). Needs "Protected customer data" access for the app.
const hookOk = new Map<string, number>();
export type HookStatus = { ok: boolean; error: string; at: string };
const hookStatus = new Map<string, HookStatus>();
export const webhookStatus = (shop: string) => hookStatus.get(shop) ?? null;

export async function ensureOrderWebhook(shop: string, a: AdminGraphql, force = false) {
  if (!force && Date.now() - (hookOk.get(shop) ?? 0) < 6 * 3600_000) return hookStatus.get(shop);
  const base = (process.env.SHOPIFY_APP_URL || "").replace(/\/$/, "");
  const at = new Date().toISOString();
  if (!base) {
    const st = { ok: false, error: "SHOPIFY_APP_URL not set", at };
    hookStatus.set(shop, st);
    return st;
  }
  const uri = `${base}/webhooks/orders/create`;
  try {
    const d = await gql<{ webhookSubscriptions: { nodes: { id: string; uri?: string; endpoint?: { callbackUrl?: string } }[] } }>(
      a,
      `#graphql
      query WcGbHooks { webhookSubscriptions(first: 20, topics: [ORDERS_CREATE]) { nodes { id uri } } }`,
    );
    if (!d.webhookSubscriptions.nodes.some((n) => n.uri === uri)) {
      const c = await gql<{ webhookSubscriptionCreate: { userErrors: { message: string }[] } }>(
        a,
        `#graphql
        mutation WcGbHookCreate($sub: WebhookSubscriptionInput!) {
          webhookSubscriptionCreate(topic: ORDERS_CREATE, webhookSubscription: $sub) { webhookSubscription { id } userErrors { field message } }
        }`,
        { sub: { uri, format: "JSON", includeFields: ["id", "admin_graphql_api_id"] } },
      );
      const e = errs(c.webhookSubscriptionCreate.userErrors);
      if (e) throw new Error(e);
    }
    hookOk.set(shop, Date.now());
    const st = { ok: true, error: "", at };
    hookStatus.set(shop, st);
    return st;
  } catch (e) {
    const st = { ok: false, error: (e as Error).message.slice(0, 300), at };
    hookStatus.set(shop, st);
    return st;
  }
}

/** Periodic safety net (every 30 s): every order since the earliest switch-on, max 3 days back. */
export function runGbTick(shop: string, admin?: AdminGraphql) {
  return withShop(shop, async () => {
    try {
      const a = admin ?? (await unauthenticated.admin(shop)).admin;
      const { config } = await loadGb(a);
      const active = config.products.filter((p) => p.active && p.activatedAt);
      if (!active.length) return { skipped: true, fixed: 0 };
      await ensureOrderWebhook(shop, a);
      const state = await readState(shop);
      const since = active.map((p) => p.activatedAt).sort()[0];
      const floor = new Date(Date.now() - 3 * 86400_000).toISOString();
      const from = since > floor ? since : floor;
      const d = await gql<{ orders: { nodes: OrderNode[] } }>(
        a,
        `#graphql
        query WcGbOrders($q: String!) {
          orders(first: 50, sortKey: CREATED_AT, reverse: true, query: $q) { nodes { ${ORDER_FIELDS} } }
        }`,
        { q: `created_at:>='${from}'` },
      );
      let fixed = 0;
      for (const o of d.orders.nodes.reverse()) if (await handleOrder(a, o, active, state)) fixed++;
      state.lastRunAt = new Date().toISOString();
      state.lastError = "";
      await writeState(shop, state);
      return { skipped: false, fixed };
    } catch (e) {
      const s = await readState(shop);
      s.lastRunAt = new Date().toISOString();
      s.lastError = (e as Error).message.slice(0, 300);
      await writeState(shop, s).catch(() => {});
      throw e;
    }
  });
}

declare global {
  // eslint-disable-next-line no-var
  var wcGbScheduler: NodeJS.Timeout | undefined;
}

async function tickAll() {
  if (process.env.WC_GB_SCHEDULER === "off") return;
  let shops: string[] = [];
  try {
    const rows = await prisma.session.findMany({ where: { isOnline: false }, select: { shop: true } });
    shops = [...new Set<string>(rows.map((r: { shop: string }) => r.shop))];
  } catch {
    return;
  }
  for (const shop of shops) {
    try {
      const { admin } = await unauthenticated.admin(shop);
      await repointCopies(admin as unknown as AdminGraphql).catch((e) => console.warn(`[wc-gb] repoint ${shop}:`, (e as Error).message));
      await runGbTick(shop);
    } catch (e) {
      console.warn(`[wc-gb] ${shop}:`, (e as Error).message);
    }
  }
}

export function startGbScheduler() {
  if (globalThis.wcGbScheduler) return;
  globalThis.wcGbScheduler = setInterval(() => void tickAll(), 30_000);
  setTimeout(() => void tickAll(), 30_000);
}
