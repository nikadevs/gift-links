import type { authenticate } from "./shopify.server";

/**
 * Best Sellers Protection (replacement for Vitals «Best Sellers Protection»).
 * One app-owned JSON metafield on the AppInstallation (wc_bsp.config = {enabled});
 * the Gift Links app embed (blocks/gift-links.liquid) prints the code only when
 * it is enabled. No separate app embed (Roman's rule).
 */
type AdminGraphql = Awaited<ReturnType<typeof authenticate.admin>>["admin"];

export type BspConfig = { version: 1; enabled: boolean; updatedAt: string };
export type BestSellingCollection = { id: string; title: string; handle: string };

export async function loadBspConfig(admin: AdminGraphql) {
  const res = await admin.graphql(
    `#graphql
    query WcBspConfig {
      currentAppInstallation {
        id
        metafield(namespace: "wc_bsp", key: "config") { value }
      }
    }`,
  );
  const json = (await res.json()) as {
    data?: { currentAppInstallation?: { id: string; metafield?: { value?: string | null } | null } };
  };
  const inst = json.data?.currentAppInstallation;
  const config: BspConfig = { version: 1, enabled: false, updatedAt: "" };
  try {
    const p = JSON.parse(inst?.metafield?.value || "{}");
    if (typeof p?.enabled === "boolean") config.enabled = p.enabled;
    if (typeof p?.updatedAt === "string") config.updatedAt = p.updatedAt;
  } catch {
    // corrupted value — treat as off
  }
  return { installationId: inst?.id ?? "", config };
}

export async function saveBspConfig(admin: AdminGraphql, installationId: string, config: BspConfig) {
  const res = await admin.graphql(
    `#graphql
    mutation WcBspSave($metafields: [MetafieldsSetInput!]!) {
      metafieldsSet(metafields: $metafields) { userErrors { field message } }
    }`,
    {
      variables: {
        metafields: [
          { ownerId: installationId, namespace: "wc_bsp", key: "config", type: "json", value: JSON.stringify(config) },
        ],
      },
    },
  );
  const json = (await res.json()) as { data?: { metafieldsSet?: { userErrors: { message: string }[] } } };
  const errors = json.data?.metafieldsSet?.userErrors ?? [];
  if (errors.length) throw new Error(errors.map((e) => e.message).join("; "));
}

/**
 * Collections whose DEFAULT sort is "Best selling": without ?sort_by their
 * page already lists products by sales, so hiding the option can't help there.
 */
export async function loadBestSellingCollections(admin: AdminGraphql): Promise<BestSellingCollection[]> {
  const out: BestSellingCollection[] = [];
  let after: string | null = null;
  for (let i = 0; i < 10; i++) {
    const res = await admin.graphql(
      `#graphql
      query WcBspCollections($after: String) {
        collections(first: 250, after: $after) {
          nodes { id title handle sortOrder }
          pageInfo { hasNextPage endCursor }
        }
      }`,
      { variables: { after } },
    );
    const json = (await res.json()) as {
      data?: {
        collections?: {
          nodes: { id: string; title: string; handle: string; sortOrder: string }[];
          pageInfo: { hasNextPage: boolean; endCursor: string | null };
        };
      };
    };
    const c = json.data?.collections;
    if (!c) break;
    for (const n of c.nodes) {
      if (n.sortOrder === "BEST_SELLING") out.push({ id: n.id, title: n.title, handle: n.handle });
    }
    if (!c.pageInfo.hasNextPage) break;
    after = c.pageInfo.endCursor;
  }
  return out;
}
