import puppeteer from 'puppeteer-core';
import chromium from '@sparticuz/chromium';

// One disposable browser, only the public brand page. No account cookies,
// challenge solving or browser fingerprints are supplied.
const browser = await puppeteer.launch({
  executablePath: await chromium.executablePath(),
  args: chromium.args,
  headless: 'shell',
  timeout: 30000,
});
try {
  const page = await browser.newPage();
  await page.goto('https://www.trustpilot.com/review/woodencrew.store?stars=5&sort=recency', { waitUntil: 'domcontentloaded', timeout: 30000 });
  try { await page.waitForSelector('script#__NEXT_DATA__', { timeout: 30000 }); }
  catch { throw new Error(`Server browser cannot read Trustpilot: ${await page.title()}`); }
  process.stdout.write(await page.content());
} finally { await browser.close(); }
